%% 问题五 MATLAB 完整包统一入口
% 运行本文件即可依次完成：
%   1. 严格三导弹同步遮蔽复核；
%   2. 表7与结果数据导出；
%   3. 图22—图25生成；
%   4. 判定公式与最终结果显示。

clear; clc;
packageFolder = fileparts(mfilename('fullpath'));
if isempty(packageFolder), packageFolder = pwd; end

run(fullfile(packageFolder,'problem5.m'));
% problem5.m 内部含 clear，因此返回后重新取得包目录。
packageFolder = fileparts(mfilename('fullpath'));
run(fullfile(packageFolder,'show_problem5_results.m'));

fprintf('\n问题五全部计算、表格和图片均已生成。\n');
fprintf('输出目录：%s\n',packageFolder);
