%% 问题五严格同步判据公式与计算结果显示
% 本文件读取 problem5.m 保存的数据，显示论文可用的判定公式与最终数值。

resultFolder = fileparts(mfilename('fullpath'));
if isempty(resultFolder), resultFolder = pwd; end
dataFile = fullfile(resultFolder,'problem5_sync_result.mat');
assert(isfile(dataFile),'未找到 problem5_sync_result.mat，请先运行 problem5.m。');
S = load(dataFile);
[DO_PLOT,BT_IMG_DIR] = btInit();

% 离散判定公式：只有三枚导弹在同一采样时刻全部满足完全遮蔽，该时刻才计时。
% I_sync(t_k) = I_1(t_k) AND I_2(t_k) AND I_3(t_k)
% T_sync = dt * SUM_k I_sync(t_k)
syncCheck = all(S.missileCovered,2);
displayDuration = sum(syncCheck)*mean(diff(S.t));
assert(abs(displayDuration-S.syncDuration)<1e-9,'显示公式与主程序结果不一致。');

fprintf('\n============================================================\n');
fprintf('            问题五严格同步遮蔽结果显示\n');
fprintf('============================================================\n');
fprintf('离散判定公式：\n');
fprintf('I_sync(t_k) = I_1(t_k) AND I_2(t_k) AND I_3(t_k)\n');
fprintf('T_sync = Delta_t * SUM_k I_sync(t_k)\n\n');
fprintf('M1 单独完全遮蔽时长：%.4f s\n',S.singleDuration(1));
fprintf('M2 单独完全遮蔽时长：%.4f s\n',S.singleDuration(2));
fprintf('M3 单独完全遮蔽时长：%.4f s\n',S.singleDuration(3));
fprintf('三枚导弹同时完全遮蔽总时长：%.4f s\n',S.syncDuration);
fprintf('同步有效区间：\n');
for k=1:numel(S.syncIntervalStart)
    fprintf('  区间%d：[%.3f, %.3f] s，时长 %.3f s\n',k, ...
        S.syncIntervalStart(k),S.syncIntervalEnd(k),S.syncIntervalDuration(k));
end

% 生成论文或答辩中可直接使用的公式结果图。
if DO_PLOT
fig = btNewFigure('', [80 80 1350 780]);
axes('Position',[.05 .05 .90 .90]);
axis([0 1 0 1]); axis off; hold on;
fontName = btFontName();

text(.5,.93,'问题五：严格三导弹同步遮蔽判定公式与结果', ...
    'HorizontalAlignment','center','FontName',fontName,'FontSize',33,'FontWeight','bold');
text(.5,.78,'I_{sync}(t_k) = I_1(t_k) AND I_2(t_k) AND I_3(t_k)', ...
    'HorizontalAlignment','center','FontSize',33,'Color',[.10 .25 .48],'FontWeight','bold');
text(.5,.66,'T_{sync} = Delta t * sum_k I_{sync}(t_k)', ...
    'HorizontalAlignment','center','FontSize',33,'Color',[.10 .25 .48],'FontWeight','bold');

rectangle('Position',[.10 .33 .80 .23], ...
    'FaceColor',[.92 .97 1.00],'EdgeColor',[.20 .40 .65],'LineWidth',1.8);
resultText = sprintf(['M1：%.4f s       M2：%.4f s       M3：%.4f s\n' ...
    '三枚导弹同时完全遮蔽总时长：%.4f s'], ...
    S.singleDuration(1),S.singleDuration(2),S.singleDuration(3),S.syncDuration);
text(.5,.445,resultText,'HorizontalAlignment','center','VerticalAlignment','middle', ...
    'FontName',fontName,'FontSize',27,'FontWeight','bold','Color',[.12 .22 .34]);

nIv = numel(S.syncIntervalStart);
intervalText = '同步有效区间：';
for k=1:nIv
    oneInterval = sprintf('[%.2f, %.2f] s',S.syncIntervalStart(k),S.syncIntervalEnd(k));
    if k<nIv, oneInterval=[oneInterval '  U  ']; end
    intervalText=[intervalText oneInterval];
end
text(.5,.22,intervalText,'HorizontalAlignment','center','FontName',fontName, ...
    'FontSize',22,'Color',[.25 .25 .25]);
text(.5,.10,'注意：三个单独时长不能相加；仅逻辑“与”成立的采样时刻计入总时长。', ...
    'HorizontalAlignment','center','FontName',fontName,'FontSize',21,'Color',[.65 .16 .12]);

btExportFig(fig,fullfile(BT_IMG_DIR,'图26_问题五严格同步判定公式与结果.png'),300);
formulaImage = fullfile(BT_IMG_DIR,'图26_问题五严格同步判定公式与结果.png');
fprintf('已生成公式结果图：%s\n',formulaImage);
else
    fprintf('[跳过绘图] 请在图形界面中运行本脚本以生成公式结果图。\n');
end

