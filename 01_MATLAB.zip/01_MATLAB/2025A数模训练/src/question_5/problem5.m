%% 2025 A题问题五：三枚导弹同时完全遮蔽（严格同步判据）
% 判定顺序：
%   1) 对每枚导弹、圆柱目标上的每个采样点，至少有一个有效烟幕遮挡；
%   2) M1、M2、M3 三枚导弹在同一时刻均满足 1)，该时刻才计入总时长；
%   3) 已到达假目标的导弹不再限制后续时刻（其状态置为 true）。
% 严禁把 M1、M2、M3 的单独遮蔽时长相加。

clear; clc;
[DO_PLOT,BT_IMG_DIR] = btInit();

outputFolder = fileparts(mfilename('fullpath'));
if isempty(outputFolder), outputFolder = pwd; end

%% 物理参数
g = 9.8;
vMissile = 300;
smokeRadius = 10;
sinkSpeed = 3;
smokeLife = 20;

F = [17800,    0, 1800;
     12000, 1400, 1400;
      6000,-3000,  700;
     11000, 2000, 1800;
     13000,-2000, 1300];
M0 = [20000,    0, 2000;
      19000,  600, 2100;
      18000, -600, 1900];

%% 已由“可行策略库 + 粒子群局部精化”得到的严格同步可行解
thetaDeg = [7.7200, 225.9063, 85.0849, 235.8995, 126.4878];
speed = [112.7200, 134.7849, 92.5863, 113.5688, 139.4668];

dropTime = [0,       1.0000,  2.0000;
            4.7237,  5.8247, 10.0925;
           28.4049, 29.6337, 34.6679;
            5.9744,  8.0044, 11.7792;
           11.3982, 12.7997, 17.8651];

delay = [0,       0,       0;
         5.7240,  8.0623,  7.7630;
         2.1175,  3.5552,  0.4814;
        11.7820, 12.8766, 12.7397;
         3.0717,  5.2558,  3.2808];

theta = deg2rad(thetaDeg);
burstTime = dropTime + delay;

% 同机相邻投放间隔与起爆高度检查
assert(all(all(diff(dropTime,1,2) >= 1-1e-10)), '存在同机投放间隔小于1 s。');
burstHeight = F(:,3) - 0.5*g*delay.^2;
assert(all(burstHeight(:) >= -1e-8), '存在起爆点落到地面以下。');

%% 计算15个起爆点
burstPoint = zeros(15,3);
cloudBurst = zeros(1,15);
cloudIndex = zeros(15,2);
q = 0;
for u = 1:5
    direction = [cos(theta(u)), sin(theta(u)), 0];
    for j = 1:3
        q = q+1;
        cloudBurst(q) = burstTime(u,j);
        burstPoint(q,:) = F(u,:) + speed(u)*cloudBurst(q)*direction ...
            + [0,0,-0.5*g*delay(u,j)^2];
        cloudIndex(q,:) = [u,j];
    end
end

%% 完整圆柱目标采样：侧面 + 上下端面
na = 72;
ang = (0:na-1)'*2*pi/na;
zSide = linspace(0,10,11);
[aa,zz] = ndgrid(ang,zSide);
Pside = [7*cos(aa(:)), 200+7*sin(aa(:)), zz(:)];

rCap = linspace(0,7,8);
[ac,rc] = ndgrid(ang,rCap);
Pbottom = [rc(:).*cos(ac(:)), 200+rc(:).*sin(ac(:)), zeros(numel(rc),1)];
Ptop = Pbottom; Ptop(:,3) = 10;
targetPoints = unique([Pside;Pbottom;Ptop],'rows');

%% 高密度时间复核
timeMain = tic;
dt = 0.01;
arrivalTime = sqrt(sum(M0.^2,2))/vMissile;
t = 0:dt:max(arrivalTime);
nt = numel(t);

active = t' >= cloudBurst & t' <= cloudBurst+smokeLife;
Cx = repmat(burstPoint(:,1)',nt,1);
Cy = repmat(burstPoint(:,2)',nt,1);
Cz = repmat(burstPoint(:,3)'+sinkSpeed*cloudBurst,nt,1) - sinkSpeed*t';

missileCovered = false(nt,3);
cloudContribution = zeros(15,3);
for m = 1:3
    % 导弹到达原点前的直线运动
    ratio = 1-t'/arrivalTime(m);
    Mx = M0(m,1)*ratio;
    My = M0(m,2)*ratio;
    Mz = M0(m,3)*ratio;

    % 计算 15 个云团中心到“导弹—目标点”线段的距离。
    % 【北太天元性能优化】原版对 1658 个目标点逐个循环（1658 次迭代、每次都是
    %  nt×15 的小矩阵），在北太天元里解释器开销极大。现改为
    %  “目标点分块（向量化） + 云团循环”，迭代次数从 1658 降到约 75 次，
    %  数学上完全等价（逐点取 min/max 换成沿点维度的 min/max 归约）。
    worstPointDistance = -inf(nt,1);
    worstCloudDistance = -inf(nt,15);
    ptChunk = 400;
    nPt = size(targetPoints,1);
    for pc0 = 1:ptChunk:nPt
        pc1 = min(pc0+ptChunk-1,nPt);
        nLocal = pc1-pc0+1;
        Px = targetPoints(pc0:pc1,1)';
        Py = targetPoints(pc0:pc1,2)';
        Pz = targetPoints(pc0:pc1,3)';
        Ax = Px-Mx;      % nt x nLocal
        Ay = Py-My;
        Az = Pz-Mz;
        den = Ax.^2+Ay.^2+Az.^2;
        bestCloud = inf(nt,nLocal);
        for qq = 1:15
            Bx = Cx(:,qq)-Mx;    % nt x 1
            By = Cy(:,qq)-My;
            Bz = Cz(:,qq)-Mz;
            lambda = (Ax.*Bx+Ay.*By+Az.*Bz)./den;
            distance = sqrt((Bx-lambda.*Ax).^2 + ...
                            (By-lambda.*Ay).^2 + ...
                            (Bz-lambda.*Az).^2);
            % 必须落在线段内部，且烟幕已经起爆并仍在20 s有效期内
            distance(~active(:,qq) | lambda<=0 | lambda>=1) = inf;
            worstCloudDistance(:,qq) = max(worstCloudDistance(:,qq),max(distance,[],2));
            bestCloud = btMinAB(bestCloud,distance);
        end
        worstPointDistance = max(worstPointDistance,max(bestCloud,[],2));
    end

    missileCovered(:,m) = worstPointDistance <= smokeRadius;
    beforeArrival = t' < arrivalTime(m);
    for qq = 1:15
        cloudContribution(qq,m) = sum(worstCloudDistance(:,qq)<=smokeRadius & beforeArrival)*dt;
    end
    missileCovered(t' >= arrivalTime(m),m) = true;
    fprintf('  导弹 M%d 遮蔽判定完成（累计 %.1f s）\n',m,toc(timeMain));
end

% 核心目标函数：三枚导弹状态取逻辑“与”，不是求和或逻辑“或”
syncCovered = all(missileCovered,2);
syncDuration = sum(syncCovered)*dt;

%% 输出结果
fprintf('\n问题五严格同步判据复核结果\n');
fprintf('目标采样点数：%d，时间步长：%.3f s\n',size(targetPoints,1),dt);
singleDuration = zeros(3,1);
for m = 1:3
    beforeArrival = t' < arrivalTime(m);
    singleDuration(m) = sum(missileCovered(:,m) & beforeArrival)*dt;
    fprintf('M%d 单独完全遮蔽时长：%.4f s\n',m,singleDuration(m));
end
fprintf('三枚导弹同时完全遮蔽总时长：%.4f s\n',syncDuration);
fprintf('同步有效区间：');
showIntervals(syncCovered,t);

summaryTable = table(["M1";"M2";"M3";"Sync_M1_M2_M3"],[singleDuration;syncDuration], ...
    'VariableNames',{'Object','FullCoverageDuration_s'});
writetable(summaryTable,fullfile(outputFolder,'问题五计算结果.csv'));
dSync = diff([false;syncCovered;false]);
syncLeft = find(dSync==1); syncRight = find(dSync==-1)-1;
intervalTable = table((1:numel(syncLeft))',t(syncLeft)',t(syncRight)', ...
    (syncRight-syncLeft+1)*dt,'VariableNames',{'Interval','Start_s','End_s','Duration_s'});
writetable(intervalTable,fullfile(outputFolder,'问题五同步有效区间.csv'));

resultTable = table((1:5)',thetaDeg',speed',dropTime(:,1),delay(:,1), ...
    dropTime(:,2),delay(:,2),dropTime(:,3),delay(:,3), ...
    'VariableNames',{'UAV','Heading_deg','Speed','Drop1','Delay1', ...
    'Drop2','Delay2','Drop3','Delay3'});
disp(resultTable);
writetable(resultTable,fullfile(outputFolder,'问题五最优投放策略.csv'));

% 保存计算数据，便于论文作图或继续优化
% 北太天元不支持把 table 写入 MAT 文件，因此这里只存数值/逻辑数组，
% 表格数据已经用 writetable 写成 CSV。
syncIntervalStart    = t(syncLeft);
syncIntervalEnd      = t(syncRight);
syncIntervalDuration = (syncRight-syncLeft+1)*dt;
save(fullfile(outputFolder,'problem5_sync_result.mat'),'thetaDeg','speed','dropTime','delay', ...
    'burstTime','burstPoint','arrivalTime','t','missileCovered', ...
    'syncCovered','syncDuration','singleDuration','cloudContribution', ...
    'syncIntervalStart','syncIntervalEnd','syncIntervalDuration');

%% 生成论文问题五所需的四幅图
if DO_PLOT
    makeSurrogateFlowchart(outputFolder);
    makeContributionHeatmap(cloudContribution,outputFolder);
    makeCoverageTimeline(t,missileCovered,syncCovered,arrivalTime,outputFolder);

    % 图23使用真实粗粒度仿真样本训练两隐层BP网络，并进行主动学习诊断。
    xBest = packDecision(theta,speed,dropTime,delay);
    makeSurrogateConvergence(xBest,F,M0,g,smokeRadius,sinkSpeed,smokeLife,outputFolder);
else
    fprintf('[跳过绘图] 请在图形界面中运行本脚本以生成图22—图25。\n');
end

fprintf('\n已生成论文插图：\n');
fprintf('  图22_问题五神经网络代理模型构建流程图.png\n');
fprintf('  图23_问题五神经网络训练与主动学习收敛图.png\n');
fprintf('  图24_问题五烟幕弹任务贡献热力图.png\n');
fprintf('  图25_问题五多导弹协同遮蔽时序图.png\n');
fprintf('表7数据：问题五最优投放策略.csv\n');
fprintf('汇总结果：问题五计算结果.csv、问题五同步有效区间.csv\n');

function showIntervals(mask,t)
d = diff([false;mask;false]);
left = find(d==1);
right = find(d==-1)-1;
if isempty(left)
    fprintf('无\n');
    return;
end
for k = 1:numel(left)
    fprintf('[%.3f, %.3f] s',t(left(k)),t(right(k)));
    if k<numel(left), fprintf(' U '); else, fprintf('\n'); end
end
end

function makeSurrogateFlowchart(outputFolder)
fig = btNewFigure('', [50 50 1400 780]);
axes('Position',[0 0 1 1]); axis([0 1 0 1]); axis off; hold on;
fontName = btFontName();

drawBox([.05 .73 .19 .12],[.86 .94 1.00],'统一运动-遮蔽模型',fontName);
drawBox([.31 .73 .17 .12],[.89 1.00 .90],'可行参数样本 Q',fontName);
drawBox([.55 .73 .18 .12],[1.00 .94 .80],'高精度标签 T(Q)',fontName);
drawBox([.80 .73 .15 .12],[.96 .88 1.00],'归一化数据集',fontName);
drawArrow([.24 .31],[.79 .79]); drawArrow([.48 .55],[.79 .79]); drawArrow([.73 .80],[.79 .79]);

drawBox([.17 .43 .20 .14],[.88 .95 1.00],sprintf('输入层\n40维决策变量'),fontName);
drawBox([.42 .43 .19 .14],[.88 1.00 .91],sprintf('BP代理网络\n40-32-16-1'),fontName);
drawBox([.66 .43 .18 .14],[1.00 .92 .86],sprintf('输出层\n预测同步时长'),fontName);
drawArrow([.37 .42],[.50 .50]); drawArrow([.61 .66],[.50 .50]);
drawArrow([.875 .27],[.73 .57]);

drawBox([.04 .13 .18 .13],[.94 .94 .94],'大规模候选池',fontName);
drawBox([.28 .13 .18 .13],[.89 .96 1.00],'代理模型快速预测',fontName);
drawBox([.52 .13 .15 .13],[1.00 .94 .79],'Top-K优势方案',fontName);
drawBox([.73 .13 .21 .13],[.91 1.00 .89],sprintf('统一模型高精度复核\n加入训练集并更新'),fontName);
drawArrow([.22 .28],[.195 .195]); drawArrow([.46 .52],[.195 .195]); drawArrow([.67 .73],[.195 .195]);
drawArrow([.835 .55],[.26 .43]);

text(.5,.94,'问题五：神经网络代理模型与主动学习流程','HorizontalAlignment','center', ...
    'FontName',fontName,'FontSize',33,'FontWeight','bold','Color',[.12 .20 .34]);
text(.5,.045,'代理筛选只负责缩小搜索范围，最终时长仍由严格三导弹同步判据复核', ...
    'HorizontalAlignment','center','FontName',fontName,'FontSize',21,'Color',[.35 .35 .35]);

btExportFig(fig,'图22_问题五神经网络代理模型构建流程图.png',300);
end

function drawBox(pos,colorValue,label,fontName)
rectangle('Position',pos,'FaceColor',colorValue,'EdgeColor',[.25 .35 .50],'LineWidth',1.6);
text(pos(1)+pos(3)/2,pos(2)+pos(4)/2,label,'HorizontalAlignment','center', ...
    'VerticalAlignment','middle','FontName',fontName,'FontSize',21,'FontWeight','bold');
end

function drawArrow(x,y)
% 画带实心三角箭头的连线
% 北太天元没有 annotation，这里用「直线 + 小三角形 patch」实现，
% MATLAB 与北太天元都能正常渲染。
    col = [.25 .35 .55];
    plot(x,y,'-','Color',col,'LineWidth',1.7);
    dx = x(2)-x(1); dy = y(2)-y(1);
    L = sqrt(dx^2+dy^2);
    if L <= 0, return; end
    ux = dx/L; uy = dy/L;
    hl = 0.030;      % 箭头长度（归一化坐标）
    hw = 0.012;      % 箭头半宽
    px = x(2); py = y(2);
    bx = px-ux*hl; by = py-uy*hl;
    patch([px, bx-uy*hw, bx+uy*hw],[py, by+ux*hw, by-ux*hw],col,'EdgeColor','none');
end

function makeContributionHeatmap(contribution,outputFolder)
fig = btNewFigure('', [50 50 980 1080]);
axes('Position',[.16 .10 .65 .82]);
imagesc(contribution); axis tight;
% 白 -> 北太天元青(#24A0CC) 的渐变：0 值显示为白色，避免大片深紫底色
    nColor = 256;
    tCol = linspace(0,1,nColor)';
    colormap((1-tCol)*[1 1 1] + tCol*btC(6));
colorbar;
xticks(1:3); xticklabels({'M1','M2','M3'});
labels=cell(15,1); q=0;
for u=1:5
    for j=1:3, q=q+1; labels{q}=sprintf('FY%d-%d',u,j); end
end
yticks(1:15); yticklabels(labels);
% 北太天元 set(gca,...) 不可用：改为把数据上下翻转 + 标签倒序，达到同样的显示效果
xlabel('来袭导弹','FontSize',18); ylabel('烟幕弹编号','FontSize',18);
title('问题五：十五枚烟幕弹任务贡献分布','FontSize',26,'FontWeight','bold');
mx=max(contribution(:)); if mx<=0, mx=1; end
for r=1:15
    for c=1:3
        v = contribution(r,c);
        if v <= 0
            text(c,r,char(8211),'HorizontalAlignment','center', ...
                 'Color',[0.78 0.78 0.78],'FontSize',16);
        else
            tv = min(1,max(0,v/mx));
            cc = (1-tv)*[1 1 1] + tv*btC(1);           % 该格实际填充色
            lum = 0.299*cc(1)+0.587*cc(2)+0.114*cc(3); % 相对亮度
            if lum < 0.62
                tcol = 'w';
            else
                tcol = [0.12 0.12 0.12];
            end
            text(c,r,sprintf('%.2f',v),'HorizontalAlignment','center', ...
                 'FontWeight','bold','Color',tcol,'FontSize',15);
        end
    end
end
btExportFig(fig,'图24_问题五烟幕弹任务贡献热力图.png',300);
end

function makeCoverageTimeline(t,covered,syncCovered,arrivalTime,outputFolder)
fig=btNewFigure('', [50 50 1500 760]);
axes('Position',[.14 .14 .82 .72]); hold on;
displayCovered=covered;
for m=1:3, displayCovered(t'>=arrivalTime(m),m)=false; end
states=[displayCovered,syncCovered];
colors=[btC(1); btC(5); btC(3); btC(2)];   % 北太天元色板：蓝 / 绿 / 黄 / 红
for k=1:4
    mask=states(:,k);
    d=diff([false;mask;false]);
    left=find(d==1); right=find(d==-1)-1;
    for j=1:numel(left)
        x1=t(left(j)); x2=t(right(j))+mean(diff(t));
        btPatchFade([x1 x2 x2 x1],[k-.34 k-.34 k+.34 k+.34],colors(k,:),0.92);
    end
end
for m=1:3
    xline(arrivalTime(m),'--','Color',colors(m,:),'LineWidth',1.1);
end
ylim([.5 4.5]); xlim([0,max(t)]); yticks(1:4);
yticklabels({'M1','M2','M3','三导弹同步'});
btGrid();
% 北太天元 set(gca,...) 不可用，改为绘制时直接使用倒序数据
xlabel('时间 / s','FontSize',18); ylabel('遮蔽状态','FontSize',18);
title('问题五：最优方案多导弹协同遮蔽时序','FontSize',26,'FontWeight','bold');
subtitle(sprintf(['实色区间：导弹到达前完整圆柱均被遮蔽；同步行按三导弹逻辑与计算。' ...
    ' 虚线到达时刻 M1=%.2f s，M2=%.2f s，M3=%.2f s'], ...
    arrivalTime(1),arrivalTime(2),arrivalTime(3)), ...
    'FontName',btFontName(),'FontSize',15,'Color',[.35 .35 .35]);
btExportFig(fig,'图25_问题五多导弹协同遮蔽时序图.png',300);
end

function makeSurrogateConvergence(xBest,F,M0,g,R,sinkSpeed,life,outputFolder)
rng(20250901,'twister');
n0=180; X=zeros(n0,40); Y=zeros(n0,1); X(1,:)=xBest;
for i=2:n0
    if i<=round(.8*n0), scale=.35; else, scale=1.0; end
    X(i,:)=perturbDecision(xBest,F,g,scale);
end
M0norm = sqrt(sum(M0.^2,2));
P=coarseTargetPoints(); tc=0:.25:max(M0norm)/300;
for i=1:n0
    Y(i)=coarseSyncDuration(X(i,:),F,M0,P,tc,R,sinkSpeed,life,g);
end

order=randperm(n0); nTrain=round(.82*n0);
itr=order(1:nTrain); iva=order(nTrain+1:end);
[model,trainLoss,valLoss]=trainBP(X(itr,:),Y(itr),X(iva,:),Y(iva),220);

rounds=8; bestCurve=zeros(rounds+1,1); bestCurve(1)=max(Y);
allX=X; allY=Y;
for r=1:rounds
    pool=zeros(360,40);
    [~,ib]=max(allY); center=allX(ib,:);
    for i=1:size(pool,1), pool(i,:)=perturbDecision(center,F,g,.22+.035*r); end
    pred=predictBP(model,pool);
    [~,ix]=maxk(pred,8);
    newX=pool(ix,:); newY=zeros(8,1);
    for i=1:8
        newY(i)=coarseSyncDuration(newX(i,:),F,M0,P,tc,R,sinkSpeed,life,g);
    end
    allX=[allX;newX]; allY=[allY;newY]; bestCurve(r+1)=max(allY);
    [model,~,~]=trainBP(allX,allY,zeros(0,40),zeros(0,1),90);
end

fig=btNewFigure('', [50 50 1450 620]);

subplot(1,2,1);
semilogy(0:numel(trainLoss)-1,trainLoss,'LineWidth',2,'Color',[.15 .42 .75]);
btGrid(); btBox();
xlabel('训练轮次','FontSize',18); ylabel('归一化均方误差','FontSize',18);
title('BP代理模型训练损失','FontSize',18); legend({'训练集'},'Location','best');

subplot(1,2,2);
plot(0:rounds,bestCurve,'-o','LineWidth',2,'MarkerFaceColor',[.22 .65 .42],'Color',[.12 .48 .30]);
btGrid(); btBox();
xlabel('主动学习轮次','FontSize',18); ylabel('当前最优同步时长 / s','FontSize',18);
title('优势样本主动更新','FontSize',18);
span=max(bestCurve)-min(bestCurve); pad=max(.12,.65*span);
ylim([min(bestCurve)-pad,max(bestCurve)+pad]);

btSgTitle('问题五：神经网络训练与主动学习收敛过程',15);
btExportFig(fig,'图23_问题五神经网络训练与主动学习收敛图.png',300);
save(fullfile(outputFolder,'problem5_surrogate_diagnostics.mat'), ...
     'trainLoss','valLoss','bestCurve','allX','allY');
end

function x=packDecision(theta,speed,td,tau)
x=[theta(:)',speed(:)',reshape(td',1,[]),reshape(tau',1,[])];
end

function [theta,speed,td,tau]=unpackDecision(x)
theta=x(1:5);speed=x(6:10);td=reshape(x(11:25),3,5)';tau=reshape(x(26:40),3,5)';
end

function x=perturbDecision(x0,F,g,scale)
[theta,speed,td,tau]=unpackDecision(x0);theta=mod(theta+randn(1,5)*(.025*scale),2*pi);
speed=max(70,btMinAB(140,speed+randn(1,5)*(3*scale)));maxTau=sqrt(2*F(:,3)/g)-1e-5;
for u=1:5
 z=sort(max(0,td(u,:)+randn(1,3)*(.65*scale)));
 for j=2:3,z(j)=max(z(j),z(j-1)+1);end
 td(u,:)=btMinAB(z,55);tau(u,:)=max(0,btMinAB(maxTau(u),tau(u,:)+randn(1,3)*(.7*scale)));
end
x=packDecision(theta,speed,td,tau);
end

function P=coarseTargetPoints()
a=(0:7)'*2*pi/8;z=[0 5 10];[aa,zz]=ndgrid(a,z);P=[7*cos(aa(:)),200+7*sin(aa(:)),zz(:)];
end

function duration=coarseSyncDuration(x,F,M0,P,t,R,sinkSpeed,life,g)
[theta,speed,td,tau]=unpackDecision(x);tb=td+tau;T=numel(t);pb=zeros(15,3);bt=zeros(1,15);q=0;
for u=1:5,d=[cos(theta(u)) sin(theta(u)) 0];for j=1:3,q=q+1;bt(q)=tb(u,j);pb(q,:)=F(u,:)+speed(u)*bt(q)*d+[0 0 -.5*g*tau(u,j)^2];end,end
active=t'>=bt&t'<=bt+life;cx=repmat(pb(:,1)',T,1);cy=repmat(pb(:,2)',T,1);cz=repmat(pb(:,3)'+sinkSpeed*bt,T,1)-sinkSpeed*t';covered=false(T,3);
for m=1:3
 arr=norm(M0(m,:))/300;fac=1-t'/arr;mx=M0(m,1)*fac;my=M0(m,2)*fac;mz=M0(m,3)*fac;worst=-inf(T,1);
 for p=1:size(P,1)
  ax=P(p,1)-mx;ay=P(p,2)-my;az=P(p,3)-mz;den=ax.^2+ay.^2+az.^2;bx=cx-mx;by=cy-my;bz=cz-mz;la=(ax.*bx+ay.*by+az.*bz)./den;
  dist=sqrt((bx-la.*ax).^2+(by-la.*ay).^2+(bz-la.*az).^2);dist(~active|la<=0|la>=1)=inf;worst=max(worst,min(dist,[],2));
 end
 covered(:,m)=worst<=R;covered(t'>=arr,m)=true;
end
duration=sum(all(covered,2))*mean(diff(t));
end

function [model,trainLoss,valLoss]=trainBP(X,Y,Xv,Yv,epochs)
muX=mean(X,1);sigX=std(X,0,1);sigX(sigX<1e-9)=1;muY=mean(Y);sigY=std(Y);if sigY<1e-9,sigY=1;end
Z=(X-muX)./sigX;yt=(Y-muY)/sigY;Zv=(Xv-muX)./sigX;yv=(Yv-muY)/sigY;
nIn=size(X,2);W1=randn(nIn,32)*sqrt(2/nIn);b1=zeros(1,32);W2=randn(32,16)*sqrt(2/32);b2=zeros(1,16);W3=randn(16,1)*sqrt(2/16);b3=0;
params={W1,b1,W2,b2,W3,b3};mom=cellfun(@zerosLike,params,'UniformOutput',false);vel=cellfun(@zerosLike,params,'UniformOutput',false);trainLoss=zeros(epochs,1);valLoss=zeros(epochs,1);
for ep=1:epochs
 W1=params{1};b1=params{2};W2=params{3};b2=params{4};W3=params{5};b3=params{6};H1=tanh(Z*W1+b1);H2=tanh(H1*W2+b2);yp=H2*W3+b3;e=yp-yt;trainLoss(ep)=mean(e.^2);
 d3=2*e/size(Z,1);gW3=H2'*d3;gb3=sum(d3,1);d2=(d3*W3').*(1-H2.^2);gW2=H1'*d2;gb2=sum(d2,1);d1=(d2*W2').*(1-H1.^2);gW1=Z'*d1;gb1=sum(d1,1);grads={gW1,gb1,gW2,gb2,gW3,gb3};
 lr=.008;for k=1:6,mom{k}=.9*mom{k}+.1*grads{k};vel{k}=.999*vel{k}+.001*(grads{k}.^2);mh=mom{k}/(1-.9^ep);vh=vel{k}/(1-.999^ep);params{k}=params{k}-lr*mh./(sqrt(vh)+1e-8);end
 if isempty(Xv),valLoss(ep)=NaN;else,h1=tanh(Zv*params{1}+params{2});h2=tanh(h1*params{3}+params{4});pv=h2*params{5}+params{6};valLoss(ep)=mean((pv-yv).^2);end
end
model.params=params;model.muX=muX;model.sigX=sigX;model.muY=muY;model.sigY=sigY;
if isempty(Xv),valLoss=[];end
end

function z=zerosLike(x),z=zeros(size(x));end

function y=predictBP(model,X)
Z=(X-model.muX)./model.sigX;p=model.params;h1=tanh(Z*p{1}+p{2});h2=tanh(h1*p{3}+p{4});y=(h2*p{5}+p{6})*model.sigY+model.muY;
end
