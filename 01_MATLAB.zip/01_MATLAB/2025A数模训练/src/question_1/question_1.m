%% 问题1：FY1 投放 1 枚烟幕弹对 M1 的有效遮蔽时长
%  北太天元（Baltamatica）移植版
%  方法：三维运动模型 + 时间粗扫描 + 二分法精化遮蔽边界
%  遮蔽口径：真目标轮廓参数，判断视线是否穿过半径 10 m 的烟幕球
%
%  说明：北太天元 2025 版已移除终端绘图功能，本脚本在图形界面（GUI）中
%        运行会自动画出 4 张图并导出 PNG；若在终端运行则只做计算。

clear; clc;

%% ===================== 0. 绘图开关与输出目录 =====================
[DO_PLOT,imgDir] = btInit();

global BT_PAUSE_SEC
if isempty(BT_PAUSE_SEC), BT_PAUSE_SEC = 60; end   %% 每画一张停 60 秒等主人保存


%% --------1.基础参数与初始位置----------
O=[0,0,0];                 % 假目标位置
cyl_params=[7,10,0,200,0]; % 圆柱参数[半径,高度,底面圆心x,y,z]
T_plot=[0,200,5];          % 圆柱几何中心(仅用于画图)
M10=[20000,0,2000];        % M1初始位置
F10=[17800,0,1800];        % FY1初始位置

vM=300;                    % M1速度，m/s
vF1=120;                   % FY1速度，m/s
g=9.8;                     % 重力加速度，m/s^2
gVec=[0,0,-g];             % 重力加速度向量
vCloud=[0,0,-3];           % 烟幕云团下沉速度，m/s
R=10;                      % 烟幕有效球半径，m
cloudLife=20;              % 烟幕有效持续时间，s

td11=1.5;                  % FY1投放时刻，s
tau11=3.6;                 % 引信延迟，s
tb11=td11+tau11;           % 起爆时刻，s

%% --------2.M1运动方程----------
eM1=(O-M10)/norm(O-M10);   % M1飞向假目标的单位方向
vM1=vM*eM1;                % M1速度向量
M1=@(t) M10+vM1.*t;        % M1(t)
tM1Arrive=norm(O-M10)/vM;  % M1到达假目标时刻

%% --------3.FY1运动方程----------
eF1=[-1,0,0];
vF1Vec=vF1*eF1;
F1=@(t) F10+vF1Vec.*t;     % FY1(t)

%% --------4.投放点、烟幕弹运动及起爆点----------
P011=F1(td11);             % 投放点
P11=@(t) P011+vF1Vec.*(t-td11)+0.5.*gVec.*(t-td11).^2; % 平抛运动
Pb11=P11(tb11);            % 起爆点

%% --------5.烟幕云团中心运动----------
C11=@(t) Pb11+vCloud.*(t-tb11); % tb11<=t<=tb11+20

%% --------6.有效判定时间区间----------
tBegin=tb11;
tEnd=min(tb11+cloudLife,tM1Arrive);
if tEnd<=tBegin
    error('烟幕有效期与M1来袭过程没有交集。');
end

%% --------7.时间粗扫描----------
dt=0.01;                   % 步长，s
tGrid=tBegin:dt:tEnd;
if tGrid(end)<tEnd
    tGrid(end+1)=tEnd;
end

nTime=numel(tGrid);
lambdaGrid=zeros(1,nTime);
d2Grid=zeros(1,nTime);
covered=false(1,nTime);

ticStep=tic;
for k=1:nTime
    t=tGrid(k);
    [lambdaGrid(k),d2Grid(k)]=coverGeometry(t,M1,C11,T_plot);
    covered(k)=isCoveredCylinder(t,M1,C11,R,cyl_params);
    if mod(k,200)==0
        fprintf('  时间粗扫描 %d/%d (t=%.2f s)\n',k,nTime,t);
    end
end
fprintf('  粗扫描完成，用时 %.2f s\n',toc(ticStep));

%% --------8.二分法精化遮蔽边界----------
changeIndex=find(covered(1:end-1)~=covered(2:end));

tStart=[];
tFinish=[];

if covered(1)
    tStart(end+1)=tBegin;
end

for j=1:numel(changeIndex)
    k=changeIndex(j);
    tLeft=tGrid(k);
    tRight=tGrid(k+1);
    tBoundary=refineBoundary(tLeft,tRight,covered(k),M1,C11,R,cyl_params);
    if ~covered(k) && covered(k+1)
        tStart(end+1)=tBoundary;
    elseif covered(k) && ~covered(k+1)
        tFinish(end+1)=tBoundary;
    end
end

if covered(end)
    tFinish(end+1)=tEnd;
end

if numel(tStart)~=numel(tFinish)
    error('遮蔽区间起止点数量不一致，请减小dt后重试。');
end

intervals=[tStart(:),tFinish(:)];
if isempty(intervals)
    Teff=0;
else
    Teff=sum(intervals(:,2)-intervals(:,1));
end

%% --------9.输出结果----------
fprintf('\n========== 问题1计算结果（北太天元） ==========\n');
fprintf('FY1投放时刻 td11      = %.6f s\n',td11);
fprintf('投放点 P011           = (%.3f,%.3f,%.3f) m\n',P011(1),P011(2),P011(3));
fprintf('引信延迟 tau11        = %.6f s\n',tau11);
fprintf('起爆时刻 tb11         = %.6f s\n',tb11);
fprintf('起爆点 Pb11           = (%.3f,%.3f,%.3f) m\n',Pb11(1),Pb11(2),Pb11(3));
fprintf('烟幕有效判定区间      = [%.6f,%.6f] s\n',tBegin,tEnd);

if isempty(intervals)
    fprintf('未形成有效遮蔽。\n');
else
    for k=1:size(intervals,1)
        fprintf('有效区间 %d            = [%.9f,%.9f] s，时长 %.9f s\n',...
            k,intervals(k,1),intervals(k,2),...
            intervals(k,2)-intervals(k,1));
    end
end
fprintf('总有效遮蔽时长 Teff   = %.9f s\n',Teff);
fprintf('================================================\n\n');

%% --------10. 计算距离用于绘图 ----------
distanceGrid=sqrt(max(d2Grid,0));

%% --------10b. 保存绘图所需数据（供「只出图」直接读取）----------
save('problem1_result.mat','O','T_plot','M10','F10','P011','Pb11','R','cloudLife', ...
     'td11','tb11','tEnd','tGrid','distanceGrid','intervals','tM1Arrive');

%% ===================== 11. 绘图 =====================
if ~DO_PLOT
    fprintf('[跳过绘图] 当前环境没有图形函数（北太天元终端不提供绘图）。\n');
    fprintf('           请在北太天元图形界面中运行本脚本即可自动出图。\n');
    return;
end

% 统一配色
cM1    = btC(2);   % 导弹 红  #E86452
cFY1   = btC(1);   % 无人机 蓝 #42A5F5
cShell = btC(3);   % 烟幕弹 黄 #F6BD16
cCloud = btC(5);   % 云团 绿  #9CCC65
cTgt   = btC(4);   % 假目标 紫 #7E57C2
cDrop  = btC(6);   % 投放点 青 #24A0CC
cBurst = btC(7);   % 起爆点 深红 #B71C1C
cBand  = btTint(5,0.65);  % 有效区间底色（浅绿）


% ---- 图1：烟幕弹运动轨迹（x-z 侧视图） ----
fig1 = btNewFigure('图1 烟幕弹运动轨迹（侧视）', [100,100,860,620]);
hold on; btGrid(); btBox();

tUAV   = linspace(0,td11,50);
tShell = linspace(td11,tb11,100);
tCloud = linspace(tb11,tEnd,100);

uavPos   = sampleTrajectory(F1,tUAV);
shellPos = sampleTrajectory(P11,tShell);
cloudPos = sampleTrajectory(C11,tCloud);

plot3(uavPos(:,1),uavPos(:,2),uavPos(:,3),'-','Color',cFY1,'LineWidth',2.4,...
      'DisplayName','无人机飞行轨迹');
plot3(shellPos(:,1),shellPos(:,2),shellPos(:,3),'-','Color',cShell,'LineWidth',2.6,...
      'DisplayName','烟幕弹平抛轨迹');
plot3(cloudPos(:,1),cloudPos(:,2),cloudPos(:,3),'-','Color',cCloud,'LineWidth',2.6,...
      'DisplayName','烟幕云团下沉轨迹');

scatter3(F10(1),F10(2),F10(3),90,cFY1,'filled','DisplayName','无人机初始位置');
scatter3(P011(1),P011(2),P011(3),90,cDrop,'filled','DisplayName','投放点');
scatter3(Pb11(1),Pb11(2),Pb11(3),120,cBurst,'filled','DisplayName','起爆点');

view(0,0);
btGrid(); btBox();   % view 之后再设一次：三维图必须有网格和方框才立体
xlabel('x / m','FontSize',18); ylabel('y / m','FontSize',18); zlabel('z / m','FontSize',18);
title('图1  烟幕弹投放→爆炸→云团下沉轨迹（侧视图）','FontSize',21);
legend('Location','best','FontSize',15);
% 去掉 axis equal：否则 y 方向被压成窄条，坐标区填不满画面

xAll = [F10(1),P011(1),Pb11(1),cloudPos(:,1)'];
zAll = [F10(3),P011(3),Pb11(3),cloudPos(:,3)'];
xlim([min(xAll)-200, max(xAll)+200]);
zlim([min(zAll)-200, max(zAll)+200]);
ylim([-10,10]);

btExportFig(fig1,fullfile(imgDir,'图1_烟幕弹运动轨迹.png'));

% ---- 图2：距离 d(t) 随时间变化（含有效遮蔽区间） ----
fig2 = btNewFigure('图2 烟幕中心到视线的距离', [200,200,860,540]);
hold on; btGrid(); btBox();

plot(tGrid,distanceGrid,'-','Color',cFY1,'LineWidth',2.2,'DisplayName','d_{11}(t)');
yline(10,'--','Color',btGray()*0.75,'LineWidth',1.6,'DisplayName','R = 10 m');

if ~isempty(intervals)
    yLim = ylim;
    btShadePatch(intervals,yLim,cBand,'有效遮蔽区间');
end

xlabel('时间 t / s','FontSize',18);
ylabel('距离 d_{11}(t) / m','FontSize',18);
title('图2  烟幕中心到“导弹—真目标”视线的距离','FontSize',21);
legend('Location','best','FontSize',15);
ylim([0,max(distanceGrid)*1.12]);

btExportFig(fig2,fullfile(imgDir,'图2_烟幕中心到视线距离.png'));

% ---- 图3：三维全景（斜视角） ----
fig3 = btNewFigure('图3 第一问全景三维（斜视）', [300,100,900,700]);
hold on; btGrid(); btBox();

tMplot = linspace(0,tM1Arrive,200);
Mplot  = sampleTrajectory(M1,tMplot);
plot3(Mplot(:,1),Mplot(:,2),Mplot(:,3),'-','Color',cM1,'LineWidth',2.0,...
      'DisplayName','M1 轨迹');

uavPosAll   = sampleTrajectory(F1,linspace(0,td11,50));
shellPosAll = sampleTrajectory(P11,linspace(td11,tb11,100));
cloudPosAll = sampleTrajectory(C11,linspace(tb11,tEnd,100));

plot3(uavPosAll(:,1),uavPosAll(:,2),uavPosAll(:,3),'-','Color',cFY1,'LineWidth',2.0,...
      'DisplayName','FY1 轨迹');
plot3(shellPosAll(:,1),shellPosAll(:,2),shellPosAll(:,3),'-','Color',cShell,'LineWidth',2.2,...
      'DisplayName','烟幕弹轨迹');
plot3(cloudPosAll(:,1),cloudPosAll(:,2),cloudPosAll(:,3),'-','Color',cCloud,'LineWidth',2.2,...
      'DisplayName','云团中心轨迹');

scatter3(O(1),O(2),O(3),90,cTgt,'filled','DisplayName','假目标');
scatter3(T_plot(1),T_plot(2),T_plot(3),90,cCloud,'filled','DisplayName','真目标代表点');
scatter3(F10(1),F10(2),F10(3),70,cFY1,'filled','DisplayName','FY1 初始位置');
scatter3(P011(1),P011(2),P011(3),70,cDrop,'filled','DisplayName','投放点');
scatter3(Pb11(1),Pb11(2),Pb11(3),90,cBurst,'filled','DisplayName','起爆点');

if ~isempty(intervals)
    tShow = mean(intervals(1,:));
else
    [~,idx] = min(distanceGrid);
    tShow = tGrid(idx);
end
MtShow = M1(tShow);
CtShow = C11(tShow);
plot3([MtShow(1),T_plot(1)],[MtShow(2),T_plot(2)],[MtShow(3),T_plot(3)],...
      'k--','LineWidth',1.3,'DisplayName','视线（某时刻）');

[xs,ys,zs] = sphere(14);
btSurfBall(R*xs+CtShow(1),R*ys+CtShow(2),R*zs+CtShow(3),btGray(),0.30,'烟幕球（示意）');

view(-35,25);
btGrid(); btBox();   % view 之后再设一次：三维图必须有网格和方框才立体
xlabel('x / m','FontSize',18); ylabel('y / m','FontSize',18); zlabel('z / m','FontSize',18);
title(sprintf('图3  第一问全景三维（烟幕球时刻 t = %.2f s）',tShow),'FontSize',21);
legend('Location','best','FontSize',14);
% 去掉 axis equal：否则 y 方向被压成窄条，坐标区填不满画面
ylim([-1000,1000]);

btExportFig(fig3,fullfile(imgDir,'图3_第一问全景三维.png'));

% ---- 图4：三维全景侧视图 ----
fig4 = btNewFigure('图4 第一问全景侧视图', [400,150,900,700]);
hold on; btGrid(); btBox();

plot3(Mplot(:,1),Mplot(:,2),Mplot(:,3),'-','Color',cM1,'LineWidth',2.0,'DisplayName','M1 轨迹');
plot3(uavPosAll(:,1),uavPosAll(:,2),uavPosAll(:,3),'-','Color',cFY1,'LineWidth',2.0,...
      'DisplayName','FY1 轨迹');

scatter3(T_plot(1),T_plot(2),T_plot(3),90,cCloud,'filled','DisplayName','真目标代表点');
scatter3(F10(1),F10(2),F10(3),70,cFY1,'filled','DisplayName','FY1 初始位置');
scatter3(P011(1),P011(2),P011(3),70,cDrop,'filled','DisplayName','投放点');
scatter3(Pb11(1),Pb11(2),Pb11(3),90,cBurst,'filled','DisplayName','起爆点');

view(0,0);
btGrid(); btBox();   % view 之后再设一次：三维图必须有网格和方框才立体
xlabel('x / m','FontSize',18); ylabel('y / m','FontSize',18); zlabel('z / m','FontSize',18);
title(sprintf('图4  第一问全景侧视图（烟幕球时刻 t = %.2f s）',tShow),'FontSize',21);
legend('Location','northwest','FontSize',14);
% 去掉 axis equal：否则 y 方向被压成窄条，坐标区填不满画面

xlim([min(Mplot(:,1))-500, max(Mplot(:,1))+500]);
zLo = min([Mplot(:,3);cloudPosAll(:,3);0])-100;
zHi = max([Mplot(:,3);cloudPosAll(:,3);T_plot(3)])+100;
zlim([zLo,zHi]);
ylim([-500,500]);

btExportFig(fig4,fullfile(imgDir,'图4_第一问全景侧视图.png'));

fprintf('\n问题1 的 4 张图已生成，输出目录：\n  %s\n', imgDir);
