function val = btCircleExtreme(th0,halfWidth,Mt,Ct,center,r,z,which,mode)
% btCircleExtreme  在北太天元下用向量化网格细化求圆周上的极值（取代 fminbnd）
    lo = th0 - halfWidth;
    hi = th0 + halfWidth;
    val = [];
    for round = 1:3
        th = linspace(lo,hi,33);
        [d2v,lamv] = btCircleEval(th,Mt,Ct,center,r,z);
        if strcmp(which,'d2')
            f = d2v;
        else
            f = lamv;
        end
        if strcmp(mode,'max')
            [val,idx] = max(f);
        else
            [val,idx] = min(f);
        end
        step = (hi-lo)/32;
        lo = th(idx) - step;
        hi = th(idx) + step;
    end
end
