function f = btNewFigure(figName,pos)
% btNewFigure  创建图窗（北太天元防崩版）
%
%  三种模式：
%   ① 全局 BT_FIG_ONLY = k   → 只让第 k 张可见（「只出图」单图脚本用）
%   ② 全局 BT_PAUSE_SEC > 0  → 【主程序在 GUI 里直接跑时用】
%        每画一张就停 BT_PAUSE_SEC 秒，让主人另存为，然后自动关掉再画下一张
%        —— 界面上任何时刻只有一个窗口，不会崩
%   ③ 都不设（终端模式）      → 正常全画（终端本来就不绘图，走不到这）
    global BT_FIG_BG BT_FIG_ONLY BT_FIG_COUNT BT_LAST_HIDDEN BT_PAUSE_SEC BT_PREV_FIG

    if nargin < 2 || isempty(pos)
        pos = [100 100 900 650];
    end
    if nargin < 1 || isempty(figName)
        figName = '';
    end
    bg = [247 247 247]/255;
    if ~isempty(BT_FIG_BG)
        bg = BT_FIG_BG;
    end

    if isempty(BT_FIG_COUNT), BT_FIG_COUNT = 0; end
    BT_FIG_COUNT = BT_FIG_COUNT + 1;
    want = isempty(BT_FIG_ONLY) || (BT_FIG_COUNT == BT_FIG_ONLY);

    % ---- 模式②：先让主人保存上一张，再关掉它 ----
    if isempty(BT_FIG_ONLY) && ~isempty(BT_PAUSE_SEC) && BT_PAUSE_SEC > 0 && ~isempty(BT_PREV_FIG)
        fprintf('\n>>> 第 %d 张图画好了，请用「文件→另存为」保存。\n', BT_FIG_COUNT-1);
        fprintf('>>> %d 秒后自动关闭本窗口并画下一张……\n\n', round(BT_PAUSE_SEC));
        try, pause(BT_PAUSE_SEC); catch, end
        try, close(BT_PREV_FIG); catch, end
        BT_PREV_FIG = [];
    end

    % ---- 模式①：关掉上一张隐藏窗 ----
    if ~isempty(BT_LAST_HIDDEN)
        try, close(BT_LAST_HIDDEN); catch, end
        BT_LAST_HIDDEN = [];
    end

    f = [];
    if want
        try
            f = figure('Color',bg,'Name',figName,'Position',pos);
        catch
            try
                f = figure('Color',bg,'Position',pos);
            catch
                try
                    f = figure('Color',bg);
                catch
                    f = figure;
                end
            end
        end
        BT_PREV_FIG = f;
    else
        try
            f = figure('Color',bg,'Visible','off','Position',pos);
        catch
            try
                f = figure('Visible','off','Position',pos);
            catch
                f = figure('Visible','off');
            end
        end
        BT_LAST_HIDDEN = f;
    end
end
