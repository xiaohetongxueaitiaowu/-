function btBox()
% btBox  按坐标区类型与风格开关决定是否画完整边框
%   · 三维坐标区：默认保留方框（三维盒子感更强）
%   · 二维坐标区：默认只留左下两条轴线（北太天元默认样式）
    global BT_STYLE
    if isempty(BT_STYLE), BT_STYLE = 'baltamatica'; end
    is3D = false;
    try
        [az,el] = view;
        is3D = ~(abs(el-90) < 1e-6);
    catch
    end
    try
        if is3D || strcmp(BT_STYLE,'paper')
            box on;
        else
            box off;
        end
    catch
    end
end
