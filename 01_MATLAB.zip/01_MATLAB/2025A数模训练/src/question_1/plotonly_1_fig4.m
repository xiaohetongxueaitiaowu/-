%% 问题1 - 图4：第一问全景侧视图
%%   本脚本只画这一张图。画完请「文件→另存为」保存，然后关掉窗口，再跑下一张。
clear; clc;
[~,imgDir] = btInit();
load('problem1_result.mat');
if ~exist('imgDir','var'), imgDir = pwd; end
%% 重建运动方程
vM=300; vF1=120; g=9.8; gVec=[0,0,-g]; vCloud=[0,0,-3];
eM1=(O-M10)/norm(O-M10); vM1=vM*eM1; M1=@(t) M10+vM1.*t;
eF1=[-1,0,0]; vF1Vec=vF1*eF1; F1=@(t) F10+vF1Vec.*t;
P11=@(t) P011+vF1Vec.*(t-td11)+0.5.*gVec.*(t-td11).^2;
C11=@(t) Pb11+vCloud.*(t-tb11);
%% 统一配色（北太天元色板）
cM1    = btC(2);   % 导弹 红
cFY1   = btC(1);   % 无人机 蓝
cShell = btC(3);   % 烟幕弹 黄
cCloud = btC(5);   % 云团 绿
cTgt   = btC(4);   % 假目标 紫
cDrop  = btC(6);   % 投放点 青
cBurst = btC(7);   % 起爆点 深红
cBand  = btTint(5,0.65);  % 有效区间底色

%% 图4 复用的量（从图3 段落搬过来的同名计算，数值一致）
tMplot = linspace(0,tM1Arrive,200);
Mplot  = sampleTrajectory(M1,tMplot);
uavPosAll   = sampleTrajectory(F1,linspace(0,td11,50));
shellPosAll = sampleTrajectory(P11,linspace(td11,tb11,100));
cloudPosAll = sampleTrajectory(C11,linspace(tb11,tEnd,100));
if ~isempty(intervals)
    tShow = mean(intervals(1,:));
else
    [~,idxT] = min(distanceGrid); tShow = tGrid(idxT);
end
% ---- 图4：三维全景侧视图 ----
fig4 = btNewFigure('图4 第一问全景侧视图', [400,150,900,700]);
hold on; btGrid(); btBox();

plot3(Mplot(:,1),Mplot(:,2),Mplot(:,3),'-','Color',cM1,'LineWidth',2.0,'DisplayName','M1 轨迹');
plot3(uavPosAll(:,1),uavPosAll(:,2),uavPosAll(:,3),'-','Color',cFY1,'LineWidth',2.0,...
      'DisplayName','FY1 轨迹');

scatter3(T_plot(1),T_plot(2),T_plot(3),90,cCloud,'filled','DisplayName','真目标代表点');
scatter3(F10(1),F10(2),F10(3),70,cFY1,'filled','DisplayName','FY1 初始位置');
scatter3(P011(1),P011(2),P011(3),70,cDrop,'filled','DisplayName','投放点');
scatter3(Pb11(1),Pb11(2),Pb11(3),90,cBurst,'filled','DisplayName','起爆点');

view(0,0);
btGrid(); btBox();   % view 之后再设一次：三维图必须有网格和方框才立体
xlabel('x / m','FontSize',18); ylabel('y / m','FontSize',18); zlabel('z / m','FontSize',18);
title(sprintf('图4  第一问全景侧视图（烟幕球时刻 t = %.2f s）',tShow),'FontSize',21);
legend('Location','northwest','FontSize',14);
% 去掉 axis equal：否则 y 方向被压成窄条，坐标区填不满画面

xlim([min(Mplot(:,1))-500, max(Mplot(:,1))+500]);
zLo = min([Mplot(:,3);cloudPosAll(:,3);0])-100;
zHi = max([Mplot(:,3);cloudPosAll(:,3);T_plot(3)])+100;
zlim([zLo,zHi]);
ylim([-500,500]);

btExportFig(fig4,fullfile(imgDir,'图4_第一问全景侧视图.png'));

fprintf('\n问题1 的 4 张图已生成，输出目录：\n  %s\n', imgDir);

disp('图已画好 —— 请用「文件→另存为」保存，然后关掉窗口再跑下一张。');
