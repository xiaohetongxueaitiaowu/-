function [DO_PLOT,imgDir] = btInit()
% btInit  运行环境初始化（北太天元 / MATLAB 通用）
%   返回：
%     DO_PLOT - 当前环境是否有图形函数（图形界面或 MATLAB 里为 1，北太天元终端为 0）
%     imgDir  - 图片输出目录（自动创建）
%
%   图片目录优先级：
%     1) 环境变量 BT_IMG_DIR_OVERRIDE（用 setenv 设置，可跨 clear 保留）
%     2) 默认  <本目录>/../../北太天元图片
%
%   同时把绘图默认样式设成「北太天元风格」：色序、底色、文字颜色、字体、网格。
%   北太天元不支持 set(0,...) 时会自动忽略，不影响运行。

    global BT_IMG_DIR

    DO_PLOT = (exist('figure') ~= 0);

    imgDir = '';
    try
        imgDir = getenv('BT_IMG_DIR_OVERRIDE');
    catch
        imgDir = '';
    end
    if isempty(imgDir)
        here = pwd;
        try
            mf = mfilename('fullpath');
            if ~isempty(mf)
                here = fileparts(mf);
            end
        catch
        end
        imgDir = fullfile(here,'..','..','北太天元图片');
    end

    try
        if exist(imgDir,'dir') ~= 7
            mkdir(imgDir);
        end
    catch
        imgDir = pwd;
    end

    BT_IMG_DIR = imgDir;

    % ================= 北太天元风格默认样式 =================
    % 色值取自北太天元自带示例图：
    %   图窗底色 #F7F7F7、坐标区底色 #FFFFFF、坐标轴与文字 #262626
    %   默认色序 #42A5F5 / #E86452 / #F6BD16 / #7E57C2 / #9CCC65 / #24A0CC / #B71C1C
    % 北太天元本体的 set(0,...) 不被支持，会抛异常，这里直接忽略。
    dark = [38 38 38]/255;
    try
        set(0,'defaultFigureColor',[247 247 247]/255);
        set(0,'defaultAxesColor','w');
        set(0,'defaultAxesXColor',dark);
        set(0,'defaultAxesYColor',dark);
        set(0,'defaultAxesZColor',dark);
        set(0,'defaultTextColor',dark);
        set(0,'defaultAxesColorOrder',btPalette());
        set(0,'defaultAxesGridColor',dark);
        set(0,'defaultAxesGridAlpha',0.15);
        set(0,'defaultAxesBox','on');
        set(0,'defaultAxesFontName',btFontName());
        set(0,'defaultTextFontName',btFontName());
        set(0,'defaultAxesFontSize',16);
        set(0,'defaultTextFontSize',16);
        set(0,'defaultLineLineWidth',1.2);
    catch
        % 北太天元不支持 set(0,...)：忽略即可
    end
end
