function xyz=sampleTrajectory(positionFunction,tValues)
% 对只接受标量时间的三维位置函数进行采样
    xyz=zeros(numel(tValues),3);
    for i=1:numel(tValues)
        xyz(i,:)=positionFunction(tValues(i));
    end
end