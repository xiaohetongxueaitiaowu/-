function c = btC(k)
% btC  取北太天元默认色板中的第 k 种颜色（k = 1..7）
%   1 蓝 #42A5F5   2 红 #E86452   3 黄 #F6BD16   4 紫 #7E57C2
%   5 绿 #9CCC65   6 青 #24A0CC   7 深红 #B71C1C
    p = btPalette();
    k = max(1,min(size(p,1),round(k)));
    c = p(k,:);
end
