function [max_d2,min_lam,max_lam] = findWorstOnCircle(t,M1,C11,center,r,z,N_seg)
% 在高度 z 的圆周上求三个极值：d2 最大值、lambda 最小值、lambda 最大值
%
% 【北太天元移植说明】
%   原 MATLAB 版对每一小段圆弧调用 3 次 fminbnd（共 3*N_seg 次）。
%   北太天元的 fminbnd 单次约 9 ms，整题会到 1 小时量级，故改为
%   “密集向量化网格 + 三轮局部细化”，精度不低于原实现，速度快约千倍。

    Mt = M1(t);
    Ct = C11(t);

    % ---- 1. 密集向量化粗网格 ----
    Nf = max(720,20*N_seg);
    th = linspace(0,2*pi,Nf+1);
    th = th(1:Nf);

    [d2v,lamv] = btCircleEval(th,Mt,Ct,center,r,z);

    [~,iD] = max(d2v);
    [~,iL] = min(lamv);
    [~,iU] = max(lamv);

    halfWidth = 2*pi/Nf;

    % ---- 2. 局部细化 ----
    max_d2  = btCircleExtreme(th(iD),halfWidth,Mt,Ct,center,r,z,'d2', 'max');
    min_lam = btCircleExtreme(th(iL),halfWidth,Mt,Ct,center,r,z,'lam','min');
    max_lam = btCircleExtreme(th(iU),halfWidth,Mt,Ct,center,r,z,'lam','max');
end
