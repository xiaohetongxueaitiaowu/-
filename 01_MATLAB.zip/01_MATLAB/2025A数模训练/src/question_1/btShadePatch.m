function btShadePatch(intervals,yLim,cBand,labelText)
% btShadePatch  用一个 patch 对象画全部有效遮蔽区间（用 NaN 分隔各段）
%   北太天元不支持 patch 的 HandleVisibility 属性，改用单对象避免图例出现一堆条目；
%   同时 FaceAlpha 若不支持会自动降级为不透明填充。
    if nargin < 4 || isempty(labelText), labelText = '有效遮蔽区间'; end
    xv = [];
    yv = [];
    for i=1:size(intervals,1)
        xv = [xv, intervals(i,1), intervals(i,2), intervals(i,2), intervals(i,1), NaN];
        yv = [yv, yLim(1), yLim(1), yLim(2), yLim(2), NaN];
    end
    try
        if isempty(labelText)
            patch(xv,yv,cBand,'FaceAlpha',0.30,'EdgeColor','none');
        else
            patch(xv,yv,cBand,'FaceAlpha',0.30,'EdgeColor','none','DisplayName',labelText);
        end
    catch
        try
            if isempty(labelText)
                patch(xv,yv,cBand,'EdgeColor','none');
            else
                patch(xv,yv,cBand,'EdgeColor','none','DisplayName',labelText);
            end
        catch
            patch(xv,yv,cBand);
        end
    end
end
