%% 只画问题1的图（不重算）
%%   数据由 question_1.m 在北太天元终端跑一次生成 problem1_result.mat
load('problem1_result.mat');
if ~exist('imgDir','var'), imgDir = pwd; end

%% 重建运动方程（由已保存的参数还原，数值与 question_1.m 完全一致）
vM=300; vF1=120; g=9.8; gVec=[0,0,-g]; vCloud=[0,0,-3];
eM1=(O-M10)/norm(O-M10); vM1=vM*eM1;
M1=@(t) M10+vM1.*t;
eF1=[-1,0,0]; vF1Vec=vF1*eF1;
F1=@(t) F10+vF1Vec.*t;
P11=@(t) P011+vF1Vec.*(t-td11)+0.5.*gVec.*(t-td11).^2;
C11=@(t) Pb11+vCloud.*(t-tb11);

%% ---- 以下绘图段与 question_1.m 完全一致 ----

% 统一配色
cM1    = btC(2);   % 导弹 红  #E86452
cFY1   = btC(1);   % 无人机 蓝 #42A5F5
cShell = btC(3);   % 烟幕弹 黄 #F6BD16
cCloud = btC(5);   % 云团 绿  #9CCC65
cTgt   = btC(4);   % 假目标 紫 #7E57C2
cDrop  = btC(6);   % 投放点 青 #24A0CC
cBurst = btC(7);   % 起爆点 深红 #B71C1C
cBand  = btTint(5,0.65);  % 有效区间底色（浅绿）


% ---- 图1：烟幕弹运动轨迹（x-z 侧视图） ----
fig1 = btNewFigure('图1 烟幕弹运动轨迹（侧视）', [100,100,860,620]);
hold on; btGrid(); btBox();

tUAV   = linspace(0,td11,50);
tShell = linspace(td11,tb11,100);
tCloud = linspace(tb11,tEnd,100);

uavPos   = sampleTrajectory(F1,tUAV);
shellPos = sampleTrajectory(P11,tShell);
cloudPos = sampleTrajectory(C11,tCloud);

plot3(uavPos(:,1),uavPos(:,2),uavPos(:,3),'-','Color',cFY1,'LineWidth',2.4,...
      'DisplayName','无人机飞行轨迹');
plot3(shellPos(:,1),shellPos(:,2),shellPos(:,3),'-','Color',cShell,'LineWidth',2.6,...
      'DisplayName','烟幕弹平抛轨迹');
plot3(cloudPos(:,1),cloudPos(:,2),cloudPos(:,3),'-','Color',cCloud,'LineWidth',2.6,...
      'DisplayName','烟幕云团下沉轨迹');

scatter3(F10(1),F10(2),F10(3),90,cFY1,'filled','DisplayName','无人机初始位置');
scatter3(P011(1),P011(2),P011(3),90,cDrop,'filled','DisplayName','投放点');
scatter3(Pb11(1),Pb11(2),Pb11(3),120,cBurst,'filled','DisplayName','起爆点');

view(0,0);
btGrid(); btBox();   % view 之后再设一次：三维图必须有网格和方框才立体
xlabel('x / m','FontSize',18); ylabel('y / m','FontSize',18); zlabel('z / m','FontSize',18);
title('图1  烟幕弹投放→爆炸→云团下沉轨迹（侧视图）','FontSize',21);
legend('Location','best','FontSize',15);
% 去掉 axis equal：否则 y 方向被压成窄条，坐标区填不满画面

xAll = [F10(1),P011(1),Pb11(1),cloudPos(:,1)'];
zAll = [F10(3),P011(3),Pb11(3),cloudPos(:,3)'];
xlim([min(xAll)-200, max(xAll)+200]);
zlim([min(zAll)-200, max(zAll)+200]);
ylim([-10,10]);

btExportFig(fig1,fullfile(imgDir,'图1_烟幕弹运动轨迹.png'));

% ---- 图2：距离 d(t) 随时间变化（含有效遮蔽区间） ----
fig2 = btNewFigure('图2 烟幕中心到视线的距离', [200,200,860,540]);
hold on; btGrid(); btBox();

plot(tGrid,distanceGrid,'-','Color',cFY1,'LineWidth',2.2,'DisplayName','d_{11}(t)');
yline(10,'--','Color',btGray()*0.75,'LineWidth',1.6,'DisplayName','R = 10 m');

if ~isempty(intervals)
    yLim = ylim;
    btShadePatch(intervals,yLim,cBand,'有效遮蔽区间');
end

xlabel('时间 t / s','FontSize',18);
ylabel('距离 d_{11}(t) / m','FontSize',18);
title('图2  烟幕中心到“导弹—真目标”视线的距离','FontSize',21);
legend('Location','best','FontSize',15);
ylim([0,max(distanceGrid)*1.12]);

btExportFig(fig2,fullfile(imgDir,'图2_烟幕中心到视线距离.png'));

% ---- 图3：三维全景（斜视角） ----
fig3 = btNewFigure('图3 第一问全景三维（斜视）', [300,100,900,700]);
hold on; btGrid(); btBox();

tMplot = linspace(0,tM1Arrive,200);
Mplot  = sampleTrajectory(M1,tMplot);
plot3(Mplot(:,1),Mplot(:,2),Mplot(:,3),'-','Color',cM1,'LineWidth',2.0,...
      'DisplayName','M1 轨迹');

uavPosAll   = sampleTrajectory(F1,linspace(0,td11,50));
shellPosAll = sampleTrajectory(P11,linspace(td11,tb11,100));
cloudPosAll = sampleTrajectory(C11,linspace(tb11,tEnd,100));

plot3(uavPosAll(:,1),uavPosAll(:,2),uavPosAll(:,3),'-','Color',cFY1,'LineWidth',2.0,...
      'DisplayName','FY1 轨迹');
plot3(shellPosAll(:,1),shellPosAll(:,2),shellPosAll(:,3),'-','Color',cShell,'LineWidth',2.2,...
      'DisplayName','烟幕弹轨迹');
plot3(cloudPosAll(:,1),cloudPosAll(:,2),cloudPosAll(:,3),'-','Color',cCloud,'LineWidth',2.2,...
      'DisplayName','云团中心轨迹');

scatter3(O(1),O(2),O(3),90,cTgt,'filled','DisplayName','假目标');
scatter3(T_plot(1),T_plot(2),T_plot(3),90,cCloud,'filled','DisplayName','真目标代表点');
scatter3(F10(1),F10(2),F10(3),70,cFY1,'filled','DisplayName','FY1 初始位置');
scatter3(P011(1),P011(2),P011(3),70,cDrop,'filled','DisplayName','投放点');
scatter3(Pb11(1),Pb11(2),Pb11(3),90,cBurst,'filled','DisplayName','起爆点');

if ~isempty(intervals)
    tShow = mean(intervals(1,:));
else
    [~,idx] = min(distanceGrid);
    tShow = tGrid(idx);
end
MtShow = M1(tShow);
CtShow = C11(tShow);
plot3([MtShow(1),T_plot(1)],[MtShow(2),T_plot(2)],[MtShow(3),T_plot(3)],...
      'k--','LineWidth',1.3,'DisplayName','视线（某时刻）');

[xs,ys,zs] = sphere(14);
btSurfBall(R*xs+CtShow(1),R*ys+CtShow(2),R*zs+CtShow(3),btGray(),0.30,'烟幕球（示意）');

view(-35,25);
btGrid(); btBox();   % view 之后再设一次：三维图必须有网格和方框才立体
xlabel('x / m','FontSize',18); ylabel('y / m','FontSize',18); zlabel('z / m','FontSize',18);
title(sprintf('图3  第一问全景三维（烟幕球时刻 t = %.2f s）',tShow),'FontSize',21);
legend('Location','best','FontSize',14);
% 去掉 axis equal：否则 y 方向被压成窄条，坐标区填不满画面
ylim([-1000,1000]);

btExportFig(fig3,fullfile(imgDir,'图3_第一问全景三维.png'));

% ---- 图4：三维全景侧视图 ----
fig4 = btNewFigure('图4 第一问全景侧视图', [400,150,900,700]);
hold on; btGrid(); btBox();

plot3(Mplot(:,1),Mplot(:,2),Mplot(:,3),'-','Color',cM1,'LineWidth',2.0,'DisplayName','M1 轨迹');
plot3(uavPosAll(:,1),uavPosAll(:,2),uavPosAll(:,3),'-','Color',cFY1,'LineWidth',2.0,...
      'DisplayName','FY1 轨迹');

scatter3(T_plot(1),T_plot(2),T_plot(3),90,cCloud,'filled','DisplayName','真目标代表点');
scatter3(F10(1),F10(2),F10(3),70,cFY1,'filled','DisplayName','FY1 初始位置');
scatter3(P011(1),P011(2),P011(3),70,cDrop,'filled','DisplayName','投放点');
scatter3(Pb11(1),Pb11(2),Pb11(3),90,cBurst,'filled','DisplayName','起爆点');

view(0,0);
btGrid(); btBox();   % view 之后再设一次：三维图必须有网格和方框才立体
xlabel('x / m','FontSize',18); ylabel('y / m','FontSize',18); zlabel('z / m','FontSize',18);
title(sprintf('图4  第一问全景侧视图（烟幕球时刻 t = %.2f s）',tShow),'FontSize',21);
legend('Location','best','FontSize',14);
% 去掉 axis equal：否则 y 方向被压成窄条，坐标区填不满画面

xlim([min(Mplot(:,1))-500, max(Mplot(:,1))+500]);
zLo = min([Mplot(:,3);cloudPosAll(:,3);0])-100;
zHi = max([Mplot(:,3);cloudPosAll(:,3);T_plot(3)])+100;
zlim([zLo,zHi]);
ylim([-500,500]);

btExportFig(fig4,fullfile(imgDir,'图4_第一问全景侧视图.png'));

fprintf('\n问题1 的 4 张图已生成，输出目录：\n  %s\n', imgDir);
