function btSurfBall(X,Y,Z,faceColor,alphaVal,dispName)
% btSurfBall  画半透明球面 / 曲面（北太天元兼容）
%   FaceAlpha 或 DisplayName 不被支持时自动降级重试，保证图形能画出来。
    if nargin < 5 || isempty(alphaVal), alphaVal = 0.35; end
    if nargin < 6, dispName = ''; end
    try
        if isempty(dispName)
            surf(X,Y,Z,'FaceColor',faceColor,'FaceAlpha',alphaVal,'EdgeColor','none');
        else
            surf(X,Y,Z,'FaceColor',faceColor,'FaceAlpha',alphaVal,'EdgeColor','none', ...
                 'DisplayName',dispName);
        end
    catch
        try
            if isempty(dispName)
                surf(X,Y,Z,'FaceColor',faceColor,'EdgeColor','none');
            else
                surf(X,Y,Z,'FaceColor',faceColor,'EdgeColor','none','DisplayName',dispName);
            end
        catch
            try
                surf(X,Y,Z,'FaceColor',faceColor);
            catch
                surf(X,Y,Z);
            end
        end
    end
end
