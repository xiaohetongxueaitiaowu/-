function c = btTint(k,amount)
% btTint  取北太天元色板第 k 色的浅色版本（amount 越大越浅，0~1）
%   用于「有效遮蔽区间」这类半透明底色。
    if nargin < 2 || isempty(amount), amount = 0.65; end
    c = btC(k)*(1-amount) + amount;
end
