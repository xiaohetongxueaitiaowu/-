function btFont(sz)
% btFont  设置当前坐标区的刻度/文字字号（北太天元兼容）
%   北太天元不支持 set(0,'defaultAxesFontSize',...) 和 set(gca,...)，
%   但帮助文档里提供了 fontsize 函数，这里优先用它，失败再退回 set。
    global BT_FONTSIZE
    if nargin < 1 || isempty(sz)
        if isempty(BT_FONTSIZE), sz = 16; else, sz = BT_FONTSIZE; end
    end
    try
        fontsize(gca,sz);
        return;
    catch
    end
    try
        set(gca,'FontSize',sz);
    catch
    end
end
