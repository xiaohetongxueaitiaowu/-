function [d2,lam] = btCircleEval(th,Mt,Ct,center,r,z)
% btCircleEval  向量化计算圆周(高度z)上各角度对应的投影参数 lam 与垂距平方 d2
%   等价于逐点调用 coverGeometry(t,M1,C11,P)，但一次算完整个角度向量。
    px = center(1) + r*cos(th);
    py = center(2) + r*sin(th);
    pz = center(3) + z;

    vx = px - Mt(1);
    vy = py - Mt(2);
    vz = pz - Mt(3);        % v = T - M1

    wx = Ct(1) - Mt(1);
    wy = Ct(2) - Mt(2);
    wz = Ct(3) - Mt(3);     % w = C - M1

    vv  = vx.*vx + vy.*vy + vz.*vz;
    lam = (wx.*vx + wy.*vy + wz.*vz)./vv;

    hx = Mt(1) + lam.*vx;
    hy = Mt(2) + lam.*vy;
    hz = Mt(3) + lam.*vz;   % 垂足 H

    dx = Ct(1) - hx;
    dy = Ct(2) - hy;
    dz = Ct(3) - hz;
    d2 = dx.*dx + dy.*dy + dz.*dz;
end
