function f = btFontName()
% btFontName  返回绘图用中文字体
%
%   优先级：
%     1) 全局变量 BT_FONT 指定的字体（用 global BT_FONT; BT_FONT='字体名'; 强制指定）
%     2) 汉仪文黑 85W（如果系统装了）
%     3) 北太天元自带的思源黑体 Source Han Sans CN
%        —— 北太天元图形模块内部写死的默认字体就是它
%     4) 苹方 PingFang SC / 黑体 Heiti SC
%     5) Helvetica（兜底）
%
%   想换字体：在运行渲染脚本前执行
%       global BT_FONT; BT_FONT = '汉仪文黑85W';
    global BT_FONT
    f = 'Helvetica';
    try
        if ~isempty(BT_FONT)
            f = BT_FONT;
            return;
        end
        lst = listfonts;
        cand = {'汉仪文黑85W','汉仪文黑 85W','Hanyi WenHei 85W','HanyiWenHei85W', ...
                'Source Han Sans CN','PingFang SC','Heiti SC','STHeiti'};
        for k = 1:numel(cand)
            if any(strcmp(lst,cand{k}))
                f = cand{k};
                return;
            end
        end
    catch
        f = 'Helvetica';
    end
end
