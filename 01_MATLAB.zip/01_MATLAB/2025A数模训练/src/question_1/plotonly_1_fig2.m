%% 问题1 - 图2：烟幕中心到视线距离
%%   本脚本只画这一张图。画完请「文件→另存为」保存，然后关掉窗口，再跑下一张。
clear; clc;
[~,imgDir] = btInit();
load('problem1_result.mat');
if ~exist('imgDir','var'), imgDir = pwd; end
%% 重建运动方程
vM=300; vF1=120; g=9.8; gVec=[0,0,-g]; vCloud=[0,0,-3];
eM1=(O-M10)/norm(O-M10); vM1=vM*eM1; M1=@(t) M10+vM1.*t;
eF1=[-1,0,0]; vF1Vec=vF1*eF1; F1=@(t) F10+vF1Vec.*t;
P11=@(t) P011+vF1Vec.*(t-td11)+0.5.*gVec.*(t-td11).^2;
C11=@(t) Pb11+vCloud.*(t-tb11);
%% 统一配色（北太天元色板）
cM1    = btC(2);   % 导弹 红
cFY1   = btC(1);   % 无人机 蓝
cShell = btC(3);   % 烟幕弹 黄
cCloud = btC(5);   % 云团 绿
cTgt   = btC(4);   % 假目标 紫
cDrop  = btC(6);   % 投放点 青
cBurst = btC(7);   % 起爆点 深红
cBand  = btTint(5,0.65);  % 有效区间底色


% ---- 图2：距离 d(t) 随时间变化（含有效遮蔽区间） ----
fig2 = btNewFigure('图2 烟幕中心到视线的距离', [200,200,860,540]);
hold on; btGrid(); btBox();

plot(tGrid,distanceGrid,'-','Color',cFY1,'LineWidth',2.2,'DisplayName','d_{11}(t)');
yline(10,'--','Color',btGray()*0.75,'LineWidth',1.6,'DisplayName','R = 10 m');

if ~isempty(intervals)
    yLim = ylim;
    btShadePatch(intervals,yLim,cBand,'有效遮蔽区间');
end

xlabel('时间 t / s','FontSize',18);
ylabel('距离 d_{11}(t) / m','FontSize',18);
title('图2  烟幕中心到“导弹—真目标”视线的距离','FontSize',21);
legend('Location','best','FontSize',15);
ylim([0,max(distanceGrid)*1.12]);

btExportFig(fig2,fullfile(imgDir,'图2_烟幕中心到视线距离.png'));

disp('图已画好 —— 请用「文件→另存为」保存，然后关掉窗口再跑下一张。');
