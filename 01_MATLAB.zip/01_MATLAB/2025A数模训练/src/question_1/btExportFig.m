function ok = btExportFig(fig,filePath,resolution)
% btExportFig  把图形窗口导出成 PNG
%
% ============================ 重要 ============================
%  默认【不自动导出】！
%  北太天元的 print / saveas 有可能弹出「打印对话框」或「保存对话框」，
%  而对话框是模态的 —— 一旦弹在窗口后面，整个界面看起来就像卡死了。
%  所以这里默认什么都不做，只把图留在屏幕上，由主人自己保存。
%
%  如果确认环境支持自动导出，再手动打开：
%      global BT_EXPORT_MODE; BT_EXPORT_MODE = 'auto';    % 试 exportgraphics -> saveas
%      global BT_EXPORT_MODE; BT_EXPORT_MODE = 'print';   % 再额外试 print
% =============================================================
    global BT_IMG_DIR BT_EXPORT_MODE

    if nargin < 3 || isempty(resolution)
        resolution = 200;
    end

    if isempty(BT_EXPORT_MODE)
        BT_EXPORT_MODE = 'none';          % ← 默认：只画图，不碰任何导出函数
    end

    if strcmp(BT_EXPORT_MODE,'none')
        ok = 0;
        return;
    end

    if isempty(strfind(filePath,filesep))
        if ~isempty(BT_IMG_DIR)
            filePath = fullfile(BT_IMG_DIR,filePath);
        end
    end

    ok = 0;
    if ok == 0 && exist('exportgraphics') ~= 0 && ~strcmp(BT_EXPORT_MODE,'print')
        try
            exportgraphics(fig,filePath,'Resolution',resolution);
            ok = 1;
        catch
            ok = 0;
        end
    end
    if ok == 0 && exist('saveas') ~= 0
        try
            saveas(fig,filePath);
            ok = 1;
        catch
            ok = 0;
        end
    end
    if ok == 0 && strcmp(BT_EXPORT_MODE,'print') && exist('print') ~= 0
        try
            print(fig,filePath,'-dpng',sprintf('-r%d',resolution));
            ok = 1;
        catch
            ok = 0;
        end
    end

    if ok == 1
        fprintf('    [已导出图片] %s\n', filePath);
    end
end
