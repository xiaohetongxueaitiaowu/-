function c = btGray()
% btGray  中性灰（用于烟幕球face这类不抢视觉的辅助面）
    c = [0.62 0.64 0.66];
end
