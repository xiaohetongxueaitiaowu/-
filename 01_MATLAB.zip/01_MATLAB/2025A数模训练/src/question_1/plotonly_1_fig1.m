%% 问题1 - 图1：烟幕弹运动轨迹
%%   本脚本只画这一张图。画完请「文件→另存为」保存，然后关掉窗口，再跑下一张。
clear; clc;
[~,imgDir] = btInit();
load('problem1_result.mat');
if ~exist('imgDir','var'), imgDir = pwd; end
%% 重建运动方程
vM=300; vF1=120; g=9.8; gVec=[0,0,-g]; vCloud=[0,0,-3];
eM1=(O-M10)/norm(O-M10); vM1=vM*eM1; M1=@(t) M10+vM1.*t;
eF1=[-1,0,0]; vF1Vec=vF1*eF1; F1=@(t) F10+vF1Vec.*t;
P11=@(t) P011+vF1Vec.*(t-td11)+0.5.*gVec.*(t-td11).^2;
C11=@(t) Pb11+vCloud.*(t-tb11);
%% 统一配色（北太天元色板）
cM1    = btC(2);   % 导弹 红
cFY1   = btC(1);   % 无人机 蓝
cShell = btC(3);   % 烟幕弹 黄
cCloud = btC(5);   % 云团 绿
cTgt   = btC(4);   % 假目标 紫
cDrop  = btC(6);   % 投放点 青
cBurst = btC(7);   % 起爆点 深红
cBand  = btTint(5,0.65);  % 有效区间底色


% ---- 图1：烟幕弹运动轨迹（x-z 侧视图） ----
fig1 = btNewFigure('图1 烟幕弹运动轨迹（侧视）', [100,100,860,620]);
hold on; btGrid(); btBox();

tUAV   = linspace(0,td11,50);
tShell = linspace(td11,tb11,100);
tCloud = linspace(tb11,tEnd,100);

uavPos   = sampleTrajectory(F1,tUAV);
shellPos = sampleTrajectory(P11,tShell);
cloudPos = sampleTrajectory(C11,tCloud);

plot3(uavPos(:,1),uavPos(:,2),uavPos(:,3),'-','Color',cFY1,'LineWidth',2.4,...
      'DisplayName','无人机飞行轨迹');
plot3(shellPos(:,1),shellPos(:,2),shellPos(:,3),'-','Color',cShell,'LineWidth',2.6,...
      'DisplayName','烟幕弹平抛轨迹');
plot3(cloudPos(:,1),cloudPos(:,2),cloudPos(:,3),'-','Color',cCloud,'LineWidth',2.6,...
      'DisplayName','烟幕云团下沉轨迹');

scatter3(F10(1),F10(2),F10(3),90,cFY1,'filled','DisplayName','无人机初始位置');
scatter3(P011(1),P011(2),P011(3),90,cDrop,'filled','DisplayName','投放点');
scatter3(Pb11(1),Pb11(2),Pb11(3),120,cBurst,'filled','DisplayName','起爆点');

view(0,0);
btGrid(); btBox();   % view 之后再设一次：三维图必须有网格和方框才立体
xlabel('x / m','FontSize',18); ylabel('y / m','FontSize',18); zlabel('z / m','FontSize',18);
title('图1  烟幕弹投放→爆炸→云团下沉轨迹（侧视图）','FontSize',21);
legend('Location','best','FontSize',15);
% 去掉 axis equal：否则 y 方向被压成窄条，坐标区填不满画面

xAll = [F10(1),P011(1),Pb11(1),cloudPos(:,1)'];
zAll = [F10(3),P011(3),Pb11(3),cloudPos(:,3)'];
xlim([min(xAll)-200, max(xAll)+200]);
zlim([min(zAll)-200, max(zAll)+200]);
ylim([-10,10]);

btExportFig(fig1,fullfile(imgDir,'图1_烟幕弹运动轨迹.png'));

disp('图已画好 —— 请用「文件→另存为」保存，然后关掉窗口再跑下一张。');
