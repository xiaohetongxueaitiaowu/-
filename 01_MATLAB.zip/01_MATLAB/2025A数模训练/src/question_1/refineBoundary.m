function tBoundary=refineBoundary(tLeft,tRight,leftFlag,M1,C11,R,cyl_params)
% 二分法定位遮蔽状态变化时刻
    while (tRight-tLeft)>1e-8
        tMid=0.5*(tLeft+tRight);
        midFlag=isCoveredCylinder(tMid,M1,C11,R,cyl_params);

        if midFlag==leftFlag
            tLeft=tMid;
        else
            tRight=tMid;
        end
    end
    tBoundary=0.5*(tLeft+tRight);
end