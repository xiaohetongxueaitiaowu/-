function X = repair_decision(X, lb, ub, cfg)
%REPAIR_DECISION 将模拟退火候选解修复到物理可行域。

X = reshape(X,1,[]);

% 航向角周期归一化至[-pi,pi)
X(1) = atan2(sin(X(1)),cos(X(1)));

% 其余变量截断到边界
X(2:4) = btMinAB(ub(2:4),max(lb(2:4),X(2:4)));

% 起爆必须发生在M1到达假目标之前
X(3) = min(X(3),cfg.tM1Arrive);
X(4) = min(X(4),max(0,cfg.tM1Arrive-X(3)));

% 起爆点高度不得低于地面
tauHeightMax = sqrt(2*cfg.F10(3)/cfg.g);
X(4) = min(X(4),tauHeightMax);
end

