function tf = btWant(k)
% btWant  恒返回 true
%   【为什么】之前想靠 if btWant(k) 跳过不画的图段，结果各图段之间共用变量
%   （例如问题2 的图1/图2 段算了 MPlot，图3 段要用），一跳就报未定义变量。
%   现在改成：代码全跑（变量齐全），只由 btNewFigure 把「不用画的那几张」
%   建成隐藏窗口并及时关掉，界面上永远只有一个可见图窗。
    tf = true;
end
