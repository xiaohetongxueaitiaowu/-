function X = random_feasible_decision(lb, ub, cfg)
%RANDOM_FEASIBLE_DECISION 随机生成一个物理可行决策向量。

X = lb+(ub-lb).*rand(1,4);
X = repair_decision(X,lb,ub,cfg);
end

