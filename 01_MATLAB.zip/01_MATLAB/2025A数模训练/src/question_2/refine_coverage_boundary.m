function tBoundary = refine_coverage_boundary(tLeft,tRight,leftFlag, ...
    X,cfg,Q,tol)
%REFINE_COVERAGE_BOUNDARY 用二分法精化遮蔽状态变化时刻。

while tRight-tLeft>tol
    tMid=0.5*(tLeft+tRight);
    midFlag=cylinder_covered_at_times(tMid,X,cfg,Q);
    if midFlag==leftFlag
        tLeft=tMid;
    else
        tRight=tMid;
    end
end
tBoundary=0.5*(tLeft+tRight);
end

