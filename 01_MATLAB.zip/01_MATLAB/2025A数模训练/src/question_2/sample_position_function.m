function xyz=sample_position_function(fun,t)
% 对只接受标量时间的三维位置函数进行采样
    xyz=zeros(numel(t),3);
    for i=1:numel(t)
        xyz(i,:)=fun(t(i));
    end
end