function btPatchFade(xv,yv,faceColor,alphaVal,dispName)
% btPatchFade  画半透明色块（北太天元兼容，FaceAlpha 不支持时自动降级）
    if nargin < 4 || isempty(alphaVal), alphaVal = 0.5; end
    if nargin < 5, dispName = ''; end
    try
        if isempty(dispName)
            patch(xv,yv,faceColor,'EdgeColor','none','FaceAlpha',alphaVal);
        else
            patch(xv,yv,faceColor,'EdgeColor','none','FaceAlpha',alphaVal,'DisplayName',dispName);
        end
    catch
        try
            if isempty(dispName)
                patch(xv,yv,faceColor,'EdgeColor','none');
            else
                patch(xv,yv,faceColor,'EdgeColor','none','DisplayName',dispName);
            end
        catch
            patch(xv,yv,faceColor);
        end
    end
end
