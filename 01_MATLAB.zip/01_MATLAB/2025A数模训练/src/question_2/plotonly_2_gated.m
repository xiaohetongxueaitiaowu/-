% 按 BT_FIG_ONLY 只画指定的一张（供单图入口调用）
L=load('problem2_sa_result.mat'); r=L.result;
cfg=problem2_default_config();
Qfinal=make_cylinder_target_points(cfg,72,9,4);
cv=readmatrix('problem2_sa_convergence.csv');
c1=cv(:,2); c1=c1(~isnan(c1)); c2=cv(:,3); c2=c2(~isnan(c2));
stage1=struct('X',r.Xbest,'cost',-r.Teff,'history',struct('bestCost',c1));
stage2=struct('X',r.Xbest,'cost',-r.Teff,'history',struct('bestCost',c2));
plot_problem2_sa_result(r.Xbest,cfg,Qfinal,0.02,r.intervals,stage1,stage2);
