function h = btSgTitle(txt,fontSize)
% btSgTitle  北太天元没有 sgtitle，这里用隐藏坐标轴在上方居中写标题
    if nargin < 2 || isempty(fontSize), fontSize = 12; end
    h = axes('Position',[0,0.945,1,0.05],'Visible','off');
    text(0.5,0.5,txt,'HorizontalAlignment','center', ...
         'VerticalAlignment','middle','FontSize',fontSize,'FontWeight','bold');
end
