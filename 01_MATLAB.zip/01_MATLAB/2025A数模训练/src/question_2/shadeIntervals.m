function shadeIntervals(intervals)
% 在当前坐标轴中用浅绿色标出有效遮蔽区间
% 北太天元适配：不使用坐标轴句柄传递、不使用 uistack、不使用 HandleVisibility，
%              并且整段区间用「单个」patch 对象绘制（避免图例里出现一堆条目）。
    if isempty(intervals)
        return;
    end
    yLimits = ylim;
    btShadePatch(intervals,yLimits,[0.68,0.92,0.74]);
end
