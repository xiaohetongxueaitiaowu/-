function cfg=problem2_default_config()
% 问题2的一些固定参数
    cfg.O=[0,0,0];
    cfg.M10=[20000,0,2000];
    cfg.F10=[17800,0,1800];

    cfg.vM=300;
    cfg.g=9.8;
    cfg.vCloud=3;
    cfg.smokeR=10;
    cfg.cloudLife=20;

    cfg.targetCenterXY=[0,200];
    cfg.targetR=7;
    cfg.targetH=10;

    cfg.eM1=(cfg.O-cfg.M10)/norm(cfg.O-cfg.M10);
    cfg.vM1=cfg.vM*cfg.eM1;
    cfg.tM1Arrive=norm(cfg.O-cfg.M10)/cfg.vM;

    cfg.timeChunk=100;
end