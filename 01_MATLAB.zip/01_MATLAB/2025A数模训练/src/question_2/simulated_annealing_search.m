function [bestX,bestCost,history] = simulated_annealing_search( ...
    objective,x0,lb,ub,cfg,opt)
%SIMULATED_ANNEALING_SEARCH 自编有界模拟退火算法。

currentX=repair_decision(x0,lb,ub,cfg);
currentCost=objective(currentX);
bestX=currentX;
bestCost=currentCost;

n=opt.MaxIterations;
history.currentCost=zeros(n,1);
history.bestCost=zeros(n,1);
history.temperature=zeros(n,1);
history.accepted=false(n,1);

stall=0;
reheatUntil=0;

for k=1:n
    if n==1
        progress=1;
    else
        progress=(k-1)/(n-1);
    end

    T=opt.InitialTemperature* ...
        (opt.FinalTemperature/opt.InitialTemperature)^progress;
    step=opt.InitialStep.* ...
        (opt.FinalStep./opt.InitialStep).^progress;

    % 长时间无改进时短暂升温并扩大步长。
    if k<=reheatUntil
        T=max(T,0.25*opt.InitialTemperature);
        step=max(step,0.25*opt.InitialStep);
    end

    % 小概率全局跳跃；其余情况在当前点附近高斯扰动。
    if rand<opt.GlobalJumpProbability*(1-progress)
        candidateX=random_feasible_decision(lb,ub,cfg);
    else
        candidateX=currentX+step.*randn(1,numel(currentX));
        candidateX=repair_decision(candidateX,lb,ub,cfg);
    end

    candidateCost=objective(candidateX);
    delta=candidateCost-currentCost;

    accept=(delta<=0) || (rand<exp(-delta/max(T,eps)));
    if accept
        currentX=candidateX;
        currentCost=candidateCost;
        history.accepted(k)=true;
    end

    if currentCost<bestCost
        bestX=currentX;
        bestCost=currentCost;
        stall=0;
    else
        stall=stall+1;
    end

    if stall>=opt.ReheatAfter
        currentX=bestX;
        currentCost=bestCost;
        reheatUntil=min(n,k+opt.ReheatLength);
        stall=0;
    end

    history.currentCost(k)=currentCost;
    history.bestCost(k)=bestCost;
    history.temperature(k)=T;

    if opt.DisplayEvery>0 && (mod(k,opt.DisplayEvery)==0 || k==1 || k==n)
        fprintf(['迭代%5d/%5d，T=%9.5f，当前目标=%12.6f，', ...
            '最优目标=%12.6f\n'],k,n,T,currentCost,bestCost);
    end
end

history.acceptanceRate=mean(history.accepted);
fprintf('本次退火接受率：%.2f%%\n',100*history.acceptanceRate);
end

