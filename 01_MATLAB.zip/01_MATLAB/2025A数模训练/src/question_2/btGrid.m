function btGrid()
% btGrid  按坐标区类型与风格开关决定是否显示网格
%   · 三维坐标区：默认打开网格（不加网格三维图没有立体感）
%   · 二维坐标区：默认关闭（北太天元帮助示例图都没有网格）
%   · 想全部打开（论文常见样式）：global BT_STYLE; BT_STYLE = 'paper';
    global BT_STYLE
    if isempty(BT_STYLE), BT_STYLE = 'baltamatica'; end
    is3D = false;
    try
        [az,el] = view;
        is3D = ~(abs(el-90) < 1e-6);
    catch
    end
    try
        if is3D || strcmp(BT_STYLE,'paper')
            grid on;
        else
            grid off;
        end
    catch
    end
end
