function C = btMinAB(A,B)
% btMinAB  逐元素取较小值 —— 北太天元兼容替代（等价于 MATLAB 的 min(A,B)）
%
%   背景：北太天元的 min(A,B) 在矩阵规模稍大时会返回错误结果
%         （例如 min(ones(80,10442)*5,3) 返回 5 而不是 3，等于没裁剪）。
%         这里用「逻辑索引 + 赋值」实现，且不使用任何乘法，
%         因此对 inf 元素也安全（不会出现 inf*0 = NaN）。
%
%   支持标量与数组混合（自动广播），例如 btMinAB(3, [1 5 2]) -> [1 3 2]

    if numel(A) >= numel(B)
        C = A;
        if numel(B) == 1
            D = B*ones(size(A));
        else
            D = B;
        end
    else
        C = B;
        if numel(A) == 1
            D = A*ones(size(B));
        else
            D = A;
        end
    end

    mask = D < C;
    C(mask) = D(mask);
end
