function btExportAllFigures(prefix,nameList)
% btExportAllFigures  批量导出图窗（默认关闭，见 btExportFig 的说明）
%   只有把 global BT_EXPORT_MODE 设成 'auto' 或 'print' 时才会真正导出。
    global BT_EXPORT_MODE
    if isempty(BT_EXPORT_MODE) || strcmp(BT_EXPORT_MODE,'none')
        return;
    end
    global BT_IMG_DIR
    if isempty(BT_IMG_DIR), return; end
    n = min(numel(nameList),20);
    for k = 1:n
        if isempty(findobj('Type','figure','Number',k)), continue; end
        try
            f = figure(k);
            fileName = sprintf('%s_%02d_%s.png',prefix,k,nameList{k});
            btExportFig(f,fullfile(BT_IMG_DIR,fileName));
        catch
        end
    end
end
