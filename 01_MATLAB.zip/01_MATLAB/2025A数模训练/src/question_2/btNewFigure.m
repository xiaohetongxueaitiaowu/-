function f = btNewFigure(figName,pos)
% btNewFigure  创建图窗
%   · 默认配色与北太天元一致（#F7F7F7 浅灰底）
%   · 全局 BT_FIG_ONLY = k 时：只让第 k 张图可见，其余建为隐藏窗口并顺手关掉，
%     这样界面上永远只有一个图窗（北太天元同时开多窗会崩）。
    global BT_FIG_BG BT_FIG_ONLY BT_FIG_COUNT BT_LAST_HIDDEN

    if nargin < 2 || isempty(pos)
        pos = [100 100 900 650];
    end
    if nargin < 1 || isempty(figName)
        figName = '';
    end
    bg = [247 247 247]/255;
    if ~isempty(BT_FIG_BG)
        bg = BT_FIG_BG;
    end

    if isempty(BT_FIG_COUNT), BT_FIG_COUNT = 0; end
    BT_FIG_COUNT = BT_FIG_COUNT + 1;
    want = isempty(BT_FIG_ONLY) || (BT_FIG_COUNT == BT_FIG_ONLY);

    % 关掉上一张「不用画」的隐藏窗口，避免窗口堆积
    if ~isempty(BT_LAST_HIDDEN)
        try, close(BT_LAST_HIDDEN); catch, end
        BT_LAST_HIDDEN = [];
    end

    f = [];
    if want
        try
            f = figure('Color',bg,'Name',figName,'Position',pos);
        catch
            try
                f = figure('Color',bg,'Position',pos);
            catch
                try
                    f = figure('Color',bg);
                catch
                    f = figure;
                end
            end
        end
    else
        try
            f = figure('Color',bg,'Visible','off','Position',pos);
        catch
            try
                f = figure('Visible','off','Position',pos);
            catch
                f = figure('Visible','off');
            end
        end
        BT_LAST_HIDDEN = f;
    end
end
