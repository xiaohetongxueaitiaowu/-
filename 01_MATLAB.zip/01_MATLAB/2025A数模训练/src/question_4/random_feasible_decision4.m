function X=random_feasible_decision4(lb,ub,cfg)
% 在边界内均匀随机生成一个可行解
    X=lb+(ub-lb).*rand(1,12);
    X=repair_decision4(X,lb,ub,cfg);
end