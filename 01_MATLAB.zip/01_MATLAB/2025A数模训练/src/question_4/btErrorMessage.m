function message = btErrorMessage(err)
% 北太天元 catch 返回错误文本，MATLAB catch 返回 MException 对象。
    if ischar(err) || isstring(err)
        message = char(err);
    else
        try
            message = char(err.message);
        catch
            message = '绘图模块发生错误，请查看命令窗口中的详细信息。';
        end
    end
end
