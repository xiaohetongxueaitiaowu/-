% 只画问题4的图（诊断信息重新算一遍，约 20 秒，比跑优化快得多）
plotDir = fileparts(mfilename('fullpath'));
if ~isempty(plotDir), addpath(plotDir); cd(plotDir); end
[DO_PLOT,BT_IMG_DIR] = btInit();
if ~DO_PLOT
    error('请在北太天元图形界面运行 plotonly_4；命令行批处理模式没有绘图函数。');
end
try, close all; catch, end
global BT_FIG_COUNT BT_LAST_HIDDEN BT_FIG_ONLY
BT_FIG_COUNT = 0; BT_LAST_HIDDEN = []; BT_FIG_ONLY = [];
L=load('problem4_sa_result.mat'); r=L.result;
cfg=problem4_default_config();
Q=make_cylinder_target_points4(cfg,72,9,4); dt=0.04;
[~,iv,fd]=evaluate_cooperative_duration4(r.Xbest,cfg,Q,dt,1e-6);
cv=readmatrix('problem4_cpso_convergence.csv');
c1=cv(:,2); c1=c1(~isnan(c1)); c2=cv(:,3); c2=c2(~isnan(c2)); c3=cv(:,4); c3=c3(~isnan(c3));
h=struct('bestCost',c3);
s1=struct('X',r.Xbest,'cost',-r.Teff,'history',struct('bestCost',c1));
s2=struct('X',r.Xbest,'cost',-r.Teff,'history',struct('bestCost',c2));
s3=struct('X',r.Xbest,'cost',-r.Teff,'history',h);
plot_problem4_sa_result(r.Xbest,cfg,Q,dt,iv,s1,s2,s3,fd);
fprintf('问题4 的图已画好（%d 张），请用图形窗口的「文件→另存为」保存。\n',6+size(iv,1));
