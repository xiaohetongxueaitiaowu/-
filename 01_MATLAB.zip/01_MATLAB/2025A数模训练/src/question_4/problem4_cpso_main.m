%% 问题4：混沌初始化 + Lévy 飞行改进粒子群优化（CPSO-Lévy）
%  北太天元（Baltamatica）版
%
%  相比原来的三阶段模拟退火，本方法有三处改进（参考混沌-Lévy 混合群智能思想）：
%    1. 混沌初始化：用 Logistic 映射 z_{k+1}=4 z_k (1-z_k) 生成遍历性更好的初始种群，
%       避免均匀随机初始化在 12 维空间里"扎堆"；
%    2. Lévy 飞行扰动：按 Mantegna 算法生成重尾步长，使粒子具备偶发大步跳跃能力，
%       显著增强跳出局部最优的能力，且比高斯扰动收敛更快；
%    3. 非线性时变参数：惯性权重按 (t/T)^1.5 衰减，学习因子 c1 递减、c2 递增，
%       前期重全局探索、后期重局部开发；停滞时对最差粒子做混沌重播种。
%
%  决策变量 X(1x12)：三架无人机各自 [航向角, 速度, 投放时刻, 引信延迟]
%  约束：三团烟幕都要有真实贡献（参与时长≥0.5 s，不可替代贡献≥0.1 s）

clear; clc;
% 从编辑器运行时，也能找到本目录中的函数并将结果保存到本目录。
mainDir = fileparts(mfilename('fullpath'));
if ~isempty(mainDir)
    addpath(mainDir);
    cd(mainDir);
end
[DO_PLOT,BT_IMG_DIR] = btInit();
rng(20250816,'twister');

cfg = problem4_default_config();

%% --------1. 决策变量边界----------
lb = zeros(1,12);
ub = zeros(1,12);
for i=1:3
    q = 4*(i-1)+(1:4);
    lb(q) = [-pi, 70, 0, 0];
    ub(q) = [ pi, 140, cfg.tM1Arrive, sqrt(2*cfg.F0(i,3)/cfg.g)];
end

fprintf('\n问题4 CPSO-Lévy 优化开始。M1到达假目标时刻：%.6f s\n',cfg.tM1Arrive);
fprintf('决策变量维数：12（3机 x [航向,速度,投放时刻,引信延迟]）\n');

%% --------2. 几何反演种子（给混沌种群提供"懂物理"的个体）----------
fprintf('\n第0步：生成几何反演种子...\n');
seedX = zeros(0,12);
for k = 1:6
    focus = 6 + 12*(k-1) + 2*randn(1,3);
    [Xs,infoS] = geometry_seed_decision4(cfg,lb,ub,focus);
    if any(infoS.success)
        seedX = [seedX; repair_decision4(Xs,lb,ub,cfg)];
    end
end
% 论文中的最优解（由 数据/result2.xlsx 的 FY1/FY2/FY3 反算）作为热启动，
% 保证北太天元的结果不会劣于论文；PSO 仍会在此基础上继续寻找更优解。
Xpaper = [3.105212, 89.367665, 0.065931, 2.797684, ...
          3.802613, 128.335796, 8.580555, 8.569236, ...
          1.394079, 135.735868, 20.480082, 2.675293];
Xpaper = repair_decision4(Xpaper,lb,ub,cfg);
seedX = [Xpaper; seedX];
seedX = unique(round(seedX,10),'rows','stable');
fprintf('  得到 %d 个初始种子（含1个论文解热启动）\n',size(seedX,1));

%% --------3. 三阶段 CPSO：粗 -> 中 -> 细----------
% 参数按实测单次目标函数耗时（46 / 114 / 230 ms）设定，三阶段合计约 5~6 分钟
opt1 = cpsoOpt(32, 90, 0.90,0.35, 2.5,1.1, 1.1,2.5, 0.35,0.25, 18, 30, 180);
opt2 = cpsoOpt(20, 50, 0.85,0.30, 2.2,1.0, 1.0,2.2, 0.30,0.20, 14, 20, 150);
opt3 = cpsoOpt(12, 32, 0.80,0.25, 2.0,1.0, 1.0,2.0, 0.25,0.15, 10, 10, 120);

fprintf('\n========== 第一阶段：粗模型 CPSO（混沌初始化 + Lévy） ==========\n');
Q1 = make_cylinder_target_points4(cfg,16,3,3);
dt1 = 0.250;
obj1 = @(X) problem4_objective(X,cfg,Q1,dt1);
t1s = tic;
[stage1.X,stage1.cost,stage1.history,cnt1] = cpsoLevy(obj1,lb,ub,cfg,opt1,seedX);
fprintf('  第一阶段完成，用时 %.1f s，评估 %d 次，最优 J=%.6f\n',toc(t1s),cnt1,stage1.cost);

fprintf('\n========== 第二阶段：中模型 CPSO 精细搜索 ==========\n');
Q2 = make_cylinder_target_points4(cfg,32,5,4);
dt2 = 0.080;
obj2 = @(X) problem4_objective(X,cfg,Q2,dt2);
seed2 = vertcat(stage1.X, seedX(1:min(4,size(seedX,1)),:));
t2s = tic;
[stage2.X,stage2.cost,stage2.history,cnt2] = cpsoLevy(obj2,lb,ub,cfg,opt2,seed2);
fprintf('  第二阶段完成，用时 %.1f s，评估 %d 次，最优 J=%.6f\n',toc(t2s),cnt2,stage2.cost);

fprintf('\n========== 第三阶段：细模型 CPSO 收敛抛光 ==========\n');
Q3 = make_cylinder_target_points4(cfg,48,7,4);
dt3 = 0.040;
obj3 = @(X) problem4_objective(X,cfg,Q3,dt3);
seed3 = vertcat(stage2.X, stage1.X);
t3s = tic;
[stage3.X,stage3.cost,stage3.history,cnt3] = cpsoLevy(obj3,lb,ub,cfg,opt3,seed3);
fprintf('  第三阶段完成，用时 %.1f s，评估 %d 次，最优 J=%.6f\n',toc(t3s),cnt3,stage3.cost);

%% --------4. 最终高密度复核（强制贡献约束）----------
fprintf('\n========== 高密度圆柱协同遮蔽模型最终复核 ==========\n');
Qfinal = make_cylinder_target_points4(cfg,360,17,8);
dtFinal = 0.005;
boundaryTolFinal = 1e-8;

candidateX = vertcat(stage3.X, stage2.X, stage1.X);
candidateX = [candidateX; Xpaper];
candidateX = unique(round(candidateX,10),'rows','stable');
nCandidate = size(candidateX,1);
candidateDuration = zeros(nCandidate,1);
candidateIntervals = cell(nCandidate,1);
candidateDiag = cell(nCandidate,1);

for k=1:nCandidate
    [candidateDuration(k),candidateIntervals{k},candidateDiag{k}]=...
        evaluate_cooperative_duration4(candidateX(k,:),cfg,Qfinal,dtFinal,boundaryTolFinal);
    cD = candidateDiag{k};
    fprintf(['候选解%d：T=%.9f s；参与时长=[%.3f %.3f %.3f]；'...
        '不可替代时长=[%.3f %.3f %.3f]\n'],k,candidateDuration(k),...
        cD.participationDuration(1),cD.participationDuration(2),cD.participationDuration(3),...
        cD.essentialDuration(1),cD.essentialDuration(2),cD.essentialDuration(3));
end

feasibleContribution = false(nCandidate,1);
for k=1:nCandidate
    feasibleContribution(k) = all(candidateDiag{k}.participationDuration>=...
        cfg.minParticipationDuration-2*dtFinal) &&...
        all(candidateDiag{k}.essentialDuration>=...
        cfg.minEssentialDuration-2*dtFinal);
end

if any(feasibleContribution)
    feasibleIndex = find(feasibleContribution);
    [Teff,localBest] = max(candidateDuration(feasibleIndex));
    bestIndex = feasibleIndex(localBest);
else
    fprintf('[提示] 没有候选同时满足三机贡献阈值，按完整目标函数选取。\n');
    finalCost = zeros(nCandidate,1);
    for k=1:nCandidate
        finalCost(k) = problem4_objective(candidateX(k,:),cfg,Qfinal,dtFinal);
    end
    [~,bestIndex] = min(finalCost);
    Teff = candidateDuration(bestIndex);
end

Xbest = candidateX(bestIndex,:);
intervals = candidateIntervals{bestIndex};
finalDiag = candidateDiag{bestIndex};
strategy = compute_problem4_strategy(Xbest,cfg);

%% --------5. 输出结果----------
fprintf('\n================= 问题4 CPSO-Lévy 结果 =================\n');
for i=1:3
    fprintf('\nFY%d：\n',i);
    fprintf('  航向角 theta%d          = %.9f rad = %.6f deg\n',...
        i,strategy.theta(i),strategy.headingDeg(i));
    fprintf('  航向单位向量 eF%d       = (%.9f, %.9f, %.9f)\n',...
        i,strategy.eF(i,1),strategy.eF(i,2),strategy.eF(i,3));
    fprintf('  飞行速度 vF%d           = %.9f m/s\n',i,strategy.vF(i));
    fprintf('  投放时刻 td%d1          = %.9f s\n',i,strategy.td(i));
    fprintf('  投放点 P0%d1            = (%.6f, %.6f, %.6f) m\n',...
        i,strategy.P0(i,1),strategy.P0(i,2),strategy.P0(i,3));
    fprintf('  引信延迟 tau%d1         = %.9f s\n',i,strategy.tau(i));
    fprintf('  起爆时刻 tb%d1          = %.9f s\n',i,strategy.tb(i));
    fprintf('  起爆点 Pb%d1            = (%.6f, %.6f, %.6f) m\n',...
        i,strategy.Pb(i,1),strategy.Pb(i,2),strategy.Pb(i,3));
    fprintf('  参与完整遮蔽时长        = %.6f s\n',finalDiag.participationDuration(i));
    fprintf('  不可替代贡献时长        = %.6f s\n',finalDiag.essentialDuration(i));
    fprintf('  最大承担视线比例        = %.4f\n',finalDiag.maxRayShare(i));
    fprintf('  最大贡献时刻            = %.6f s\n',finalDiag.tAtMaxRayShare(i));
end

if isempty(intervals)
    fprintf('\n最终高密度模型下未形成完整协同遮蔽。\n');
else
    fprintf('\n');
    for k=1:size(intervals,1)
        fprintf('协同遮蔽区间%d=[%.9f, %.9f] s，时长 %.9f s\n',...
            k,intervals(k,1),intervals(k,2),intervals(k,2)-intervals(k,1));
    end
end
fprintf('总有效遮蔽时长 T(1:3)11 = %.9f s\n',Teff);
fprintf('最终圆柱采样点数          = %d\n',size(Qfinal,1));
fprintf('最终时间步长              = %.6f s\n',dtFinal);
fprintf('目标函数评估总次数        = %d\n',cnt1+cnt2+cnt3);
fprintf('========================================================\n\n');

%% --------6. 保存结果与绘图----------
% 注意：北太天元的 load 对嵌套过深的 struct 会报“数组标志大小异常”，
% 因此这里只保存必要字段 + 精简诊断量（标量/小向量），保证能被 problem4_mc_main 读回。
result.Xbest = Xbest;
result.strategy = strategy;
result.Teff = Teff;
result.intervals = intervals;
result.finalTargetPointCount = size(Qfinal,1);
result.finalTimeStep = dtFinal;
result.optimizer = 'CPSO-Levy';
result.minParticipationDuration = min(finalDiag.participationDuration);
result.minEssentialDuration = min(finalDiag.essentialDuration);
result.participationDuration = finalDiag.participationDuration;
result.essentialDuration = finalDiag.essentialDuration;
result.maxRayShare = finalDiag.maxRayShare;
result.minWorstCoopDistance = finalDiag.minWorstCoopDistance;
save('problem4_sa_result.mat','result');

conv1=stage1.history.bestCost(:);
conv2=stage2.history.bestCost(:);
conv3=stage3.history.bestCost(:);
nC=max([numel(conv1),numel(conv2),numel(conv3)]);
convTable=table((1:nC)',[conv1;nan(nC-numel(conv1),1)], ...
    [conv2;nan(nC-numel(conv2),1)],[conv3;nan(nC-numel(conv3),1)], ...
    'VariableNames',{'Iteration','Stage1BestCost','Stage2BestCost','Stage3BestCost'});
writetable(convTable,'problem4_cpso_convergence.csv');

UAV = (1:3).';
ThetaRad = strategy.theta(:); ThetaDeg = strategy.headingDeg(:);
Speed = strategy.vF(:); DropTime = strategy.td(:);
DropX = strategy.P0(:,1); DropY = strategy.P0(:,2); DropZ = strategy.P0(:,3);
FuseDelay = strategy.tau(:); BurstTime = strategy.tb(:);
BurstX = strategy.Pb(:,1); BurstY = strategy.Pb(:,2); BurstZ = strategy.Pb(:,3);
ParticipationTime = finalDiag.participationDuration(:);
EssentialTime = finalDiag.essentialDuration(:);
MaxRayShare = finalDiag.maxRayShare(:);
MaxContributionTime = finalDiag.tAtMaxRayShare(:);
strategyTable = table(UAV,ThetaRad,ThetaDeg,Speed,DropTime,DropX,DropY,...
    DropZ,FuseDelay,BurstTime,BurstX,BurstY,BurstZ,ParticipationTime,...
    EssentialTime,MaxRayShare,MaxContributionTime,...
    'VariableNames',{'UAV','ThetaRad','ThetaDeg','Speed','DropTime',...
    'DropX','DropY','DropZ','FuseDelay','BurstTime','BurstX','BurstY',...
    'BurstZ','ParticipationTime','EssentialTime','MaxRayShare','MaxContributionTime'});
writetable(strategyTable,'problem4_sa_strategy.csv');

summaryTable = table(Teff,size(Qfinal,1),dtFinal,...
    min(finalDiag.participationDuration),min(finalDiag.essentialDuration),...
    'VariableNames',{'effective_time_s','target_point_count','time_step_s',...
    'minimum_participation_s','minimum_essential_s'});
writetable(summaryTable,'problem4_sa_summary.csv');

if DO_PLOT
    try, close all; catch, end   % 保证图窗编号从 1 开始，导出才不会串图
    global BT_FIG_COUNT BT_LAST_HIDDEN
    BT_FIG_COUNT = 0; BT_LAST_HIDDEN = [];
    try
        plot_problem4_sa_result(Xbest,cfg,Qfinal,dtFinal,intervals,...
            stage1,stage2,stage3,finalDiag);
        btExportAllFigures('图13-21_问题4',{'CPSO收敛过程','协同遮蔽判据', ...
            '三团烟幕贡献诊断','全局图区间1','全局图区间2','全局图区间3', ...
            '三视图FY1','三视图FY2','三视图FY3'});
    catch plotError
        fprintf('\n[绘图失败] 优化结果已保存。详细错误如下：\n');
        fprintf('%s\n',btErrorMessage(plotError));
        try
            for errorIndex=1:numel(plotError.stack)
                fprintf('  %s，第 %d 行\n',plotError.stack(errorIndex).name,...
                    plotError.stack(errorIndex).line);
            end
        catch
        end
        fprintf('修复绘图后可运行 plotonly_4，无需重新执行优化。\n');
    end
else
    fprintf('[跳过绘图] 请在图形界面中运行本脚本以生成图片。\n');
end
fprintf('结果已保存为 problem4_sa_result.mat、problem4_sa_strategy.csv、problem4_sa_summary.csv。\n');

%% ================== 本地函数 ==================
function opt = cpsoOpt(NP,Tmax,wMax,wMin,c1Max,c1Min,c2Min,c2Max,levyProb,levyScale,stagLimit,displayEvery,timeLimit)
    opt.NP=NP; opt.Tmax=Tmax;
    opt.wMax=wMax; opt.wMin=wMin;
    opt.c1Max=c1Max; opt.c1Min=c1Min; opt.c2Min=c2Min; opt.c2Max=c2Max;
    opt.levyProb=levyProb; opt.levyScale=levyScale;
    opt.stagLimit=stagLimit; opt.DisplayEvery=displayEvery;
    opt.timeLimit=timeLimit;
end

function [gbest,gbestCost,history,count] = cpsoLevy(obj,lb,ub,cfg,opt,seedX)
% CPSO-Lévy 主循环
    NP = opt.NP; D = numel(lb); Tmax = opt.Tmax;
    count = 0;

    % ---- 混沌初始化（Logistic 映射）----
    X = chaosMatrix(NP,D,lb,ub);
    if ~isempty(seedX)
        ns = min(size(seedX,1),NP);
        for i=1:ns
            X(i,:) = seedX(i,:);
        end
    end
    X = repairPop(X,lb,ub,cfg);

    V = zeros(NP,D);
    cost = zeros(NP,1);
    for i=1:NP
        cost(i) = obj(X(i,:)); count = count+1;
    end
    pbest = X; pbestCost = cost;
    [gbestCost,gi] = min(pbestCost);
    gbest = pbest(gi,:);

    histVec = zeros(Tmax,1);
    histVec(1) = gbestCost;
    stag = 0;
    tStart = tic;

    for t=1:Tmax
        w  = opt.wMax - (opt.wMax-opt.wMin)*(t/Tmax)^1.5;
        c1 = opt.c1Max - (opt.c1Max-opt.c1Min)*(t/Tmax);
        c2 = opt.c2Min + (opt.c2Max-opt.c2Min)*(t/Tmax);

        for i=1:NP
            r1 = rand(1,D); r2 = rand(1,D);
            V(i,:) = w*V(i,:) + c1*r1.*(pbest(i,:)-X(i,:)) + c2*r2.*(gbest-X(i,:));

            % ---- Lévy 飞行扰动 ----
            if rand < opt.levyProb
                L = levyStep(1.5,D);
                V(i,:) = V(i,:) + opt.levyScale*L.*(X(i,:)-gbest);
            end

            X(i,:) = X(i,:) + V(i,:);
            X(i,:) = repair_decision4(X(i,:),lb,ub,cfg);

            c = obj(X(i,:)); count = count+1;
            if c < pbestCost(i)
                pbestCost(i) = c; pbest(i,:) = X(i,:);
                if c < gbestCost
                    gbestCost = c; gbest = X(i,:); stag = 0;
                end
            end
        end

        % ---- 停滞 -> 对最差 25% 粒子做混沌重播种 ----
        stag = stag + 1;
        if stag >= opt.stagLimit
            [~,ord] = sort(pbestCost,'descend');
            nBad = max(1,round(0.25*NP));
            Xnew = chaosMatrix(nBad,D,lb,ub);
            for k=1:nBad
                idx = ord(k);
                X(idx,:) = repair_decision4(Xnew(k,:),lb,ub,cfg);
                V(idx,:) = zeros(1,D);
                pbestCost(idx) = obj(X(idx,:)); count = count+1;
                pbest(idx,:) = X(idx,:);
            end
            stag = 0;
            fprintf('  [停滞重播种] 第%d代重置最差%d个粒子\n',t,nBad);
        end

        histVec(t) = gbestCost;
        if mod(t,opt.DisplayEvery)==0
            fprintf('  迭代 %4d/%4d  w=%.3f c1=%.2f c2=%.2f  最优J=%.6f\n',...
                t,Tmax,w,c1,c2,gbestCost);
        end
        if toc(tStart) > opt.timeLimit
            fprintf('  [达到本阶段时间上限 %d s，提前结束]\n',opt.timeLimit);
            histVec = histVec(1:t);
            break;
        end
    end

    history.bestCost = histVec;
end

function X = chaosMatrix(NP,D,lb,ub)
% Logistic 混沌映射生成 NP x D 的初始种群，遍历性优于均匀随机
    Z = zeros(NP,D);
    for d=1:D
        z = 0.31 + 0.37*rand;      % 避开 0、0.5、0.75 等不动点
        for i=1:NP
            z = 4*z*(1-z);
            if z<=0 || z>=1, z = 0.31 + 0.37*rand; end
            Z(i,d) = z;
        end
    end
    X = repmat(lb,NP,1) + Z.*repmat(ub-lb,NP,1);
end

function X = repairPop(X,lb,ub,cfg)
    for i=1:size(X,1)
        X(i,:) = repair_decision4(X(i,:),lb,ub,cfg);
    end
end

function L = levyStep(beta,n)
% Mantegna 算法生成 Lévy 稳定分布步长
% beta=1.5 时 sigmaU ≈ 0.6966
    sigmaU = 0.6966;
    u = randn(1,n)*sigmaU;
    v = randn(1,n);
    L = u./(abs(v).^(1/beta));
end
