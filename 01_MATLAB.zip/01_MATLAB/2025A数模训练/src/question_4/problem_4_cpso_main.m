% 兼容带下划线的入口名称。实际 CPSO 主程序为 problem4_cpso_main.m。
entryDir = fileparts(mfilename('fullpath'));
if ~isempty(entryDir)
    addpath(entryDir);
    cd(entryDir);
end
problem4_cpso_main;
