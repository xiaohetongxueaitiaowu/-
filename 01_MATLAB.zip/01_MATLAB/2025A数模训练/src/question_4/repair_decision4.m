function X=repair_decision4(X,lb,ub,cfg)
% 将候选解投影到物理可行域（航向周期化、速度/时刻截断、起爆高度约束）
    X=reshape(X,1,[]);
    for i=1:3
        q=4*(i-1)+(1:4);
        theta=atan2(sin(X(q(1))),cos(X(q(1))));
        v=min(ub(q(2)),max(lb(q(2)),X(q(2))));
        td=min(cfg.tM1Arrive,max(0,X(q(3))));
        tauHeightMax=sqrt(2*cfg.F0(i,3)/cfg.g);
        tau=min(tauHeightMax,max(0,X(q(4))));
        tau=min(tau,max(0,cfg.tM1Arrive-td));
        X(q)=[theta,v,td,tau];
    end
    X=btMinAB(ub,max(lb,X));
end