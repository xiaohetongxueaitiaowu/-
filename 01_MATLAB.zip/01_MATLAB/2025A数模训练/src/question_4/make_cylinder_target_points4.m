function Q=make_cylinder_target_points4(cfg,nTheta,nZ,nRadial)
% 离散圆柱表面（侧面+上下端面）用于遮蔽判定采样
    theta=(0:nTheta-1).'*(2*pi/nTheta);
    zValues=linspace(0,cfg.targetH,nZ);
    [thetaGrid,zGrid]=ndgrid(theta,zValues);
    xSide=cfg.targetCenterXY(1)+cfg.targetR*cos(thetaGrid);
    ySide=cfg.targetCenterXY(2)+cfg.targetR*sin(thetaGrid);
    Q=[xSide(:),ySide(:),zGrid(:)];

    if nRadial>=3
        radii=linspace(0,cfg.targetR,nRadial);
        radii=radii(2:end-1);
        for r=radii
            xRing=cfg.targetCenterXY(1)+r*cos(theta);
            yRing=cfg.targetCenterXY(2)+r*sin(theta);
            Q=[Q; ... 
                xRing,yRing,zeros(nTheta,1); ...
                xRing,yRing,cfg.targetH*ones(nTheta,1)];
        end
    end

    Q=[Q;cfg.targetCenterXY(1),cfg.targetCenterXY(2),0; ...
        cfg.targetCenterXY(1),cfg.targetCenterXY(2),cfg.targetH];
    Q=unique(round(Q,10),'rows','stable');
end