%% 问题4：FY1、FY2、FY3各投放1枚烟幕弹的稳健模拟退火优化
% 算法思路：
%   1. 用几何反演生成大量高质量初始种子，避免随机初始化盲目性；
%   2. 目标函数同时奖励总时长和每架无人机的参与/不可替代贡献；
%   3. 采用多阶段退火（粗→中→高密度）逐级精化；
%   4. 最终复核严格满足三机贡献约束。
clear;clc;
%% ===== 北太天元环境初始化（自动识别是否可绘图） =====
[DO_PLOT,BT_IMG_DIR] = btInit();

rng(20250816,'twister');

cfg=problem4_default_config();

%% --------1.决策变量边界与参数----------
% X=[theta_i,v_i,td_i1,tau_i1] (i=1,2,3)
lb=zeros(1,12);ub=zeros(1,12);
for i=1:3
    q=4*(i-1)+(1:4);
    tauMax=sqrt(2*cfg.F0(i,3)/cfg.g);
    lb(q)=[-pi,70,0,0];
    ub(q)=[ pi,140,cfg.tM1Arrive,tauMax];
end
fprintf('\n问题4稳健模拟退火开始。M1到达假目标时刻：%.6f s\n',...
    cfg.tM1Arrive);

%% --------2.第0阶段：几何反演种子池与快速筛选----------
% 生成大量几何种子 + 随机种子 + 已知优秀解，并快速评估
Q0=make_cylinder_target_points4(cfg,18,4,2);
dt0=0.18;
obj0=@(X)problem4_objective(X,cfg,Q0,dt0);

nGeometrySeeds=72;
nRandomSeeds=12;
legacyBestX=[3.120279200,113.121625216,0.316055252,3.293162646,...
    -0.929526435,101.630066445,12.663188543,4.299586466,...
    -2.961027809,77.809242390,4.277545904,10.999355056];
constructiveSeedX=[3.113834727,106.4908712,0.030662454,2.990546391,...
    -1.835045331,92.02648584,8.420797211,6.848175326,...
    1.780768468,124.7413844,19.90538660,5.535932371];
nHybridSeeds=6;
nPool=nGeometrySeeds+nRandomSeeds+2+nHybridSeeds;
seedPool=zeros(nPool,12);
row=0;

% 几何种子：按时间段分工（FY1早段，FY2中段，FY3晚段）
for r=1:nGeometrySeeds
    focus=[7+2.8*randn,17+4.0*randn,27+5.0*randn];
    row=row+1;
    seedPool(row,:)=geometry_seed_decision4(cfg,lb,ub,focus);
end
% 随机种子
for r=1:nRandomSeeds
    row=row+1;
    seedPool(row,:)=random_feasible_decision4(lb,ub,cfg);
end
% 已知优秀解
row=row+1; seedPool(row,:)=repair_decision4(legacyBestX,lb,ub,cfg);
row=row+1; seedPool(row,:)=repair_decision4(constructiveSeedX,lb,ub,cfg);

% 混合种子：保留旧解FY1/FY2，用几何种子替换FY3
for r=1:nHybridSeeds
    donor=geometry_seed_decision4(cfg,lb,ub,...
        [7+2*randn,17+3*randn,27+4*randn]);
    hybrid=legacyBestX;
    hybrid(9:12)=donor(9:12);
    row=row+1;
    seedPool(row,:)=repair_decision4(hybrid,lb,ub,cfg);
end

% 快速评估所有种子
seedCost=zeros(nPool,1);
fprintf('\n第0阶段：筛选%d个初始策略。\n',nPool);
for r=1:nPool
    seedCost(r)=obj0(seedPool(r,:));
    if mod(r,15)==0 || r==nPool
        fprintf('  已筛选 %d/%d，当前最好J=%.6f\n',r,nPool,min(seedCost(1:r)));
    end
end
% 选择兼顾质量和差异性的起点
nRuns1=12;
[start1,start1Cost]=select_diverse_seeds4(seedPool,seedCost,nRuns1,cfg);
fprintf('选出%d个兼顾质量与差异性的粗搜索起点。\n',nRuns1);

%% --------3.第一阶段：粗网格多起点退火----------
Q1=make_cylinder_target_points4(cfg,28,5,3);
dt1=0.08;
obj1=@(X)problem4_objective(X,cfg,Q1,dt1);

sa1.MaxIterations=1000;
sa1.InitialTemperature=35;
sa1.FinalTemperature=0.03;
sa1.InitialStep=repmat([deg2rad(20),14,4.0,2.2],1,3);
sa1.FinalStep=repmat([deg2rad(0.08),0.08,0.018,0.018],1,3);
sa1.GlobalJumpProbability=0.025;
sa1.GlobalJumpFloor=0.002;
sa1.GlobalCandidates=3;
sa1.BlockMoveProbability=0.52;   % 分块扰动概率
sa1.CoordinateMoveProbability=0.16;
sa1.BlockRestartProbability=0.035;
sa1.ArchiveSize=10;
sa1.AdaptWindow=50;
sa1.ReheatAfter=130;
sa1.ReheatLength=55;
sa1.ReheatScale=0.65;
sa1.DisplayEvery=200;
sa1.GlobalSampler=@()geometry_seed_decision4(cfg,lb,ub,[]);

stage1=repmat(struct('X',[],'cost',[],'history',[]),nRuns1,1);
for r=1:nRuns1
    fprintf('\n========== 第一阶段，第%d/%d次退火 ==========\n',r,nRuns1);
    [stage1(r).X,stage1(r).cost,stage1(r).history]=...
        simulated_annealing_search4(obj1,start1(r,:),lb,ub,cfg,sa1);
end
[~,order1]=sort([stage1.cost]);stage1=stage1(order1);

%% --------4.第二阶段：中密度精细退火----------
Q2=make_cylinder_target_points4(cfg,52,8,4);
dt2=0.03;
obj2=@(X)problem4_objective(X,cfg,Q2,dt2);
nRuns2=6;
start2=vertcat(stage1(1:nRuns2).X);

sa2=sa1;
sa2.MaxIterations=1600;
sa2.InitialTemperature=8;
sa2.FinalTemperature=0.002;
sa2.InitialStep=repmat([deg2rad(6),4.5,1.1,0.65],1,3);
sa2.FinalStep=repmat([deg2rad(0.015),0.015,0.004,0.004],1,3);
sa2.GlobalJumpProbability=0.009;
sa2.GlobalJumpFloor=0.001;
sa2.GlobalCandidates=2;
sa2.BlockMoveProbability=0.58;
sa2.BlockRestartProbability=0.015;
sa2.ReheatAfter=170;
sa2.ReheatLength=50;
sa2.DisplayEvery=250;

stage2=repmat(struct('X',[],'cost',[],'history',[]),nRuns2,1);
for r=1:nRuns2
    fprintf('\n========== 第二阶段，第%d/%d次精细退火 ==========\n',r,nRuns2);
    [stage2(r).X,stage2(r).cost,stage2(r).history]=...
        simulated_annealing_search4(obj2,start2(r,:),lb,ub,cfg,sa2);
end
[~,order2]=sort([stage2.cost]);stage2=stage2(order2);

%% --------5.第三阶段：高密度局部抛光----------
Q3=make_cylinder_target_points4(cfg,96,11,6);
dt3=0.012;
obj3=@(X)problem4_objective(X,cfg,Q3,dt3);
nRuns3=3;
start3=vertcat(stage2(1:nRuns3).X);

sa3=sa2;
sa3.MaxIterations=900;
sa3.InitialTemperature=1.5;
sa3.FinalTemperature=0.0003;
sa3.InitialStep=repmat([deg2rad(1.6),1.2,0.25,0.18],1,3);
sa3.FinalStep=repmat([deg2rad(0.004),0.004,0.0015,0.0015],1,3);
sa3.GlobalJumpProbability=0;
sa3.GlobalJumpFloor=0;
sa3.BlockRestartProbability=0;
sa3.ReheatAfter=150;
sa3.ReheatLength=35;
sa3.DisplayEvery=180;

stage3=repmat(struct('X',[],'cost',[],'history',[]),nRuns3,1);
for r=1:nRuns3
    fprintf('\n========== 第三阶段，第%d/%d次高密度抛光 ==========\n',r,nRuns3);
    [stage3(r).X,stage3(r).cost,stage3(r).history]=...
        simulated_annealing_search4(obj3,start3(r,:),lb,ub,cfg,sa3);
end
[~,order3]=sort([stage3.cost]);stage3=stage3(order3);

%% --------6.最终高密度复核（强制贡献约束）----------
fprintf('\n========== 高密度圆柱协同遮蔽模型最终复核 ==========\n');
Qfinal=make_cylinder_target_points4(cfg,360,17,8);
dtFinal=0.002;
boundaryTolFinal=1e-8;
candidateX=vertcat(stage3.X);
candidateX=[candidateX;vertcat(stage2(1:3).X);vertcat(stage1(1:2).X);...
    start1(1,:);repair_decision4(constructiveSeedX,lb,ub,cfg)];
candidateX=unique(round(candidateX,10),'rows','stable');
nCandidate=size(candidateX,1);
candidateDuration=zeros(nCandidate,1);
candidateIntervals=cell(nCandidate,1);
candidateDiag=cell(nCandidate,1);

for k=1:nCandidate
    [candidateDuration(k),candidateIntervals{k},candidateDiag{k}]=...
        evaluate_cooperative_duration4(candidateX(k,:),cfg,Qfinal,...
        dtFinal,boundaryTolFinal);
    cD=candidateDiag{k};
    fprintf(['候选解%d：T=%.9f s；参与时长=[%.3f %.3f %.3f]；'...
        '不可替代时长=[%.3f %.3f %.3f]\n'],k,candidateDuration(k),...
        cD.participationDuration(1),cD.participationDuration(2),cD.participationDuration(3),...
        cD.essentialDuration(1),cD.essentialDuration(2),cD.essentialDuration(3));
end

% 最终选择：必须满足所有无人机的最低贡献要求
feasibleContribution=false(nCandidate,1);
for k=1:nCandidate
    feasibleContribution(k)=all(candidateDiag{k}.participationDuration>=...
        cfg.minParticipationDuration-2*dtFinal) &&...
        all(candidateDiag{k}.essentialDuration>=...
        cfg.minEssentialDuration-2*dtFinal);
end
if any(feasibleContribution)
    feasibleIndex=find(feasibleContribution);
    [Teff,localBest]=max(candidateDuration(feasibleIndex));
    bestIndex=feasibleIndex(localBest);
else
    warning('高密度复核中没有候选同时满足三机贡献阈值，将按完整目标函数选取。');
    finalCost=zeros(nCandidate,1);
    for k=1:nCandidate
        finalCost(k)=problem4_objective(candidateX(k,:),cfg,Qfinal,dtFinal);
    end
    [~,bestIndex]=min(finalCost);
    Teff=candidateDuration(bestIndex);
end

Xbest=candidateX(bestIndex,:);
intervals=candidateIntervals{bestIndex};
finalDiag=candidateDiag{bestIndex};
strategy=compute_problem4_strategy(Xbest,cfg);

%% --------7.输出结果----------
fprintf('\n================= 问题4修改版结果 =================\n');
for i=1:3
    fprintf('\nFY%d：\n',i);
    fprintf('  航向角 theta%d          = %.9f rad = %.6f deg\n',...
        i,strategy.theta(i),strategy.headingDeg(i));
    fprintf('  航向单位向量 eF%d       = (%.9f, %.9f, %.9f)\n',...
        i,strategy.eF(i,1),strategy.eF(i,2),strategy.eF(i,3));
    fprintf('  飞行速度 vF%d           = %.9f m/s\n',i,strategy.vF(i));
    fprintf('  投放时刻 td%d1          = %.9f s\n',i,strategy.td(i));
    fprintf('  投放点 P0%d1            = (%.6f, %.6f, %.6f) m\n',...
        i,strategy.P0(i,1),strategy.P0(i,2),strategy.P0(i,3));
    fprintf('  引信延迟 tau%d1         = %.9f s\n',i,strategy.tau(i));
    fprintf('  起爆时刻 tb%d1          = %.9f s\n',i,strategy.tb(i));
    fprintf('  起爆点 Pb%d1            = (%.6f, %.6f, %.6f) m\n',...
        i,strategy.Pb(i,1),strategy.Pb(i,2),strategy.Pb(i,3));
    fprintf('  参与完整遮蔽时长        = %.6f s\n',...
        finalDiag.participationDuration(i));
    fprintf('  不可替代贡献时长        = %.6f s\n',...
        finalDiag.essentialDuration(i));
    fprintf('  最大承担视线比例        = %.4f\n',finalDiag.maxRayShare(i));
    fprintf('  最大贡献时刻            = %.6f s\n',finalDiag.tAtMaxRayShare(i));
end

if isempty(intervals)
    fprintf('\n最终高密度模型下未形成完整协同遮蔽。\n');
else
    fprintf('\n');
    for k=1:size(intervals,1)
        fprintf('协同遮蔽区间%d=[%.9f, %.9f] s，时长 %.9f s\n',...
            k,intervals(k,1),intervals(k,2),intervals(k,2)-intervals(k,1));
    end
end
fprintf('总有效遮蔽时长 T(1:3)11 = %.9f s\n',Teff);
fprintf('最终圆柱采样点数          = %d\n',size(Qfinal,1));
fprintf('最终时间步长              = %.6f s\n',dtFinal);
fprintf('=======================================================\n\n');

%% --------8.保存结果与绘图----------
result.Xbest=Xbest;
result.strategy=strategy;
result.Teff=Teff;
result.intervals=intervals;
result.finalDiagnostics=finalDiag;
result.finalTargetPointCount=size(Qfinal,1);
result.finalTimeStep=dtFinal;
result.seedPool=seedPool;
result.seedCost=seedCost;
result.selectedSeedCost=start1Cost;
result.stage1=stage1;
result.stage2=stage2;
result.stage3=stage3;
save('problem4_sa_result.mat','result');

% 输出CSV表格
UAV=(1:3).';
ThetaRad=strategy.theta(:);ThetaDeg=strategy.headingDeg(:);
Speed=strategy.vF(:);DropTime=strategy.td(:);
DropX=strategy.P0(:,1);DropY=strategy.P0(:,2);DropZ=strategy.P0(:,3);
FuseDelay=strategy.tau(:);BurstTime=strategy.tb(:);
BurstX=strategy.Pb(:,1);BurstY=strategy.Pb(:,2);BurstZ=strategy.Pb(:,3);
ParticipationTime=finalDiag.participationDuration(:);
EssentialTime=finalDiag.essentialDuration(:);
MaxRayShare=finalDiag.maxRayShare(:);
MaxContributionTime=finalDiag.tAtMaxRayShare(:);
strategyTable=table(UAV,ThetaRad,ThetaDeg,Speed,DropTime,DropX,DropY,...
    DropZ,FuseDelay,BurstTime,BurstX,BurstY,BurstZ,ParticipationTime,...
    EssentialTime,MaxRayShare,MaxContributionTime);
writetable(strategyTable,'problem4_sa_strategy.csv');

summaryTable=table(Teff,size(Qfinal,1),dtFinal,...
    min(finalDiag.participationDuration),min(finalDiag.essentialDuration),...
    'VariableNames',{'effective_time_s','target_point_count','time_step_s',...
    'minimum_participation_s','minimum_essential_s'});
writetable(summaryTable,'problem4_sa_summary.csv');

if DO_PLOT
    plot_problem4_sa_result(Xbest,cfg,Qfinal,dtFinal,intervals,...
        stage1,stage2,stage3,finalDiag);
    btExportAllFigures('图13-21_问题4',{'模拟退火收敛过程','协同遮蔽判据', ...
        '三团烟幕贡献诊断','全局图区间1','全局图区间2','全局图区间3', ...
        '三视图FY1','三视图FY2','三视图FY3'});
else
    fprintf('[跳过绘图] 请在图形界面中运行本脚本以生成图片。\n');
end
fprintf('修改版结果已保存为MAT、CSV和图形文件。\n');