%% 问题4修改版快速自检（约数秒至数十秒，不执行完整退火）
% 用于验证给定策略是否满足三机贡献要求
clear;clc;
cfg=problem4_default_config();

X=[3.113834727,106.4908712,0.030662454,2.990546391,...
   -1.835045331,92.02648584,8.420797211,6.848175326,...
    1.780768468,124.7413844,19.90538660,5.535932371];

Q=make_cylinder_target_points4(cfg,96,11,6);
[Teff,intervals,diagInfo]=evaluate_cooperative_duration4(X,cfg,Q,0.01,1e-6);

fprintf('\n========== 修改版快速自检 ==========\n');
fprintf('总有效遮蔽时长：%.6f s\n',Teff);
for i=1:3
    fprintf(['FY%d：参与时长 %.6f s，不可替代时长 %.6f s，'...
        '最大承担视线比例 %.2f%%\n'],i,diagInfo.participationDuration(i),...
        diagInfo.essentialDuration(i),100*diagInfo.maxRayShare(i));
end
disp('有效遮蔽区间：');disp(intervals);

assert(Teff>0,'快速自检失败：没有形成有效遮蔽。');
assert(all(diagInfo.participationDuration>0),...
    '快速自检失败：至少一架无人机没有参与遮蔽。');
assert(all(diagInfo.essentialDuration>0),...
    '快速自检失败：至少一架无人机没有不可替代贡献。');
fprintf('快速自检通过：FY1、FY2、FY3均有有效贡献。\n');
fprintf('====================================\n');