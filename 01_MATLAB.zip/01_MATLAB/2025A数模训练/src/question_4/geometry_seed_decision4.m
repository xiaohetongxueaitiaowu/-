function [X,info]=geometry_seed_decision4(cfg,lb,ub,focusTimes)
% 几何反演种子：根据希望的遮蔽时刻反推航向、速度、投放/起爆参数
% 使初始解直接落在导弹—真目标视线束附近，避免高维随机搜索盲目性
    if nargin<4 || isempty(focusTimes)
        focusTimes=[8,18,28]+[2,4,5].*randn(1,3);
    end
    focusTimes=max(2,btMinAB(cfg.tM1Arrive-1,reshape(focusTimes,1,3)));

    X=zeros(1,12);
    info.success=false(1,3);
    info.focusTime=focusTimes;
    info.cloudCenterAtFocus=nan(3,3);

    for i=1:3
        q=4*(i-1)+(1:4);
        bestLocal=[];
        bestScore=inf;

        for trial=1:1800
            % 在指定时刻附近抖动，使种子覆盖不同时间区域
            tFocus=max(2,min(cfg.tM1Arrive-1,...
                focusTimes(i)+0.8*randn));
            ageMax=min([cfg.cloudLife-0.2,tFocus-0.5,10]);
            if ageMax<=0,continue;end
            cloudAge=0.1+ageMax*rand;
            tb=tFocus-cloudAge;
            if tb<=0.2,continue;end

            v=70+70*rand;
            reach=v*tb;
            M=cfg.M10+cfg.vM1*tFocus;

            % 目标点在圆柱内部随机扰动，避免种子完全重合
            phi=2*pi*rand;
            radial=0.35*cfg.targetR*sqrt(rand);
            target=[cfg.targetCenterXY+radial*[cos(phi),sin(phi)],...
                cfg.targetH*(0.25+0.5*rand)];

            % 求无人机水平可达圆与视线水平投影的交点
            d=target(1:2)-M(1:2);
            f=M(1:2)-cfg.F0(i,1:2);
            a=dot(d,d);
            b=2*dot(f,d);
            c=dot(f,f)-reach^2;
            disc=b^2-4*a*c;
            if a<=eps || disc<0,continue;end
            rootsLambda=[(-b-sqrt(disc))/(2*a),(-b+sqrt(disc))/(2*a)];
            valid=rootsLambda(rootsLambda>=0.015 & rootsLambda<=0.985);
            if isempty(valid),continue;end

            % 优先选靠近中点的交点
            [~,which]=max(valid.*(1-valid));
            lambda=valid(which);
            C=M+lambda*(target-M);
            PbZ=C(3)+cfg.vCloud*cloudAge;
            if PbZ<=0 || PbZ>=cfg.F0(i,3),continue;end

            tau=sqrt(2*(cfg.F0(i,3)-PbZ)/cfg.g);
            td=tb-tau;
            if td<0 || tau<0 || tb>cfg.tM1Arrive,continue;end

            PbXY=M(1:2)+lambda*d;
            delta=PbXY-cfg.F0(i,1:2);
            theta=atan2(delta(2),delta(1));
            theta=atan2(sin(theta),cos(theta));
            v=min(ub(q(2)),max(lb(q(2)),v));
            td=min(ub(q(3)),max(lb(q(3)),td));
            tau=min(ub(q(4)),max(lb(q(4)),tau));
            tau=min(tau,max(0,cfg.tM1Arrive-td));
            local=[theta,v,td,tau];

            % 修复后计算真实云团中心与期望中心的偏差，保留最佳
            tb2=local(3)+local(4);
            Pb=cfg.F0(i,:)+local(2)*[cos(local(1)),sin(local(1)),0]*tb2+...
                [0,0,-0.5*cfg.g*local(4)^2];
            C2=Pb-[0,0,cfg.vCloud*max(0,tFocus-tb2)];
            score=norm(C2-C)+0.05*abs(tFocus-focusTimes(i));
            if score<bestScore
                bestScore=score;
                bestLocal=local;
                info.focusTime(i)=tFocus;
                info.cloudCenterAtFocus(i,:)=C2;
            end
            if score<0.25,break;end
        end

        if isempty(bestLocal)
            fallback=random_feasible_decision4(lb,ub,cfg);
            bestLocal=fallback(q);
        else
            info.success(i)=true;
        end
        X(q)=bestLocal;
    end

    X=repair_decision4(X,lb,ub,cfg);
end