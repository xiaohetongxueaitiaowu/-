function [covered,worstCoopDistance,cloudDetail]=cooperative_covered_at_times4(tVec,X,cfg,Q)
% 协同遮蔽核心判定：D(t)=max_j min_i d_i1j(t)，同时诊断每团烟幕的参与和不可替代贡献
% 输出cloudDetail包含：参与标识、不可替代标识、承担视线比例、个体最佳/最差距离等
    tVec=tVec(:);
    nT=numel(tVec);
    nQ=size(Q,1);
    s=compute_problem4_strategy(X,cfg);

    M=cfg.M10+tVec.*cfg.vM1;
    Qx=Q(:,1).'; Qy=Q(:,2).'; Qz=Q(:,3).';
    covered=false(nT,1);
    worstCoopDistance=inf(nT,1);
    needDetail=nargout>=3;
    if needDetail
        cloudDetail.active=false(nT,3);
        cloudDetail.nearAnyRay=false(nT,3);
        cloudDetail.participationFlag=false(nT,3);
        cloudDetail.essentialFlag=false(nT,3);
        cloudDetail.rayShare=zeros(nT,3);
        cloudDetail.individualBestDistance=inf(nT,3);
        cloudDetail.individualWorstDistance=inf(nT,3);
        cloudDetail.withoutWorstDistance=inf(nT,3);
    end

    for first=1:cfg.timeChunk:nT
        last=min(first+cfg.timeChunk-1,nT);
        idx=first:last;
        tc=tVec(idx);
        Mx=M(idx,1); My=M(idx,2); Mz=M(idx,3);

        vx=Qx-Mx; vy=Qy-My; vz=Qz-Mz;
        denominator=vx.^2+vy.^2+vz.^2;
        nLocal=numel(idx);
        allD2=inf(nLocal,nQ,3);

        for i=1:3
            % 仅当烟幕处于有效期内且不触地才参与计算
            active=tc>=s.tb(i) & tc<=s.tb(i)+cfg.cloudLife & ...
                tc<=cfg.tM1Arrive;
            if ~any(active), continue; end

            Cx=s.Pb(i,1)*ones(numel(idx),1);
            Cy=s.Pb(i,2)*ones(numel(idx),1);
            Cz=s.Pb(i,3)-cfg.vCloud*(tc-s.tb(i));
            active=active & Cz>=0;

            wx=Cx-Mx; wy=Cy-My; wz=Cz-Mz;
            lambda=(wx.*vx+wy.*vy+wz.*vz)./denominator;
            % 北太天元 min(1,大矩阵) 存在缺陷，改用纯元素运算裁剪到 [0,1]
            lambdaHat = lambda.*(lambda>0).*(lambda<1) + 1.0*(lambda>=1);
            Hx=Mx+lambdaHat.*vx;
            Hy=My+lambdaHat.*vy;
            Hz=Mz+lambdaHat.*vz;
            d2=(Cx-Hx).^2+(Cy-Hy).^2+(Cz-Hz).^2;
            d2(~active,:)=inf;
            allD2(:,:,i)=d2;
            if needDetail
                cloudDetail.active(idx,i)=active;
                cloudDetail.nearAnyRay(idx,i)=any(d2<=cfg.smokeR^2,2);
                cloudDetail.individualBestDistance(idx,i)=sqrt(min(d2,[],2));
                cloudDetail.individualWorstDistance(idx,i)=sqrt(max(d2,[],2));
            end
        end

        % 对每条目标视线取三团烟幕的最小距离，再对所有视线取最大
        [minD2,owner]=min(allD2,[],3);
        maxMinD2=max(minD2,[],2);
        worstCoopDistance(idx)=sqrt(maxMinD2.*(maxMinD2>0));
        covered(idx)=maxMinD2<=cfg.smokeR^2;

        % 计算每团烟幕的视线分担比例和贡献标识
        if needDetail
            for i=1:3
                owned=(owner==i) & isfinite(allD2(:,:,i));
                share=sum(owned,2)/nQ;
                cloudDetail.rayShare(idx,i)=share;
                cloudDetail.participationFlag(idx,i)=covered(idx) & share>0;

                other=setdiff(1:3,i);
                withoutD2=min(allD2(:,:,other),[],3);
                withoutWorstD2=max(withoutD2,[],2);
                cloudDetail.withoutWorstDistance(idx,i)=sqrt(withoutWorstD2.*(withoutWorstD2>0));
                cloudDetail.essentialFlag(idx,i)=covered(idx) & ...
                    withoutWorstD2>cfg.smokeR^2; % 移除后遮蔽失效，即为不可替代贡献
            end
        end
    end
end