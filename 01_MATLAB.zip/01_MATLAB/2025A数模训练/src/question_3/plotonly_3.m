% 只画问题3的图
L=load('problem3_sa_result.mat'); r=L.result;
cfg=problem3_default_config();
Qfinal=make_cylinder_target_points3(cfg,72,9,4);
cv=readmatrix('problem3_sa_convergence.csv');
c1=cv(:,2); c1=c1(~isnan(c1)); c2=cv(:,3); c2=c2(~isnan(c2));
stage1=struct('X',r.Xbest,'cost',-r.Teff,'history',struct('bestCost',c1));
stage2=struct('X',r.Xbest,'cost',-r.Teff,'history',struct('bestCost',c2));
plot_problem3_sa_result(r.Xbest,cfg,Qfinal,0.02,r.intervals,stage1,stage2);
fprintf('问题3 的图已画好（4 张），请用图形窗口的「文件→另存为」保存。\n');
