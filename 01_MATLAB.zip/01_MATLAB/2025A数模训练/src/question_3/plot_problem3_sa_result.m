function plot_problem3_sa_result(X,cfg,Q,dt,intervals,stage1,stage2)
% 绘制收敛、协同遮蔽判据、三维全局图及三视图
    s=compute_problem3_strategy(X,cfg);
    tBegin=min(s.tb);
    tEnd=min(max(s.tb+cfg.cloudLife),cfg.tM1Arrive);
    t=(tBegin:dt:tEnd).';
    if t(end)<tEnd, t(end+1,1)=tEnd; end
    [covered,D]=cooperative_covered_at_times(t,X,cfg,Q);

    %% 1. 收敛曲线
    if btWant(1)
    btNewFigure('问题3模拟退火收敛过程', [100,100,900,350]);
    hold on;
    for r=1:numel(stage1)
_hl = {};   %% 只把带名字的曲线放进图例（北太天元句柄是 cell，用元胞数组存）
        _hl{end+1} = plot(stage1(r).history.bestCost,'LineWidth',1.0,...
            'DisplayName',sprintf('粗搜索%d',r));
    end
    for r=1:numel(stage2)
        _hl{end+1} = plot(stage2(r).history.bestCost,'LineWidth',1.5,...
            'DisplayName',sprintf('精细搜索%d',r));
    end
    xlabel('迭代次数','FontSize',18); ylabel('历史最优目标函数值','FontSize',18);
    title('问题3模拟退火收敛过程','FontSize',18); btGrid(); btBox();
    legend(_hl,'Location','best');
    xlim([1,50]);

    %% 2. 遮蔽判据
    end
    if btWant(2)
    btNewFigure('问题3协同遮蔽判据', []);
    subplot(2,1,1);
    plot(t,D,'b-','LineWidth',1.5); hold on;
    yline(cfg.smokeR,'r--','烟幕半径10 m','LineWidth',1.2);
    shadeIntervals(intervals);
    xlabel('时间 t / s','FontSize',18); ylabel('D_3(t) / m','FontSize',18);
    title('协同判据 D_3(t)=max_j min_m d_{1mj}(t)','FontSize',18); btGrid(); btBox();
    subplot(2,1,2);
    stairs(t,double(covered),'Color',btC(5),'LineWidth',1.5);
    ylim([-0.1,1.1]); yticks([0,1]);
    yticklabels({'未完全遮蔽','协同完全遮蔽'});
    xlabel('时间 t / s','FontSize',18); ylabel('遮蔽状态','FontSize',18); btGrid(); btBox();

    %% 3. 定义轨迹函数
    M1=@(tt) cfg.M10+cfg.vM1*tt;
    F1=@(tt) cfg.F10+s.vF1Vec*tt;
    trueTargetBottom=[cfg.targetCenterXY,0];

    if ~isempty(intervals)
        tShow=mean(intervals(1,:));
    else
        [~,k]=min(D);
        tShow=t(k);
    end

    %% 4. 全局三维图（FY1轨迹延长至导弹抵达）
    end
    if btWant(3)
    btNewFigure('问题3最优三烟幕策略（全局）', []); hold on;
    [xc,yc,zc]=cylinder(cfg.targetR,20);
    btSurfBall(xc+cfg.targetCenterXY(1),yc+cfg.targetCenterXY(2),zc*cfg.targetH,btTint(5,0.55),0.55,'真目标圆柱');
    tM=linspace(0,cfg.tM1Arrive,120);
    M_pts=sample_pts(M1,tM);
_hl = {};   %% 只把带名字的曲线放进图例（北太天元句柄是 cell，用元胞数组存）
    _hl{end+1} = plot3(M_pts(:,1),M_pts(:,2),M_pts(:,3),'r-','LineWidth',1.8,...
        'DisplayName','M1轨迹');
    tF=linspace(0,cfg.tM1Arrive,100);
    F_pts=sample_pts(F1,tF);
    _hl{end+1} = plot3(F_pts(:,1),F_pts(:,2),F_pts(:,3),'b-','LineWidth',1.8,...
        'DisplayName','FY1轨迹');
    _hl{end+1} = scatter3(cfg.O(1),cfg.O(2),cfg.O(3),80,btC(4),'filled',...
        'DisplayName','假目标');

    colors=[btC(2); btC(4); btC(6)];   % 北太天元色板：红 / 紫 / 青
    for m=1:3
        Pm=@(tt) s.P0(m,:)+s.vF1Vec*(tt-s.td(m))+...
            [0,0,-0.5*cfg.g*(tt-s.td(m))^2];
        Cm=@(tt) s.Pb(m,:)+[0,0,-cfg.vCloud*(tt-s.tb(m))];
        tP=linspace(s.td(m),s.tb(m),80);
        P_pts=sample_pts(Pm,tP);
        _hl{end+1} = plot3(P_pts(:,1),P_pts(:,2),P_pts(:,3),'-','LineWidth',2.0,...
            'Color',colors(m,:),'DisplayName',sprintf('烟幕弹%d轨迹',m));
        tC=linspace(s.tb(m),min(s.tb(m)+20,cfg.tM1Arrive),100);
        C_pts=sample_pts(Cm,tC);
        _hl{end+1} = plot3(C_pts(:,1),C_pts(:,2),C_pts(:,3),'--','LineWidth',1.5,...
            'Color',colors(m,:),'DisplayName',sprintf('云团%d中心',m));
        _hl{end+1} = scatter3(s.P0(m,1),s.P0(m,2),s.P0(m,3),55,colors(m,:),'filled',...
            'DisplayName',sprintf('投放点%d',m));
        _hl{end+1} = scatter3(s.Pb(m,1),s.Pb(m,2),s.Pb(m,3),65,colors(m,:),'filled',...
            'DisplayName',sprintf('起爆点%d',m));
        if tShow>=s.tb(m) && tShow<=s.tb(m)+20
            Ct=Cm(tShow);
            [xs,ys,zs]=sphere(10);
            btSurfBall(cfg.smokeR*xs+Ct(1),cfg.smokeR*ys+Ct(2),...
                cfg.smokeR*zs+Ct(3),colors(m,:),0.35,sprintf('第%d团烟幕球',m));
        end
    end

    % 绘制遮蔽区间首尾视线
    nIntervals=min(4,size(intervals,1));
    for k=1:nIntervals
        tStart=intervals(k,1);
        tEnd_iv=intervals(k,2);
        Mt_start=M1(tStart);
        plot3([Mt_start(1),trueTargetBottom(1)],...
              [Mt_start(2),trueTargetBottom(2)],...
              [Mt_start(3),trueTargetBottom(3)],'k--','LineWidth',0.8);
        scatter3(Mt_start(1),Mt_start(2),Mt_start(3),30,'k','filled');
        Mt_end=M1(tEnd_iv);
        plot3([Mt_end(1),trueTargetBottom(1)],...
              [Mt_end(2),trueTargetBottom(2)],...
              [Mt_end(3),trueTargetBottom(3)],'k--','LineWidth',0.8);
        scatter3(Mt_end(1),Mt_end(2),Mt_end(3),30,'k','filled');
    end

    xlabel('x / m','FontSize',18); ylabel('y / m','FontSize',18); zlabel('z / m','FontSize',18);
    title('全局视图（FY1轨迹延长至导弹抵达）','FontSize',18);
    legend(_hl,'Location','bestoutside');
    btGrid(); btBox(); view(-35,25);

    %% 5. 三视图
    end
    if btWant(4)
    btNewFigure('问题3三视图（局部）', [100,100,1400,1000]);
    center=s.Pb(2,:);
    xRange=2000; yRange=100; zRange=500;
    trueBottom=[cfg.targetCenterXY,0];

    % 主视图（XZ）
    subplot(2,2,1); hold on; view(0,0);
    btGrid(); btBox();   % view 之后再设一次：三维图必须有网格和方框才立体
    plot3(M_pts(:,1),M_pts(:,2),M_pts(:,3),'r-','LineWidth',1.2);
    plot3(F_pts(:,1),F_pts(:,2),F_pts(:,3),'b-','LineWidth',1.2);
    for m=1:3
        Pm=@(tt) s.P0(m,:)+s.vF1Vec*(tt-s.td(m))+...
            [0,0,-0.5*cfg.g*(tt-s.td(m))^2];
        Cm=@(tt) s.Pb(m,:)+[0,0,-cfg.vCloud*(tt-s.tb(m))];
        tP=linspace(s.td(m),s.tb(m),50);
        P_pts=sample_pts(Pm,tP);
        plot3(P_pts(:,1),P_pts(:,2),P_pts(:,3),'-','Color',colors(m,:),'LineWidth',1.2);
        tC=linspace(s.tb(m),min(s.tb(m)+20,cfg.tM1Arrive),50);
        C_pts=sample_pts(Cm,tC);
        plot3(C_pts(:,1),C_pts(:,2),C_pts(:,3),'--','Color',colors(m,:),'LineWidth',1.2);
        scatter3(s.P0(m,1),s.P0(m,2),s.P0(m,3),50,colors(m,:),'filled');
        scatter3(s.Pb(m,1),s.Pb(m,2),s.Pb(m,3),60,colors(m,:),'filled');
        theta_circ=linspace(0,2*pi,40);
        Cx=s.Pb(m,1)+cfg.smokeR*cos(theta_circ);
        Cz=s.Pb(m,3)+cfg.smokeR*sin(theta_circ);
        Cy=s.Pb(m,2)*ones(size(theta_circ));
        plot3(Cx,Cy,Cz,'Color',colors(m,:),'LineWidth',1.5);
    end
    for k=1:nIntervals
        tStart=intervals(k,1);
        tEnd_iv=intervals(k,2);
        Mt_s=M1(tStart);
        plot3([Mt_s(1),trueBottom(1)],[Mt_s(2),trueBottom(2)],...
              [Mt_s(3),trueBottom(3)],'k--','LineWidth',2.0);
        scatter3(Mt_s(1),Mt_s(2),Mt_s(3),50,'k','filled');
        Mt_e=M1(tEnd_iv);
        plot3([Mt_e(1),trueBottom(1)],[Mt_e(2),trueBottom(2)],...
              [Mt_e(3),trueBottom(3)],'k--','LineWidth',2.0);
        scatter3(Mt_e(1),Mt_e(2),Mt_e(3),50,'k','filled');
    end
    xlabel('x (m)','FontSize',18); zlabel('z (m)','FontSize',18); title('主视图 (XZ)','FontSize',18);
    xlim([center(1)-xRange,center(1)+xRange]);
    zlim([center(3)-zRange,center(3)+zRange]);
    btGrid(); btBox();

    % 俯视图（XY）
    subplot(2,2,3); hold on; view(0,90);
    btGrid(); btBox();   % view 之后再设一次：三维图必须有网格和方框才立体
    plot3(M_pts(:,1),M_pts(:,2),M_pts(:,3),'r-','LineWidth',1.2);
    plot3(F_pts(:,1),F_pts(:,2),F_pts(:,3),'b-','LineWidth',1.2);
    for m=1:3
        Pm=@(tt) s.P0(m,:)+s.vF1Vec*(tt-s.td(m))+...
            [0,0,-0.5*cfg.g*(tt-s.td(m))^2];
        Cm=@(tt) s.Pb(m,:)+[0,0,-cfg.vCloud*(tt-s.tb(m))];
        tP=linspace(s.td(m),s.tb(m),50);
        P_pts=sample_pts(Pm,tP);
        plot3(P_pts(:,1),P_pts(:,2),P_pts(:,3),'-','Color',colors(m,:),'LineWidth',1.2);
        tC=linspace(s.tb(m),min(s.tb(m)+20,cfg.tM1Arrive),50);
        C_pts=sample_pts(Cm,tC);
        plot3(C_pts(:,1),C_pts(:,2),C_pts(:,3),'--','Color',colors(m,:),'LineWidth',1.2);
        scatter3(s.P0(m,1),s.P0(m,2),s.P0(m,3),50,colors(m,:),'filled');
        scatter3(s.Pb(m,1),s.Pb(m,2),s.Pb(m,3),60,colors(m,:),'filled');
        theta_circ=linspace(0,2*pi,40);
        Cx=s.Pb(m,1)+cfg.smokeR*cos(theta_circ);
        Cy=s.Pb(m,2)+cfg.smokeR*sin(theta_circ);
        Cz=s.Pb(m,3)*ones(size(theta_circ));
        plot3(Cx,Cy,Cz,'Color',colors(m,:),'LineWidth',1.5);
    end
    for k=1:nIntervals
        tStart=intervals(k,1);
        tEnd_iv=intervals(k,2);
        Mt_s=M1(tStart);
        plot3([Mt_s(1),trueBottom(1)],[Mt_s(2),trueBottom(2)],...
              [Mt_s(3),trueBottom(3)],'k--','LineWidth',2.0);
        scatter3(Mt_s(1),Mt_s(2),Mt_s(3),50,'k','filled');
        Mt_e=M1(tEnd_iv);
        plot3([Mt_e(1),trueBottom(1)],[Mt_e(2),trueBottom(2)],...
              [Mt_e(3),trueBottom(3)],'k--','LineWidth',2.0);
        scatter3(Mt_e(1),Mt_e(2),Mt_e(3),50,'k','filled');
    end
    xlabel('x (m)','FontSize',18); ylabel('y (m)','FontSize',18); title('俯视图 (XY)','FontSize',18);
    xlim([center(1)-xRange,center(1)+xRange]);
    ylim([center(2)-yRange,center(2)+yRange]);
    btGrid(); btBox();

    % 左视图（YZ）
    subplot(2,2,2); hold on; view(90,0);
    btGrid(); btBox();   % view 之后再设一次：三维图必须有网格和方框才立体
    plot3(M_pts(:,1),M_pts(:,2),M_pts(:,3),'r-','LineWidth',1.2);
    plot3(F_pts(:,1),F_pts(:,2),F_pts(:,3),'b-','LineWidth',1.2);
    for m=1:3
        Pm=@(tt) s.P0(m,:)+s.vF1Vec*(tt-s.td(m))+...
            [0,0,-0.5*cfg.g*(tt-s.td(m))^2];
        Cm=@(tt) s.Pb(m,:)+[0,0,-cfg.vCloud*(tt-s.tb(m))];
        tP=linspace(s.td(m),s.tb(m),50);
        P_pts=sample_pts(Pm,tP);
        plot3(P_pts(:,1),P_pts(:,2),P_pts(:,3),'-','Color',colors(m,:),'LineWidth',1.2);
        tC=linspace(s.tb(m),min(s.tb(m)+20,cfg.tM1Arrive),50);
        C_pts=sample_pts(Cm,tC);
        plot3(C_pts(:,1),C_pts(:,2),C_pts(:,3),'--','Color',colors(m,:),'LineWidth',1.2);
        scatter3(s.P0(m,1),s.P0(m,2),s.P0(m,3),50,colors(m,:),'filled');
        scatter3(s.Pb(m,1),s.Pb(m,2),s.Pb(m,3),60,colors(m,:),'filled');
        theta_circ=linspace(0,2*pi,40);
        Cy=s.Pb(m,2)+cfg.smokeR*cos(theta_circ);
        Cz=s.Pb(m,3)+cfg.smokeR*sin(theta_circ);
        Cx=s.Pb(m,1)*ones(size(theta_circ));
        plot3(Cx,Cy,Cz,'Color',colors(m,:),'LineWidth',1.5);
    end
    for k=1:nIntervals
        tStart=intervals(k,1);
        tEnd_iv=intervals(k,2);
        Mt_s=M1(tStart);
        plot3([Mt_s(1),trueBottom(1)],[Mt_s(2),trueBottom(2)],...
              [Mt_s(3),trueBottom(3)],'k--','LineWidth',2.0);
        scatter3(Mt_s(1),Mt_s(2),Mt_s(3),50,'k','filled');
        Mt_e=M1(tEnd_iv);
        plot3([Mt_e(1),trueBottom(1)],[Mt_e(2),trueBottom(2)],...
              [Mt_e(3),trueBottom(3)],'k--','LineWidth',2.0);
        scatter3(Mt_e(1),Mt_e(2),Mt_e(3),50,'k','filled');
    end
    ylabel('y (m)','FontSize',18); zlabel('z (m)','FontSize',18); title('左视图 (YZ)','FontSize',18);
    ylim([center(2)-yRange,center(2)+yRange]);
    zlim([center(3)-zRange,center(3)+zRange]);
    btGrid(); btBox();

    % 右下角图例（用 NaN 占位线生成图例条目）
    % 北太天元不支持 gobjects，也不支持对未定义变量做句柄数组索引赋值，
    % 因此这里改为按顺序直接画占位线，再让 legend 自动按绘制顺序取条目。
    subplot(2,2,4); axis off;
    hold on;
_hl = {};   %% 只把带名字的曲线放进图例（北太天元句柄是 cell，用元胞数组存）
    _hl{end+1} = plot(NaN,NaN,'r-','LineWidth',1.2,'DisplayName','M1轨迹');
    _hl{end+1} = plot(NaN,NaN,'b-','LineWidth',1.2,'DisplayName','FY1轨迹');
    for m=1:3
        _hl{end+1} = plot(NaN,NaN,'-','Color',colors(m,:),'LineWidth',1.2,...
            'DisplayName',sprintf('烟弹%d轨迹',m));
        _hl{end+1} = plot(NaN,NaN,'--','Color',colors(m,:),'LineWidth',1.2,...
            'DisplayName',sprintf('云团%d中心',m));
        _hl{end+1} = plot(NaN,NaN,'o','MarkerEdgeColor',colors(m,:),...
            'MarkerFaceColor',colors(m,:),'MarkerSize',6,...
            'DisplayName',sprintf('投放点%d',m));
        _hl{end+1} = plot(NaN,NaN,'s','MarkerEdgeColor',colors(m,:),...
            'MarkerFaceColor',colors(m,:),'MarkerSize',7,...
            'DisplayName',sprintf('起爆点%d',m));
    end
    _hl{end+1} = plot(NaN,NaN,'k--','LineWidth',2.0,'DisplayName','视线(区间首尾)');
    legend(_hl,'Location','best');
    btSgTitle(sprintf('三视图（以第2起爆点为中心，范围 x:±%d, y:±%d, z:±%d m）',xRange,yRange,zRange));
end
end