function J=problem3_objective(X,cfg,Q,dt)
% 模拟退火最小化目标
    [Teff,~,diagInfo]=evaluate_cooperative_duration(X,cfg,Q,dt,0);
    if Teff>0
        J=-100-Teff+1e-5*diagInfo.minWorstCoopDistance;
    elseif isfinite(diagInfo.minWorstCoopDistance)
        J=max(0,diagInfo.minWorstCoopDistance-cfg.smokeR);
    else
        J=1e8;
    end
end