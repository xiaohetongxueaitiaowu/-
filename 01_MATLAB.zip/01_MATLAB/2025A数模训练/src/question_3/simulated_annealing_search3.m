function [bestX,bestCost,history]=simulated_annealing_search3(...
    objective,x0,lb,ub,cfg,opt)
% 8维有界模拟退火算法
    currentX=repair_decision3(x0,lb,ub,cfg);
    currentCost=objective(currentX);
    bestX=currentX; bestCost=currentCost;
    n=opt.MaxIterations;
    history.currentCost=zeros(n,1);
    history.bestCost=zeros(n,1);
    history.temperature=zeros(n,1);
    history.accepted=false(n,1);
    stall=0; reheatUntil=0;

    for k=1:n
        if n==1, r=1; else, r=(k-1)/(n-1); end
        Ck=opt.InitialTemperature*...
            (opt.FinalTemperature/opt.InitialTemperature)^r;
        sk=opt.InitialStep.*(opt.FinalStep./opt.InitialStep).^r;

        if k<=reheatUntil
            Ck=max(Ck,0.25*opt.InitialTemperature);
            sk=max(sk,0.25*opt.InitialStep);
        end

        qk=opt.GlobalJumpProbability*(1-r);
        if rand<qk
            candidateX=random_feasible_decision3(lb,ub,cfg);
        else
            candidateX=currentX+sk.*randn(1,8);
            candidateX=repair_decision3(candidateX,lb,ub,cfg);
        end

        candidateCost=objective(candidateX);
        deltaJ=candidateCost-currentCost;
        accept=(deltaJ<=0) || (rand<exp(-deltaJ/max(Ck,eps)));
        if accept
            currentX=candidateX; currentCost=candidateCost;
            history.accepted(k)=true;
        end

        if currentCost<bestCost
            bestX=currentX; bestCost=currentCost; stall=0;
        else
            stall=stall+1;
        end

        if stall>=opt.ReheatAfter
            currentX=bestX; currentCost=bestCost;
            reheatUntil=min(n,k+opt.ReheatLength);
            stall=0;
        end

        history.currentCost(k)=currentCost;
        history.bestCost(k)=bestCost;
        history.temperature(k)=Ck;
        if opt.DisplayEvery>0 && (k==1 || mod(k,opt.DisplayEvery)==0 || k==n)
            fprintf('迭代%5d/%5d，Ck=%9.5f，当前J=%12.6f，最优J=%12.6f\n',...
                k,n,Ck,currentCost,bestCost);
        end
    end
    history.acceptanceRate=mean(history.accepted);
    fprintf('本次退火接受率：%.2f%%\n',100*history.acceptanceRate);
end