function f = btNewFigure(figName,pos)
% btNewFigure 创建正常可见的图窗，各图窗保持打开，供手动查看和保存。
% 不再暂停等待、自动关闭上一张图或将其他图窗隐藏。
    global BT_FIG_BG

    if nargin < 2 || isempty(pos)
        pos = [100 100 900 650];
    end
    if nargin < 1 || isempty(figName)
        figName = '';
    end
    bg = [247 247 247]/255;
    if ~isempty(BT_FIG_BG)
        bg = BT_FIG_BG;
    end

    try
        f = figure('Visible','on','Color',bg,'Name',figName,'Position',pos);
    catch
        try
            f = figure('Visible','on','Color',bg,'Position',pos);
        catch
            try
                f = figure('Visible','on','Color',bg);
            catch
                f = figure;
                try, set(f,'Visible','on'); catch, end
            end
        end
    end
end
