function shade_intervals(intervals)
% 在当前坐标轴中用浅绿色标出有效遮蔽区间
if isempty(intervals)
return;
end
ax=gca;
yLimits=ylim(ax);
for i=1:size(intervals,1)
p=patch(ax,[intervals(i,1),intervals(i,2),intervals(i,2),intervals(i,1)],...
[yLimits(1),yLimits(1),yLimits(2),yLimits(2)],...
[0.68,0.92,0.74],'FaceAlpha',0.25,'EdgeColor','none',...
'HandleVisibility','off');
uistack(p,'bottom');
end
set(ax,'Layer','top');
end
