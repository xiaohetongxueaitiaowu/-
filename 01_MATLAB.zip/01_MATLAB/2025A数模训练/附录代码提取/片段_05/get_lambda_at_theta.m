function lambda=get_lambda_at_theta(th,t,M1,C11,center,r,z)
% 计算圆周上角度th处的点对应的投影参数lambda
% 输入：th-角度, t, M1, C11, center-底面圆心, r-半径, z-高度
% 输出：lambda-投影参数
P=center+[r*cos(th),r*sin(th),z];
[lambda,~]=coverGeometry(t,M1,C11,P);
end
