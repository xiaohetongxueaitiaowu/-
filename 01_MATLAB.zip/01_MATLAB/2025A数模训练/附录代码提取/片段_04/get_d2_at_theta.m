function d2=get_d2_at_theta(th,t,M1,C11,center,r,z)
% 计算圆周上角度th处的点对应的垂直距离平方d2
% 输入：th-角度, t, M1, C11, center-底面圆心, r-半径, z-高度
% 输出：d2-垂直距离平方
P=center+[r*cos(th),r*sin(th),z];
[~,d2]=coverGeometry(t,M1,C11,P);
end
