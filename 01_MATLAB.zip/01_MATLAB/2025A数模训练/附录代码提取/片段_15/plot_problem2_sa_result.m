function plot_problem2_sa_result(X,cfg,Q,dt,intervals,stage1,stage2)
% 绘制收敛、遮蔽判据以及最优方案三维图（全局+三视图）

s=compute_problem2_strategy(X,cfg);
tEnd=min(s.tb11+cfg.cloudLife,cfg.tM1Arrive);
t=(s.tb11:dt:tEnd).';
if t(end)<tEnd
t(end+1,1)=tEnd;
end
[covered,worstDistance]=cylinder_covered_at_times(t,X,cfg,Q);

%% 1. 收敛曲线
figure('Color','w','Name','问题2模拟退火收敛过程'); hold on;
for r=1:numel(stage1)
plot(stage1(r).history.bestCost,'LineWidth',1.0,...
'DisplayName',sprintf('粗搜索%d',r));
end
for r=1:numel(stage2)
plot(stage2(r).history.bestCost,'LineWidth',1.5,...
'DisplayName',sprintf('精细搜索%d',r));
end
xlabel('迭代次数');
ylabel('历史最优目标函数值');
title('模拟退火收敛过程');
grid on; box on; legend('Location','best');

%% 2. 遮蔽判据图
figure('Color','w','Name','问题2圆柱目标遮蔽判据');
subplot(2,1,1);
plot(t,worstDistance,'b-','LineWidth',1.5); hold on;
yline(cfg.smokeR,'r--','烟幕半径10 m','LineWidth',1.2);
shadeIntervals(intervals);
xlabel('时间 t / s');
ylabel('最坏目标视线距离 / m');
title('完整圆柱遮蔽条件：所有目标视线距离均不超过10 m');
grid on; box on;

subplot(2,1,2);
stairs(t,double(covered),'Color',[0.1,0.55,0.3],'LineWidth',1.5);
ylim([-0.1,1.1]); yticks([0,1]);
yticklabels({'未完全遮蔽','完全遮蔽'});
xlabel('时间 t / s'); ylabel('遮蔽状态');
grid on; box on;

%% 3. 轨迹函数定义
M1=@(tt) cfg.M10+cfg.vM1*tt;
F1=@(tt) cfg.F10+s.vF1Vec*tt;
P11=@(tt) s.P011+s.vF1Vec*(tt-s.td11)+[0,0,-0.5*cfg.g*(tt-s.td11)^2];
C11=@(tt) s.Pb11+[0,0,-cfg.vCloud*(tt-s.tb11)];

if ~isempty(intervals)
tShow=mean(intervals(1,:));
else
[~,k]=min(worstDistance);
tShow=t(k);
end

% 采样轨迹点
tM=linspace(0,cfg.tM1Arrive,400);
tF=linspace(0,s.tb11,150);
tP=linspace(s.td11,s.tb11,100);
tC=linspace(s.tb11,tEnd,150);
MPlot=sample_position_function(M1,tM);
FPlot=sample_position_function(F1,tF);
PPlot=sample_position_function(P11,tP);
CPlot=sample_position_function(C11,tC);

%% 3a. 全局三维图
figure('Color','w','Name','问题2最优方案三维图（全局）'); hold on;
[xc,yc,zc]=cylinder(cfg.targetR,80);
xc=xc+cfg.targetCenterXY(1);
yc=yc+cfg.targetCenterXY(2);
zc=zc*cfg.targetH;
surf(xc,yc,zc,'FaceColor',[0.15,0.65,0.38],...
'FaceAlpha',0.55,'EdgeColor','none','DisplayName','有效遮蔽区间');
plot3(MPlot(:,1),MPlot(:,2),MPlot(:,3),'r-','LineWidth',1.8,...
'DisplayName','M1轨迹');
plot3(FPlot(:,1),FPlot(:,2),FPlot(:,3),'b-','LineWidth',1.8,...
'DisplayName','FY1轨迹');
plot3(PPlot(:,1),PPlot(:,2),PPlot(:,3),...
'Color',[0.88,0.46,0.08],'LineWidth',2.0,...
'DisplayName','烟幕弹轨迹');
plot3(CPlot(:,1),CPlot(:,2),CPlot(:,3),...
'Color',[0.25,0.25,0.25],'LineWidth',2.0,...
'DisplayName','云团中心轨迹');
scatter3(cfg.O(1),cfg.O(2),cfg.O(3),80,[0.95,0.65,0.05],'filled',...
'DisplayName','假目标');
scatter3(s.P011(1),s.P011(2),s.P011(3),65,'b','filled',...
'DisplayName','投放点');
scatter3(s.Pb11(1),s.Pb11(2),s.Pb11(3),65,[0.88,0.25,0.08],'filled',...
'DisplayName','起爆点');

Mt=M1(tShow);
Ct=C11(tShow);
[xs,ys,zs]=sphere(48);
surf(cfg.smokeR*xs+Ct(1),cfg.smokeR*ys+Ct(2),...
cfg.smokeR*zs+Ct(3),'FaceColor',[0.55,0.58,0.60],...
'FaceAlpha',0.38,'EdgeColor','none',...
'DisplayName','烟幕球');

% 导弹→真目标视线
trueTargetBottom=[cfg.targetCenterXY,0];
plot3([Mt(1),trueTargetBottom(1)],...
[Mt(2),trueTargetBottom(2)],...
[Mt(3),trueTargetBottom(3)],'k--','LineWidth',1.2,...
'DisplayName','导弹→真目标视线');

% 少量圆柱采样视线（不加入图例）
nShow=min(20,size(Q,1));
idx=round(linspace(1,size(Q,1),nShow));
for j=idx
q=Q(j,:);
plot3([Mt(1),q(1)],[Mt(2),q(2)],[Mt(3),q(3)],...
'k-','LineWidth',0.45,'HandleVisibility','off','Color',[0.4,0.4,0.4,0.5]);
end

xlabel('x / m'); ylabel('y / m'); zlabel('z / m');
title('全局视图');
legend('Location','bestoutside');
grid on; box on;
view(38,24);

%% 3b. 标准三视图（图例统一放在右下角）
figure('Color','w','Name','问题2最优方案三视图（放大）');
center=s.Pb11;
range=150;
trueTargetBottom=[cfg.targetCenterXY,0];
Mt_show=M1(tShow);
theta_circ=linspace(0,2*pi,50);
trajLineWidth=2;

% ---- 左上：主视图（前视图，XZ）----
subplot(2,2,1); hold on; view(0,0);
plot3(MPlot(:,1),MPlot(:,2),MPlot(:,3),'r-','LineWidth',trajLineWidth);
plot3(FPlot(:,1),FPlot(:,2),FPlot(:,3),'b-','LineWidth',trajLineWidth);
plot3(PPlot(:,1),PPlot(:,2),PPlot(:,3),'Color',[0.88,0.46,0.08],'LineWidth',trajLineWidth);
plot3(CPlot(:,1),CPlot(:,2),CPlot(:,3),'Color',[0.25,0.25,0.25],'LineWidth',trajLineWidth);
scatter3(s.P011(1),s.P011(2),s.P011(3),80,'b','filled');
scatter3(s.Pb11(1),s.Pb11(2),s.Pb11(3),80,[0.88,0.25,0.08],'filled');
% 烟幕球投影（XZ平面圆）
cxz=Ct(1)+cfg.smokeR*cos(theta_circ);
czz=Ct(3)+cfg.smokeR*sin(theta_circ);
cyz=Ct(2)*ones(size(theta_circ));
plot3(cxz,cyz,czz,'Color',[0.55,0.58,0.60],'LineWidth',1.5);
% 视线
plot3([Mt_show(1),trueTargetBottom(1)],...
[Mt_show(2),trueTargetBottom(2)],...
[Mt_show(3),trueTargetBottom(3)],'k--','LineWidth',trajLineWidth);
text(s.Pb11(1)+10,s.Pb11(2)+15,s.Pb11(3)+20,'起爆点','Color',[0.88,0.25,0.08],'FontSize',9);
text(s.P011(1)+10,s.P011(2)-40,s.P011(3)+20,'投放点','Color','b','FontSize',9);
text(Ct(1)+10,Ct(2)+15,Ct(3)-20,'烟幕球','Color',[0.3,0.3,0.3],'FontSize',9);
xlabel('x'); zlabel('z'); title('主视图 (XZ)');
xlim([center(1)-range,center(1)+range]);
zlim([center(3)-range,center(3)+range]);
grid on; box on;

% ---- 左下：俯视图（XY）----
subplot(2,2,3); hold on; view(0,90);
plot3(MPlot(:,1),MPlot(:,2),MPlot(:,3),'r-','LineWidth',trajLineWidth);
plot3(FPlot(:,1),FPlot(:,2),FPlot(:,3),'b-','LineWidth',trajLineWidth);
plot3(PPlot(:,1),PPlot(:,2),PPlot(:,3),'Color',[0.88,0.46,0.08],'LineWidth',trajLineWidth);
plot3(CPlot(:,1),CPlot(:,2),CPlot(:,3),'Color',[0.25,0.25,0.25],'LineWidth',trajLineWidth);
scatter3(s.P011(1),s.P011(2),s.P011(3),80,'b','filled');
scatter3(s.Pb11(1),s.Pb11(2),s.Pb11(3),80,[0.88,0.25,0.08],'filled');
cx=Ct(1)+cfg.smokeR*cos(theta_circ);
cy=Ct(2)+cfg.smokeR*sin(theta_circ);
cz=Ct(3)*ones(size(theta_circ));
plot3(cx,cy,cz,'Color',[0.55,0.58,0.60],'LineWidth',1.5);
plot3([Mt_show(1),trueTargetBottom(1)],...
[Mt_show(2),trueTargetBottom(2)],...
[Mt_show(3),trueTargetBottom(3)],'k--','LineWidth',trajLineWidth);
text(s.Pb11(1),s.Pb11(2)+20,s.Pb11(3)+10,'起爆点','Color',[0.88,0.25,0.08],'FontSize',9);
text(s.P011(1),s.P011(2)-15,s.P011(3)+10,'投放点','Color','b','FontSize',9);
text(Ct(1),Ct(2)-20,Ct(3)-15,'烟幕球','Color',[0.3,0.3,0.3],'FontSize',9);
xlabel('x'); ylabel('y'); title('俯视图 (XY)');
xlim([center(1)-range,center(1)+range]);
ylim([center(2)-range./2,center(2)+range./2]);
grid on; box on;

% ---- 右上：左视图（YZ）----
subplot(2,2,2); hold on; view(90,0);
plot3(MPlot(:,1),MPlot(:,2),MPlot(:,3),'r-','LineWidth',trajLineWidth);
plot3(FPlot(:,1),FPlot(:,2),FPlot(:,3),'b-','LineWidth',trajLineWidth);
plot3(PPlot(:,1),PPlot(:,2),PPlot(:,3),'Color',[0.88,0.46,0.08],'LineWidth',trajLineWidth);
plot3(CPlot(:,1),CPlot(:,2),CPlot(:,3),'Color',[0.25,0.25,0.25],'LineWidth',trajLineWidth);
scatter3(s.P011(1),s.P011(2),s.P011(3),80,'b','filled');
scatter3(s.Pb11(1),s.Pb11(2),s.Pb11(3),80,[0.88,0.25,0.08],'filled');
cyz2=Ct(2)+cfg.smokeR*cos(theta_circ);
czz2=Ct(3)+cfg.smokeR*sin(theta_circ);
cxz2=Ct(1)*ones(size(theta_circ));
plot3(cxz2,cyz2,czz2,'Color',[0.55,0.58,0.60],'LineWidth',1.5);
plot3([Mt_show(1),trueTargetBottom(1)],...
[Mt_show(2),trueTargetBottom(2)],...
[Mt_show(3),trueTargetBottom(3)],'k--','LineWidth',trajLineWidth);
text(s.Pb11(1),s.Pb11(2)+8,s.Pb11(3)+10,'起爆点','Color',[0.88,0.25,0.08],'FontSize',9);
text(s.P011(1),s.P011(2)-20,s.P011(3)+10,'投放点','Color','b','FontSize',9);
text(Ct(1),Ct(2)+8,Ct(3)-15,'烟幕球','Color',[0.3,0.3,0.3],'FontSize',9);
ylabel('y'); zlabel('z'); title('左视图 (YZ)');
ylim([center(2)-range./2,center(2)+range./2]);
zlim([center(3)-range,center(3)+range]);
grid on; box on;

% ---- 右下：图例（空轴） ----
subplot(2,2,4); axis off;
hold on;
h1=plot(NaN,NaN,'r-','LineWidth',trajLineWidth,'DisplayName','M1轨迹');
h2=plot(NaN,NaN,'k--','LineWidth',trajLineWidth,'DisplayName','导弹→真目标视线');
legend([h1,h2],'Location','northeast','Box','on');

sgtitle('起爆处放大三视图（显示范围以起爆点为中心xz轴方向±150m,y轴方向±75m）');
end
