function [covered,worstCoopDistance]=cooperative_covered_at_times(tVec,X,cfg,Q)
% 三云团协同遮蔽判定：D3(t)=max_j min_m d_1mj(t)，D3<=10为完全遮蔽
tVec=tVec(:);
nT=numel(tVec);
nQ=size(Q,1);
s=compute_problem3_strategy(X,cfg);

M=cfg.M10+tVec.*cfg.vM1;
Qx=Q(:,1).'; Qy=Q(:,2).'; Qz=Q(:,3).';
covered=false(nT,1);
worstCoopDistance=inf(nT,1);

for first=1:cfg.timeChunk:nT
last=min(first+cfg.timeChunk-1,nT);
idx=first:last;
tc=tVec(idx);
Mx=M(idx,1); My=M(idx,2); Mz=M(idx,3);

vx=Qx-Mx; vy=Qy-My; vz=Qz-Mz;
denominator=vx.^2+vy.^2+vz.^2;
minD2=inf(numel(idx),nQ);

for m=1:3
active=tc>=s.tb(m) & tc<=s.tb(m)+cfg.cloudLife &...
tc<=cfg.tM1Arrive;
if ~any(active), continue; end

Cx=s.Pb(m,1)*ones(numel(idx),1);
Cy=s.Pb(m,2)*ones(numel(idx),1);
Cz=s.Pb(m,3)-cfg.vCloud*(tc-s.tb(m));
active=active & Cz>=0;

wx=Cx-Mx; wy=Cy-My; wz=Cz-Mz;
lambda=(wx.*vx+wy.*vy+wz.*vz)./denominator;
lambdaHat=min(1,max(0,lambda));
Hx=Mx+lambdaHat.*vx;
Hy=My+lambdaHat.*vy;
Hz=Mz+lambdaHat.*vz;
d2=(Cx-Hx).^2+(Cy-Hy).^2+(Cz-Hz).^2;
d2(~active,:)=inf;
minD2=min(minD2,d2);
end

maxMinD2=max(minD2,[],2);
worstCoopDistance(idx)=sqrt(max(maxMinD2,0));
covered(idx)=maxMinD2<=cfg.smokeR^2;
end
end
