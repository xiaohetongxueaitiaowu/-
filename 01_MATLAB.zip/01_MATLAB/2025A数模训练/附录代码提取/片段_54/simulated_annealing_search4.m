function [bestX,bestCost,history]=simulated_annealing_search4(...
objective,x0,lb,ub,cfg,opt)
% 带分块扰动、精英档案和自适应再升温的模拟退火
% 扰动策略：全局跳跃、分块替换、分块扰动、单坐标扰动、普通高斯扰动
currentX=repair_decision4(x0,lb,ub,cfg);
currentCost=objective(currentX);
bestX=currentX;
bestCost=currentCost;

n=opt.MaxIterations;
history.currentCost=zeros(n,1);
history.bestCost=zeros(n,1);
history.temperature=zeros(n,1);
history.accepted=false(n,1);
history.proposalType=zeros(n,1); % 1局部，2分块，3坐标，4分块重置，5全局

globalFloor=get_opt4(opt,'GlobalJumpFloor',0.003);
blockMoveProb=get_opt4(opt,'BlockMoveProbability',0.48);
coordinateMoveProb=get_opt4(opt,'CoordinateMoveProbability',0.16);
blockRestartProb=get_opt4(opt,'BlockRestartProbability',0.035);
globalCandidates=get_opt4(opt,'GlobalCandidates',3);
archiveSize=get_opt4(opt,'ArchiveSize',10);
adaptWindow=get_opt4(opt,'AdaptWindow',60);
reheatScale=get_opt4(opt,'ReheatScale',0.65);

archiveX=currentX;
archiveCost=currentCost;
stall=0;
reheatUntil=0;
stepScale=1;

for k=1:n
if n==1,r=1;else,r=(k-1)/(n-1);end
Ck=opt.InitialTemperature*...
(opt.FinalTemperature/opt.InitialTemperature)^r;
sk=opt.InitialStep.*(opt.FinalStep./opt.InitialStep).^r;
sk=sk*stepScale;

if k<=reheatUntil
Ck=max(Ck,0.35*opt.InitialTemperature);
sk=max(sk,0.30*opt.InitialStep);
end

qGlobal=globalFloor+opt.GlobalJumpProbability*(1-r);
u=rand;
% 根据概率选择扰动类型
if u<qGlobal
% 全局跳跃：从几何采样器生成多个候选，取最优
candidateCost=inf;
candidateX=currentX;
for j=1:globalCandidates
trialX=global_sample4(opt,lb,ub,cfg);
trialCost=objective(trialX);
if trialCost<candidateCost
candidateX=trialX;
candidateCost=trialCost;
end
end
proposalType=5;
elseif u<qGlobal+blockRestartProb
% 分块重置：仅替换一架无人机的整组变量
donor=global_sample4(opt,lb,ub,cfg);
candidateX=currentX;
i=randi(3);q=4*(i-1)+(1:4);
candidateX(q)=donor(q);
candidateX=repair_decision4(candidateX,lb,ub,cfg);
candidateCost=objective(candidateX);
proposalType=4;
elseif u<qGlobal+blockRestartProb+blockMoveProb
% 分块扰动：整组变量同时加噪声
candidateX=currentX;
i=randi(3);q=4*(i-1)+(1:4);
candidateX(q)=candidateX(q)+sk(q).*randn(1,4);
candidateX=repair_decision4(candidateX,lb,ub,cfg);
candidateCost=objective(candidateX);
proposalType=2;
elseif u<qGlobal+blockRestartProb+blockMoveProb+coordinateMoveProb
% 单坐标扰动
candidateX=currentX;
j=randi(12);
candidateX(j)=candidateX(j)+sk(j)*randn;
candidateX=repair_decision4(candidateX,lb,ub,cfg);
candidateCost=objective(candidateX);
proposalType=3;
else
% 普通高斯扰动
candidateX=currentX+sk.*randn(1,12);
candidateX=repair_decision4(candidateX,lb,ub,cfg);
candidateCost=objective(candidateX);
proposalType=1;
end

% 接受/拒绝
deltaJ=candidateCost-currentCost;
accept=(deltaJ<=0)||(rand<exp(-deltaJ/max(Ck,eps)));
if accept
currentX=candidateX;
currentCost=candidateCost;
history.accepted(k)=true;
end

% 更新精英档案
[archiveX,archiveCost]=update_archive4(archiveX,archiveCost,...
candidateX,candidateCost,archiveSize);
if currentCost<bestCost
bestX=currentX;
bestCost=currentCost;
stall=0;
else
stall=stall+1;
end

% 停滞后从档案中随机选点再升温，避免陷入局部
if stall>=opt.ReheatAfter
base=archiveX(randi(size(archiveX,1)),:);
currentX=repair_decision4(base+...
reheatScale*opt.InitialStep.*randn(1,12),lb,ub,cfg);
currentCost=objective(currentX);
reheatUntil=min(n,k+opt.ReheatLength);
stall=0;
end

history.currentCost(k)=currentCost;
history.bestCost(k)=bestCost;
history.temperature(k)=Ck;
history.proposalType(k)=proposalType;

% 自适应调节邻域尺度
if mod(k,adaptWindow)==0
recentRate=mean(history.accepted(k-adaptWindow+1:k));
if recentRate<0.12
stepScale=max(0.35,0.78*stepScale);
elseif recentRate>0.55
stepScale=min(2.0,1.18*stepScale);
end
end

if opt.DisplayEvery>0&&(k==1||mod(k,opt.DisplayEvery)==0||k==n)
fprintf('迭代%5d/%5d，Ck=%9.5f，当前J=%12.6f，最优J=%12.6f\n',...
k,n,Ck,currentCost,bestCost);
end
end

history.acceptanceRate=mean(history.accepted);
history.archiveX=archiveX;
history.archiveCost=archiveCost;
fprintf('本次退火接受率：%.2f%%\n',100*history.acceptanceRate);
end

function value=get_opt4(opt,name,defaultValue)
if isfield(opt,name),value=opt.(name);else,value=defaultValue;end
end

function X=global_sample4(opt,lb,ub,cfg)
if isfield(opt,'GlobalSampler') && ~isempty(opt.GlobalSampler)
X=opt.GlobalSampler();
else
X=random_feasible_decision4(lb,ub,cfg);
end
X=repair_decision4(X,lb,ub,cfg);
end

function [archiveX,archiveCost]=update_archive4(archiveX,archiveCost,x,cost,maxSize)
% 维护精英档案，并去重
archiveX=[archiveX;x]; 
archiveCost=[archiveCost;cost]; 
[archiveCost,order]=sort(archiveCost,'ascend');
archiveX=archiveX(order,:);

keep=true(size(archiveCost));
for i=2:numel(archiveCost)
for j=1:i-1
if keep(j) && norm(archiveX(i,:)-archiveX(j,:))<1e-8
keep(i)=false;break;
end
end
end
archiveX=archiveX(keep,:);
archiveCost=archiveCost(keep);
if numel(archiveCost)>maxSize
archiveX=archiveX(1:maxSize,:);
archiveCost=archiveCost(1:maxSize);
end
end
