function plot_problem4_sa_result(X,cfg,Q,dt,intervals,stage1,stage2,stage3,finalDiag)
% 绘制收敛曲线、协同判据、三团烟幕贡献诊断、各有效区间全局图及三视图
if nargin<8,stage3=[];end
if nargin<9,finalDiag=[];end
s = compute_problem4_strategy(X,cfg);
tBegin = min(s.tb);
tEnd = min(max(s.tb + cfg.cloudLife), cfg.tM1Arrive);
t = (tBegin:dt:tEnd).';
if t(end) < tEnd, t(end+1,1) = tEnd; end
[covered,D,cloudDetail] = cooperative_covered_at_times4(t,X,cfg,Q);

%% 1. 收敛曲线
figure('Color','w','Name','问题4模拟退火收敛过程'); hold on;
for r=1:numel(stage1)
plot(stage1(r).history.bestCost,'LineWidth',1.0,...
'DisplayName',sprintf('粗搜索%d',r));
end
for r=1:numel(stage2)
plot(stage2(r).history.bestCost,'LineWidth',1.5,...
'DisplayName',sprintf('精细搜索%d',r));
end
for r=1:numel(stage3)
plot(stage3(r).history.bestCost,'LineWidth',2.0,...
'DisplayName',sprintf('高密度抛光%d',r));
end
xlabel('迭代次数'); ylabel('历史最优目标函数值');
title('问题4模拟退火收敛过程'); grid on; box on; legend('Location','best');

%% 2. 协同遮蔽判据
figure('Color','w','Name','问题4协同遮蔽判据');
subplot(2,1,1);
plot(t,D,'b-','LineWidth',1.5); hold on;
yline(cfg.smokeR,'r--','烟幕半径10 m','LineWidth',1.2);
shadeIntervals(intervals);
xlabel('时间 t / s'); ylabel('D_{(1:3)11}(t) / m');
title('三架无人机烟幕协同遮蔽判据'); grid on; box on;
subplot(2,1,2);
stairs(t,double(covered),'Color',[0.1,0.55,0.3],'LineWidth',1.5);
ylim([-0.1,1.1]); yticks([0,1]);
yticklabels({'未完全遮蔽','协同完全遮蔽'});
xlabel('时间 t / s'); ylabel('遮蔽状态'); grid on; box on;

%% 3. 三团烟幕的真实贡献诊断
participationDuration=sum(cloudDetail.participationFlag,1)*dt;
essentialDuration=sum(cloudDetail.essentialFlag,1)*dt;
figure('Color','w','Name','问题4三团烟幕贡献诊断',...
'Position',[120,120,1100,720]);
subplot(2,1,1);hold on;
for i=1:3
plot(t,cloudDetail.rayShare(:,i),'LineWidth',1.8,...
'DisplayName',sprintf('FY%d承担视线比例',i));
end
shadeIntervals(intervals);
xlabel('时间 t / s');ylabel('目标视线比例');
title('完整遮蔽过程中各烟幕承担的圆柱目标视线比例');
ylim([0,1.05]);grid on;box on;legend('Location','best');

subplot(2,1,2);
bar([participationDuration(:),essentialDuration(:)],'grouped');
xticks(1:3);xticklabels({'FY1','FY2','FY3'});
ylabel('贡献时长 / s');
title('参与时长与不可替代贡献时长');
legend({'参与完整遮蔽','移除后遮蔽失效'},'Location','best');
grid on;box on;

%% 定义轨迹函数
M1 = @(tt) cfg.M10 + cfg.vM1*tt;
trueTargetBottom = [cfg.targetCenterXY, 0];
colors = [0.10,0.42,0.90; 0.70,0.22,0.75; 0.05,0.62,0.72];
uavNames = {'FY1','FY2','FY3'};

%% 4. 为每个有效区间绘制全局图
numIntervals = size(intervals,1);
if numIntervals == 0
fprintf('无有效遮蔽区间，跳过全局图绘制。\n');
else
for k = 1:numIntervals
tStart = intervals(k,1);
tEnd_iv = intervals(k,2);
idxIv=find(t>=tStart & t<=tEnd_iv & covered);
if isempty(idxIv)
[~,kMid]=min(abs(t-0.5*(tStart+tEnd_iv)));
else
% 展示参与烟幕数量最多的时刻
score=sum(cloudDetail.rayShare(idxIv,:)>0,2)+...
1e-3*min(cloudDetail.rayShare(idxIv,:)+...
(cloudDetail.rayShare(idxIv,:)==0),[],2);
[~,kLocal]=max(score);
kMid=idxIv(kLocal);
end
tMid=t(kMid);

figure('Color','w','Name',sprintf('问题4全局图-区间%d (%.2f~%.2f s)',k,tStart,tEnd_iv));
hold on;
% 圆柱
[xc,yc,zc] = cylinder(cfg.targetR,80);
surf(xc+cfg.targetCenterXY(1), yc+cfg.targetCenterXY(2), zc*cfg.targetH,...
'FaceColor',[0.15,0.65,0.38],'FaceAlpha',0.55,'EdgeColor','none',...
'DisplayName','真目标圆柱');
tM = linspace(0, cfg.tM1Arrive, 400);
M_pts = sample_pts(M1, tM);
plot3(M_pts(:,1), M_pts(:,2), M_pts(:,3), 'r-', 'LineWidth', 1.8,...
'DisplayName','M1轨迹');
scatter3(cfg.O(1), cfg.O(2), cfg.O(3), 80, [0.95,0.65,0.05], 'filled',...
'DisplayName','假目标');

for i = 1:3
Fi = @(tt) cfg.F0(i,:) + s.vFVec(i,:)*tt;
tF = linspace(0, s.tb(i), 120);
F_pts = sample_pts(Fi, tF);
plot3(F_pts(:,1), F_pts(:,2), F_pts(:,3), '-', 'Color', colors(i,:),...
'LineWidth', 1.2, 'DisplayName', sprintf('%s飞行轨迹',uavNames{i}));

isActive = (tMid >= s.tb(i)) && (tMid <= s.tb(i) + cfg.cloudLife);
if isActive
Pi = @(tt) s.P0(i,:) + s.vFVec(i,:)*(tt-s.td(i)) + [0,0,-0.5*cfg.g*(tt-s.td(i))^2];
tP = linspace(s.td(i), s.tb(i), 60);
P_pts = sample_pts(Pi, tP);
plot3(P_pts(:,1), P_pts(:,2), P_pts(:,3), '-', 'Color', colors(i,:),...
'LineWidth', 2.0, 'DisplayName', sprintf('%s烟幕弹轨迹',uavNames{i}));
Ci = @(tt) s.Pb(i,:) + [0,0,-cfg.vCloud*(tt-s.tb(i))];
tC = linspace(s.tb(i), min(s.tb(i)+cfg.cloudLife, cfg.tM1Arrive), 80);
C_pts = sample_pts(Ci, tC);
plot3(C_pts(:,1), C_pts(:,2), C_pts(:,3), '--', 'Color', colors(i,:),...
'LineWidth', 1.5, 'DisplayName', sprintf('%s云团中心',uavNames{i}));
scatter3(s.P0(i,1), s.P0(i,2), s.P0(i,3), 55, colors(i,:), 'filled',...
'DisplayName', sprintf('%s投放点',uavNames{i}));
scatter3(s.Pb(i,1), s.Pb(i,2), s.Pb(i,3), 65, colors(i,:), 'filled',...
'DisplayName', sprintf('%s起爆点',uavNames{i}));
Ct = Ci(tMid);
[xs,ys,zs] = sphere(30);
surf(cfg.smokeR*xs+Ct(1), cfg.smokeR*ys+Ct(2),...
cfg.smokeR*zs+Ct(3), 'FaceColor', colors(i,:),...
'FaceAlpha', 0.25, 'EdgeColor', 'none',...
'DisplayName', sprintf('%s烟幕球：承担%.1f%%视线',...
uavNames{i},100*cloudDetail.rayShare(kMid,i)));
else
tF_full = linspace(0, cfg.tM1Arrive, 300);
F_full = sample_pts(Fi, tF_full);
plot3(F_full(:,1), F_full(:,2), F_full(:,3), ':', 'Color', colors(i,:),...
'LineWidth', 0.8, 'HandleVisibility','off');
end
end

Mt_start = M1(tStart);
Mt_end = M1(tEnd_iv);
plot3([Mt_start(1), trueTargetBottom(1)], [Mt_start(2), trueTargetBottom(2)],...
[Mt_start(3), trueTargetBottom(3)], 'k--', 'LineWidth', 1.0,...
'DisplayName','区间起始视线');
scatter3(Mt_start(1), Mt_start(2), Mt_start(3), 40, 'k', 'filled',...
'DisplayName','起始时刻导弹位置');
plot3([Mt_end(1), trueTargetBottom(1)], [Mt_end(2), trueTargetBottom(2)],...
[Mt_end(3), trueTargetBottom(3)], 'k--', 'LineWidth', 1.0,...
'DisplayName','区间结束视线');
scatter3(Mt_end(1), Mt_end(2), Mt_end(3), 40, 'k', 'filled',...
'DisplayName','结束时刻导弹位置');

xlabel('x / m'); ylabel('y / m'); zlabel('z / m');
title(sprintf('区间%d：有效遮蔽 [%.3f, %.3f] s', k, tStart, tEnd_iv));
legend('Location','bestoutside');
grid on; box on; axis equal; view(38,24);
end
end

%% 5. 三幅独立三视图：展示每团烟幕的最大贡献时刻
for i = 1:3
if ~isempty(finalDiag) && isfinite(finalDiag.tAtMaxRayShare(i))
tShow=finalDiag.tAtMaxRayShare(i);
else
[shareMax,kShare]=max(cloudDetail.rayShare(:,i).*covered);
if shareMax>0,tShow=t(kShare);else,tShow=s.tb(i);end
end
tShow=max(s.tb(i),min(s.tb(i)+cfg.cloudLife,tShow));
center=s.Pb(i,:)+[0,0,-cfg.vCloud*(tShow-s.tb(i))];

figure('Color','w','Name',sprintf('问题4三视图-FY%d最大贡献时刻',i),...
'Position', [100, 100, 1200, 800]);
range = 150;
trueBottom = [cfg.targetCenterXY, 0];
Mt_show = M1(tShow);

% 主视图 (XZ)
subplot(2,2,1); hold on; view(0,0);
tM = linspace(0, cfg.tM1Arrive, 400);
M_pts = sample_pts(M1, tM);
plot3(M_pts(:,1), M_pts(:,2), M_pts(:,3), 'r-', 'LineWidth', 1.2, 'DisplayName','M1轨迹');
Fi = @(tt) cfg.F0(i,:) + s.vFVec(i,:)*tt;
tF = linspace(0, s.tb(i), 80);
F_pts = sample_pts(Fi, tF);
plot3(F_pts(:,1), F_pts(:,2), F_pts(:,3), '-', 'Color', colors(i,:), 'LineWidth', 1.2,...
'DisplayName',sprintf('%s飞行轨迹',uavNames{i}));
Pi = @(tt) s.P0(i,:) + s.vFVec(i,:)*(tt-s.td(i)) + [0,0,-0.5*cfg.g*(tt-s.td(i))^2];
tP = linspace(s.td(i), s.tb(i), 40);
P_pts = sample_pts(Pi, tP);
plot3(P_pts(:,1), P_pts(:,2), P_pts(:,3), '-', 'Color', colors(i,:), 'LineWidth', 1.8,...
'DisplayName','烟幕弹轨迹');
Ci = @(tt) s.Pb(i,:) + [0,0,-cfg.vCloud*(tt-s.tb(i))];
tC = linspace(s.tb(i), min(s.tb(i)+cfg.cloudLife, cfg.tM1Arrive), 50);
C_pts = sample_pts(Ci, tC);
plot3(C_pts(:,1), C_pts(:,2), C_pts(:,3), '--', 'Color', colors(i,:), 'LineWidth', 1.2,...
'DisplayName','云团中心轨迹');
scatter3(s.P0(i,1), s.P0(i,2), s.P0(i,3), 50, colors(i,:), 'filled', 'DisplayName','投放点');
scatter3(s.Pb(i,1), s.Pb(i,2), s.Pb(i,3), 60, colors(i,:), 'filled', 'DisplayName','起爆点');
theta_circ = linspace(0,2*pi,40);
Cx = center(1) + cfg.smokeR*cos(theta_circ);
Cz = center(3) + cfg.smokeR*sin(theta_circ);
Cy = center(2)*ones(size(theta_circ));
plot3(Cx, Cy, Cz, 'Color', colors(i,:), 'LineWidth', 1.5, 'DisplayName','烟幕球投影');
scatter3(center(1),center(2),center(3),55,colors(i,:),'filled',...
'DisplayName','最大贡献时刻云团中心');
plot3([Mt_show(1), trueBottom(1)], [Mt_show(2), trueBottom(2)],...
[Mt_show(3), trueBottom(3)], 'k--', 'LineWidth', 1.2, 'DisplayName','视线(贡献时刻)');
scatter3(trueBottom(1), trueBottom(2), trueBottom(3), 30, [0.15,0.65,0.38], 'filled',...
'DisplayName','真目标底部');
xlim([center(1)-range, center(1)+range]);
zlim([center(3)-range, center(3)+range]);
xlabel('x (m)'); zlabel('z (m)'); title('主视图 (XZ)');
grid on; box on;

% 俯视图 (XY)
subplot(2,2,3); hold on; view(0,90);
plot3(M_pts(:,1), M_pts(:,2), M_pts(:,3), 'r-', 'LineWidth', 1.2, 'DisplayName','M1轨迹');
plot3(F_pts(:,1), F_pts(:,2), F_pts(:,3), '-', 'Color', colors(i,:), 'LineWidth', 1.2,...
'DisplayName',sprintf('%s飞行轨迹',uavNames{i}));
plot3(P_pts(:,1), P_pts(:,2), P_pts(:,3), '-', 'Color', colors(i,:), 'LineWidth', 1.8,...
'DisplayName','烟幕弹轨迹');
plot3(C_pts(:,1), C_pts(:,2), C_pts(:,3), '--', 'Color', colors(i,:), 'LineWidth', 1.2,...
'DisplayName','云团中心轨迹');
scatter3(s.P0(i,1), s.P0(i,2), s.P0(i,3), 50, colors(i,:), 'filled', 'DisplayName','投放点');
scatter3(s.Pb(i,1), s.Pb(i,2), s.Pb(i,3), 60, colors(i,:), 'filled', 'DisplayName','起爆点');
Cx = center(1) + cfg.smokeR*cos(theta_circ);
Cy = center(2) + cfg.smokeR*sin(theta_circ);
Cz = center(3)*ones(size(theta_circ));
plot3(Cx, Cy, Cz, 'Color', colors(i,:), 'LineWidth', 1.5, 'DisplayName','烟幕球投影');
scatter3(center(1),center(2),center(3),55,colors(i,:),'filled',...
'DisplayName','最大贡献时刻云团中心');
plot3([Mt_show(1), trueBottom(1)], [Mt_show(2), trueBottom(2)],...
[Mt_show(3), trueBottom(3)], 'k--', 'LineWidth', 1.2, 'DisplayName','视线(贡献时刻)');
scatter3(trueBottom(1), trueBottom(2), trueBottom(3), 30, [0.15,0.65,0.38], 'filled',...
'DisplayName','真目标底部');
xlim([center(1)-range, center(1)+range]);
ylim([center(2)-range, center(2)+range]);
xlabel('x (m)'); ylabel('y (m)'); title('俯视图 (XY)');
grid on; box on;

% 左视图 (YZ)
subplot(2,2,2); hold on; view(90,0);
plot3(M_pts(:,1), M_pts(:,2), M_pts(:,3), 'r-', 'LineWidth', 1.2, 'DisplayName','M1轨迹');
plot3(F_pts(:,1), F_pts(:,2), F_pts(:,3), '-', 'Color', colors(i,:), 'LineWidth', 1.2,...
'DisplayName',sprintf('%s飞行轨迹',uavNames{i}));
plot3(P_pts(:,1), P_pts(:,2), P_pts(:,3), '-', 'Color', colors(i,:), 'LineWidth', 1.8,...
'DisplayName','烟幕弹轨迹');
plot3(C_pts(:,1), C_pts(:,2), C_pts(:,3), '--', 'Color', colors(i,:), 'LineWidth', 1.2,...
'DisplayName','云团中心轨迹');
scatter3(s.P0(i,1), s.P0(i,2), s.P0(i,3), 50, colors(i,:), 'filled', 'DisplayName','投放点');
scatter3(s.Pb(i,1), s.Pb(i,2), s.Pb(i,3), 60, colors(i,:), 'filled', 'DisplayName','起爆点');
Cy = center(2) + cfg.smokeR*cos(theta_circ);
Cz = center(3) + cfg.smokeR*sin(theta_circ);
Cx = center(1)*ones(size(theta_circ));
plot3(Cx, Cy, Cz, 'Color', colors(i,:), 'LineWidth', 1.5, 'DisplayName','烟幕球投影');
scatter3(center(1),center(2),center(3),55,colors(i,:),'filled',...
'DisplayName','最大贡献时刻云团中心');
plot3([Mt_show(1), trueBottom(1)], [Mt_show(2), trueBottom(2)],...
[Mt_show(3), trueBottom(3)], 'k--', 'LineWidth', 1.2, 'DisplayName','视线(贡献时刻)');
scatter3(trueBottom(1), trueBottom(2), trueBottom(3), 30, [0.15,0.65,0.38], 'filled',...
'DisplayName','真目标底部');
ylim([center(2)-range, center(2)+range]);
zlim([center(3)-range, center(3)+range]);
ylabel('y (m)'); zlabel('z (m)'); title('左视图 (YZ)');
grid on; box on;

% 图例
subplot(2,2,4); axis off;
hold on;
h1 = plot(NaN,NaN,'r-','LineWidth',1.2,'DisplayName','M1轨迹');
h2 = plot(NaN,NaN,'-','Color',colors(i,:),'LineWidth',1.2,'DisplayName',sprintf('%s飞行轨迹',uavNames{i}));
h3 = plot(NaN,NaN,'-','Color',colors(i,:),'LineWidth',1.8,'DisplayName','烟幕弹轨迹');
h4 = plot(NaN,NaN,'--','Color',colors(i,:),'LineWidth',1.2,'DisplayName','云团中心轨迹');
h5 = scatter(NaN,NaN,50,colors(i,:),'filled','DisplayName','投放点');
h6 = scatter(NaN,NaN,60,colors(i,:),'filled','DisplayName','起爆点');
h7 = plot(NaN,NaN,'Color',colors(i,:),'LineWidth',1.5,'DisplayName','烟幕球投影');
h8 = plot(NaN,NaN,'k--','LineWidth',1.2,'DisplayName','视线(贡献时刻)');
h9 = scatter(NaN,NaN,30,[0.15,0.65,0.38],'filled','DisplayName','真目标底部');
legend([h1,h2,h3,h4,h5,h6,h7,h8,h9], 'Location','best', 'Box','on', 'FontSize',9);

if ~isempty(finalDiag)
shareText=100*finalDiag.maxRayShare(i);
else
shareText=100*max(cloudDetail.rayShare(:,i).*covered);
end
sgtitle(sprintf('%s 最大贡献时刻 t=%.3f s，承担视线比例 %.1f%%（范围±%d m）',...
uavNames{i},tShow,shareText,range));
end
end


function pts = sample_pts(fun, t)
pts = zeros(numel(t),3);
for i = 1:numel(t)
pts(i,:) = fun(t(i));
end
end
