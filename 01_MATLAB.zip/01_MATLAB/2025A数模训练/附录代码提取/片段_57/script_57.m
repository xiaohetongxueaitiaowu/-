%% 问题五完整包统一入口

clear; clc; close all;
packageFolder = fileparts(mfilename('fullpath'));
if isempty(packageFolder), packageFolder = pwd; end

run(fullfile(packageFolder,'problem5.m'));
% problem5.m 内部含 clear，因此返回后重新取得包目录。
packageFolder = fileparts(mfilename('fullpath'));
run(fullfile(packageFolder,'show_problem5_results.m'));

fprintf('\n问题五全部计算、表格和图片均已生成。\n');
fprintf('输出目录：%s\n',packageFolder);
