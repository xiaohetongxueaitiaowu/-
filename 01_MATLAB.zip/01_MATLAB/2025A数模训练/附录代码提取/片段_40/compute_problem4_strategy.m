function s=compute_problem4_strategy(X,cfg)
% 从12维决策向量计算三架无人机的完整策略（航向、速度、投放/起爆时刻与位置）
s.theta=zeros(1,3);
s.headingDeg=zeros(1,3);
s.vF=zeros(1,3);
s.td=zeros(1,3);
s.tau=zeros(1,3);
s.tb=zeros(1,3);
s.eF=zeros(3,3);
s.vFVec=zeros(3,3);
s.P0=zeros(3,3);
s.Pb=zeros(3,3);

for i=1:3
q=4*(i-1)+(1:4);
s.theta(i)=atan2(sin(X(q(1))),cos(X(q(1))));
s.vF(i)=X(q(2));
s.td(i)=X(q(3));
s.tau(i)=X(q(4));
s.tb(i)=s.td(i)+s.tau(i);
s.eF(i,:)=[cos(s.theta(i)),sin(s.theta(i)),0];
s.vFVec(i,:)=s.vF(i)*s.eF(i,:);
s.P0(i,:)=cfg.F0(i,:)+s.vFVec(i,:)*s.td(i);
s.Pb(i,:)=s.P0(i,:)+s.vFVec(i,:)*s.tau(i)+...
[0,0,-0.5*cfg.g*s.tau(i)^2];
s.headingDeg(i)=mod(rad2deg(s.theta(i)),360);
end
end
