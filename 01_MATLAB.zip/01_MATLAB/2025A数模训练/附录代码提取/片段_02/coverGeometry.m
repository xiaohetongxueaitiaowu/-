function[lambda,d2]=coverGeometry(t,M1,C11,T)
% 计算烟幕中心在"M1--真目标"视线上的投影参数lambda和垂直距离平方d2
% 输入：t-时刻，M1-导弹位置函数句柄，C11-烟幕中心函数句柄，T-真目标点坐标
% 输出：lambda-投影参数，d2-垂直距离平方
Mt=M1(t);
Ct=C11(t);

v=T-Mt;                       % M1指向真目标
w=Ct-Mt;                      % M1指向烟幕中心

lambda=dot(w,v)/dot(v,v);
H=Mt+lambda.*v;               % 垂足
delta=Ct-H;
d2=dot(delta,delta);
end
