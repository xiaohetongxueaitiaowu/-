function cfg=problem4_default_config()
% 问题4固定参数及贡献阈值、目标函数权重设置
cfg.O=[0,0,0];
cfg.M10=[20000,0,2000];
cfg.F0=[17800,0,1800;12000,1400,1400;6000,-3000,700];
cfg.vM=300;
cfg.g=9.8;
cfg.vCloud=3;
cfg.smokeR=10;
cfg.cloudLife=20;
cfg.targetCenterXY=[0,200];
cfg.targetR=7;
cfg.targetH=10;
cfg.eM1=(cfg.O-cfg.M10)/norm(cfg.O-cfg.M10);
cfg.vM1=cfg.vM*cfg.eM1;
cfg.tM1Arrive=norm(cfg.O-cfg.M10)/cfg.vM;
cfg.timeChunk=80;

% 三团烟幕贡献约束：避免某架无人机烟幕完全冗余
cfg.minParticipationDuration=0.50; % 至少参与完整遮蔽0.50 s
cfg.minEssentialDuration=0.10;     % 至少有0.10 s为不可替代贡献

% 目标函数权重：总遮蔽时长为主，贡献不足采用分层惩罚
cfg.objectiveWeightTotal=40;
cfg.objectiveWeightParticipationDeficit=600;
cfg.objectiveWeightEssentialDeficit=900;
cfg.objectiveWeightParticipationReward=2;
cfg.objectiveWeightEssentialReward=5;
cfg.objectiveWeightRayShare=0.5;
end
