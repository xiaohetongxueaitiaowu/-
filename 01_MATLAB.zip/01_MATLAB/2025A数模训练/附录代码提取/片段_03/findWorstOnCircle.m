function[max_d2,min_lam,max_lam]=findWorstOnCircle(t,M1,C11,center,r,z,N_seg)
% 在高度z的圆周上分段搜索三个极值：d2最大值、lambda最小值和最大值
% 输入：t, M1, C11, center-圆柱底面圆心, r-半径, z-高度, N_seg-分段数
% 输出：max_d2-最大d2, min_lam-最小lambda, max_lam-最大lambda
max_d2=-inf;
min_lam=inf;
max_lam=-inf;

for i=1:N_seg
a=(i-1)*2*pi/N_seg;
b=i*2*pi/N_seg;

% d2最大值
[~,fval]=fminbnd(@(th)-get_d2_at_theta(th,t,M1,C11,center,r,z),a,b);
d2_local=-fval;
if d2_local>max_d2
max_d2=d2_local;
end

% lambda最小值
[~,lam_min_local]=fminbnd(@(th)get_lambda_at_theta(th,t,M1,C11,center,r,z),a,b);
if lam_min_local<min_lam
min_lam=lam_min_local;
end

% lambda最大值
[~,neg_lam_max]=fminbnd(@(th)-get_lambda_at_theta(th,t,M1,C11,center,r,z),a,b);
lam_max_local=-neg_lam_max;
if lam_max_local>max_lam
max_lam=lam_max_local;
end
end
end
