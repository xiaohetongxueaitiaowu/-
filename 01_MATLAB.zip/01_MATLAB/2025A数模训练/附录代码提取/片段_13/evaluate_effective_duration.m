function [Teff,intervals,diagInfo]=evaluate_effective_duration(X,cfg,Q,dt,boundaryTol)
% 计算一个投放方案的完整圆柱遮蔽时长
s=compute_problem2_strategy(X,cfg);
diagInfo.minWorstDistance=inf;
diagInfo.tAtMinWorstDistance=NaN;
diagInfo.maxClearance=-inf;

% 物理可行性检查
if s.vF1<70 || s.vF1>140 || s.td11<0 || s.tau11<0 || ...
s.tb11>cfg.tM1Arrive || s.Pb11(3)<0
Teff=0;
intervals=zeros(0,2);
return;
end

tBegin=s.tb11;
tEnd=min(s.tb11+cfg.cloudLife,cfg.tM1Arrive);
if tEnd<=tBegin
Teff=0;
intervals=zeros(0,2);
return;
end

tGrid=(tBegin:dt:tEnd).';
if isempty(tGrid) || tGrid(end)<tEnd
tGrid(end+1,1)=tEnd;
end

[covered,worstDistance]=cylinder_covered_at_times(tGrid,X,cfg,Q);
[diagInfo.minWorstDistance,kMin]=min(worstDistance);
diagInfo.tAtMinWorstDistance=tGrid(kMin);
diagInfo.maxClearance=cfg.smokeR-diagInfo.minWorstDistance;

changeIndex=find(covered(1:end-1)~=covered(2:end));
tStart=zeros(0,1);
tFinish=zeros(0,1);

if covered(1)
tStart(end+1,1)=tBegin;
end

for j=1:numel(changeIndex)
k=changeIndex(j);
tB=refine_coverage_boundary(tGrid(k),tGrid(k+1),covered(k),...
X,cfg,Q,boundaryTol);
if ~covered(k) && covered(k+1)
tStart(end+1,1)=tB;
else
tFinish(end+1,1)=tB;
end
end

if covered(end)
tFinish(end+1,1)=tEnd;
end

if numel(tStart)~=numel(tFinish)
Teff=0;
intervals=zeros(0,2);
return;
end

intervals=[tStart,tFinish];
if isempty(intervals)
Teff=0;
else
Teff=sum(intervals(:,2)-intervals(:,1));
end
end
