%% 问题1：FY1投放1枚烟幕弹对M1的有效遮蔽时长
% 方法：三维运动模型+时间粗扫描+二分法精化边界
% 遮蔽口径：真目标轮廓参数，判断视线是否穿过半径10m的烟幕球

clear;clc;close all;

%% --------1.基础参数与初始位置----------
O=[0,0,0];                 % 假目标位置
cyl_params=[7,10,0,200,0]; % 圆柱参数[半径,高度,底面圆心x,y,z]
T_plot=[0,200,5];          % 圆柱几何中心(仅用于画图)
M10=[20000,0,2000];        % M1初始位置
F10=[17800,0,1800];        % FY1初始位置

vM=300;                    % M1速度，m/s
vF1=120;                   % FY1速度，m/s
g=9.8;                     % 重力加速度，m/s^2
gVec=[0,0,-g];             % 重力加速度向量
vCloud=[0,0,-3];           % 烟幕云团下沉速度，m/s
R=10;                      % 烟幕有效球半径，m
cloudLife=20;              % 烟幕有效持续时间，s

td11=1.5;                  % FY1投放时刻，s
tau11=3.6;                 % 引信延迟，s
tb11=td11+tau11;           % 起爆时刻，s

%% --------2.M1运动方程----------
eM1=(O-M10)/norm(O-M10);   % M1飞向假目标的单位方向
vM1=vM*eM1;                % M1速度向量
M1=@(t) M10+vM1.*t;        % M1(t)
tM1Arrive=norm(O-M10)/vM;  % M1到达假目标时刻

%% --------3.FY1运动方程----------
eF1=[-1,0,0];
vF1Vec=vF1*eF1;
F1=@(t) F10+vF1Vec.*t;     % FY1(t)

%% --------4.投放点、烟幕弹运动及起爆点----------
P011=F1(td11);             % 投放点
P11=@(t) P011+vF1Vec.*(t-td11)+0.5.*gVec.*(t-td11).^2; % 平抛运动
Pb11=P11(tb11);            % 起爆点

%% --------5.烟幕云团中心运动----------
C11=@(t) Pb11+vCloud.*(t-tb11); % tb11<=t<=tb11+20

%% --------6.有效判定时间区间----------
tBegin=tb11;
tEnd=min(tb11+cloudLife,tM1Arrive);
if tEnd<=tBegin
error('烟幕有效期与M1来袭过程没有交集。');
end

%% --------7.时间粗扫描----------
dt=0.01;                   % 步长，s
tGrid=tBegin:dt:tEnd;
if tGrid(end)<tEnd
tGrid(end+1)=tEnd;
end

nTime=numel(tGrid);
lambdaGrid=zeros(1,nTime);
d2Grid=zeros(1,nTime);
covered=false(1,nTime);

for k=1:nTime
t=tGrid(k);
[lambdaGrid(k),d2Grid(k)]=coverGeometry(t,M1,C11,T_plot);
covered(k)=isCoveredCylinder(t,M1,C11,R,cyl_params);
end

%% --------8.二分法精化遮蔽边界----------
changeIndex=find(covered(1:end-1)~=covered(2:end));
tol=1e-8;                  % 二分法精度

tStart=[];
tFinish=[];

if covered(1)
tStart(end+1)=tBegin;
end

for j=1:numel(changeIndex)
k=changeIndex(j);
tLeft=tGrid(k);
tRight=tGrid(k+1);
tBoundary=refineBoundary(tLeft,tRight,covered(k),M1,C11,R,cyl_params);
if ~covered(k) && covered(k+1)
tStart(end+1)=tBoundary;
elseif covered(k) && ~covered(k+1)
tFinish(end+1)=tBoundary;
end
end

if covered(end)
tFinish(end+1)=tEnd;
end

if numel(tStart)~=numel(tFinish)
error('遮蔽区间起止点数量不一致，请减小dt后重试。');
end

intervals=[tStart(:),tFinish(:)];
if isempty(intervals)
Teff=0;
else
Teff=sum(intervals(:,2)-intervals(:,1));
end

%% --------9.输出结果----------
fprintf('\n========== 问题1计算结果 ==========\n');
fprintf('FY1投放时刻 td11      = %.6f s\n',td11);
fprintf('投放点 P011           = (%.3f,%.3f,%.3f) m\n',P011);
fprintf('引信延迟 tau11        = %.6f s\n',tau11);
fprintf('起爆时刻 tb11         = %.6f s\n',tb11);
fprintf('起爆点 Pb11           = (%.3f,%.3f,%.3f) m\n',Pb11);
fprintf('烟幕有效判定区间      = [%.6f,%.6f] s\n',tBegin,tEnd);

if isempty(intervals)
fprintf('未形成有效遮蔽。\n');
else
for k=1:size(intervals,1)
fprintf('有效区间 %d            = [%.9f,%.9f] s，时长 %.9f s\n',...
k,intervals(k,1),intervals(k,2),...
intervals(k,2)-intervals(k,1));
end
end
fprintf('总有效遮蔽时长 Teff   = %.9f s\n',Teff);
fprintf('======================================\n\n');

%% --------10. 计算距离用于绘图 ----------
distanceGrid=sqrt(max(d2Grid,0));

%% --------11. 绘图（四个独立图）----------

% ---- 图1：烟幕弹运动轨迹（x-z侧视图，仅显示烟幕弹相关） ----
figure('Color','w','Name','烟幕弹运动轨迹（侧视）','Position',[100,100,800,600]);
hold on; grid on; box on;

tUAV=linspace(0,td11,50);
tShell=linspace(td11,tb11,100);
tCloud=linspace(tb11,tEnd,100);

uavPos=sampleTrajectory(F1,tUAV);
shellPos=sampleTrajectory(P11,tShell);
cloudPos=sampleTrajectory(C11,tCloud);

plot3(uavPos(:,1),uavPos(:,2),uavPos(:,3),'b-','LineWidth',2,'DisplayName','无人机飞行轨迹');
plot3(shellPos(:,1),shellPos(:,2),shellPos(:,3),'Color',[0.85,0.45,0.10],'LineWidth',2.5,'DisplayName','烟幕弹平抛轨迹');
plot3(cloudPos(:,1),cloudPos(:,2),cloudPos(:,3),'Color',[0.10,0.60,0.35],'LineWidth',2.5,'DisplayName','烟幕云团下沉轨迹');

scatter3(F10(1),F10(2),F10(3),80,'b','filled','DisplayName','无人机初始位置');
scatter3(P011(1),P011(2),P011(3),80,[0.10,0.40,0.90],'filled','DisplayName','投放点');
scatter3(Pb11(1),Pb11(2),Pb11(3),100,[0.85,0.30,0.10],'filled','DisplayName','起爆点');

view(0,0);
xlabel('x / m'); ylabel('y / m'); zlabel('z / m');
title('烟幕弹投放→爆炸→云团下沉轨迹（侧视图）','FontSize',15);
legend('Location','best','FontSize',10);
axis equal;
xlim([min([F10(1),P011(1),Pb11(1),cloudPos(:,1)'])-200,...
max([F10(1),P011(1),Pb11(1),cloudPos(:,1)'])+200]);
zlim([min([F10(3),P011(3),Pb11(3),cloudPos(:,3)'])-200,...
max([F10(3),P011(3),Pb11(3),cloudPos(:,3)'])+200]);
ylim([-10,10]);

% ---- 图2：距离 d(t) 随时间变化（含有效区间图例） ----
figure('Color','w','Name','烟幕中心到视线的距离','Position',[200,200,800,500]);
hold on; grid on; box on;

plot(tGrid,distanceGrid,'b-','LineWidth',2,'DisplayName','d_{11}(t)');
yline(10,'--','Color',[0.5 0.5 0.5],'LineWidth',1.2,'DisplayName','R=10 m');

if ~isempty(intervals)
yLim=ylim;
for i=1:size(intervals,1)
if i==1
patch([intervals(i,1),intervals(i,2),intervals(i,2),intervals(i,1)],...
[yLim(1),yLim(1),yLim(2),yLim(2)],...
[0.70,0.92,0.76],'FaceAlpha',0.25,'EdgeColor','none',...
'HandleVisibility','on','DisplayName','有效遮蔽区间');
else
patch([intervals(i,1),intervals(i,2),intervals(i,2),intervals(i,1)],...
[yLim(1),yLim(1),yLim(2),yLim(2)],...
[0.70,0.92,0.76],'FaceAlpha',0.25,'EdgeColor','none',...
'HandleVisibility','off');
end
end
end

xlabel('时间 t / s');
ylabel('距离 d_{11}(t) / m');
title('烟幕中心到导弹-真目标视线的距离');
legend('Location','best');
ylim([0,max(distanceGrid)*1.1]);

% ---- 图3：三维全景（斜视角） ----
figure('Color','w','Name','第一问全景三维（斜视）','Position',[300,100,900,700]);
hold on; grid on; box on;

tMplot=linspace(0,tM1Arrive,200);
Mplot=sampleTrajectory(M1,tMplot);
plot3(Mplot(:,1),Mplot(:,2),Mplot(:,3),'r-','LineWidth',1.8,'DisplayName','M1轨迹');

uavPosAll=sampleTrajectory(F1,linspace(0,td11,50));
plot3(uavPosAll(:,1),uavPosAll(:,2),uavPosAll(:,3),'b-','LineWidth',1.8,'DisplayName','FY1轨迹');

shellPosAll=sampleTrajectory(P11,linspace(td11,tb11,100));
plot3(shellPosAll(:,1),shellPosAll(:,2),shellPosAll(:,3),'Color',[0.85,0.45,0.10],'LineWidth',2.2,'DisplayName','烟幕弹轨迹');

cloudPosAll=sampleTrajectory(C11,linspace(tb11,tEnd,100));
plot3(cloudPosAll(:,1),cloudPosAll(:,2),cloudPosAll(:,3),'Color',[0.10,0.60,0.35],'LineWidth',2.2,'DisplayName','云团中心轨迹');

scatter3(O(1),O(2),O(3),80,[0.95,0.60,0.05],'filled','DisplayName','假目标');
scatter3(T_plot(1),T_plot(2),T_plot(3),80,[0.10,0.65,0.40],'filled','DisplayName','真目标代表点');
scatter3(F10(1),F10(2),F10(3),60,'b','filled','DisplayName','FY1初始位置');
scatter3(P011(1),P011(2),P011(3),60,[0.10,0.40,0.90],'filled','DisplayName','投放点');
scatter3(Pb11(1),Pb11(2),Pb11(3),80,[0.85,0.30,0.10],'filled','DisplayName','起爆点');

if ~isempty(intervals)
tShow=mean(intervals(1,:));
else
[~,idx]=min(distanceGrid);
tShow=tGrid(idx);
end
MtShow=M1(tShow);
CtShow=C11(tShow);
plot3([MtShow(1),T_plot(1)],[MtShow(2),T_plot(2)],[MtShow(3),T_plot(3)],...
'k--','LineWidth',1.2,'DisplayName','视线（某时刻）');
[xs,ys,zs]=sphere(30);
surf(R*xs+CtShow(1),R*ys+CtShow(2),R*zs+CtShow(3),...
'FaceColor',[0.55,0.58,0.60],'FaceAlpha',0.30,'EdgeColor','none',...
'DisplayName','烟幕球（示意）');

view(45,20);
xlabel('x / m'); ylabel('y / m'); zlabel('z / m');
title(sprintf('第一问全景（烟幕球时刻 t=%.2f s）',tShow));
legend('Location','bestoutside');
axis equal;
ylim([-1000,1000]);

% ---- 图4：三维全景的侧视图（view(0,0)） ----
figure('Color','w','Name','第一问全景侧视图','Position',[400,150,900,700]);
hold on; grid on; box on;

plot3(Mplot(:,1),Mplot(:,2),Mplot(:,3),'r-','LineWidth',1.8,'DisplayName','M1轨迹');
plot3(uavPosAll(:,1),uavPosAll(:,2),uavPosAll(:,3),'b-','LineWidth',1.8,'DisplayName','FY1轨迹');

scatter3(T_plot(1),T_plot(2),T_plot(3),80,[0.10,0.65,0.40],'filled','DisplayName','真目标代表点');
scatter3(F10(1),F10(2),F10(3),60,'b','filled','DisplayName','FY1初始位置');
scatter3(P011(1),P011(2),P011(3),60,[0.10,0.40,0.90],'filled','DisplayName','投放点');
scatter3(Pb11(1),Pb11(2),Pb11(3),80,[0.85,0.30,0.10],'filled','DisplayName','起爆点');

view(0,0);
xlabel('x / m'); ylabel('y / m'); zlabel('z / m');
title(sprintf('第一问全景侧视图（烟幕球时刻 t=%.2f s）',tShow));
legend('Location','bestoutside');
axis equal;
xlim([min(Mplot(:,1))-500,max(Mplot(:,1))+500]);
zlim([min([Mplot(:,3);cloudPosAll(:,3);0])-100,max([Mplot(:,3);cloudPosAll(:,3);T_plot(3)])+100]);
ylim([-500,500]);
