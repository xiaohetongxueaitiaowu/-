function [covered,worstDistance]=cylinder_covered_at_times(tVec,X,cfg,Q)
% 判断各时刻整个圆柱目标是否完全被遮蔽
tVec=tVec(:);
nT=numel(tVec);
covered=false(nT,1);
worstDistance=inf(nT,1);

s=compute_problem2_strategy(X,cfg);

M=cfg.M10+tVec.*cfg.vM1;
C=repmat(s.Pb11,nT,1);
C(:,3)=C(:,3)-cfg.vCloud*(tVec-s.tb11);

active=tVec>=s.tb11 & ...
tVec<=s.tb11+cfg.cloudLife & ...
tVec<=cfg.tM1Arrive;

Qx=Q(:,1).';
Qy=Q(:,2).';
Qz=Q(:,3).';
activeIndex=find(active);

for first=1:cfg.timeChunk:numel(activeIndex)
last=min(first+cfg.timeChunk-1,numel(activeIndex));
idx=activeIndex(first:last);

Mx=M(idx,1); My=M(idx,2); Mz=M(idx,3);
Cx=C(idx,1); Cy=C(idx,2); Cz=C(idx,3);

vx=Qx-Mx; vy=Qy-My; vz=Qz-Mz;
wx=Cx-Mx; wy=Cy-My; wz=Cz-Mz;

denominator=vx.^2+vy.^2+vz.^2;
lambda=(wx.*vx+wy.*vy+wz.*vz)./denominator;

lambdaHat=min(1,max(0,lambda));
Hx=Mx+lambdaHat.*vx;
Hy=My+lambdaHat.*vy;
Hz=Mz+lambdaHat.*vz;

d2=(Cx-Hx).^2+(Cy-Hy).^2+(Cz-Hz).^2;
maxD2=max(d2,[],2);

worstDistance(idx)=sqrt(max(maxD2,0));
covered(idx)=maxD2<=cfg.smokeR^2;
end
end
