function pts=sample_pts(fun,t)
% 对只接受标量时间的三维位置函数进行采样
pts=zeros(numel(t),3);
for i=1:numel(t)
pts(i,:)=fun(t(i));
end
end
