function X=repair_decision3(X,lb,ub,cfg)
% 将8维候选解投影到物理可行域
X=reshape(X,1,[]);
X(1)=atan2(sin(X(1)),cos(X(1)));
X(2)=min(ub(2),max(lb(2),X(2)));

td=min(cfg.tM1Arrive,max(0,X(3:5)));
tau=max(0,X(6:8));
[td,order]=sort(td);
tau=tau(order);

u=td-[0,1,2];
u=min(cfg.tM1Arrive-2,max(0,u));
u=sort(u);
td=u+[0,1,2];

tauHeightMax=sqrt(2*cfg.F10(3)/cfg.g);
for m=1:3
tau(m)=min(tauHeightMax,tau(m));
tau(m)=min(tau(m),max(0,cfg.tM1Arrive-td(m)));
end

X=[X(1),X(2),td,tau];
X=min(ub,max(lb,X));
end
