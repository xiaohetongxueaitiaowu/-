%% 问题2：模拟退火优化FY1单枚烟幕弹投放策略
% 将本文件与其余函数文件放在同一个MATLAB文件夹中，直接运行本文件。
% 决策变量：X = [theta1, vF1, td11, tau11]
% 遮蔽判据：整个圆柱真目标的采样视线均与半径10 m烟幕球相交。

clear;clc;close all;
rng(20250813,'twister');

%% --------1.参数与决策变量边界----------
cfg=problem2_default_config();
% X = [航向角(rad), 速度(m/s), 投放时刻(s), 引信延迟(s)]
tauMax=sqrt(2*cfg.F10(3)/cfg.g);
lb=[-pi,70,0,0];
ub=[pi,140,cfg.tM1Arrive,tauMax];

fprintf('\n问题2模拟退火开始。M1到达假目标时刻：%.6f s\n',cfg.tM1Arrive);

%% --------2.第一阶段：粗网格、多起点全局搜索----------
Q1=make_cylinder_target_points(cfg,36,5,3);
dt1=0.05;
obj1=@(X) problem2_objective(X,cfg,Q1,dt1,1.0e-5);

sa1.MaxIterations=1000;
sa1.InitialTemperature=8.0;
sa1.FinalTemperature=0.02;
sa1.InitialStep=[deg2rad(20),15,5.0,3.0];
sa1.FinalStep=[deg2rad(0.08),0.08,0.015,0.015];
sa1.GlobalJumpProbability=0.025;
sa1.ReheatAfter=180;
sa1.ReheatLength=50;
sa1.DisplayEvery=100;

nRuns1=3;
start1=zeros(nRuns1,4);
start1(1,:)=[pi,120,1.5,3.6];
for r=2:nRuns1
start1(r,:)=random_feasible_decision(lb,ub,cfg);
end

stage1=repmat(struct('X',[],'cost',[],'history',[]),nRuns1,1);
for r=1:nRuns1
fprintf('\n========== 第一阶段，第%d/%d次退火 ==========\n',r,nRuns1);
[stage1(r).X,stage1(r).cost,stage1(r).history]=...
simulated_annealing_search(obj1,start1(r,:),lb,ub,cfg,sa1);
end

[~,order1]=sort([stage1.cost]);
stage1=stage1(order1);

%% --------3.第二阶段：更密圆柱网格和更小时间步长的精细退火----------
Q2=make_cylinder_target_points(cfg,72,9,4);
dt2=0.02;
obj2=@(X) problem2_objective(X,cfg,Q2,dt2,3.0e-6);

sa2.MaxIterations=650;
sa2.InitialTemperature=2.0;
sa2.FinalTemperature=0.002;
sa2.InitialStep=[deg2rad(5),5.0,1.2,0.8];
sa2.FinalStep=[deg2rad(0.01),0.015,0.003,0.003];
sa2.GlobalJumpProbability=0.005;
sa2.ReheatAfter=130;
sa2.ReheatLength=35;
sa2.DisplayEvery=65;

nRuns2=min(2,nRuns1);
stage2=repmat(struct('X',[],'cost',[],'history',[]),nRuns2,1);
for r=1:nRuns2
fprintf('\n========== 第二阶段，第%d/%d次精细退火 ==========\n',r,nRuns2);
x0=stage1(r).X;
[stage2(r).X,stage2(r).cost,stage2(r).history]=...
simulated_annealing_search(obj2,x0,lb,ub,cfg,sa2);
end

[~,order2]=sort([stage2.cost]);
stage2=stage2(order2);

%% --------4.高密度圆柱网格最终复核----------
Qfinal=make_cylinder_target_points(cfg,360,17,8);
dtFinal=0.002;
boundaryTolFinal=1.0e-8;

candidateX=vertcat(stage2.X,stage1(1).X);
candidateX=unique(round(candidateX,10),'rows','stable');
nCandidate=size(candidateX,1);

candidateDuration=zeros(nCandidate,1);
candidateIntervals=cell(nCandidate,1);
candidateDiag=cell(nCandidate,1);

fprintf('\n========== 高密度圆柱模型最终复核 ==========\n');
for k=1:nCandidate
[candidateDuration(k),candidateIntervals{k},candidateDiag{k}]=...
evaluate_effective_duration(candidateX(k,:),cfg,Qfinal,...
dtFinal,boundaryTolFinal);
fprintf('候选解%d：有效遮蔽时长 %.9f s\n',k,candidateDuration(k));
end

[Teff,bestIndex]=max(candidateDuration);
Xbest=candidateX(bestIndex,:);
intervals=candidateIntervals{bestIndex};
finalDiag=candidateDiag{bestIndex};
strategy=compute_problem2_strategy(Xbest,cfg);

%% --------5.输出最优方案----------
fprintf('\n================= 问题2模拟退火结果 =================\n');
fprintf('航向角（从+x轴逆时针）  = %.9f rad = %.6f deg\n',...
strategy.theta1,strategy.headingDeg);
fprintf('相对朝向假目标的-x方向偏角 = %.6f deg\n',...
strategy.relativeToNegativeXDeg);
fprintf('航向单位向量 eF1         = (%.9f, %.9f, %.9f)\n',strategy.eF1);
fprintf('FY1飞行速度 vF1          = %.9f m/s\n',strategy.vF1);
fprintf('投放时刻 td11            = %.9f s\n',strategy.td11);
fprintf('引信延迟 tau11           = %.9f s\n',strategy.tau11);
fprintf('起爆时刻 tb11            = %.9f s\n',strategy.tb11);
fprintf('投放点 P011              = (%.6f, %.6f, %.6f) m\n',strategy.P011);
fprintf('起爆点 Pb11              = (%.6f, %.6f, %.6f) m\n',strategy.Pb11);

if isempty(intervals)
fprintf('最终高密度圆柱模型下未形成完整遮蔽。\n');
else
for k=1:size(intervals,1)
fprintf('有效遮蔽区间%d             = [%.9f, %.9f] s，时长 %.9f s\n',...
k,intervals(k,1),intervals(k,2),...
intervals(k,2)-intervals(k,1));
end
end

fprintf('最大有效遮蔽时长 Teff    = %.9f s\n',Teff);
fprintf('最终圆柱表面采样点数      = %d\n',size(Qfinal,1));
fprintf('最终时间扫描步长          = %.6f s\n',dtFinal);
fprintf('=======================================================\n\n');

%% --------6.保存结果----------
result=struct();
result.Xbest=Xbest;
result.strategy=strategy;
result.Teff=Teff;
result.intervals=intervals;
result.finalDiagnostics=finalDiag;
result.finalTargetPointCount=size(Qfinal,1);
result.finalTimeStep=dtFinal;
result.stage1=stage1;
result.stage2=stage2;

save('problem2_sa_result.mat','result');

resultTable=table(...
strategy.theta1,strategy.headingDeg,...
strategy.relativeToNegativeXDeg,strategy.vF1,...
strategy.td11,strategy.tau11,strategy.tb11,...
strategy.P011(1),strategy.P011(2),strategy.P011(3),...
strategy.Pb11(1),strategy.Pb11(2),strategy.Pb11(3),Teff,...
'VariableNames',{...
	'theta_rad','theta_deg','relative_to_negative_x_deg','speed_mps',...
	'drop_time_s','fuse_delay_s','burst_time_s',...
	'drop_x_m','drop_y_m','drop_z_m',...
	'burst_x_m','burst_y_m','burst_z_m','effective_time_s'});
writetable(resultTable,'problem2_sa_result.csv');

%% --------7.绘图----------
plot_problem2_sa_result(Xbest,cfg,Qfinal,dtFinal,intervals,...
stage1,stage2);

fprintf('结果已保存为 problem2_sa_result.mat 和 problem2_sa_result.csv。\n');
