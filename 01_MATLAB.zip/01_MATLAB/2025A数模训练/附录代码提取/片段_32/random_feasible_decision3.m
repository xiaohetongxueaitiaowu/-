function X=random_feasible_decision3(lb,ub,cfg)
% 随机生成物理可行的8维决策变量
X=lb+(ub-lb).*rand(1,8);
X=repair_decision3(X,lb,ub,cfg);
end
