function pts = sample_pts(fun, t)
pts = zeros(numel(t),3);
for i = 1:numel(t)
pts(i,:) = fun(t(i));
end
