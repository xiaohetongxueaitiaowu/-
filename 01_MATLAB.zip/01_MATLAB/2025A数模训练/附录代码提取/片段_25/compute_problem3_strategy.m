function s=compute_problem3_strategy(X,cfg)
% 由决策变量计算三枚弹的投放点、起爆点和时刻
s.theta1=atan2(sin(X(1)),cos(X(1)));
s.vF1=X(2);
s.td=X(3:5);
s.tau=X(6:8);
s.tb=s.td+s.tau;
s.eF1=[cos(s.theta1),sin(s.theta1),0];
s.vF1Vec=s.vF1*s.eF1;
s.headingDeg=mod(rad2deg(s.theta1),360);
s.relativeToNegativeXDeg=rad2deg(atan2(sin(s.theta1-pi),...
cos(s.theta1-pi)));
s.P0=zeros(3,3);
s.Pb=zeros(3,3);
for m=1:3
s.P0(m,:)=cfg.F10+s.vF1Vec*s.td(m);
s.Pb(m,:)=s.P0(m,:)+s.vF1Vec*s.tau(m)+...
[0,0,-0.5*cfg.g*s.tau(m)^2];
end
end
