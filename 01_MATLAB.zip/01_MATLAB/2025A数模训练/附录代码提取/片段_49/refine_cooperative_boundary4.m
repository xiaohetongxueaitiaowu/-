function tBoundary=refine_cooperative_boundary4(tLeft,tRight,leftFlag,...
X,cfg,Q,tol)
% 二分法精化协同遮蔽状态边界（用于最终高精度区间定位）
while tRight-tLeft>tol
tMid=0.5*(tLeft+tRight);
midFlag=cooperative_covered_at_times4(tMid,X,cfg,Q);
if midFlag==leftFlag
tLeft=tMid;
else
tRight=tMid;
end
end
tBoundary=0.5*(tLeft+tRight);
end
