function flag=isCoveredCylinder(t,M1,C11,R,cyl_params)
% 判断烟幕球是否完全遮蔽圆柱目标，cyl_params=[半径,高度,底面圆心x,y,z]
r=cyl_params(1);
h=cyl_params(2);
center=cyl_params(3:5);   % [0,200,0]

Ct=C11(t);
if Ct(3)<0                % 烟幕中心低于地面直接无效
flag=false;
return;
end

% 快速检查：几何中心未被遮蔽则直接false
T_center=center+[0,0,h/2];
[lam_c,d2_c]=coverGeometry(t,M1,C11,T_center);
if ~(lam_c>0 && lam_c<1 && d2_c<=R^2)
flag=false;
return;
end

% 搜索上下两个圆周
z_levels=[0,h];
N_seg=36;          % 将0~2pi分成36段

for z=z_levels
[max_d2,min_lam,max_lam]=findWorstOnCircle(t,M1,C11,center,r,z,N_seg);
if max_d2>R^2 || min_lam<=0 || max_lam>=1
flag=false;
return;
end
end

flag=true;
end
