function [Teff,intervals,diagInfo]=evaluate_cooperative_duration(X,cfg,Q,dt,boundaryTol)
% 计算三云团协同遮蔽的时间并集长度
s=compute_problem3_strategy(X,cfg);
diagInfo.minWorstCoopDistance=inf;
diagInfo.tAtMinimum=NaN;
diagInfo.maxClearance=-inf;

% 物理可行性检查
if s.vF1<70 || s.vF1>140 || any(s.td<0) || any(diff(s.td)<1-1e-10) ||...
any(s.tau<0) || any(s.tb>cfg.tM1Arrive) || any(s.Pb(:,3)<0)
Teff=0; intervals=zeros(0,2); return;
end

tBegin=min(s.tb);
tEnd=min(max(s.tb+cfg.cloudLife),cfg.tM1Arrive);
if tEnd<=tBegin
Teff=0; intervals=zeros(0,2); return;
end

tGrid=(tBegin:dt:tEnd).';
if isempty(tGrid) || tGrid(end)<tEnd
tGrid(end+1,1)=tEnd;
end
[covered,D]=cooperative_covered_at_times(tGrid,X,cfg,Q);
[diagInfo.minWorstCoopDistance,kMin]=min(D);
diagInfo.tAtMinimum=tGrid(kMin);
diagInfo.maxClearance=cfg.smokeR-diagInfo.minWorstCoopDistance;

% 退火阶段 boundaryTol=0 只用离散时间并集
if boundaryTol<=0
Teff=sum(covered)*dt;
Teff=min(Teff,tEnd-tBegin);
intervals=logical_intervals_from_grid(tGrid,covered);
return;
end

% 最终复核阶段用二分法精化边界
changeIndex=find(covered(1:end-1)~=covered(2:end));
tStart=zeros(0,1); tFinish=zeros(0,1);
if covered(1), tStart(end+1,1)=tBegin; end
for j=1:numel(changeIndex)
k=changeIndex(j);
tB=refine_cooperative_boundary(tGrid(k),tGrid(k+1),covered(k),...
X,cfg,Q,boundaryTol);
if ~covered(k) && covered(k+1)
tStart(end+1,1)=tB;
else
tFinish(end+1,1)=tB;
end
end
if covered(end), tFinish(end+1,1)=tEnd; end
if numel(tStart)~=numel(tFinish)
Teff=0; intervals=zeros(0,2); return;
end
intervals=[tStart,tFinish];
if isempty(intervals), Teff=0;
else, Teff=sum(intervals(:,2)-intervals(:,1)); end
end

function intervals=logical_intervals_from_grid(t,flag)
% 仅退火阶段用，粗略区间输出
starts=flag & [true;~flag(1:end-1)];
ends=flag & [~flag(2:end);true];
intervals=[t(starts),t(ends)];
end
