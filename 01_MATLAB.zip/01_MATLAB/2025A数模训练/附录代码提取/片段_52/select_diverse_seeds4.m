function [selectedX,selectedCost]=select_diverse_seeds4(poolX,poolCost,nSelect,cfg)
% 从种子池中选择兼顾质量与多样性的起点（精英+最远点采样）
[poolCost,order]=sort(poolCost(:),'ascend');
poolX=poolX(order,:);
nPool=size(poolX,1);
nSelect=min(nSelect,nPool);
if nSelect==0
selectedX=zeros(0,size(poolX,2));
selectedCost=zeros(0,1);
return;
end

nElite=min(ceil(nSelect/2),nPool);
chosen=1:nElite;  % 先取最优的一半
candidate=(nElite+1):min(nPool,max(4*nSelect,nElite));

% 从剩余候选中不断选择与已选集合距离最远的点
while numel(chosen)<nSelect && ~isempty(candidate)
minDistance=inf(numel(candidate),1);
for a=1:numel(candidate)
for b=1:numel(chosen)
minDistance(a)=min(minDistance(a),decision_distance4(...
poolX(candidate(a),:),poolX(chosen(b),:),cfg));
end
end
[~,take]=max(minDistance);
chosen(end+1)=candidate(take); %#ok<AGROW>
candidate(take)=[];
end

if numel(chosen)<nSelect
remaining=setdiff(1:nPool,chosen,'stable');
chosen=[chosen,remaining(1:nSelect-numel(chosen))];
end
selectedX=poolX(chosen,:);
selectedCost=poolCost(chosen);
end

function d=decision_distance4(x,y,cfg)
% 计算两个决策变量在归一化后的欧氏距离，用于多样性度量
z=zeros(1,12);
for i=1:3
q=4*(i-1)+(1:4);
z(q(1))=atan2(sin(x(q(1))-y(q(1))),cos(x(q(1))-y(q(1))))/pi;
z(q(2))=(x(q(2))-y(q(2)))/70;
z(q(3))=(x(q(3))-y(q(3)))/cfg.tM1Arrive;
tauScale=sqrt(2*cfg.F0(i,3)/cfg.g);
z(q(4))=(x(q(4))-y(q(4)))/max(tauScale,eps);
end
d=norm(z);
end
