function strategy=compute_problem2_strategy(X,cfg)
% 由决策变量计算投放点与起爆点
theta1=atan2(sin(X(1)),cos(X(1)));
vF1=X(2);
td11=X(3);
tau11=X(4);
tb11=td11+tau11;

eF1=[cos(theta1),sin(theta1),0];
vF1Vec=vF1*eF1;
P011=cfg.F10+vF1Vec*td11;
Pb11=P011+vF1Vec*tau11+[0,0,-0.5*cfg.g*tau11^2];

strategy.theta1=theta1;
strategy.headingDeg=mod(rad2deg(theta1),360);
strategy.relativeToNegativeXDeg=...
rad2deg(atan2(sin(theta1-pi),cos(theta1-pi)));
strategy.eF1=eF1;
strategy.vF1=vF1;
strategy.vF1Vec=vF1Vec;
strategy.td11=td11;
strategy.tau11=tau11;
strategy.tb11=tb11;
strategy.P011=P011;
strategy.Pb11=Pb11;
end
