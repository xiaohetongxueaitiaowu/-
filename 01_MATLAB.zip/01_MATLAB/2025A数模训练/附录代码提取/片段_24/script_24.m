%% 问题3：模拟退火优化FY1投放3枚烟幕弹的协同遮蔽策略
% 决策变量：
% X3=[theta1,vF1,td11,td12,td13,tau11,tau12,tau13]
% 协同遮蔽判据：D3(t)=max_j min_{m属于A(t)} d_1mj(t)<=10。

clear;clc;close all;
rng(20250813,'twister');

%% --------1.固定参数与变量边界----------
cfg=problem3_default_config();
tauMax=sqrt(2*cfg.F10(3)/cfg.g);
% X3=[theta,v,td1,td2,td3,tau1,tau2,tau3]
lb=[-pi,70,0,1,2,0,0,0];
ub=[pi,140,cfg.tM1Arrive-2,cfg.tM1Arrive-1,cfg.tM1Arrive,...
tauMax,tauMax,tauMax];

fprintf('\n问题3模拟退火开始。M1到达假目标时刻：%.6f s\n',cfg.tM1Arrive);

%% --------2.第一阶段：多起点粗搜索----------
Q1=make_cylinder_target_points3(cfg,24,4,3);
dt1=0.10;
obj1=@(X) problem3_objective(X,cfg,Q1,dt1);

sa1.MaxIterations=900;
sa1.InitialTemperature=10.0;
sa1.FinalTemperature=0.03;
sa1.InitialStep=[deg2rad(22),16,5,5,5,3,3,3];
sa1.FinalStep=[deg2rad(0.10),0.10,0.025,0.025,0.025,0.025,0.025,0.025];
sa1.GlobalJumpProbability=0.035;
sa1.ReheatAfter=170;
sa1.ReheatLength=55;
sa1.DisplayEvery=100;

nRuns1=4;
start1=zeros(nRuns1,8);
start1(1,:)=[pi,120,1.5,4.5,7.5,3.6,4.5,5.4];
for r=2:nRuns1
start1(r,:)=random_feasible_decision3(lb,ub,cfg);
end

stage1=repmat(struct('X',[],'cost',[],'history',[]),nRuns1,1);
for r=1:nRuns1
fprintf('\n========== 第一阶段，第%d/%d次退火 ==========\n',r,nRuns1);
[stage1(r).X,stage1(r).cost,stage1(r).history]=...
simulated_annealing_search3(obj1,start1(r,:),lb,ub,cfg,sa1);
end
[~,idx1]=sort([stage1.cost]);
stage1=stage1(idx1);

%% --------3.第二阶段：精细搜索----------
nRuns2=2;
knownBestX=[3.133292676,137.890922149,0.063033070,3.469750075,...
10.179821234,3.687209999,5.135813342,8.340389201];
startList=cell(1,nRuns2);
for r=1:nRuns2-1
startList{r}=stage1(r).X;
end
startList{nRuns2}=knownBestX;

Q2=make_cylinder_target_points3(cfg,48,7,4);
dt2=0.035;
obj2=@(X) problem3_objective(X,cfg,Q2,dt2);

sa2.MaxIterations=1200;
sa2.InitialTemperature=2.5;
sa2.FinalTemperature=0.0005;
sa2.InitialStep=[deg2rad(4),3,0.8,0.8,0.8,0.5,0.5,0.5];
sa2.FinalStep=[deg2rad(0.005),0.005,0.002,0.002,0.002,0.002,0.002,0.002];
sa2.GlobalJumpProbability=0.006;
sa2.ReheatAfter=140;
sa2.ReheatLength=40;
sa2.DisplayEvery=120;

stage2=repmat(struct('X',[],'cost',[],'history',[]),nRuns2,1);
for r=1:nRuns2
fprintf('\n========== 第二阶段，第%d/%d次精细退火 ==========\n',r,nRuns2);
[stage2(r).X,stage2(r).cost,stage2(r).history]=...
simulated_annealing_search3(obj2,startList{r},lb,ub,cfg,sa2);
end
[~,idx2]=sort([stage2.cost]);
stage2=stage2(idx2);

%% --------4.高密度圆柱模型最终复核----------
Qfinal=make_cylinder_target_points3(cfg,360,17,8);
dtFinal=0.002;
boundaryTolFinal=1.0e-8;

candidateX=vertcat(stage2.X,stage1(1).X);
candidateX=unique(round(candidateX,10),'rows','stable');
nCandidate=size(candidateX,1);
candidateDuration=zeros(nCandidate,1);
candidateIntervals=cell(nCandidate,1);
candidateDiag=cell(nCandidate,1);

fprintf('\n========== 高密度圆柱协同遮蔽模型最终复核 ==========\n');
for k=1:nCandidate
[candidateDuration(k),candidateIntervals{k},candidateDiag{k}]=...
evaluate_cooperative_duration(candidateX(k,:),cfg,Qfinal,...
dtFinal,boundaryTolFinal);
fprintf('候选解%d：有效遮蔽时长 %.9f s\n',k,candidateDuration(k));
end

[Teff,bestIndex]=max(candidateDuration);
Xbest=candidateX(bestIndex,:);
intervals=candidateIntervals{bestIndex};
finalDiag=candidateDiag{bestIndex};
strategy=compute_problem3_strategy(Xbest,cfg);

%% --------5.输出最优投放策略----------
fprintf('\n================= 问题3模拟退火结果 =================\n');
fprintf('航向角（从+x轴逆时针） = %.9f rad = %.6f deg\n',...
strategy.theta1,strategy.headingDeg);
fprintf('相对-x方向偏角          = %.6f deg\n',...
strategy.relativeToNegativeXDeg);
fprintf('航向单位向量 eF1        = (%.9f, %.9f, %.9f)\n',strategy.eF1);
fprintf('FY1飞行速度 vF1         = %.9f m/s\n',strategy.vF1);

for m=1:3
fprintf('\n第%d枚烟幕弹：\n',m);
fprintf('  投放时刻 td1%d         = %.9f s\n',m,strategy.td(m));
fprintf('  投放点 P01%d           = (%.6f, %.6f, %.6f) m\n',...
m,strategy.P0(m,:));
fprintf('  引信延迟 tau1%d        = %.9f s\n',m,strategy.tau(m));
fprintf('  起爆时刻 tb1%d         = %.9f s\n',m,strategy.tb(m));
fprintf('  起爆点 Pb1%d           = (%.6f, %.6f, %.6f) m\n',...
m,strategy.Pb(m,:));
end

if isempty(intervals)
fprintf('\n最终高密度模型下未形成完整协同遮蔽。\n');
else
fprintf('\n');
for k=1:size(intervals,1)
fprintf('协同遮蔽区间%d = [%.9f, %.9f] s，时长 %.9f s\n',...
k,intervals(k,1),intervals(k,2),...
intervals(k,2)-intervals(k,1));
end
end
fprintf('总有效遮蔽时长 Teff     = %.9f s\n',Teff);
fprintf('最终圆柱采样点数         = %d\n',size(Qfinal,1));
fprintf('最终时间步长             = %.6f s\n',dtFinal);
fprintf('=======================================================\n\n');

%% --------6.保存MAT和CSV结果----------
result.Xbest=Xbest;
result.strategy=strategy;
result.Teff=Teff;
result.intervals=intervals;
result.finalDiagnostics=finalDiag;
result.finalTargetPointCount=size(Qfinal,1);
result.finalTimeStep=dtFinal;
result.stage1=stage1;
result.stage2=stage2;
save('problem3_sa_result.mat','result');

Smoke=(1:3).';
DropTime=strategy.td(:);
DropX=strategy.P0(:,1); DropY=strategy.P0(:,2); DropZ=strategy.P0(:,3);
FuseDelay=strategy.tau(:);
BurstTime=strategy.tb(:);
BurstX=strategy.Pb(:,1); BurstY=strategy.Pb(:,2); BurstZ=strategy.Pb(:,3);
strategyTable=table(Smoke,DropTime,DropX,DropY,DropZ,FuseDelay,...
BurstTime,BurstX,BurstY,BurstZ);
writetable(strategyTable,'problem3_sa_strategy.csv');

summaryTable=table(strategy.theta1,strategy.headingDeg,...
strategy.relativeToNegativeXDeg,strategy.vF1,Teff,...
'VariableNames',{'theta_rad','theta_deg',...
	'relative_to_negative_x_deg','speed_mps','effective_time_s'});
writetable(summaryTable,'problem3_sa_summary.csv');

%% --------7.绘图----------
plot_problem3_sa_result(Xbest,cfg,Qfinal,dtFinal,intervals,stage1,stage2);
fprintf('结果已保存为MAT和CSV文件。\n');
