function J=problem2_objective(X,cfg,Q,dt,boundaryTol)
% 模拟退火最小化的目标函数
[Teff,~,diagInfo]=evaluate_effective_duration(X,cfg,Q,dt,boundaryTol);

if Teff>0
J=-Teff;
elseif isfinite(diagInfo.minWorstDistance)
J=max(0,diagInfo.minWorstDistance-cfg.smokeR);
else
J=1.0e8;
end
end
