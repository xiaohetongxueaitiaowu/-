function [Teff,intervals,diagInfo]=evaluate_cooperative_duration4(...
X,cfg,Q,dt,boundaryTol)
% 计算协同遮蔽总时长，同时输出每架无人机的参与时长、不可替代时长等诊断信息
s=compute_problem4_strategy(X,cfg);
diagInfo.minWorstCoopDistance=inf;
diagInfo.tAtMinimum=NaN;
diagInfo.maxClearance=-inf;
diagInfo.participationDuration=zeros(1,3);
diagInfo.essentialDuration=zeros(1,3);
diagInfo.nearRayDuration=zeros(1,3);
diagInfo.rayShareIntegral=zeros(1,3);
diagInfo.minCloudRayDistance=inf(1,3);
diagInfo.tAtMaxRayShare=nan(1,3);
diagInfo.maxRayShare=zeros(1,3);
diagInfo.cloudDetail=[];

% 物理可行性检查
if any(s.vF<70) || any(s.vF>140) || any(s.td<0) || any(s.tau<0) || ...
any(s.tb>cfg.tM1Arrive) || any(s.Pb(:,3)<0)
Teff=0; intervals=zeros(0,2); return;
end

tBegin=min(s.tb);
tEnd=min(max(s.tb+cfg.cloudLife),cfg.tM1Arrive);
if tEnd<=tBegin
Teff=0; intervals=zeros(0,2); return;
end

tGrid=(tBegin:dt:tEnd).';
if isempty(tGrid) || tGrid(end)<tEnd
tGrid(end+1,1)=tEnd;
end
[covered,D,cloudDetail]=cooperative_covered_at_times4(tGrid,X,cfg,Q);
[diagInfo.minWorstCoopDistance,kMin]=min(D);
diagInfo.tAtMinimum=tGrid(kMin);
diagInfo.maxClearance=cfg.smokeR-diagInfo.minWorstCoopDistance;
timeSpan=tEnd-tBegin;
diagInfo.participationDuration=min(timeSpan, ...
sum(cloudDetail.participationFlag,1)*dt);
diagInfo.essentialDuration=min(timeSpan, ...
sum(cloudDetail.essentialFlag,1)*dt);
diagInfo.nearRayDuration=min(timeSpan, ...
sum(cloudDetail.nearAnyRay,1)*dt);
diagInfo.rayShareIntegral=sum(cloudDetail.rayShare.*covered,1)*dt;
diagInfo.minCloudRayDistance=min(cloudDetail.individualBestDistance,[],1);
for i=1:3
[diagInfo.maxRayShare(i),kShare]=max(cloudDetail.rayShare(:,i).*covered);
if diagInfo.maxRayShare(i)>0
diagInfo.tAtMaxRayShare(i)=tGrid(kShare);
end
end
diagInfo.cloudDetail=cloudDetail;
diagInfo.timeGrid=tGrid;
diagInfo.covered=covered;

% 退火过程使用离散时长（boundaryTol<=0），最终复核时精化边界
if boundaryTol<=0
Teff=sum(covered)*dt;
Teff=min(Teff,tEnd-tBegin);
intervals=logical_intervals4(tGrid,covered);
return;
end

changeIndex=find(covered(1:end-1)~=covered(2:end));
tStart=zeros(0,1); tFinish=zeros(0,1);
if covered(1),tStart(end+1,1)=tBegin;end
for j=1:numel(changeIndex)
k=changeIndex(j);
tB=refine_cooperative_boundary4(tGrid(k),tGrid(k+1),covered(k),...
X,cfg,Q,boundaryTol);
if ~covered(k) && covered(k+1)
tStart(end+1,1)=tB;
else
tFinish(end+1,1)=tB;
end
end
if covered(end),tFinish(end+1,1)=tEnd;end
if numel(tStart)~=numel(tFinish)
Teff=0; intervals=zeros(0,2); return;
end
intervals=[tStart,tFinish];
if isempty(intervals),Teff=0;
else,Teff=sum(intervals(:,2)-intervals(:,1));end
end

function intervals=logical_intervals4(t,flag)
% 根据逻辑向量提取连续区间的起止时间
starts=flag & [true;~flag(1:end-1)];
ends=flag & [~flag(2:end);true];
intervals=[t(starts),t(ends)];
end
