function tBoundary=refine_cooperative_boundary(tLeft,tRight,leftFlag,...
X,cfg,Q,tol)
% 二分精化协同遮蔽边界
while tRight-tLeft>tol
tMid=0.5*(tLeft+tRight);
midFlag=cooperative_covered_at_times(tMid,X,cfg,Q);
if midFlag==leftFlag
tLeft=tMid;
else
tRight=tMid;
end
end
tBoundary=0.5*(tLeft+tRight);
end
