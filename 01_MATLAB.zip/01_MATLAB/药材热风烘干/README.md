# 药材热风烘干

按原目录关系保留程序、辅助函数和随附数据；独立图表统一归入 `03_论文/图表/药材热风烘干`。

本次仅拆分与静态核对，未运行 MATLAB 求解，也未修改算法或补造数据。`src` 保留原程序相对目录；运行时需按脚本要求设置工作目录。

## 未随资料提供的输入或结果文件

- `src/q1_main.m` 引用 `../data/env1.csv`。
- `src/q2_fvm.m` 引用 `../data/env1.csv`。
- `src/q2_ts.m` 引用 `../data/env1.csv`。
- `src/q3_fvm.m` 引用 `../data/env1.csv`。
- `src/q3_sens.m` 引用 `../data/env1.csv`。
- `src/q4_fvm.m` 引用 `../data/env1.csv`。
- `src/q4_fvm.m` 引用 `../data/radius.csv`。
- `src/绘图程序/q2_surf.m` 引用 `../data/result2.mat`。
- `src/绘图程序/q3_draw_heatmaps.m` 引用 `../data/result3.xlsx`。
