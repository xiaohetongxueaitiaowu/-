%% 问题二：变物性热湿耦合模型的有限体积法求解
% 【论文对应】5.2 节 出表3表4 和 result2.xlsx（图9图10 由 q2_surf.m 出）
% 本代码主要解决问题二：在变物性条件下求解温度与含水率的时空分布
% 离散口径（与论文5.2节一致）：采用真实径向网格，最外控制体到药材表面为半个控制体厚度，
%   并将该段导热（传质）阻力与表面对流阻力串联；
%   热量与水分通量中的界面物性均取相邻控制体的调和平均（相当于串联热阻）；
%   本问不引入扩散势，水分通量直接由扩散系数与含水率梯度计算。
clc; clear; close all;  

if ~exist('../fig','dir'), mkdir('../fig'); end  % 图目录
if ~exist('../data','dir'), mkdir('../data'); end  % 数据目录

%% --------1. 工况参数 （论文5.2.1） ------------------------------------
R     = 0.02;                                 % 药材半径(m)
th0   = 28;                                   % 初始温度(°C)
C0    = 2.55;                                 % 初始干基含水率(kg/kg)
h     = 25;                                   % 对流换热系数(W/(m^2*K))后面附录二没提到 和对流传质系数都沿用问题一
hm    = 8e-7;                                 % 对流传质系数(m/s)沿用问题一
Ct_gt = 0.15;                                 % 烘干判据(kg/kg)
N     = 321;                                  % 径向控制体数
grade = 4;                                    % 最厚与最薄控制体厚度比（网格）
T_max = 120*3600;                             % 积分上限(s)仅仅用作边界

%% --------2. PCHIP插值 + 末段平台 （论文5.2.1） ---------------
E = readmatrix('../data/env1.csv');             
env.t    = E(:,1);  env.T = E(:,2);  env.C = E(:,3);  
env.tEnd = env.t(end);                          % 不能直接拿插值外推
env.ppT  = pchip(env.t, env.T);                 
env.ppC  = pchip(env.t, env.C);                 

%% --------3. 阶段切换时刻 （论文5.2.1） --------------------
[env.ton, env.thDry, env.CeDry] = stage_detect(env);  
env.ts = 7200;                                  
fprintf('== 环境条件 ==\n');  
fprintf('  预热平衡终点 t_on = %.0f s (%.2f h)，末段平台 Tinf = %.4f °C，Ce,dry = %.5f kg/kg\n', ...
        env.ton, env.ton/3600, env.thDry, env.CeDry);
fprintf('  附件1 覆盖 %.0f~%.0f s，缺测的恒温段维持上述平台值\n', env.t(1), env.tEnd);  

%% --------4. 物性经验公式（附录3） （论文5.2.1） -------------------------
% 四条都按附录3写成匿名函数D的自变量是热力学温度 用摄氏温度直接代是很隐蔽的错
rho_f = @(C)    650 + 128*C;                   % 密度rho (kg/m^3)：干料650C = 2.55时976.4
cp_f  = @(C)    1450 + 2736*C./(C+1);          % 比热容cp (J/(kg*K))：水侧1450+2736 = 4186恰好是液态水
k_f   = @(C)    0.21 + 0.38*C./(C+1);          % 导热系数k (W/(m*K))：干料0.21饱水约0.59
D_f   = @(C,Tk) 2.4e-3*exp(-0.45./C).*exp(-3850./Tk);   % 扩散系数D (m^2/s)
fprintf('\n== 初态物性 ==\n  rho = %.2f kg/m^3，cp = %.1f J/(kg·K)，k = %.4f W/(m·K)，D = %.3e m^2/s\n', ...
        rho_f(C0), cp_f(C0), k_f(C0), D_f(C0, th0+273.15));   % 应该是rho=976.40cp=3415.3k=0.4830D=5.64e-09

%% --------5. 控制体网格 （论文5.2.2） ----------------------------------
% g里都是：g.n控制体数 g.dr各自厚度 g.rf界面半径 g.r节点半径 g.dc节点间距 g.w体积权重 int r dr
g  = mesh_make(N, grade, R);
ro = (0:0.1:2)'/100;                          % 输出位置(m)：0~2cm每0.1cm共21点
fprintf('\n== 网格 ==\n  N = %d，控制体厚度 %.3f~%.3f mm（厚度比 %.1f）\n', ...
        g.n, min(g.dr)*1e3, max(g.dr)*1e3, max(g.dr)/min(g.dr));

%% --------6. 有限体积半离散 + ode15s （论文5.2.2） -----------------------
% 空间离散完 时间不离散 直接丢给ode15s下面这行是整个脚本最慢的一步
y0  = [th0*ones(g.n,1); C0*ones(g.n,1)];      % 状态向量[th; C]前N个温度 后N个含水率
opt = odeset('RelTol',1e-8, 'AbsTol',[1e-8*ones(g.n,1); 1e-10*ones(g.n,1)], ...
             'NonNegative',(g.n+1):(2*g.n), 'JPattern',jpattern(g.n), 'MaxStep',300);
% AbsTol温度和含水率分开给：两个量差好几个量级 共用一个容限会顾此失彼
% NonNegative就是不让C积分成负数MaxStep卡在300s因为环境数据每分钟变一次 步子迈太大就跨过去了
fprintf('\n== 求解 ==\n');
tic
sol = ode15s(@(t,y) fvm_rhs(t,y,g,env,R,h,hm,rho_f,cp_f,k_f,D_f), [0 T_max], y0, opt);
fprintf('  积分区间 0~%.0f h，用时 %.1f s，自适应步数 %d\n', T_max/3600, toc, numel(sol.x));

%% --------7. 全域达标时刻：确定 result2的时间范围 （论文5.2.2） -----------
% 判据是全场最大含水率<= 0.15先按60s粗扫定位到哪一分钟达标 再钻进这一分钟里按1s细查
tc  = (0:60:T_max)';
Cc  = deval(sol, tc);
iok = find(max(Cc(g.n+1:end,:), [], 1) <= Ct_gt, 1);
if isempty(iok)
    error('在 %.0f h 内未达标，请检查环境条件与参数设置。', T_max/3600);
end
tf   = (tc(max(iok-1,1)):tc(iok))';           % max是为了别让下标取到0
Cf   = deval(sol, tf);
tEnd = tf(find(max(Cf(g.n+1:end,:), [], 1) <= Ct_gt, 1));   % 烘干结束时刻 问题三的烘干时间和它同源
fprintf('\n== 烘干过程 ==\n  全域水分浓度首次 <= %.2f kg/kg 的时刻 %.0f s = %.2f h 约 %.2f 天\n', ...
        Ct_gt, tEnd, tEnd/3600, tEnd/86400);

%% --------8. 水分收支检验 （论文5.2.2） ----------------------
% 收支：内部含水率的下降总量应该等于表面累计流失的水量 残差小就说明离散格式是守恒的
% 收敛：换成161和641个控制体各算一遍3h的径向分布变化小就说明321够密了
tchk  = (0:60:tEnd)';
Ychk  = deval(sol, tchk);
meanC = (2/R^2)*(g.w' * Ychk(g.n+1:end,:))';  % 截面平均含水率：g.w加权再按2/R^2归一化
loss  = (2/R^2)*cumtrapz(tchk, surf_flux_C(g, env, R, hm, D_f, tchk, Ychk));   % 表面累计失水量 口径和上面一致才能对账
fprintf('\n== 守恒检验 ==\n  水分收支最大残差 %.3e kg/kg（相对 %.2e）\n', ...
        max(abs(meanC - C0 + loss)), max(abs(meanC - C0 + loss))/C0);

%% --------9. 表3与表4 -----------------------------------
% 题目要的：3h内每0.5h距中心0/0.5/1/1.5/2cm只打印不写文件
hh       = (0.5:0.5:3)';
[thT,CT] = fields_at(ro, g, env, h, hm, k_f, D_f, hh*3600, deval(sol, hh*3600));
print_table('表3  3小时内药材的温度 (°C)',        hh, thT');
print_table('表4  3小时内药材的水分浓度 (kg/kg)', hh, CT');

%% --------10. result2.xlsx（表3表4的完整版） ------------------------------
% 题目要的：3h内每1s x每0.1cm温度和水分浓度各一张表 另存result2.mat给q2_surf用 省得重跑
tq  = (0:10800)';
thO = zeros(numel(tq), numel(ro));            % 先把内存开好再填 比在循环里一点点长大快
CO  = zeros(numel(tq), numel(ro));
blk = 20000;                                  % 分块查 一次查10801个时刻矩阵太大
tic
for k = 1:blk:numel(tq)
    idx = k:min(k+blk-1, numel(tq));          % 最后一块用min封顶 别越界
    [thB, CB] = fields_at(ro, g, env, h, hm, k_f, D_f, tq(idx), deval(sol, tq(idx)));
    thO(idx,:) = thB';
    CO(idx,:)  = CB';
end
fprintf('\n== result2.xlsx ==\n  插值到输出网格用时 %.1f s，开始写出 …\n', toc);
hdr = [{'时间\到药材中心的距离'}, num2cell(0:0.1:2)];       % 和模板一致
if exist('../data/result2.xlsx','file'), delete('../data/result2.xlsx'); end   % 防止旧表残留
tic
writecell(hdr, '../data/result2.xlsx', 'Sheet','温度', 'Range','A1');
writematrix([tq round(thO,4)], '../data/result2.xlsx', 'Sheet','温度', 'Range','A2');   % round到4位是题目的要求
writecell(hdr, '../data/result2.xlsx', 'Sheet','水分浓度', 'Range','A1');
writematrix([tq round(CO,4)], '../data/result2.xlsx', 'Sheet','水分浓度', 'Range','A2');
fprintf('  温度、水分浓度两张表，各 %d 行 x 21 列，覆盖 1~%.0f s，写出用时 %.1f s\n', ...
        numel(tq), tEnd, toc);

k60  = 1:60:numel(tq);                        % 每60s抽一行
tq60 = tq(k60);  th60 = thO(k60,:);  C60 = CO(k60,:);
tg   = linspace(0, 10800, 301);               % 作图用的密一点的时间网格 画出来没有折线感
[thg,Cg] = fields_at(ro, g, env, h, hm, k_f, D_f, tg, deval(sol, tg));
save('../data/result2.mat', 'g', 'env', 'ro', 'tq60', 'th60', 'C60', 'tg', 'thg', 'Cg');

%% ================= 局部函数 （论文5.2） =================
% 局部函数只在q2_fvm里可见 必须写在所有可执行语句后面
function [ton, thDry, CeDry] = stage_detect(env)
% 用"持续平台"判据标定预热段什么时候结束ton是判据确认的时刻 比实测稳定起点晚1200s
    sm    = movmean(env.T, 5);                % 5点滑动平均 先把抖动滤掉
    tail  = env.t >= env.t(end) - 3600;
    thDry = median(env.T(tail));              % 末段中位数当平台值 比平均值抗异常点
    CeDry = median(env.C(tail));
    d10   = [NaN(10,1); sm(11:end) - sm(1:end-10)];   % 10min增量 前10个补NaN比较时自动被排除
    dev   = sm - thDry;                       % 离平台还有多远 免得升温路上走得慢的一小段被当成平台
    ok    = abs(d10) <= 0.3 & abs(dev) <= 0.3;
    cnt   = movsum(double(ok), [0 20]);       % 要连续21个点（1200s）都满足才算
    i0    = find(cnt(11:end) == 21, 1) + 10;
    ton   = env.t(i0);
end

function [Ta, Ce] = env_at(t, env)
% 按时刻取环境条件：温度7200s之前用实测插值 之后取平台值 水分浓度14400s之后也取长期值
    t  = t(:);
    Ta = zeros(size(t));  Ce = zeros(size(t));
    iT = t <= env.ts;      Ta(iT) = ppval(env.ppT, t(iT));    Ta(~iT) = env.thDry;
    iC = t <= env.tEnd;    Ce(iC) = ppval(env.ppC, t(iC));    Ce(~iC) = env.CeDry;
end

function g = mesh_make(N, grade, R)
% 非均匀网格 指数是递减的 实际是中心薄 表面厚（和grade的字面意思反着 以这里算出来的为准）
    a    = grade^(-1/(N-1));
    dr   = R*(1-a)/(1-a^N) * a.^(N-1:-1:0)';
    rf   = [0; cumsum(dr)];                   % 界面半径 两端是0和R
    g.n  = N;   g.R = R;   g.dr = dr;   g.rf = rf;
    g.r  = (rf(1:end-1) + rf(2:end))/2;       % 节点取在控制体中心
    g.dc = diff(g.r);                         % 相邻节点间距
    g.w  = diff(rf.^2)/2;                     % int r dr 柱坐标的体积权重
end

function J = jpattern(n)
% 雅可比稀疏结构：每块只跟左右邻居耦合th和C也互相耦合 不说清楚求解器就得一个个去试
    e = ones(n,1);
    A = spones(spdiags([e e e], -1:1, n, n));
    J = [A A; A A] ~= 0;
end

function dydt = fvm_rhs(t, y, g, env, R, h, hm, rho_f, cp_f, k_f, D_f)
% 有限体积的右端项 整个脚本最要紧的一段 通量按"向外为正"取
    n  = g.n;
    th = y(1:n);
    C  = max(y(n+1:2*n), 1e-6);               % 兜底 别让物性公式在C = 0附近炸掉
    rho = rho_f(C);
    cp  = cp_f(C);
    kk  = k_f(C);
    DD  = D_f(C, th + 273.15);                 % 传进去的一定是开尔文
    % 界面系数取调和平均：界面相当于两个半块串起来 两边物性能差十几倍 算术平均会高估
    kh = 2*kk(1:end-1).*kk(2:end)./(kk(1:end-1) + kk(2:end));
    Dh = 2*DD(1:end-1).*DD(2:end)./(DD(1:end-1) + DD(2:end));
    [Ta, Ce] = env_at(t, env);
    Rk = g.dr(n)/(2*kk(n));                   % 最外节点到真实表面还有半个厚度 这段的阻力要算上
    Rd = g.dr(n)/(2*DD(n));
    % QT/QC长度都是n+1：第1个是圆心（零通量）最后一个是表面（半节点阻力串上对流阻力）
    QT = [0;  kh.*g.rf(2:n).*(th(1:n-1) - th(2:n))./g.dc;   R*(th(n) - Ta)/(Rk + 1/h )];
    QC = [0;  Dh.*g.rf(2:n).*(C(1:n-1)  - C(2:n) )./g.dc;   R*(C(n)  - Ce)/(Rd + 1/hm)];
    dth  = (QT(1:n) - QT(2:n+1))./(g.w.*rho.*cp);   % 相邻两块共用一个界面通量 一进一出正好抵消 守恒就是这么来的
    dC   = (QC(1:n) - QC(2:n+1))./g.w;
    dydt = [dth; dC];
end

function [thS, CS] = surf_vals(g, env, h, hm, k_f, D_f, t, Y)
% 算表面那一列 表面不在节点上 得用边界条件从最外节点反推出来
    n = g.n;
    [Ta, Ce] = env_at(t, env);
    Ta = Ta(:)';   Ce = Ce(:)';
    thn = Y(n,:);  Cn = Y(2*n,:);
    Rk = g.dr(n)./(2*k_f(Cn));
    Rd = g.dr(n)./(2*D_f(Cn, thn + 273.15));
    thS = Ta + (thn - Ta).*(1/h )./(Rk + 1/h );   % 表面温度往空气那边靠h越大靠得越近
    CS  = Ce + (Cn  - Ce).*(1/hm)./(Rd + 1/hm);
end

function qC = surf_flux_C(g, env, R, hm, D_f, t, Y)
% 表面水分通量 给守恒检验对账用 算法和fvm_rhs的表面界一样
    n = g.n;
    [~, Ce] = env_at(t, env);
    Cn = Y(2*n,:);
    Rd = g.dr(n)./(2*D_f(Cn, Y(n,:) + 273.15));
    qC = (R*(Cn - Ce(:)')./(Rd + 1/hm))';     % 列向量 方便cumtrapz
end

function [thF, CF] = fields_at(ro, g, env, h, hm, k_f, D_f, t, Y)
% 把节点上的解插值到题目要的输出网格 返回[位置x时刻]
    n = g.n;
    [thS, CS] = surf_vals(g, env, h, hm, k_f, D_f, t, Y);
    thF = interp_out(g, Y(1:n,:),     ro, Y(1,:),   thS);
    CF  = interp_out(g, Y(n+1:2*n,:), ro, Y(n+1,:), CS);
end

function Z = interp_out(g, Yn, ro, v0, vR)
% 两端要额外补上中心和表面的锚点：ro的端点是0和R但最内最外节点都在控制体中心 不补就成了外推
    rn = [0; g.r; g.R];
    Zn = [v0(:)'; Yn; vR(:)'];
    Z  = interp1(rn, Zn, ro, 'pchip');
end

function print_table(title, hh, Z)
% 按表3/表4的版式打印
    idx = [1 6 11 16 21];                     % 0/0.5/1/1.5/2cm在21列里的位置
    fprintf('\n== %s ==\n%8s', title, '时间/h');
    fprintf('%10.1f', 0, 0.5, 1, 1.5, 2);
    fprintf('\n');
    for j = 1:numel(hh)
        fprintf('%8.1f', hh(j));
        fprintf('%10.4f', Z(j, idx));
        fprintf('\n');
    end
end
