%% 问题三：参数灵敏度分析（蜘蛛图）
% 【论文对应】5.3.3 节 出图14
% 7个参数各扰动±5%和±10%看烘干时间跟着怎么变 画成蜘蛛图
clc; clear; close all;
if ~exist('../fig','dir'), mkdir('../fig'); end    % 图目录

%% --------1. 基准工况（与 q3_fvm 完全一致） （论文5.3.3） ----------------
R     = 0.02;                        % 药材半径(m)
th0   = 28;                          % 初始温度(°C)
C0    = 2.55;                        % 初始干基含水率(kg/kg)
Ct_gt = 0.15;                        % 烘干判据(kg/kg)
N     = 960;                         % 径向控制体数
T_max = 100*3600;                    % 求解时间上限(s)
h     = 25;                          % 对流换热系数(W/(m^2*K))附录3没给 沿用问题一
hm    = 8e-7;                        % 对流传质系数(m/s)同上
rhos  = 1;  cps = 1;  ks = 1;        % 物性缩放系数 名义工况都是1
A0    = 2.4e-3;                      % 扩散前因子(m^2/s)

% env和g是整组数据 构建结构体
env = load_env();
g   = mesh_make(N, R);
fprintf('== 名义解 ==\n');
sol0 = solve_case(h,hm,rhos,cps,ks,A0,th0,C0,T_max,g,env);
[tstar, top] = drying_time(sol0, g, Ct_gt, T_max);
fprintf('  t* = %.6f h，t_op = %.4f h = %.0f s\n', tstar/3600, top/3600, top);

%% --------2. 灵敏度分析 （论文5.3.3） 出图14 ----------------------------------
% rho和cp在方程里永远是乘在一起出现的 所以只画一条rhocp曲线 单独扰动哪个效果都一样
names = {'h','h_m','D_0','k','\rhoc_p','T_a','C_e'};
levs  = [-0.20 -0.10 0 +0.10 +0.20];   % 论文5.3.3 的扰动档位 ±10% ±20% 别改成 ±5% 图14对不上
T     = nan(numel(names), numel(levs));
T(:,3) = top/3600;                                  % 0处就是名义烘干时间
fprintf('\n== 灵敏度（烘干时间 / h）==\n%8s', '参数');
fprintf('%10d%%', levs*100);  fprintf('\n');
for i = 1:numel(names)
    for j = [1 2 4 5]
        [h2,hm2,cps2,ks2,A02,env2] = perturb(h,hm,cps,ks,A0,env,names{i},levs(j));
        % 每个扰动点都从初值重解一遍完整过程 不是在名义解上插值：物性对C th太非线性 插不了
        si = solve_case(h2,hm2,rhos,cps2,ks2,A02,th0,C0,T_max,g,env2);
        T(i,j) = drying_time(si, g, Ct_gt, T_max)/3600;
    end
    fprintf('%8s', names{i});
    fprintf('%11.4f', T(i,:));
    fprintf('\n');
end
fig_sens(names, levs, T, top/3600);

%% ================= 局部函数 （论文5.3.3） =================
% 把name指定的参数乘(1+d)别的原样带出去MATLAB值传递 改动得靠返回值接住
function [h, hm, cps, ks, A0, env] = perturb(h, hm, cps, ks, A0, env, name, d)
    switch name
        case 'h',        h   = h*(1+d);
        case 'h_m',      hm  = hm*(1+d);
        case 'D_0',      A0  = A0*(1+d);
        case 'k',        ks  = ks*(1+d);
        case '\rhoc_p',  cps = cps*(1+d);
% 后两支改的是环境：空气温度抬高Arrhenius项变大 烘干更快 空气水分抬高 表面浓度差变小 失水更慢
        case 'T_a', env.thDry = env.thDry*(1+d);
        case 'C_e',      env.CeDry = env.CeDry*(1+d);
    end
end


% 读烘房实测数据 末段取1h中位数当恒温平台值
function env = load_env()
    E = readmatrix('../data/env1.csv');
    env.t = E(:,1);  env.T = E(:,2);  env.C = E(:,3);
    env.tEnd = env.t(end);   env.ts = 7200;         % ts = 2h预热段和恒温段的分界
    tail = env.t >= env.t(end) - 3600;
    env.thDry = median(env.T(tail));
    env.CeDry = median(env.C(tail));
% 用pchip保形插值 别用样条 样条在拐点会过冲 能把温度插到50°C以上
    env.ppT = pchip(env.t, env.T);
    env.ppC = pchip(env.t, env.C);
end

% 任意时刻的环境条件：实测段查插值 之后保持平台值ode15s每步都调 得向量化
function [Ta, Ce] = env_at(t, env)
    t  = t(:);
    Ta = zeros(size(t));   Ce = zeros(size(t));
    iT = t <= env.ts;      Ta(iT) = ppval(env.ppT, t(iT));   Ta(~iT) = env.thDry;
    iC = t <= env.tEnd;    Ce(iC) = ppval(env.ppC, t(iC));   Ce(~iC) = env.CeDry;
end

% 径向网格：表面加密 最外节点正好落在表面r = R上
function g = mesh_make(N, R)
% rn = R*(1-(1-(1:N)'/N).^1.5)：指数1.5让节点往表面那边挤 最外节点就是R
    rn = R*(1 - (1 - (1:N)'/N).^1.5);
    rf = [0; (rn(1:end-1) + rn(2:end))/2; R];       % 界面半径 两端是圆心和表面
    g.n = N;  g.R = R;  g.r = rn;  g.rf = rf;
    g.dc = diff(rn);  g.w = diff(rf.^2)/2;          % 节点间距 控制体权重（差个2pi）
end

% 雅可比稀疏结构 给ode15s省掉逐列差分
function J = jpattern(n)
    e = ones(n,1);
    A = spones(spdiags([e e e], -1:1, n, n));
    J = [A A; A A] ~= 0;
end


% 半离散右端项dydt = [dth/dt; dC/dt] ode15s每步都要调
function dydt = fvm_rhs(t, y, h, hm, rhos, cps, ks, A0, g, env)
    n  = g.n;
    th = y(1:n);
    C  = max(y(n+1:2*n), 1e-6);                     % 试探步可能把C试成0或负数 先兜住
    rho = rhos*(650 + 128*C);                       % rho (kg/m^3)
    cp  = cps *(1450 + 2736*C./(C+1));              % cp (J/(kg*K))
    kk  = ks  *(0.21 + 0.38*C./(C+1));              % k (W/(m*K))
% 界面上的A(th) = A0*exp(-3850/T)界面温度取两边平均 加273.15换成开尔文
    Af = A0 * exp(-3850./((th(1:end-1)+th(2:end))/2 + 273.15));
% 水分走扩散势Phi = C.*exp(-0.45./C) - 0.45*expint(0.45./C) expint是指数积分
% 求导正好得exp(-0.45./C)界面上直接算Phi之差 比纠结界面C怎么平均稳得多
    Phi_f = @(C) C.*exp(-0.45./C) - 0.45*expint(0.45./C);
    Ph = Phi_f(C);
    kh = 2*kk(1:end-1).*kk(2:end)./(kk(1:end-1) + kk(2:end));   % 界面导热取调和平均
    [Ta, Ce] = env_at(t, env);
% n+1个界面上的热流和质量流：圆心零通量 内部用差商 表面走第三类边界
    QT = [0;  kh.*g.rf(2:n).*(th(1:n-1) - th(2:n))./g.dc;  g.R*h *(th(n) - Ta)];
    QC = [0;  Af.*g.rf(2:n).*(Ph(1:n-1) - Ph(2:n))./g.dc;  g.R*hm*(C(n) - Ce)];
% 相邻两块共用一个界面通量 一进一出正好抵消 总量只能从表面进出
    dth = (QT(1:n) - QT(2:n+1))./(g.w.*rho.*cp);
    dC  = (QC(1:n) - QC(2:n+1))./g.w;
    dydt = [dth; dC];
end

% 解整个烘干过程 返回ode15s的解对象（deval能查任意时刻）
function sol = solve_case(h, hm, rhos, cps, ks, A0, th0, C0, T_max, g, env)
% 容差收得很紧：判据只有0.15后期含水率变化极慢 容差一松就是几十分钟的误差
    opt = odeset('RelTol',1e-8, 'AbsTol',[1e-8*ones(g.n,1); 1e-10*ones(g.n,1)], ...
                 'NonNegative',(g.n+1):(2*g.n), 'JPattern',jpattern(g.n), 'MaxStep',300);
    sol = ode15s(@(t,y) fvm_rhs(t,y,h,hm,rhos,cps,ks,A0,g,env), [0 T_max], ...
                 [th0*ones(g.n,1); C0*ones(g.n,1)], opt);
end

% 全场最大含水率 分批查 免得一次开太大
function M = maxC_series(sol, g, tc)
    tc = tc(:)';   M = zeros(size(tc));   blk = 5000;
    for k = 1:blk:numel(tc)
        idx = k:min(k+blk-1, numel(tc));
        Y = deval(sol, tc(idx));
        M(idx) = max(Y(g.n+1:2*g.n, :), [], 1);
    end
end

% 烘干时间=全场最大含水率首次不高于判据的时刻 先60s粗扫 再1s细化 最后二分到0.01s
function [tstar, top] = drying_time(sol, g, Ct_gt, T_max)
    tc = (0:60:T_max)';
    Mc = maxC_series(sol, g, tc);
    i0 = find(Mc <= Ct_gt, 1);
    if isempty(i0), error('搜索上限内未达标'); end
    tf = (tc(i0-1):1:tc(i0))';                      % 阈值就藏在这一分钟里
    Mf = maxC_series(sol, g, tf);
    j0 = find(Mf <= Ct_gt, 1);
    lo = tf(j0-1);   hi = tf(j0);                   % lo还没达标hi已经达标
    while hi - lo > 0.01
        mid = (lo + hi)/2;
        if maxC_series(sol, g, mid) <= Ct_gt, hi = mid; else, lo = mid; end
    end
    tstar = hi;
    top   = 60*ceil(tstar/60);                      % 结果要落在60s的输出网格上
    if maxC_series(sol, g, top) >= Ct_gt, top = top + 60; end   % 恰好等于判据就再推一分钟
end

% 蜘蛛图：横轴参数相对变化 纵轴烘干时间Ta最敏感 线画粗一点

function fig_sens(names, levs, T, top0)
    mk = {'o','s','^','d','v','>','<'};
    ls = {'-','--',':','-.','-','--',':'};
    cs = [0.12 0.35 0.65; 0.85 0.33 0.10; 0.00 0.55 0.35; 0.55 0.20 0.60;
          0.80 0.62 0.05; 0.75 0.08 0.22; 0.00 0.65 0.75];
    lw = [0.9 0.9 0.9 0.9 0.9 1.6 0.9];
    FR = setfont();
    f = figure('Units','inches','Position',[1 1 7.4 3.3],'Color','w','ToolBar','none');   % 图幅约 2:1 别乱改 论文里按这个宽度放
    ax = axes(f); hold(ax,'on');
    yline(ax, top0, '--', 'Color',[0.2 0.2 0.2], 'LineWidth',1.1);
    plot(ax, 0, top0, 'o', 'MarkerSize',4.6, 'MarkerFaceColor',[0.15 0.15 0.15], ...
         'MarkerEdgeColor','k', 'HandleVisibility','off');      % 名义点 不进图例
    hp = gobjects(1,numel(names));
% 5个点之间只连直线 不做光滑插值 光滑会暗示“扰动连续可微”模型给不出这信息
    for i = 1:numel(names)
        hp(i) = plot(ax, levs*100, T(i,:), ls{i}, 'Color', cs(i,:), 'LineWidth', lw(i), ...
                     'Marker', mk{i}, 'MarkerSize',3.8, 'MarkerFaceColor','w');
    end
    text(ax, -9.8, top0+1.9, sprintf('名义值 %.4f h', top0), ...
         'FontSize',8, 'Color',[0.15 0.15 0.15]);
    xlabel('参数相对变化 (%)');
    ylabel(ax,'烘干时间 (h)');
    xticks(ax, levs*100);   yticks(ax, 40:5:85);  ylim(ax,[40 85]);   % 和论文图14同量程 固定住才好横向比
    grid(ax,'on');  set(ax,'GridColor',[0.87 0.87 0.87],'GridAlpha',0.9);
    set(ax,'FontSize',8.5,'Box','off','TickDir','out','LineWidth',0.5);
    legend(ax, hp, names, 'Location','northeast', 'FontSize',8, 'NumColumns',3, ...
           'FontName', FR);
    drawnow;
    setfont(f);
% 存原始数据 换样式重画时直接load不用重算28个扰动工况
    save('../data/result3_sens.mat','names','levs','T','top0');
    exportgraphics(f,'../fig/问题三_灵敏度_参数对烘干时间的影响.pdf','ContentType','vector');
    fprintf('已保存 fig/问题三_灵敏度_参数对烘干时间的影响.pdf\n');
    close(f);
end
