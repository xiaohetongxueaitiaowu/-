%% 问题四绘图 图16图17图20 材料网格位移 收缩速率灵敏度 受控对照
% 【论文对应】5.4 节 出图16 图17 受控对照那张图20 用在论文第六章
% 由 q4_fvm.m 调用 半径插值对象和几组烘干时间都当参数传进来 本文件只画图导图
function plot_q4(Rpp, tRend, top, top4, topS)
% Rpp   收缩半径R(t)的pchip插值对象 单位m
% tRend 附件2观测末端(s)
% top   名义方案C的工艺结束时刻(s)
% top4  四个受控方案的烘干时长(h) 顺序 A B C D
% topS  三个收缩速率缩放的烘干时长(h) 对应 s = 0.8 1.0 1.2

FR = setfont();                              % 中文字体名 显式给FontName用
col = [0.05 0.20 0.45; 0.15 0.55 0.75; 0.20 0.65 0.40; 0.90 0.55 0.10; 0.75 0.15 0.20];

% 图20：四个方案的烘干时间 看物性和收缩各贡献多少
f = figure('Units','inches','Position',[1 1 5.4 3.0],'Color','w','ToolBar','none');
ax = axes(f); hold(ax,'on');
b = bar(ax, 1:4, top4, 0.55, 'FaceColor','flat');
b.CData = [0.62 0.72 0.80; 0.35 0.60 0.75; 0.16 0.42 0.58; 0.75 0.45 0.25];
for k = 1:4
    text(ax, k, top4(k)+max(top4)*0.03, sprintf('%.4f', top4(k)), 'HorizontalAlignment','center', ...
         'FontName',FR, 'FontSize',8);
end
xticks(ax, 1:4);  xticklabels(ax, {'A 固定+附录3','B 固定+附录4','C 收缩+附录4','D 收缩+附录3'});
ylabel(ax,'烘干时间 (h)', 'FontName',FR);  ylim(ax,[0 max(top4)*1.15]);
set(ax,'FontSize',8.5,'Box','off','TickDir','out','LineWidth',0.5,'FontName',FR);
setfont(f);
exportgraphics(f,'../fig/问题四_受控对照_物性与收缩的贡献.pdf','ContentType','vector');
fprintf('已保存 问题四_受控对照_物性与收缩的贡献.pdf\n'); close(f);

% 图16：材料点跟着药材一起内移 横轴是当前的真实位置(cm)
xi_m = (0:0.1:1)';  % 11个材料点的参考坐标
ts   = [0 6 12 24 36 top/3600];
f = figure('Units','inches','Position',[1 1 6.0 2.95],'Color','w','ToolBar','none');   % 6条行距按论文图16的比例
ax = axes(f); hold(ax,'on');
for k = 1:numel(ts)
    Rk  = R_of(ts(k)*3600, Rpp, tRend);
    rr  = xi_m*Rk*100;
    y0  = numel(ts) - k + 1;
    plot(ax, [0 Rk*100], [y0 y0], '-', 'Color',[0.75 0.82 0.88], 'LineWidth',0.8);
    plot(ax, rr, y0*ones(size(rr)), 'o-', 'Color',col(mod(k-1,5)+1,:), ...
         'MarkerSize',3.4, 'MarkerFaceColor',col(mod(k-1,5)+1,:), 'LineWidth',1.0);
    text(ax, 2.35, y0, sprintf('t = %.4g h，R = %.3f cm', ts(k), Rk*100), ...
         'FontName',FR, 'FontSize',7.5, 'VerticalAlignment','middle');
end
xlabel(ax,'药材内各材料点的当前真实位置 (cm)', 'FontName',FR);
xlim(ax,[0 2.3]);  ylim(ax,[0.4 numel(ts)+0.8]);  yticks(ax,[]);
set(ax,'FontSize',8.5,'Box','off','TickDir','out','LineWidth',0.5,'FontName',FR);
setfont(f);
exportgraphics(f,'../fig/问题四_材料网格位移_随收缩内移.pdf','ContentType','vector');
fprintf('已保存 问题四_材料网格位移_随收缩内移.pdf\n'); close(f);

% 图17：收缩速率+/-20%对烘干时间的影响(柱状图)
% 数字统一标在最高的柱子之上 柱子顶和名义值虚线都不会压到它
col6 = [0.30 0.58 0.72; 0.16 0.42 0.58; 0.62 0.75 0.83];
lab6 = {'收缩快 20%','名义收缩','收缩慢 20%'};
f = figure('Units','inches','Position',[1 1 6.6 4.2],'Color','w','ToolBar','none');   % 图幅约1.46:1 和论文图17一致
ax = axes(f); hold(ax,'on');
b = bar(ax, 1:3, topS, 0.5, 'FaceColor','flat');
b.CData = col6;
plot(ax, [0.4 3.6], [topS(2) topS(2)], '--', 'Color',[0.45 0.45 0.45], ...
     'LineWidth',1.0, 'HandleVisibility','off');                % 名义值参考线
ylab_at = max(topS)*1.06;                  % 数字的基线高度：比最高的柱子还高6%
for k = 1:3
    text(ax, k, ylab_at, sprintf('%.4f h', topS(k)), 'FontName',FR, 'FontSize',8.5, ...
         'HorizontalAlignment','center', 'VerticalAlignment','bottom');
end
xlim(ax, [0.4 3.6]);   ylim(ax, [0 max(topS)*1.22]);
set(ax, 'XTick',1:3, 'XTickLabel', lab6);
ylabel(ax,'烘干时间 (h)', 'FontName',FR);
set(ax,'FontSize',8.5,'Box','off','TickDir','out','LineWidth',0.5,'FontName',FR);
setfont(f);
exportgraphics(f,'../fig/问题四_灵敏度_收缩速率对烘干时间的影响.pdf','ContentType','vector');
fprintf('已保存 问题四_灵敏度_收缩速率对烘干时间的影响.pdf\n'); close(f);
end

% 收缩半径取值 超出附件2覆盖范围就冻在末段值
function Rt = R_of(t, Rpp, tRend)
    Rt = ppval(Rpp, min(t, tRend));
end
