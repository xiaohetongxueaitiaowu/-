%% 问题二：温度与水分浓度的三维时空曲面
% 【论文对应】5.2.2 节 出图9 图10
% 读result2.mat把th(r,t)和C(r,t)画成三维曲面

clc; clear; close all;
if ~exist('../fig','dir'), mkdir('../fig'); end

%% --------1. 读数据 （论文5.2.2） ------------------------------
S  = load('../data/result2.mat');
ro = S.ro*100;                       % 输出位置(cm)
tg = S.tg/3600;                      % 输出时刻(h)
rr = (0:0.02:2)';                    % 画图网格0.02cm x 15s密一点曲面的棱角才不明显
tt = (0:15:10800)'/3600;
[X, Y] = meshgrid(tt, rr);           % X每行是时间轴Y每列是半径轴

% 'makima'比普通样条稳 拐点附近不过冲 不会冒出假凸包
TH = interp2(tg, ro, S.thg, X, Y, 'makima');
CQ = interp2(tg, ro, S.Cg,  X, Y, 'makima');

%% --------2. 出图 -> 图9 图10 ------------------------------
% 两幅视角不一样：温度[135 30 1]从背面斜上方看 时间轴还得反转
% 水分[45 55 0]基本是俯视
surf_plot(X, Y, TH, 'warm',  '温度 T (°C)',    [135 30 1], [1.7 0.9], ...
          '../fig/问题二_曲面_温度时空分布.pdf');
surf_plot(X, Y, CQ, 'water', '水分浓度 C (kg/kg)', [45 55 0],  [1.0 0.6], ...
          '../fig/问题二_曲面_水分浓度时空分布.pdf');

%% --------局部函数 （论文5.2.2） ------------------------------

function surf_plot(X, Y, Z, ramp, zlab, vcfg, rLabs, fname)
    % 画曲面导出PDF：底图曲面+每0.5h一条剖面线+顺着曲线躺下的时刻标签+色条
    zmin = min(Z(:));   zmax = max(Z(:));   rng = zmax - zmin;   % 后面留白都按rng的比例算 温度水分两个量级都能用
    cm   = ramp_lut(ramp);
    f  = figure('Units','inches', 'Position',[1 1 5.4 4.3], 'Color','w','ToolBar','none');
    ax = axes(f);   hold(ax,'on');
    % 'texturemap'就是拿Z当颜色 不写的话颜色会分块跳
    surf(ax, X, Y, Z, Z, 'FaceColor','texturemap', 'EdgeColor','none');
    colormap(ax, cm);
    clim(ax, [zmin zmax]);       % 色条两端正好卡在数据极值 读数不用换算
    xlabel('时间 t (h)');
    ylabel('距中心距离 r (cm)');
    zlabel(zlab);
    xlim(ax, [0 3]);   ylim(ax, [0 2]);
    zlim(ax, [zmin zmax + 0.06*rng]);   % 顶上抬6%给时刻标签留地方
    xticks(ax, 0:0.5:3);   yticks(ax, 0:0.5:2);
    view(ax, vcfg(1), vcfg(2));
    if vcfg(3), set(ax, 'XDir','reverse'); end   % 反转时间轴 画面里时间还是从左到右
    camproj(ax, 'orthographic');                 % 正交投影 去掉近大远小 曲面不变形
    pbaspect(ax, [1.15 1.25 1]);
    set(ax, 'FontSize',8.5, 'Box','on', 'GridColor',[0.72 0.72 0.72], ...
            'GridAlpha',0.55, 'TickDir','out', 'LineWidth',0.5);
    drawnow;

    Yr = Y(:,1);   k = 0;        % Yr是完整的半径轴k用来在两个标签位置之间轮换
    for tk = 0.5:0.5:3
        k = k + 1;
        j = find(abs(X(1,:) - tk) < 1e-9, 1);   % 浮点数判等要用容差
        plot3(ax, tk*ones(size(Yr)), Yr, Z(:,j), '-', 'Color',[0.30 0.30 0.30], 'LineWidth',0.6);

        iL = find(abs(Yr - rLabs(1 + mod(k,2))) < 1e-9, 1);
        i2 = min(iL + 8, numel(Yr));                 % 顺着曲线再取一点 跟p1配一起定文字方向
        p1 = [tk, Yr(iL), Z(iL,j)];
        p2 = [tk, Yr(i2), Z(i2,j)];
        text(ax, p1(1), p1(2), p1(3) + 0.030*rng, sprintf('%.1f h', tk), 'FontSize',6.5, ...
             'Color',[0.30 0.30 0.30], 'Rotation', screen_angle(ax, p1, p2), ...
             'HorizontalAlignment','center', 'VerticalAlignment','bottom');
    end

    cb = colorbar(ax);
    cb.Label.String   = zlab;
    cb.Label.FontSize = 8.5;
    cb.FontSize       = 8;
    cb.Ticks          = linspace(zmin, zmax, 6);
    cb.TickLabels     = compose('%.2f', cb.Ticks);

    setfont(f);
    exportgraphics(f, fname, 'ContentType','auto', 'Resolution',400);
    fprintf('已保存 %s\n', fname);
    close(f);
end

function ang = screen_angle(ax, p1, p2)
    % 算文字该转多少度才能顺着剖面线躺下：p1p2投到屏幕坐标再atan2d
    cp = ax.CameraPosition;   ct = ax.CameraTarget;   cu = ax.CameraUpVector;
    d  = (ct - cp)/norm(ct - cp);
    r  = cross(d, cu);        r = r/norm(r);
    u  = cross(r, d);
    v  = [dot(p2 - p1, r), dot(p2 - p1, u)];
    ang = atan2d(v(2), v(1));
    if ang >  90, ang = ang - 180; end   % 别让字倒着写
    if ang < -90, ang = ang + 180; end
end

function cmap = ramp_lut(name)
    % 手搓的色带 灰度单调 黑白打印也分得清
    switch name
        case 'warm'      % 温度：米白->浅琥珀->橙->砖红
            a = [1.000 0.976 0.925
                 0.996 0.894 0.729
                 0.988 0.784 0.565
                 0.965 0.639 0.420
                 0.918 0.494 0.298
                 0.855 0.373 0.216];
        case 'water'     % 水分浓度：近白->浅湖蓝->湖蓝->中蓝
            a = [0.972 0.988 0.996
                 0.855 0.937 0.965
                 0.706 0.867 0.918
                 0.529 0.761 0.847
                 0.353 0.635 0.749
                 0.216 0.502 0.643];
    end
    xi   = linspace(0, 1, 256);
    cmap = min(max(interp1(linspace(0,1,size(a,1)), a, xi, 'pchip'), 0), 1);   % pchip穿过锚点 中间不过冲
end
