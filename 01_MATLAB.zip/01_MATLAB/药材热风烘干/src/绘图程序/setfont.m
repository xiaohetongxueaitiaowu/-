function FR = setfont(f)
% 全项目就这一个字体函数 统一整张图的字体
% 只拿字体名：FR = setfont();给legend用
% 或者setfont(f);把图窗f里所有文字一起改掉
%
% 不统一的话 默认Helvetica没汉字 汉字和数字分属两套字体 基线不一样
% 看着汉字下沉数字上飘
% 候选按优先级试：macOS用PingFang SC Windows用微软雅黑 都没有就退回Helvetica

if nargin < 1 || isempty(f)     % 没给图窗 就只查字体名 不动图
    FR = pick_cjk_font();
    return
end

FR = pick_cjk_font();

drawnow;         % legend/colorbar是后来才建的 不先跑一遍会漏掉

% 找出图里所有带FontName的对象 一起改掉
set(findall(f, '-property', 'FontName'), 'FontName', FR);
end


function FR = pick_cjk_font()
% 挑一个本机真有的中文字体 没有就用Helvetica兜底
want = {'PingFang SC','Heiti SC','Songti SC','STHeiti','Hiragino Sans GB', ...
        'Microsoft YaHei','SimHei'};

av = listfonts;                 % 本机真装了的字体

FR = 'Helvetica';               % 兜底

for k = 1:numel(want)
    if any(strcmpi(av, want{k}))
        FR = want{k};
        break
    end
end
end
