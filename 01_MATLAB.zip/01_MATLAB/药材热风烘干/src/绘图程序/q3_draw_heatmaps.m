%% 问题三：两张时空热力图（含水率 + 干燥速率）
% 【论文对应】5.3.2 节 出图12 图13
clc; clear; close all;
if ~exist('../fig','dir'), mkdir('../fig'); end  % 目录不在exportgraphics会直接报错
MODE = 'vector';  % 导出方式 末尾的产出报告要用

%% --------1. 读结果文件 （论文5.3.2） ------------------------------
Tb = [];  % 没找到就留空
for sh = sheetnames('../data/result3.xlsx')'  % 不写死表名 表被重存过的话第一张可能不是数据
    A = readmatrix('../data/result3.xlsx','Sheet',sh{1});  % 表头文字会读成NaN
    if size(A,1) > 5 && size(A,2) > 3 && all(isfinite(A(2:6,1))), Tb = A; break; end  % 行列够多、A列第2~6行是有限数 就认成浓度表
end
assert(~isempty(Tb), '../data/result3.xlsx 中未找到可用的浓度表');
ro  = Tb(1,2:end);  % 径向位置r (cm) 0~2共21点
tt  = Tb(2:end,1);  % 时间t (s) 60s一帧共3448帧
C   = Tb(2:end,2:end);  % 干基含水率(kg/kg) 行=时刻 列=半径
tq  = tt/3600;  % 换成小时(h)
Ctgt = 0.15;                                    % 达标判据(kg/kg)
t_end = tq(end);  % 烘干结束时刻(h) 取末行
fprintf('读入 %d 时刻 x %d 位置；烘干结束 t_end = %.4f h\n', numel(tt), numel(ro), t_end);

%% --------2. 干燥速率与干燥锋 （论文5.3.2） ------------------------------
% C只存4位小数 直接差分会被量化噪声淹没 所以先做1h滑动平均再求导
[~, dCdt] = gradient(C, ro, tt);  % 中心差分 第2个输出才是dC/dt (kg/kg/s)
raw  = -dCdt * 3600;  % 失水速率(kg/(kg*h)) 取负号让C下降变成正量
k    = 61;  % 61帧 = 1h
rate = filter(ones(k,1)/k, 1, raw);  % 沿时间方向61点滑动平均
rate(1:k,:) = raw(1:k,:);  % 前1h没有历史 直接用原始值
% 干燥锋r_f(t)就是C=0.15的交点 直接在0.1cm网格上找跨越单元会出锯齿 插到细网格再求交

rfine = linspace(ro(1), ro(end), 1601);  % 细网格(cm) 比原来的0.1cm细80倍
rf = nan(size(tt));  % 锋面半径(cm) NaN=还没出现 0=已推到中心
for i = 1:numel(tt)
    Ci = interp1(ro, C(i,:), rfine, 'pchip');  % pchip保单调 不会冒出假交点
    kf = find(Ci > Ctgt, 1, 'last');  % 交点夹在第kf和kf+1点之间
    if isempty(kf),            rf(i) = 0;  % 全场达标
    elseif kf == numel(rfine), rf(i) = nan;  % 表面还没达标
    else, rf(i) = rfine(kf) + (Ctgt-Ci(kf))*(rfine(kf+1)-rfine(kf))/(Ci(kf)-Ci(kf+1));  % 线性插值求Ci = Ctgt
    end
end

v = ~isnan(rf);  rf(v) = movmean(rf(v), 31);  % 抹掉残余抖动

%% --------3. 出图设置 （论文5.3.2） ------------------------------
FR = setfont();  % 中文字体名
FS   = 8.5;  % 轴刻度字号(pt)
FL   = 9.5;  % 轴标题字号(pt)比刻度大一档
FA   = 7.5;  % 图内text字号(pt)压在色场上所以取最小
xmax = 60;  % 时间轴上限(h)：烘干57.47h结束 右边留白正好写结束标注

% ColorBrewer 9级顺序色板 明度单调
YGB = [1.000 1.000 0.851; 0.929 0.973 0.694; 0.780 0.914 0.706; 0.498 0.804 0.733; ...
       0.255 0.714 0.769; 0.114 0.569 0.753; 0.133 0.369 0.659; 0.145 0.204 0.580; 0.031 0.114 0.345];
YOR = [1.000 1.000 0.800; 1.000 0.929 0.627; 0.996 0.851 0.463; 0.996 0.698 0.298; ...
       0.992 0.553 0.235; 0.988 0.306 0.165; 0.890 0.102 0.110; 0.741 0.000 0.149; 0.502 0.000 0.149];
CBc = interp1(linspace(0,1,size(YGB,1)), YGB, linspace(0,1,256), 'pchip');  % 冷色表 黄-绿-蓝 配含水率
CBw = interp1(linspace(0,1,size(YOR,1)), YOR, linspace(0,1,256), 'pchip');  % 暖色表 黄-橙-红 配干燥速率
EXP = {'ContentType','vector'};  % 整页矢量导出

%% ======== 图A：含水率时空热力图 -> 图12 ========
fA = figure('Units','inches','Position',[1 1 5.6 3.3],'Color','w','ToolBar','none');
ax = axes(fA);  hold(ax,'on'); view(ax, 2);  % 二维俯视 z只用来分层
    [xg, yg] = meshgrid(tq, ro);  % 坐标网格 [位置x时刻]

    surf(ax, xg, yg, -ones(size(C')), log10(max(C,1e-3))', 'FaceColor','texturemap','EdgeColor','none');  % 色场取log10 下限是防止log10(0)拉坏色轴
colormap(ax, CBc);  clim(ax, log10([0.05 2.55]));  % 色轴范围 C覆盖0.05~2.55 不截顶
[xc, yc] = meshgrid(tq, ro);
contour(ax, xc, yc, C', [Ctgt Ctgt], 'LineColor',[0.85 0.05 0.10], 'LineWidth',1.4);  % C=0.15那条等值线就是干燥锋
xline(ax, t_end, '--', 'Color',[0.10 0.10 0.10], 'LineWidth',0.9);  % 烘干结束竖线
cb = colorbar(ax);  cb.Label.String = '水分浓度 C (kg/kg)';
tkc = [0.05 0.1 0.15 0.25 0.5 1 2 2.55];  % 色条上标出的真实值
cb.Ticks = log10(tkc);  cb.TickLabels = compose('%.2f', tkc);  % 刻度放对数位置 标签写真实值
text(ax, t_end-1.0, 1.96, sprintf('烘干结束 %.2f h', t_end), 'Color',[0.15 0.15 0.15], ...
     'FontSize',FA, 'FontName',FR, 'HorizontalAlignment','right','VerticalAlignment','top');
xlabel(ax,'干燥时间 t (h)','FontName',FR,'FontSize',FL);
ylabel(ax,'距中心的距离 r (cm)','FontName',FR,'FontSize',FL);  % 0=中心 2=表面
xlim(ax,[0 xmax]);  ylim(ax,[0 2]);  zlim(ax,[-1 0]);  ax.ZTick = [];  % z只管分层 刻度清空
ax.FontSize = FS;  ax.TickDir = 'out';  ax.LineWidth = 0.5;
ax.Toolbar.Visible = 'off';
setfont(fA);  % 统一整图字体
fnA = '../fig/问题三_干燥历程_含水率时空热力图.pdf';
exportgraphics(fA, fnA, EXP{:});

%% ======== 图B：干燥速率时空热力图 -> 图13 ========
fB = figure('Units','inches','Position',[1 1 5.6 3.3],'Color','w','ToolBar','none');  % 与图A同尺寸 论文里并排放
ax = axes(fB);  hold(ax,'on'); view(ax, 2);  % 同图A
    [xg, yg] = meshgrid(tq, ro);
    surf(ax, xg, yg, -ones(size(C')), log10(max(rate,1e-5))', 'FaceColor','texturemap','EdgeColor','none');  % 色场取log10 下限是防止log10(0)拉坏色轴
colormap(ax, CBw);  clim(ax, log10([1e-4 1.5]));  % 下限盖住尾期的真实速率

plot(ax, tq, rf, '-', 'Color',[0.06 0.12 0.40], 'LineWidth',1.2);  % 干燥锋轨迹 NaN段会自动断线
xline(ax, t_end, '--', 'Color',[0.10 0.10 0.10], 'LineWidth',0.9);  % 烘干结束竖虚线
cb = colorbar(ax);  cb.Label.String = '干燥速率 -\partialC/\partialt (kg kg^{-1} h^{-1})';  % TeX偏导符号
tkr = [1e-4 1e-3 1e-2 0.1 1];  % 5个量级的代表值
cb.Ticks = log10(tkr);  cb.TickLabels = {'10^{-4}','10^{-3}','10^{-2}','0.1','1'};  % 位置取对数 标签用TeX
text(ax, t_end-1.0, 1.96, sprintf('烘干结束 %.2f h', t_end), 'Color',[0.15 0.15 0.15], ...
     'FontSize',FA, 'FontName',FR, 'HorizontalAlignment','right','VerticalAlignment','top');
xlabel(ax,'干燥时间 t (h)','FontName',FR,'FontSize',FL);
ylabel(ax,'距中心的距离 r (cm)','FontName',FR,'FontSize',FL);
xlim(ax,[0 xmax]);  ylim(ax,[0 2]);  zlim(ax,[-1 0]);  ax.ZTick = [];
ax.FontSize = FS;  ax.TickDir = 'out';  ax.LineWidth = 0.5;
ax.Toolbar.Visible = 'off';
setfont(fB);
fnB = '../fig/问题三_干燥速率_时空热力图与干燥锋.pdf';
exportgraphics(fB, fnB, EXP{:});

dA = dir(fnA);  dB = dir(fnB);  % 报告PDF大小 不是0字节才算写成功
fprintf('已保存（%s）：\n  %s  (%.0f KB)\n  %s  (%.0f KB)\n', MODE, fnA, dA.bytes/1024, fnB, dB.bytes/1024);
fprintf('说明：-dC/dt 作图场范围 %.3g ~ %.3g kg/(kg·h)（已 1 h 滑动平均）；干燥锋自表面 r=2 cm 向内推进至中心\n', ...
        min(rate(:)), max(rate(:)));

