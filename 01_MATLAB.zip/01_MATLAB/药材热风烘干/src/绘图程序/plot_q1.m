%% 问题一 绘图 图6图7 温度场与水分场沿半径分布
% 【论文对应】5.1.3 节 由 q1_main.m 调用
% 入参：ro 径向位置(m) ToP 温度场(degC) CoP 水分浓度场(kg/kg) outdir 出图目录
function plot_q1(ro, ToP, CoP, outdir)

tl  = [100 600 1200 1800];                   % 要画的四个时刻(s)
lg4 = {'100秒','600秒','1200秒','1800秒'};

figure('Units','inches','Position',[1 1 5.4 3.4],'Color','w','ToolBar','none');
plot(ro*100, ToP(tl+1,:)','LineWidth',1.2);
xlabel('r (cm)'); ylabel('T (\circC)'); grid on;
lg = legend(lg4,'Location','northwest'); set(lg,'FontSize',7.5,'ItemTokenSize',[12 7]);  % 图例放左上 躲开1800秒那条线
setfont(gcf);   % 画完统一字体 下一句就是导出
exportgraphics(gcf,[outdir '问题一_温度场_不同时刻沿半径分布.pdf'],'ContentType','vector');

figure('Units','inches','Position',[1 1 5.4 3.4],'Color','w','ToolBar','none');
plot(ro*100, CoP(tl+1,:)','LineWidth',1.2);
xlabel('r (cm)'); ylabel('C (kg/kg)'); grid on;
lg = legend(lg4,'Location','southwest'); set(lg,'FontSize',7.5,'ItemTokenSize',[12 7]);  % 曲线在上头 图例放左下
setfont(gcf);
exportgraphics(gcf,[outdir '问题一_水分场_不同时刻沿半径分布.pdf'],'ContentType','vector');
fprintf('已保存 图6图7(矢量 PDF)\n');
end
