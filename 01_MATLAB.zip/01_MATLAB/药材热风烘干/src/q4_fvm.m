%% 问题四：半径随失水收缩的移动边界模型（参考坐标+有限体积）
% 【论文对应】5.4 节 出表6 图16图17 受控对照那张图20 用在论文第六章 和 result4.xlsx
% 半径会缩 所以拿参考坐标xi = r/R(t)把动边界换回固定域 再丢给ode15s
% 离散口径（与论文5.4节一致）：沿用第三问的有限体积离散框架（界面物性取调和平均）；
%   热量通量——界面热导率取相邻控制体的调和平均；
%   水分通量——界面扩散系数取相邻两节点的调和平均，再乘相邻节点浓度差除以节点距离；
%   温度因子——A4(Th)=4.2e-4*exp(-3850/(Th+273.15))；
%   半径随时间变化——每个时刻按当前收缩半径更新节点间距、界面面积与控制体积，
%   在参考坐标下表现为输运项除以 R(t)^2、表面通量乘以 R(t)。
clc; clear; close all;

if ~exist('../fig','dir'), mkdir('../fig'); end
if ~exist('../data','dir'), mkdir('../data'); end

%% --------1. 工况参数 （论文5.4.1） ----------
R0    = 0.02;        % 初始半径(m)
th0   = 28;          % 初始温度(°C)
C0    = 2.55;        % 初始干基含水率(kg/kg)
h     = 25;          % 对流换热系数W/(m^2*K)附录4没给 沿用问题一
hm    = 8e-7;        % 对流传质系数(m/s)也沿用问题一
Ct_gt = 0.15;        % 烘干判据(kg/kg)
N     = 960;         % 参考域节点数 表面加密960才稳得住4位小数
T_max = 300*3600;    % 搜索上限(s)

%% --------2. 附件2的收缩半径 R(t) （论文5.4.1） ----------
D1 = readmatrix('../data/radius.csv');          % 时间(s)半径(cm)
Rt_tab = D1(:,1);
Rv      = D1(:,2)/100;
tRend   = Rt_tab(end);                         % 观测末端259200s也是R(t)的右端点
% 用PCHIP别用样条：样条会过冲 插出“先减后增”甚至负半径
Rpp = pchip(Rt_tab, Rv);
fprintf('== 收缩半径 ==\n  观测 0~%.0f s(%.0f h)，R 由 %.4f cm 收缩到 %.4f cm（%.1f%%）\n', ...
        tRend, tRend/3600, Rv(1)*100, Rv(end)*100, (1-Rv(end)/Rv(1))*100);

%% --------3. 附件1的烘房环境 （论文5.4.1） ----------
E = readmatrix('../data/env1.csv');             % 时间s温度°C水分浓度kg/kg
env.t = E(:,1);  env.T = E(:,2);  env.C = E(:,3);
env.tEnd = env.t(end);   env.ts = 7200;         % 4h之后没实测了 取末段1h中位数当平台值
tail = env.t >= env.t(end) - 3600;
env.thDry = median(env.T(tail));
env.CeDry = median(env.C(tail));
env.ppT = pchip(env.t, env.T);
env.ppC = pchip(env.t, env.C);
fprintf(' 阶段衔接 %.0f s，恒温段 Ta = %.4f °C，长期 Ce = %.5f kg/kg\n', env.ts, env.thDry, env.CeDry);

%% --------4. 附录4物性 （论文5.4.1） ----------
% rho cp k是湿基混合律Phi4(U) = exp(-0.30/U)写成导数样子界面通量才守恒
rho_f = @(U)    760 + 90*U;
cp_f  = @(U)    1850 + 2150*U./(1+U);
k_f   = @(U)    0.12 + 0.20*U./(1+U);
A4_f  = @(Th)   4.2e-4*exp(-3850./(Th + 273.15));    % D的温度部分 传进去的是°C里面换成K

%% --------5. 名义解：收缩 + 附录4 （论文5.4.2） ----------
g  = mesh_make(N);
q0 = struct('h',h, 'hm',hm, 'app4',true, 'shrink',true, 'shrinkS',1);   % 方案开关 见第6节
fprintf('\n== 求解（收缩 + 附录4）==\n');
sol = solve_case(q0, env, g, C0, th0, T_max, Rpp, tRend, R0);
[tstar, top] = drying_time(sol, g, Ct_gt, T_max);
fprintf('  阈值时刻 t* = %.6f h，工艺结束 t_op = %.4f h = %.0f s 约 %.2f 天\n', ...
        tstar/3600, top/3600, top, top/86400);
fprintf('  结束时未舍入最大含水率 %.9f kg/kg，此时 R = %.4f cm\n', ...
        maxU_at(sol, g, top), ppval(Rpp, min(top,tRend))*100);

%% --------6. 检验与亮点 （论文5.4.2）（受控对照那组同时是论文图20）----------
fprintf('\n== 检验 ==\n');
% A/B/D三个对照 和q0拼成2x2：固定/收缩x附录3/附录4
qA = struct('h',h,'hm',hm,'app4',false,'shrink',false,'shrinkS',1);
qB = struct('h',h,'hm',hm,'app4',true, 'shrink',false,'shrinkS',1);
qD = struct('h',h,'hm',hm,'app4',false,'shrink',true, 'shrinkS',1);
[~, topA] = drying_time(solve_case(qA,env,g,C0,th0,T_max,Rpp,tRend,R0), g, Ct_gt, T_max);
solB = solve_case(qB,env,g,C0,th0,T_max,Rpp,tRend,R0);   [~, topB] = drying_time(solB, g, Ct_gt, T_max);
[~, topD] = drying_time(solve_case(qD,env,g,C0,th0,T_max,Rpp,tRend,R0), g, Ct_gt, T_max);
fprintf('  受控对照烘干时间（h）：A 固定+附录3 %.4f | B 固定+附录4 %.4f | C 收缩+附录4 %.4f | D 收缩+附录3 %.4f\n', ...
        topA/3600, topB/3600, top/3600, topD/3600);
fprintf('  -> 物性改用附录4的贡献 %+.4f h，收缩的贡献 %+.4f h（在附录4物性下）\n', ...
        (topB-topA)/3600, (top-topB)/3600);
top4 = [topA topB top topD]/3600;            % 四个对照方案的烘干时长(h) 图20用
% 无交换对照h = hm = 0含水率该一直停在初值 查坐标变换和守恒
qU = struct('h',0,'hm',0,'app4',true,'shrink',true,'shrinkS',1);
sU = solve_case(qU, env, g, C0, th0, T_max, Rpp, tRend, R0);
Yu = deval(sU, [0 top/2 top]);
drift = max(abs(Yu(1:g.n,:) - C0), [], 'all');
fprintf('  无交换均匀场检验：最大漂移 %.3e kg/kg（应约0，验证坐标变换与守恒）\n', drift);
% 水分收支：平均含水率降了多少 就该等于表面累计排掉多少
tchk = (0:60:top)';
Yc   = deval(sol, tchk);
[~, Ce] = env_at(tchk, env);
wt   = AreaMean(Yc, g);
Rtc  = arrayfun(@(t) R_of(t,Rpp,tRend), tchk);
loss = cumtrapz(tchk, 2*hm./Rtc.*(Yc(g.n,:)' - Ce));   % 第n行是表面节点 排水折算到平均含水率
res  = max(abs((wt - wt(1)) + loss));
fprintf('  水分收支检验：|C_bar 变化 + 累计排水| 最大残差 %.3e kg/kg（相对 %.2e）\n', res, res/2.55);
Rall = arrayfun(@(t) R_of(t,Rpp,tRend), (0:600:tRend));
fprintf('  收缩半径检查：R 单调不增 %d，最小值 %.4f cm > 0\n', ...
        all(diff(Rall) <= 1e-12), min(Rall)*100);

% tau = int dt/R(t)^2是等效扩散时钟：半径缩小等于把内部扩散加快R0^2/R^2倍
ts_  = (0:60:top)';
Rt_  = arrayfun(@(t) R_of(t,Rpp,tRend), ts_);
tau  = cumtrapz(ts_, 1./Rt_.^2);
tau0 = ts_/R0^2;
kap  = tau./tau0;
fprintf('\n== 亮点分析 ==\n');
fprintf('  等效扩散时钟：结束时 tau_eff/tau_0 = %.3f -> 收缩把扩散时钟加快了 %.0f%%\n', ...
        kap(end), (kap(end)-1)*100);
Ss = [0.8 1.0 1.2];   topS = zeros(size(Ss));   % 收缩速率缩放±20%
for k = 1:numel(Ss)
    qk = q0;  qk.shrinkS = Ss(k);
    % 与 result4/表6 口径统一：取整分钟后的工艺结束时刻 t_op，而不是阈值时刻 t*
    [~, tk] = drying_time(solve_case(qk,env,g,C0,th0,T_max,Rpp,tRend,R0), g, Ct_gt, T_max);
    topS(k) = tk/3600;
end
fprintf('  收缩速率灵敏度：s=0.8 -> %.4f h，s=1.0 -> %.4f h，s=1.2 -> %.4f h\n', topS(1), topS(2), topS(3));
D3 = @(C,Tk) 2.4e-3*exp(-0.45./C).*exp(-3850./Tk);    % 附录3的D拿来跟附录4比
D4 = @(C,Tk) 4.2e-4*exp(-0.30./C).*exp(-3850./Tk);    % 附录4的D
Cc_ = [2.55 1.0 0.5 0.3 0.2 0.15 0.12 0.10 0.05];
fprintf('\n== 附录4 / 附录3 的扩散系数之比 D4/D3（同温）==\n');
fprintf('   C ='); fprintf('%9.2f', Cc_); fprintf('\n  比 ='); fprintf('%9.3f', D4(Cc_,323)./D3(Cc_,323)); fprintf('\n');
Cx = fzero(@(c) D4(c,323)/D3(c,323) - 1, 0.09);
fprintf('  两者相等的含水率 C* = %.4f kg/kg（低于烘干判据 0.15，故**全过程**附录4 都更慢）\n', Cx);
Tc = (0:300:top)';                              % 300s网格 下面算等效时间用
Rt2= arrayfun(@(t) R_of(t,Rpp,tRend), Tc);
tau= cumtrapz(Tc, R0^2./Rt2.^2);              % 等效时间tau = int R0^2/R^2 dt
Bi0 = hm*R0/D4(2.55, th0+273.15);                     % 传质毕渥数Bi_m = h_m*R/D
Bie = hm*R_of(top,Rpp,tRend)/D4(0.15, env.thDry+273.15);
fprintf('  Bi_m = h_m R/D：初始 %.1f，结束 %.1f（均>1，内部扩散主控 -> 表面项非瓶颈）\n', Bi0, Bie);
fprintf('  等效时间 tau(t_op)/t_op = %.3f，而实测烘干时间比 B/C = %.3f\n', tau(end)/top, topB/top);

%% --------7. 表6 与 result4.xlsx（距离为“到药材中心的真实距离”）----------
% 表6/result4 的列头是“到药材中心的距离”，给出的是当前真实距离 r 处的水分浓度，
% 对应参考坐标 ξ = r/R(t)。收缩后 r > R(t) 的位置已不在药材内，记“—”。
ro4 = (0:0.1:2)'/100;                                  % 真实距离 0, 0.1, ..., 2.0 cm
ro6 = (0:0.5:1.5)'/100;                                % 表6 距离列（2 cm 在收缩后已越界）
hh  = (6:6:54)';  hh = hh(hh*3600 < top);              % 每 6 h 一行，去掉超过 t_op 的
Rt6 = arrayfun(@(t) R_of(t,Rpp,tRend,1), [hh*3600; top]);
U6  = [fields_real(sol,g,Rpp,tRend,ro6,hh*3600)'; fields_real(sol,g,Rpp,tRend,ro6,top)'];
Us6 = [surface_at(sol,g,hh*3600); surface_at(sol,g,top)];
print_table6([hh; top/3600], U6, Us6, Rt6);

tq = (60:60:top)';
[Uq, Rtq] = fields_real(sol,g,Rpp,tRend,ro4,tq);       % 越界处为 NaN
Uq = Uq.';                                             % 统一为 [时刻 x 距离]
Us = surface_at(sol,g,tq);
hdr = [{'时间\到药材中心的距离'}, num2cell(0:0.1:2), {'药材表面'}];
C   = cell(numel(tq), numel(ro4)+2);
C(:,1) = num2cell(tq);
nOut = 0;
for j = 1:numel(ro4)
    for i = 1:numel(tq)
        if ro4(j) > Rtq(i) - 1e-9, C{i,1+j} = '—'; nOut = nOut + 1;
        else,                      C{i,1+j} = round(Uq(i,j),4);
        end
    end
end
for i = 1:numel(tq), C{i,end} = round(Us(i),4); end
if exist('../data/result4.xlsx','file'), delete('../data/result4.xlsx'); end
writecell([hdr; C], '../data/result4.xlsx', 'Sheet','Sheet1', 'Range','A1');
fprintf('\n== result4.xlsx ==\n  %d 行 x %d 列（真实距离 0~2.0 cm 共 21 列 + 药材表面），覆盖 60~%.0f s\n', ...
        numel(tq), numel(ro4)+2, top);
fprintf('  越界单元（r > R(t)，记 “—”）：%d / %d\n', nOut, numel(tq)*numel(ro4));
save('../data/result4.mat','g','env','q0','tstar','top','tq','Uq','Rtq','Us','top4','topS','-v7.3');

%% --------8. 出图 -> 图16 图17 图20 -----------
plot_q4(Rpp, tRend, top, top4, topS);   % 绘图代码在 plot_q4.m 里

%% ================= 局部函数 （论文5.4） =================
function g = mesh_make(N)
% 表面加密网格：xi_i = 1-(1-i/N)^1.5最外节点正好在xi=1
    xi = 1 - (1 - (1:N)'/N).^1.5;
    xf = [0; (xi(1:end-1) + xi(2:end))/2; 1];
    g.n = N;  g.xi = xi;  g.xf = xf;
    g.dc = diff(xi);   g.w = diff(xf.^2)/2;     % g.w是体积权重 正比于R^2
end

function J = jpattern(n)
% 雅可比稀疏结构：节点只跟左右邻居耦合U和Th也互相耦合
    e = ones(n,1);
    A = spones(spdiags([e e e], -1:1, n, n));
    J = [A A; A A] ~= 0;
end

function Rt = R_of(t, Rpp, tRend, s)
% 超出附件2覆盖范围就冻在末段值 再往外插值会不单调甚至给出负半径
% s是收缩速率的缩放因子s<1表示缩得更快
    if nargin < 4, s = 1; end
    Rt = ppval(Rpp, min(t/s, tRend));
end

function [Ta, Ce] = env_at(t, env)
% 温度7200s前插值 之后取平台 水分浓度过了tEnd也取平台
    t = t(:);
    Ta = zeros(size(t));   Ce = zeros(size(t));
    iT = t <= env.ts;     Ta(iT) = ppval(env.ppT, t(iT));   Ta(~iT) = env.thDry;
    iC = t <= env.tEnd;   Ce(iC) = ppval(env.ppC, t(iC));   Ce(~iC) = env.CeDry;
end

function dydt = q4_rhs(t, y, g, q, env, Rpp, tRend, R0)
% 参考域上的右端项 全文件最热的一段 通量都按“向外为正”取
    n  = g.n;
    U  = max(y(1:n), 1e-6);
    Th = y(n+1:2*n);
    Rt = R_of(t, Rpp, tRend, q.shrinkS);
    if ~q.shrink, Rt = R0; end

    if q.app4
        % 附录4物性 和第4节那五个句柄是同一套式子 内联省掉函数调用开销
        rho = 760 + 90*U;   cp = 1850 + 2150*U./(1+U);   kk = 0.12 + 0.20*U./(1+U);
        A4  = 4.2e-4*exp(-3850./((Th(1:end-1)+Th(2:end))/2 + 273.15));   % 界面温度取两端平均
        DD  = (4.2e-4*exp(-3850./(Th + 273.15))).*exp(-0.30./U);   % 节点扩散系数
        Dh  = 2*DD(1:end-1).*DD(2:end)./(DD(1:end-1) + DD(2:end));  % 界面扩散系数取调和平均
    else
        % 附录3：形式一样 系数和指数整套换掉
        rho = 650 + 128*U;  cp = 1450 + 2736*U./(1+U);   kk = 0.21 + 0.38*U./(1+U);
        A4  = 2.4e-3*exp(-3850./((Th(1:end-1)+Th(2:end))/2 + 273.15));
        DD  = (2.4e-3*exp(-3850./(Th + 273.15))).*exp(-0.45./U);
        Dh  = 2*DD(1:end-1).*DD(2:end)./(DD(1:end-1) + DD(2:end));
    end
    a  = rho.*cp;
    kh = 2*kk(1:end-1).*kk(2:end)./(kk(1:end-1) + kk(2:end));   % 界面导热取调和平均
    fac = g.xf(2:n)./g.dc;
    [Ta, Ce] = env_at(t, env);

    QC = [0; fac.*Dh.*(U(1:n-1) - U(2:n)); Rt*q.hm*(U(n)  - Ce)];
    QT = [0; fac.*kh.*(Th(1:n-1) - Th(2:n)); Rt*q.h *(Th(n) - Ta)];

    % 除以Rt^2*g.w：参考坐标下控制体体积正比于R^2半径一缩同样通量推得更快
    dU  = (QC(1:n) - QC(2:n+1))./(Rt^2*g.w);
    dTh = (QT(1:n) - QT(2:n+1))./(Rt^2*g.w.*a);
    dydt = [dU; dTh];
end

function sol = solve_case(q, env, g, C0, th0, T_max, Rpp, tRend, R0)
% q是方案开关 见第6节
    opt = odeset('RelTol',1e-8, 'AbsTol',[1e-10*ones(g.n,1); 1e-8*ones(g.n,1)], ...
                 'NonNegative',1:g.n, 'JPattern',jpattern(g.n), 'MaxStep',600);
    sol = ode15s(@(t,y) q4_rhs(t,y,g,q,env,Rpp,tRend,R0), [0 T_max], ...
                 [C0*ones(g.n,1); th0*ones(g.n,1)], opt);
end

function M = maxU_series(sol, g, tc)
% 每个时刻的全场最大含水率M(t)：U沿xi递减 最大在中心
    tc = tc(:)';  M = zeros(size(tc));  blk = 5000;
    for k = 1:blk:numel(tc)
        idx = k:min(k+blk-1, numel(tc));
        Y = deval(sol, tc(idx));
        M(idx) = max(Y(1:g.n, :), [], 1);
    end
end

function M = maxU_at(sol, g, t)
% 只问一个时刻的M
    M = maxU_series(sol, g, t);
end

function [tstar, top] = drying_time(sol, g, Ct_gt, T_max)
% 先60s粗扫框住根 再1s细化 最后二分到0.01s
% M(t)只能靠deval求值 全程1s扫太慢
% 取整分钟后再判一次 保证M(top)严格小于0.15
    tc = (0:60:T_max)';
    Mc = maxU_series(sol, g, tc);
    i0 = find(Mc <= Ct_gt, 1);
    if isempty(i0), error('搜索上限内未达标'); end
    tf = (max(tc(i0-1),0):1:tc(i0))';
    Mf = maxU_series(sol, g, tf);
    j0 = find(Mf <= Ct_gt, 1);
    lo = tf(max(j0-1,1));   hi = tf(j0);
    while hi - lo > 0.01
        mid = (lo+hi)/2;
        if maxU_at(sol,g,mid) <= Ct_gt, hi = mid; else, lo = mid; end
    end
    tstar = hi;
    top   = 60*ceil(tstar/60);
    if maxU_at(sol,g,top) >= Ct_gt, top = top + 60; end
end

function [Z, Rt] = fields_real(sol, g, Rpp, tRend, ro, tq)
% 真实径向距离 ro 处的水分浓度：ξ = r/R(t)；r > R(t) 处记 NaN（已不在药材内）
    Y  = deval(sol, tq(:)');
    n  = g.n;
    xi = 1 - (1 - (1:n)'/n).^1.5;
    Z  = nan(numel(ro), numel(tq));
    Rt = zeros(numel(tq),1);
    for k = 1:numel(tq)
        Rk = R_of(tq(k), Rpp, tRend, 1);   Rt(k) = Rk;
        xq = ro(:)/Rk;   in = xq <= 1 + 1e-12;
        Z(in,k) = interp1(xi, Y(1:n,k), min(xq(in),1), 'pchip');
    end
end

function Us = surface_at(sol, g, tq)
% 药材表面（ξ = 1）处的水分浓度：最外节点恰在表面
    Y  = deval(sol, tq(:)');
    Us = Y(g.n,:)';
end

function Z = fields_at(sol, xi0, tq)
% 把节点上的解插到给定的材料点xi0上 返回[材料点x时刻]
    Y  = deval(sol, tq(:)');
    n  = size(Y,1)/2;
    xi = 1 - (1 - (1:n)'/n).^1.5;                % 和mesh_make用同一个公式
    Z  = interp1(xi, Y(1:n,:), xi0, 'pchip');
end

function wt = AreaMean(Y, g)
% 截面平均含水率 按g.w加权 跟R(t)没关系
    U  = Y(1:g.n,:);
    wt = (2*(g.w' * U))';
end

function print_table6(hh, Z, Us, Rt)
% 按表6的版式打纯文本：距离列为真实距离；收缩后越界的列记 “—”
    fprintf('\n== 表6  药材烘干过程的水分浓度 (kg/kg) ==\n%10s', '时间/h');
    fprintf('%10.1f', 0, 0.5, 1, 1.5);
    fprintf('%12s%12s\n', '药材表面', '半径/cm');
    for j = 1:numel(hh)
        fprintf('%10.4f', hh(j));
        for c = 1:size(Z,2)
            if isnan(Z(j,c)), fprintf('%10s', '—'); else, fprintf('%10.4f', Z(j,c)); end
        end
        fprintf('%12.4f%12.4f\n', Us(j), Rt(j));
    end
end

