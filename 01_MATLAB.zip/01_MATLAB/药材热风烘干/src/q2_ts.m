%% 问题二 阶段切换时刻 t_s 的标定
% 【论文对应】5.2.1 节 出图8
% 用附件1的烘房温度实测序列 给t_s找三个能复核的数据依据

clc; clear; close all;
outdir = '../fig/';  if ~exist(outdir,'dir'); mkdir(outdir); end

%% --------0. 读附件1的烘房环境实测序列 （论文5.2.1） ------------------------------
E  = readmatrix('../data/env1.csv');     % 241x3无表头
te = E(:,1);                 % 时间轴(s) 0~14400
Te = E(:,2);                 % 烘房空气温度Ta (°C)
Tend = Te(end);              % 末值50.165°C
Amp  = Tend - Te(1);         % 总升幅22.165°C

%% --------1. 去噪与三种判据 （论文5.2.1） ------------------------------
% 平台段温度几乎不动 实测却在±0.24°C上下抖
% 直接拿原始数据算变化率会被噪声盖掉 先做5点滑动平均
Tes = movmean(Te,5);

% 三个判据：1) 一阶响应拟合出的时间常数tau
% 2) 去噪后10min的窗口增量 3) 与末值的偏差
f1 = @(p,x) p(1) - (p(1)-Te(1))*exp(-x/p(2));   % p(1)=Tinf p(2)=tau th0取实测首点 不参与拟合
o  = optimset('Display','off','TolX',1e-10,'TolFun',1e-10);
mm = te <= 10800;            % 只拟合前3h再往后噪声主导
p1 = fminsearch(@(p) sum((f1(p,te(mm))-Te(mm)).^2), [50 1800], o);
Tinf = p1(1);  tau = p1(2);  % Tinf = 50.370°C tau = 1914s ≈ 31.9min

dTw = nan(size(te));         % 10min增量 前10个点留NaN
for i = 11:numel(te)
    dTw(i) = Tes(i) - Tes(i-10);
end

dev = Te - Tend;

%% --------2. 判据汇总 （论文5.2.1） ------------------------------
fprintf('== 附件1 烘房温度概况 ==\n');
fprintf('  范围 %g~%g s (%.1f h)，步长 60 s；温度 %.3f -> %.3f °C\n', ...
    te(1), te(end), te(end)/3600, Te(1), Tend);
fprintf('  3 h 以后实测温度波动幅度约 ±%.2f °C(测量噪声)\n\n', ...
    (max(Te(te>10800))-min(Te(te>10800)))/2);   % 极差的一半 正好是上面去噪那条的理由

fprintf('== 判据1)  一阶响应 Ta = Tinf-(Tinf-th0)e^(-t/tau) ==\n');
fprintf('   拟合得 Tinf = %.3f °C，tau = %.0f s\n', Tinf, tau);
for k = [3 4 5]              % ktau的完成度1-e^(-k)只跟k有关3tau就走完95%了
    fprintf('   %dtau = %5.0f s (%.2f h)，理论完成度 %.1f%%\n', k, k*tau, k*tau/3600, 100*(1-exp(-k)));
end

fprintf('\n== 判据2)  去噪后 10 min 窗口增量 < 阈值(此后一直满足) ==\n');
for thr = [0.30 0.20 0.15]   % 三档阈值分别算出6360 / 11400 / 12900s
    tt = first_sustained(te, dTw, thr);
    if isnan(tt)
        fprintf('   < %.2f °C : 全时段未持续满足\n', thr);
    else
        fprintf('   < %.2f °C : t_s = %5.0f s (%.2f h) = %.2f tau，此时 Ta = %.3f °C\n', ...
            thr, tt, tt/3600, tt/tau, interp1(te,Te,tt));
    end
end

fprintf('\n== 判据3)  与末值(%.3f °C)偏差 < 阈值 ==\n', Tend);
for thr = [1.0 0.5]          % 阈值越紧切换越晚 末值那点偏差是0必然满足 不用判NaN
    tt = first_sustained(te, dev, thr);
    fprintf('   < %.2f °C : t_s = %5.0f s (%.2f h) = %.2f tau\n', thr, tt, tt/3600, tt/tau);
end

%% --------3. 几个代表时刻的数据表 （论文5.2.1） ------------------------------
% t_s 取稳定区间的起点：连续1200s内 |10min增量| ≤ 0.3 且 |与平台偏差| ≤ 0.3 的第一个窗口起点
plat = median(Te(te >= te(end)-3600));            % 末段1h中位数当平台温度
okW  = abs(dTw) <= 0.3 & abs(Tes-plat) <= 0.3;    % 前10点dTw是NaN 自动算不满足
tss  = NaN;
for i = 1:numel(te)-20
    if all(okW(i:i+20)), tss = te(i); break; end  % 21点 = 1200s
end
tlist = [1800 3600 5400 6600 7200 7656 8160 9000 10800 14400];   % 要逐行打印的时刻(s)
fprintf('\n== 关键时刻数据表 ==\n');
fprintf('%7s %10s %13s %13s %13s\n','t (h)','Ta (°C)','原始增量(°C)','去噪增量(°C)','升温完成度(%)');
for tt = tlist
    i = round(tt/60)+1;      % 在te里的下标round是照顾7656s这种不在网格上的时刻
    raw = Te(i) - Te(max(i-10,1));   % 原始增量 跟旁边的去噪增量一比就能看出去噪的效果
    fprintf('%7.2f %10.3f %13.3f %13.3f %13.1f\n', ...
        tt/3600, Te(i), raw, dTw(i), 100*(Te(i)-Te(1))/Amp);
end
i7 = round(tss/60)+1;
fprintf('\n== 建议取值 ==\n');
fprintf('  t_s = %.0f s (%.4f h) = %.2f tau：Ta = %.3f °C，升温完成度 %.1f%%，去噪增量 %.3f °C\n', ...
    tss, tss/3600, tss/tau, Te(i7), 100*(Te(i7)-Te(1))/Amp, dTw(i7));
fprintf('  (与 4tau = %.0f s 相差 %.0f s，对应环境温差仅 %.3f °C，对结果影响可忽略)\n', ...
    4*tau, abs(4*tau-tss), abs(interp1(te,Te,4*tau)-Te(i7)));

%% --------4. 绘图 -> 图8 ------------------------------
tt2 = (0:60:14400)';         % 拟合曲线自己一条时间轴 一眼能看出是模型算的
figure('Units','inches','Position',[1 1 6.2 5.0],'Color','w');   % 宽6.2in差不多A4正文栏宽

subplot(2,1,1);
plot(te/3600, Te,'-','Color',[0.75 0.75 0.75],'LineWidth',1.0); hold on;   % 原始数据浅灰 当背景
plot(te/3600, Tes,'b-','LineWidth',1.4);
plot(tt2/3600, f1(p1,tt2),'--','Color',[0.33 0.63 0.44],'LineWidth',1.3);
plot(tss/3600, Te(i7),'ro','MarkerFaceColor','r','MarkerSize',5);          % 切换点
xline(tss/3600,'r--','LineWidth',1.2);
ylim([27 52]);               % 上下各留一点空 曲线不贴边框
xlabel('t (h)'); ylabel('T_a (\circC)'); grid on;
lg = legend('实测','5 min 滑动平均','一阶响应拟合',sprintf('t_s = %.2f h', tss/3600),'Location','southeast');
set(lg,'FontSize',7.5,'ItemTokenSize',[12 7]);

subplot(2,1,2);
plot(te/3600, dTw,'b-','LineWidth',1.3); hold on;
yline(0.3,'r--','LineWidth',1.2);   % 判据2) 的阈值线 曲线掉下去之后再没抬上来就是t_s
xline(tss/3600,'r--','LineWidth',1.2);
xlabel('t (h)'); ylabel('10 min 温度增量 (\circC)'); grid on;
ylim([-0.3 2.5]);            % 上界有意截掉开头那段很大的增量（600s处约4.67°C）
lg = legend('去噪后增量','阈值 0.3 °C',sprintf('t_s = %.2f h', tss/3600),'Location','northeast');
set(lg,'FontSize',7.5,'ItemTokenSize',[12 7]);

% 字体统一 得放在画完图之后 导出之前
setfont(gcf);
exportgraphics(gcf,[outdir '问题二_阶段切换标定_烘房温度变化特征与t_s.pdf'],'ContentType','vector');
fprintf('\n已保存图: 问题二_阶段切换标定_烘房温度变化特征与t_s.pdf\n');

%% --------局部函数：首次「从这一刻起后面一直满足」的时刻 （论文5.2.1） ------
% 从某时刻起后面每个点都满足才算数 中间抬回阈值上面就作废 只看第一次会被噪点推早
function tt = first_sustained(te, x, thr)
    tt = NaN;
    n  = numel(x);
    for i = 1:n
        if all(abs(x(i:n)) < thr)
            tt = te(i);  return;
        end
    end
end
