%% 问题一 预热平衡阶段(0~1800s) 药材温度与水分浓度求解
% 【论文对应】5.1 节 出表1表2 图6图7 和 result1.xlsx
% 一维径向有限体积+ ode15s主算用pchip插值
clc; clear; close all;

outdir = '../fig/';  if ~exist(outdir,'dir'); mkdir(outdir); end
if ~exist('../data','dir'); mkdir('../data'); end

%% --------1. 读取数据与模型参数 （论文5.1.1） ------------------------------
E  = readmatrix('../data/env1.csv');
t = E(:,1);
Temp = E(:,2);                 % 烘房温度(°C)
Ce = E(:,3);                 % 烘房水分浓度(kg/kg)
rou = 820;                   % 药材密度(kg/m^3)
c_p  = 2600;                  % 比热容(J/(kg*K))
k   = 0.36;                  % 导热系数(W/(m*K))常数 所以温度和水分解耦
h   = 25;                    % 对流换热系数(W/(m^2*K))
hm  = 8e-7;                  % 对流传质系数(m/s) h管热hm管湿
R   = 0.02;                  % 药材半径(m)画图出表才乘100换cm
Temp_s  = 28;                    % 初始温度(°C)
C0  = 2.55;                  % 初始干基含水率(kg/kg)
Df  = @(c) 7e-9*exp(-0.89./c);   % 水分扩散系数经验式(m^2/s)
r2f   = @(y,yh) 1 - sum((y(:)-yh(:)).^2)/sum((y(:)-mean(y(:))).^2);
rmsef = @(y,yh) sqrt(mean((y(:)-yh(:)).^2));

%% --------2. 环境输入：pchip 插值 与 双指数拟合 （论文5.1.1） ------------------------------
% 附件1只有每60s一个点 先插成连续函数给ode15s用
% 两条路都算pchip保形忠实实测当主算 双指数压成5个参数好写论文 再对照一遍看结论变不变
TaP = @(tt) interp1(t,Temp,tt,'pchip');   % 形参别叫t会跟上面的时间列t撞名 一撞就静默传错
CeP = @(tt) interp1(t,Ce,tt,'pchip');
opt = optimset('MaxFunEvals',4e5,'MaxIter',4e5,'TolX',1e-12,'TolFun',1e-12,'Display','off');  % fminsearch选项 迭代上限放大 免得提前收工
m2  = @(p,x) p(1)-p(2).*exp(-x./p(3))-p(4).*exp(-x./p(5));  % p = [a,b,t1,c,t2]
pT  = fminsearch(@(p)sum((m2(p,t)-Temp).^2),[50,12,500,10,2500],opt);  % 初值按实测曲线的量级给
pC  = fminsearch(@(p)sum((m2(p,t)-Ce).^2),[0.05,0.012,500,0.015,3000],opt);  % 浓度是0.0x的小量 跟温度差三个数量级 初值不能共用
TaF = @(t) m2(pT,t);
CeF = @(t) m2(pC,t);
ts = (0:1:1800)';
fprintf('== 环境拟合(双指数) ==\n');
fprintf('  温度: R2=%.6f  RMSE=%.5f degC\n', r2f(Temp,m2(pT,t)), rmsef(Temp,m2(pT,t)));  % 这里量的是“拟合模型vs实测数据”
fprintf('  湿度: R2=%.6f  RMSE=%.6f\n', r2f(Ce,m2(pC,t)), rmsef(Ce,m2(pC,t)));
fprintf('  同一时刻 pchip 与拟合的差: max|dT|=%.5f  max|dC|=%.6f\n', ...
    max(abs(TaP(ts)-TaF(ts))), max(abs(CeP(ts)-CeF(ts))));

%% --------3. 有限体积离散 + ode15s求解 （论文5.1.2） ------------------------------
N = 321;  tspan = (0:1:1800)';               % 控制体数 取81的话t=100s的表面值会错到小数点后第3位
[V,A,dr,rv] = fv_geom(N,R);
y0 = [Temp_s*ones(N+1,1); C0*ones(N+1,1)];       % 前N+1个是温度 后N+1个是含水率
o1 = odeset('RelTol',1e-9,'AbsTol',1e-11);   % 结果要4位小数 默认1e-3太松

[~,YP] = ode15s(@(t,y) fv_rhs(t,y,N,V,A,dr,rou,c_p,k,h,hm,Df,TaP,CeP), tspan, y0, o1);
[~,YF] = ode15s(@(t,y) fv_rhs(t,y,N,V,A,dr,rou,c_p,k,h,hm,Df,TaF,CeF), tspan, y0, o1);

ro  = (0:0.001:R)';
ToP = interp1(rv,YP(:,1:N+1)',ro)';    CoP = interp1(rv,YP(:,N+2:end)',ro)';
ToF = interp1(rv,YF(:,1:N+1)',ro)';    CoF = interp1(rv,YF(:,N+2:end)',ro)';

fprintf('\n== 两种环境输入下解的比较 ==\n');
fprintf('  T: R2=%.8f  RMSE=%.3e  max|d|=%.3e degC\n', r2f(ToP,ToF), rmsef(ToP,ToF), max(abs(ToP(:)-ToF(:))));
fprintf('  C: R2=%.8f  RMSE=%.3e  max|d|=%.3e\n', r2f(CoP,CoF), rmsef(CoP,CoF), max(abs(CoP(:)-CoF(:))));

%% --------3b. 环境输入处理结果导出 （论文5.1.1） ----------
envFile = '../data/问题一_环境处理_插值与拟合.xlsx';
if exist(envFile,'file'), delete(envFile); end  % 先删旧的 不然上次跑的表会残留
hdr1 = {'时间/s','烘房温度 Ta/(°C)','烘房水分浓度 Ce/(kg/kg)'};
writecell(hdr1, envFile, 'Sheet','附件1原始数据', 'Range','A1');
writematrix([t Temp Ce], envFile, 'Sheet','附件1原始数据', 'Range','A2');
writecell(hdr1, envFile, 'Sheet','pchip插值', 'Range','A1');
writematrix([ts TaP(ts) CeP(ts)], envFile, 'Sheet','pchip插值', 'Range','A2');
writecell(hdr1, envFile, 'Sheet','双指数拟合', 'Range','A1');
writematrix([ts TaF(ts) CeF(ts)], envFile, 'Sheet','双指数拟合', 'Range','A2');
info = [{'双指数模型  y = a - b·exp(-t/t1) - c·exp(-t/t2)'}, cell(1,5);
        {'量','a','b','t1','c','t2'};
        [{'烘房温度 Ta'},   num2cell(pT)];
        [{'烘房水分浓度 Ce'}, num2cell(pC)]];
writecell(info, envFile, 'Sheet','拟合参数', 'Range','A1');
good = [{'量','R²（双指数）','RMSE（双指数）','max|pchip−拟合|'};
        {'烘房温度 Ta',    r2f(Temp,m2(pT,t)), rmsef(Temp,m2(pT,t)), max(abs(TaP(ts)-TaF(ts)))};
        {'烘房水分浓度 Ce', r2f(Ce,m2(pC,t)), rmsef(Ce,m2(pC,t)), max(abs(CeP(ts)-CeF(ts)))}];
writecell(good, envFile, 'Sheet','拟合优度', 'Range','A1');
cmp = [{'时间/s','max|ΔT|/(°C)','max|ΔC|/(kg/kg)'};
       num2cell([ts, max(abs(ToP-ToF),[],2), max(abs(CoP-CoF),[],2)])];
writecell(cmp, envFile, 'Sheet','两种环境下的解差异', 'Range','A1');
fprintf('\n已保存 %s（6 个工作表）\n', envFile);

%% --------4~5. 模型检验：网格收敛 与 整体守恒 （论文5.1.3） ------------------------------
Vt  = sum(V);                                % 所有控制体体积之和 拿来当平均的分母
CPn = YP(:,N+2:end);   TPn = YP(:,1:N+1);
rC  = -(2*hm/R)*(CoP(:,end) - CeP(tspan));   % 理论右端：内部界面通量两两抵消 只剩表面一项
rT  =  2*h/(rou*c_p*R)*(TaP(tspan) - ToP(:,end));
fprintf('\n== 积分守恒恒等式 ==\n');
fprintf('  水分残差=%.3e(量级%.3e)   温度残差=%.3e(量级%.3e)\n', ...
    max(abs(gradient((CPn*V)/Vt,1)-rC)), max(abs(rC)), ...
    max(abs(gradient((TPn*V)/Vt,1)-rT)), max(abs(rT)));

%% --------6. 模型检验三：与解析级数解对比 （论文5.1.3） ------------------------------
% 变环境温度没有现成解析解 就把空气温度换成28->50的阶跃 这时有经典级数解
Tinf = 50;  Bi = h*R/k;                      % 阶跃工况空气温度(°C) Bi≈1.39
fb  = @(l) l.*besselj(1,l) - Bi*besselj(0,l);  % 特征方程 l*J1(l) = Bi*J0(l) 正根就是特征值
xsc = linspace(1e-6,160,60000);  fv_ = fb(xsc);  % 起点取1e-6是躲开l=0附近
idx = find(fv_(1:end-1).*fv_(2:end) < 0);    % 相邻两点异号 中间就夹着一个根
lam = zeros(min(40,numel(idx)),1);           % 只取前40个 高阶模态衰减太快 算了也没用
for i = 1:numel(lam)
    lam(i) = fzero(fb,[xsc(idx(i)) xsc(idx(i)+1)]);
end
Cn  = 2*besselj(1,lam)./(lam.*(besselj(0,lam).^2 + besselj(1,lam).^2));
[~,YV] = ode15s(@(t,y) fv_rhs(t,y,N,V,A,dr,rou,c_p,k,h,hm,Df,@(t)Tinf*ones(size(t)),CeP), tspan, y0, o1);
Tv  = interp1(rv,YV(:,1:N+1)',ro)';
Fo  = k/(rou*c_p)*tspan/R^2;  rs = ro/R;      % Fo = k*t/(rou*c_p*R^2) 1800s时约0.76 热还没烤透
Tana = zeros(numel(tspan),numel(ro));
for i = 1:numel(tspan)
    Tana(i,:) = Tinf + (Temp_s-Tinf)*sum(Cn.*besselj(0,lam*rs').*exp(-lam.^2*Fo(i)),1);
end
fprintf('\n== 与解析级数解对比(阶跃环境 28->50 °C) ==\n');
for tt = [100 600 1800]
    fprintf('  t=%4d s : max|dT|=%.3e  R2=%.8f\n', tt, ...
        max(abs(Tv(tt+1,:)-Tana(tt+1,:))), r2f(Tv(tt+1,:),Tana(tt+1,:)));
end

%% --------7. 表1表2 与 result1.xlsx ------------------------------
tp = [100 300 600 900 1200 1500 1800];  idxo = [1 6 11 16 21];  % 表里要印的7个时刻(s)和5个半径的列号
fprintf('\n== 表1 温度(degC)，r = 0/0.5/1/1.5/2 cm ==\n');
for j = 1:numel(tp), fprintf('%5d | %s\n', tp(j), sprintf('%9.4f',ToP(tp(j)+1,idxo))); end
fprintf('\n== 表2 水分浓度(kg/kg)，r = 0/0.5/1/1.5/2 cm ==\n');
for j = 1:numel(tp), fprintf('%5d | %s\n', tp(j), sprintf('%9.4f',CoP(tp(j)+1,idxo))); end

hdr = [{'时间\到药材中心的距离'}, num2cell(0:0.1:2)];
ttv = (1:1800)';
writecell(hdr, '../data/result1.xlsx','Sheet','温度','Range','A1');
writematrix([ttv, round(ToP(2:end,:),4)], '../data/result1.xlsx','Sheet','温度','Range','A2');
writecell(hdr, '../data/result1.xlsx','Sheet','水分浓度','Range','A1');
writematrix([ttv, round(CoP(2:end,:),4)], '../data/result1.xlsx','Sheet','水分浓度','Range','A2');
save('../data/result1.mat','tspan','ro','ToP','CoP','ToF','CoF');
fprintf('\n已保存 ../data/result1.xlsx\n');

%% --------8. 绘图 -> 图6图7 ------------------------------
plot_q1(ro, ToP, CoP, outdir);   % 绘图代码在 plot_q1.m 里


%% --------局部函数：控制体几何 （论文5.1.2） ------------------------------
% 节点放在控制体中心 最内 最外各只有半个厚度 所以V(1) V(N+1)单独写
function [V,A,dr,r] = fv_geom(N,R)
    dr = R/N;  r = (0:N)'*dr;
    V = zeros(N+1,1);  A = zeros(N+1,1);
    V(1) = pi*(dr/2)^2;  A(1) = pi*dr;
    for m = 2:N
        V(m) = 2*pi*dr^2*(m-1);  A(m) = 2*pi*(m-0.5)*dr;
    end
    V(N+1) = pi*dr^2*(N-0.25);  A(N+1) = 2*pi*R;
end

%% --------局部函数：有限体积右端项 （论文5.1.2） ------------------------------
% 给ode15s反复调用的dy/dt：内部导热+表面第三类边界+内部水分扩散
function dy = fv_rhs(t,y,N,V,A,dr,rho,cp,k,h,hm,Df,Ta,Ce)
    T = y(1:N+1);  C = y(N+2:2*N+2);
    Ta_ = Ta(t);   Ce_ = Ce(t);

    Q = -k*A(1:N).*(T(2:end)-T(1:end-1))/dr;
    dT = zeros(N+1,1);   dT(1) = -Q(1);
    for m = 2:N, dT(m) = Q(m-1) - Q(m); end
    dT(N+1) = Q(N) + A(N+1)*h*(Ta_ - T(N+1));
    dT = dT./(rho*cp*V);

    Dn = Df(C);
    Dh = 2*Dn(1:end-1).*Dn(2:end)./(Dn(1:end-1)+Dn(2:end));  % 界面相当于两个热阻串联 取调和平均
    J  = -Dh.*A(1:N).*(C(2:end)-C(1:end-1))/dr;
    dC = zeros(N+1,1);   dC(1) = -J(1);
    for m = 2:N, dC(m) = J(m-1) - J(m); end
    dC(N+1) = J(N) + A(N+1)*hm*(Ce_ - C(N+1));
    dC = dC./V;
    dy = [dT; dC];
end
