%% 问题三：全空间含水率达标定烘干时间（有限体积法）
% 【论文对应】5.3.1 与 5.3.2 节 出表5 和 result3.xlsx
% 沿用问题二那套径向模型一路积分 积到处处达标 输出表5和result3.xlsx
clc; clear; close all;
if ~exist('../fig','dir'), mkdir('../fig'); end  % 放图的地方
if ~exist('../data','dir'), mkdir('../data'); end  % 放数据的地方

%% --------1. 工况参数 （论文5.3.1） ------------------------------------
R     = 0.02;         % 药材半径(m)
th0   = 28;           % 初始温度(°C)
C0    = 2.55;         % 初始干基含水率(kg/kg)
h     = 25;           % 对流换热系数(W/(m^2*K))附录3没给 沿用问题一
hm    = 8e-7;         % 对流传质系数(m/s)沿用问题一
Ct_gt = 0.15;         % 烘干判据(kg/kg)
N     = 960;          % 径向控制体数
T_max = 100*3600;     % 搜索上限(s)只是圈个边界 不是烘干时间

%% --------2. 环境条件 （论文5.3.1） --------
% env和g都是整组数组 整组一起传 懒得拆
E = readmatrix('../data/env1.csv');
env.t    = E(:,1);  env.T = E(:,2);  env.C = E(:,3);
env.tEnd = env.t(end);                    % 不能直接拿插值外推
env.ts   = 7200;                          % 阶段衔接时刻2h之前温度用实测
tail     = env.t >= env.t(end) - 3600;    % 最后1h观测当末段平台
env.thDry = median(env.T(tail));
env.CeDry = median(env.C(tail));
env.ppT  = pchip(env.t, env.T);
env.ppC  = pchip(env.t, env.C);           % 浓度一直用实测到4h末
fprintf('== 环境条件 ==\n');
fprintf('  阶段衔接 t_s = %.0f s，恒温段 Ta = %.4f °C，长期 Ce = %.5f kg/kg\n', ...
        env.ts, env.thDry, env.CeDry);

%% --------3. 物性经验公式与扩散势（附录3） （论文5.3.1） ------------------
rho_f = @(C)    650 + 128*C;                       % 表观密度(kg/m^3)
cp_f  = @(C)    1450 + 2736*C./(C+1);              % 比热容(J/(kg*K))
k_f   = @(C)    0.21 + 0.38*C./(C+1);              % 导热系数(W/(m*K))
A_f   = @(th)   2.4e-3*exp(-3850./(th + 273.15));  % 温度因子A (m^2/s)这里th是摄氏度 里面得换成热力学温度
% 离散口径（与论文5.3节一致）：热量通量中界面热导率取相邻控制体的调和平均；
% 水分通量按“界面扩散系数 × 相邻节点浓度差 / 节点距离”计算，
% 界面扩散系数取相邻两节点的调和平均；本问不引入扩散势。
D_f   = @(C,th) A_f(th).*exp(-0.45./C);            % 扩散系数 D(C,T)=A(T)*exp(-0.45/C)

%% --------4. 控制体网格与求解 （论文5.3.2） ------------------------------
g   = mesh_make(N, R);
ro  = (0:0.1:2)'/100;                      % 输出位置0~2cm每0.1cm一档
y0  = [th0*ones(g.n,1); C0*ones(g.n,1)];   % 温度在前 含水率在后 得跟fvm_rhs里的切片对上 别弄反
opt = odeset('RelTol',1e-8, 'AbsTol',[1e-8*ones(g.n,1); 1e-10*ones(g.n,1)], ...
             'NonNegative',(g.n+1):(2*g.n), 'JPattern',jpattern(g.n), 'MaxStep',300);
fprintf('\n== 求解 ==\n  N = %d，节点 %.4f~%.4f mm（最外节点即表面）\n', g.n, min(g.r)*1e3, max(g.r)*1e3);
tic
sol = ode15s(@(t,y) fvm_rhs(t,y,g,env,rho_f,cp_f,k_f,A_f,D_f,R,h,hm), [0 T_max], y0, opt);
fprintf('  积分区间 0~%.0f h，用时 %.1f s，自适应步数 %d\n', T_max/3600, toc, numel(sol.x));

%% --------5. 烘干时间：阈值时刻与整分钟工艺时刻 （论文5.3.2） --------------
% 判据取全场最大含水率 不是只盯中心那一个点 免得漏掉局部还湿着的地方
tstar = find_ts(sol, g, Ct_gt, T_max);
top   = 60*ceil(tstar/60);
if maxC_at(sol, g, top) >= Ct_gt
    top = top + 60;   % t*正好落在整分钟上时那一刻刚好0.15不满足严格小于 往后推一分钟
end
Mc = maxC_at(sol, g, tstar);
fprintf('\n== 烘干时间 ==\n');
fprintf('  阈值时刻 t*   = %.6f h = %.3f s，此时未舍入最大含水率 %.9f kg/kg\n', ...
        tstar/3600, tstar, Mc);
fprintf('  工艺结束 t_op = %.4f h = %.0f s 约 %.4f 天，未舍入最大含水率 %.9f kg/kg（严格 < %.2f）\n', ...
        top/3600, top, top/86400, maxC_at(sol, g, top), Ct_gt);

%% --------6. 水分收支检验 （论文5.3.2） -------------------
tchk  = (0:60:top)';                       % 核查收支用60s的栅格够了
Ychk  = deval(sol, tchk);
[~, Ce_t] = env_at(tchk, env);
meanC = (2/R^2)*(g.w' * Ychk(g.n+1:end,:))';                % 体平均含水率
loss  = (2*hm/R)*cumtrapz(tchk, Ychk(2*g.n,:)' - Ce_t);     % 表面累计流失量
% 残差要是突然变大 一般就是通量符号写反了 或者权算错了
fprintf('\n== 水分收支检验 ==\n  最大残差 %.3e kg/kg（相对 %.2e）\n', ...
        max(abs(meanC - C0 + loss)), max(abs(meanC - C0 + loss))/C0);

%% --------7. 表5 ----------------------------------------
hh  = (6:6:54)';                        % 6~54h的整点 本模型57.5h就结束了60h那档没必要
Yh  = devel_fields(sol, g, hh*3600, ro)';
Yop = devel_fields(sol, g, top, ro)';   % 末行是烘干结束时刻
print_table5([hh; top/3600], [Yh; Yop]);

%% --------8. result3.xlsx（表5的完整版） -------------------------------
fprintf('\n== result3.xlsx ==\n');
tq  = (60:60:top)';                     % 每60s一行 从60s开始（模板就这规矩）
Cq  = zeros(numel(tq), numel(ro));      % 先开好内存 循环里再填
blk = 20000;                            % 分块deval省内存
tic
for k = 1:blk:numel(tq)
    idx = k:min(k+blk-1, numel(tq));
    Cq(idx,:) = devel_fields(sol, g, tq(idx), ro)';
end
hdr = [{'时间\到药材中心的距离'}, num2cell(0:0.1:2)];
if exist('../data/result3.xlsx','file'), delete('../data/result3.xlsx'); end
writecell(hdr, '../data/result3.xlsx', 'Sheet','Sheet1', 'Range','A1');
writematrix([tq round(Cq,4)], '../data/result3.xlsx', 'Sheet','Sheet1', 'Range','A2');
fprintf('  水分浓度表 %d 行 x 21 列，覆盖 60~%.0f s，写出用时 %.1f s\n', numel(tq), top, toc);
save('../data/result3.mat', 'g', 'env', 'top', 'tstar', 'tq', 'Cq', 'ro');   % 存没舍入的Cq给画图用

%% ================= 局部函数 （论文5.3） =================
% 环境查询：温度过了7200s就取恒温段 浓度前4h走实测插值
function [Ta, Ce] = env_at(t, env)
    t  = t(:);
    Ta = zeros(size(t));   Ce = zeros(size(t));
    iT = t <= env.ts;      Ta(iT) = ppval(env.ppT, t(iT));   Ta(~iT) = env.thDry;
    iC = t <= env.tEnd;    Ce(iC) = ppval(env.ppC, t(iC));   Ce(~iC) = env.CeDry;
end

% 建径向网格 节点半径往表面加密 最外那个节点正好落在R上
function g = mesh_make(N, R)
    rn = R*(1 - (1 - (1:N)'/N).^1.5);
    rf = [0; (rn(1:end-1) + rn(2:end))/2; R];   % 界面取相邻节点中点 两头正好是0和R
    g.n  = N;   g.R = R;
    g.r  = rn;
    g.rf = rf;
    g.dc = diff(rn);
    g.dr = diff(rf);
    g.w  = diff(rf.^2)/2;   % 就是 int r dr 公共的 2pi 会被约掉
end

% 雅可比的稀疏结构 不告诉ode15s它就只会稠密差分 慢得多
function J = jpattern(n)
    e = ones(n,1);
    A = spones(spdiags([e e e], -1:1, n, n));   % 每个节点只跟左右邻居耦合
    J = [A A; A A] ~= 0;
end

% 右端项：每个控制体做收支平衡 界面那份通量对左右两块一正一负 正好抵消
function dydt = fvm_rhs(t, y, g, env, rho_f, cp_f, k_f, A_f, D_f, R, h, hm)
    n  = g.n;
    th = y(1:n);
    C  = max(y(n+1:2*n), 1e-6);   % 夹个下限 试探步里C太小exp(-0.45/C)会炸
    rho = rho_f(C);   cp = cp_f(C);   kk = k_f(C);
    kh  = 2*kk(1:end-1).*kk(2:end)./(kk(1:end-1) + kk(2:end));   % 界面导热取调和平均：左右两个半控制体相当于串联 热阻相加
    DD  = D_f(C, th);                                            % 节点扩散系数
    Dh  = 2*DD(1:end-1).*DD(2:end)./(DD(1:end-1) + DD(2:end));   % 界面扩散系数取调和平均
    [Ta, Ce] = env_at(t, env);
    % 第一项是圆心 通量恒为0最后一项是表面 第三类边界直接代进去
    QT = [0;  kh.*g.rf(2:n).*(th(1:n-1) - th(2:n))./g.dc;  R*h *(th(n) - Ta)];
    QC = [0;  Dh.*g.rf(2:n).*(C(1:n-1) - C(2:n))./g.dc;   R*hm*(C(n) - Ce)];
    dth  = (QT(1:n) - QT(2:n+1))./(g.w.*rho.*cp);
    dC   = (QC(1:n) - QC(2:n+1))./g.w;   % 分母不乘密度：rho是表观密度 塞进去干物质就不守恒了
    dydt = [dth; dC];
end

% 全场最大含水率 所有节点一起取max
function M = maxC(Mx, g)
    M = max(Mx(g.n+1:2*g.n, :), [], 1);   % 前N行是温度 别混进来
end

% 某个时刻的全场最大含水率
function M = maxC_at(sol, g, t)
    M = maxC(deval(sol, t), g);
end

% 一串时刻的最大含水率 分块算省deval开销
function M = maxC_series(sol, g, tc)
    tc = tc(:)';   M = zeros(size(tc));   blk = 5000;
    for k = 1:blk:numel(tc)
        idx = k:min(k+blk-1, numel(tc));
        M(idx) = maxC(deval(sol, tc(idx)), g);
    end
end

% 阈值时刻：60s粗扫-> 1s细化->二分到0.01s
function ts = find_ts(sol, g, Ct_gt, T_max)
    tc = (0:60:min(T_max, 110*3600))';
    Mc = maxC_series(sol, g, tc);
    i0 = find(Mc <= Ct_gt, 1);
    if isempty(i0), error('在 %.0f h 搜索上限内未达标。', T_max/3600); end
    tf = (max(tc(i0-1),0):1:tc(i0))';
    Mf = maxC_series(sol, g, tf);
    j0 = find(Mf <= Ct_gt, 1);
    lo = tf(max(j0-1,1));   hi = tf(j0);
    while hi - lo > 0.01
        mid = (lo + hi)/2;
        if maxC_at(sol, g, mid) <= Ct_gt, hi = mid; else, lo = mid; end
    end
    ts = hi;
end

% 把节点解插到题目要的位置上 最外节点本来就在表面r = 0那头用中心对称补
function Z = devel_fields(sol, g, t, ro)
    n  = g.n;
    Y  = deval(sol, t(:)');
    Cn = Y(n+1:2*n, :);
    rn = [0; g.r];
    Zn = [Cn(1,:); Cn];
    Z  = interp1(rn, Zn, ro, 'pchip');
end

% 按表5的版式打印：行是时刻(h)列是距中心0/0.5/1/1.5/2cm
function print_table5(hh, Z)
    idx = [1 6 11 16 21];
    fprintf('\n== 表5  药材烘干过程中的水分浓度 (kg/kg) ==\n%10s', '时间/h');
    fprintf('%10.4f', 0, 0.5, 1, 1.5, 2);
    fprintf('\n');
    for j = 1:numel(hh)
        fprintf('%10.4f', hh(j));
        fprintf('%10.4f', Z(j, idx));
        fprintf('\n');
    end
end
