%% D 对含水率与温度的灵敏度：附录3 vs 附录4（同起点对比）
% 【论文对应】6.2 节 出图19
% 从同一个起点把C扰动±20% T扰动±5%看两套D公式的相对变化
clc; clear; close all;
if ~exist('../fig','dir'), mkdir('../fig'); end  
FR = setfont();          % 只是取回字体名
color = [0.16 0.42 0.58; 0.75 0.15 0.20; 0.00 0.55 0.35; 0.90 0.55 0.10];  % 准备的4条线的颜色：深蓝色 暗红色 墨绿色还有橙黄色
f  = figure('Units','inches','Position',[1 1 7.4 2.8],'Color','w','ToolBar','none');  
tl = tiledlayout(f,1,2,'Padding','compact','TileSpacing','compact');  

% ------------- (a) 含水率 -----------------
axis1 = nexttile(tl); hold(axis1,'on');  
rdc  = (-20:0.5:20)/100;                     % 扰动±20%
line_form = {'-','--'};            % 初期C0 = 2.55用实线 末期C0 = 0.15用虚线
l = {};  
h_A  = gobjects(0);  
C0_v = [2.55 0.15];   bv = [0.45 0.30];   T0_v = [301.15 323.15];  
for i = 1:2  
    C0_0 = C0_v(i);
    for j = 1:2  
        b  = bv(j);
        y  = 100*(exp(-b*(1./(C0_0*(1+rdc)) - 1/C0_0)) - 1);  % D的相对变化
        h_A(end+1) = plot(axis1, rdc*100, y, line_form{i}, 'Color', color(j,:), 'LineWidth',1.5);  % 要换回百分数的横坐标
        l{end+1} = sprintf('附录%d（C_0 = %.2f）', 2+j, C0_0);  
    end
end
yline(axis1, 0, ':', 'Color',[0.5 0.5 0.5], 'LineWidth',0.9);  % 先是零基准线
text(axis1, -18.5, 12, '初期：D 几乎不受含水率影响', 'FontName',FR, 'FontSize',7.8, 'Color',[0.35 0.35 0.35]);
text(axis1, -18.5, -62, '末期：同样 ±20% 可让 D 变 ±40%~65%', 'FontName',FR, 'FontSize',7.8, 'Color',[0.35 0.35 0.35]);
xlabel(axis1,'含水率相对变化 \DeltaC/C (%)', 'FontName',FR);
ylabel(axis1,'扩散系数相对变化 \DeltaD/D_0 (%)', 'FontName',FR);
xticks(axis1, -20:10:20);  ylim(axis1,[-75 85]);  % 两栏共用160个百分点的量程 方便能够横着来比斜率
legend(axis1, h_A, l, 'Location','northwest', 'FontSize',7.5, 'NumColumns',2, 'FontName',FR);  
set(axis1,'FontSize',8.5,'Box','off','TickDir','out','LineWidth',0.5,'FontName',FR);  % 去上右边框 刻度朝外
grid(axis1,'on');  set(axis1,'GridColor',[0.88 0.88 0.88],'GridAlpha',0.9);

% ----------------- (b) 温度 -------------
axis2 = nexttile(tl); hold(axis2,'on');
rdt = (-5:0.25:5)/100;  % ±5% 300K附近≈±15K
hB = gobjects(0);  legB = {};
for i = 1:2  % 两个起始温度28 °C 50 °C
    T0 = T0_v(i);  
    % 跟左栏一个式子 只是把b换成活化能3850 K把C0换成T0 T必须用热力学温度
    y  = 100*(exp(-3850*(1./(T0*(1+rdt)) - 1/T0)) - 1);    
    hB(end+1) = plot(axis2, rdt*100, y, line_form{i}, 'Color', color(i+1,:), 'LineWidth',1.6);  % 线色错开一位 别和左栏撞色
    legB{end+1} = sprintf('T_0 = %.0f K（%.0f °C）', T0, T0-273.15);  
end
yline(axis2, 0, ':', 'Color',[0.5 0.5 0.5], 'LineWidth',0.9);  % 零基准线
% 右图两条曲线就差起点温度：两套附录活化能都是3850 K同一个T0下两条完全重合
text(axis2, -4.7, -66, '±5% ≈ ±15 K；附录3 与附录4 完全重合（活化能同为 3850 K）', ...
     'FontName',FR, 'FontSize',7.8, 'Color',[0.35 0.35 0.35]);
xlabel(axis2,'温度相对变化 \DeltaT/T (%)（开尔文）', 'FontName',FR);
ylabel(axis2,'扩散系数相对变化 \DeltaD/D_0 (%)', 'FontName',FR);
xticks(axis2, -5:2.5:5);  ylim(axis2,[-75 85]);  % 与左栏同量程
legend(axis2, hB, legB, 'Location','northwest', 'FontSize',7.5, 'FontName',FR);  
set(axis2,'FontSize',8.5,'Box','off','TickDir','out','LineWidth',0.5,'FontName',FR);
grid(axis2,'on');  set(axis2,'GridColor',[0.88 0.88 0.88],'GridAlpha',0.9);

setfont(f);             
exportgraphics(f,'../fig/附录3与4_D对C与T的灵敏度对比.pdf','ContentType','vector');  % 生成矢量PDF
fprintf('已保存 附录3与4_D对C与T的灵敏度对比.pdf\n'); close(f);
