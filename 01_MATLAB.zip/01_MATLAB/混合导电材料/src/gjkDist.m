%% ======================= 问题 1 =======================
%% gjkDist.m —— 两根平底直圆柱间的最短距离（GJK 精确算法）
%  ------------------------------------------------------------
%  方法：凸集距离 GJK：迭代找两圆柱支撑函数差集的最近原点，
%    终止判据 |v|^2 - v·w <= eps（无进展即收敛）；圆柱支撑函数闭式给出。
%  用途：Q1 的"精细判定"——胶囊近似（轴线距-2r）只是下界，
%    端面构型误差可达 r=30nm，导通与否必须用本函数精确距离与 1.8nm 比较。
%  依赖：无（纯几何）。
%  输出：d = 最短距离；p1、p2 = 两圆柱上的最近点对。
%% ============================================================

function d = gjkDist(cyl1, cyl2, tol, maxIter)
%GJKDIST  两个平底圆柱体之间的精确最短距离（GJK 算法，支撑函数闭式）。
%   d = gjkDist(cyl1, cyl2)
%   cyl: 结构体 struct('c',3x1中心,'u',3x1单位轴,'h',半高,'r',半径)
%   d  = 0 表示两圆柱相交/贯穿（题目允许介质相互重叠）。
%   GJK 在闵可夫斯基差 C1⊖C2 上找离原点最近的凸集点；圆柱的支撑点落在
%   端面边缘（圆环）或侧面，闭式给出。自动处理侧面-侧面 / 侧面-端面 /
%   端面-端面 / 圆环接触及退化构型（平行轴、共线、h=0、相交）。

if nargin < 3, tol = 1e-12; end
if nargin < 4, maxIter = 200; end

sup = @(dvec) cylSupport(cyl1, dvec) - cylSupport(cyl2, -dvec);

d = cyl2.c - cyl1.c;
if norm(d) < 1e-30
    d = [1; 0; 0];
end
sim = {sup(d)};
d = -sim{1};

for it = 1:maxIter
    dd = d'*d;
    if dd < tol*tol
        d = 0;
        return;
    end
    p = sup(d);
    % 收敛判据（GJK 距离版，原论文）：|v|^2 - v·w <= eps，即
    % 支撑点 w 在方向 d 上的投影不再超过当前最近点 v（v = -d）：
    % |d|^2 + w·d <= eps  =>  无法再靠近，v 即最近点。
    % 注意：不能用相交判据 w·d < 0，否则会提前终止给出错误距离。
    if dd + p'*d <= 1e-14 * max(1, dd)
        d = sqrt(dd);
        return;
    end
    sim{end+1} = p; %#ok<AGROW>
    [q, sim] = reduceSimplex(sim);
    if isempty(q)              % 原点在四面体内 -> 相交
        d = 0;
        return;
    end
    d = -q;
end
d = sqrt(d'*d);
end

% ----------------------------------------------------------------------
function p = cylSupport(cyl, dvec)
% 平底圆柱在方向 dvec 的支撑点：端面边缘（圆环）或端面内点。
ud = dvec'*cyl.u;
if abs(ud) > 1e-30
    p = cyl.c + sign(ud)*cyl.h*cyl.u;
else
    p = cyl.c;
end
du = dvec - ud*cyl.u;
nd = norm(du);
if nd > 1e-30
    p = p + cyl.r*du/nd;
end
end

% ----------------------------------------------------------------------
function [q, feat] = closestPtTriangle(p, a, b, c)
% 点 p 到三角形 abc 的最近点（Ericson 的 ClosestPtPointTriangle）。
% feat: 0-顶点a, 1-顶点b, 2-边ab, 3-顶点c, 4-边ac, 5-边bc, 6-内部
ab = b - a; ac = c - a; ap = p - a;
d1 = ab'*ap; d2 = ac'*ap;
if d1 <= 0 && d2 <= 0, q = a; feat = 0; return; end
bp = p - b;
d3 = ab'*bp; d4 = ac'*bp;
if d3 >= 0 && d4 <= d3, q = b; feat = 1; return; end
vc = d1*d4 - d3*d2;
if vc <= 0 && d1 >= 0 && d3 <= 0
    v = d1/(d1 - d3);
    q = a + v*ab; feat = 2; return;
end
cp = p - c;
d5 = ab'*cp; d6 = ac'*cp;
if d6 >= 0 && d5 <= d6, q = c; feat = 3; return; end
vb = d5*d2 - d1*d6;
if vb <= 0 && d2 >= 0 && d6 <= 0
    w = d2/(d2 - d6);
    q = a + w*ac; feat = 4; return;
end
va = d3*d6 - d5*d4;
if va <= 0 && (d4 - d3) >= 0 && (d5 - d6) >= 0
    w = (d4 - d3)/((d4 - d3) + (d5 - d6));
    q = b + w*(c - b); feat = 5; return;
end
denom = 1/(va + vb + vc);
v = vb*denom; w = vc*denom;
q = a + ab*v + ac*w; feat = 6;
end

% ----------------------------------------------------------------------
function [q, sim] = reduceSimplex(sim)
% Johnson 距离子算法：把 simplex 缩减到离原点最近的子特征。
% 返回最近点 q 与缩减后的 simplex；原点在四面体内部时返回 q = []。
k = numel(sim);
if k == 1
    q = sim{1};
    return;
end
if k == 2
    a = sim{1}; b = sim{2};
    ab = b - a;
    t = -(a'*ab)/(ab'*ab);
    if t <= 0
        q = a; sim = {a};
    elseif t >= 1
        q = b; sim = {b};
    else
        q = a + t*ab;           % 最近点在边内部，保留两个端点
    end
    return;
end
if k == 3
    [q, feat] = closestPtTriangle([0;0;0], sim{1}, sim{2}, sim{3});
    switch feat
        case 0, sim = {sim{1}};
        case 1, sim = {sim{2}};
        case 2, sim = {sim{1}, sim{2}};
        case 3, sim = {sim{3}};
        case 4, sim = {sim{1}, sim{3}};
        case 5, sim = {sim{2}, sim{3}};
        case 6, sim = {sim{1}, sim{2}, sim{3}};
    end
    return;
end
% k == 4
a = sim{1}; b = sim{2}; c = sim{3}; dd = sim{4};
if tetraContainsOrigin(a, b, c, dd)
    q = [];
    return;
end
best = inf;
faces = {[a b c], [a c dd], [a dd b], [b dd c]};
for f = 1:4
    fa = faces{f}(:,1); fb = faces{f}(:,2); fc = faces{f}(:,3);
    [qq, feat] = closestPtTriangle([0;0;0], fa, fb, fc);
    if qq'*qq < best
        best = qq'*qq; q = qq;
        switch feat
            case 0, keep = {fa};
            case 1, keep = {fb};
            case 2, keep = {fa fb};
            case 3, keep = {fc};
            case 4, keep = {fa fc};
            case 5, keep = {fb fc};
            case 6, keep = {fa fb fc};
        end
    end
end
sim = keep;
end

% ----------------------------------------------------------------------
function inside = tetraContainsOrigin(a, b, c, d)
% 原点是否在四面体 abcd 内（含边界）：四个有向体积同号（或均为0）。
s0 = det([b c d]);
s1 = det([a d c]);
s2 = det([a b d]);
s3 = det([a c b]);
eps0 = 1e-14;
pos = any([s0 s1 s2 s3] > eps0);
neg = any([s0 s1 s2 s3] < -eps0);
inside = ~(pos && neg);
end
