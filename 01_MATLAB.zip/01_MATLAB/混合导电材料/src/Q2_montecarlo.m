%% ======================= 问题 2 =======================
%% Q2_montecarlo.m —— 体积分数 0.5/0.6/0.7/1.0% 的导通概率主程序
%  ------------------------------------------------------------
%  方法：增量投掷蒙特卡洛——每次实验逐根投掷介质A（轴心均匀+方向球面
%    均匀+截断折回，每段=独立介质），记录首次导通根数 nCross（提前终止）；
%    由介质同分布性：P(φ) = P(nCross <= N(φ))，一次实验给出所有体积分数。
%  对比：同实现同并行下实测"传统逐档独立抽样"时长（runTraditional），
%    展示增量法节省算力；另有交叉验证与 95% Wilson 置信区间。
%  依赖：runSequence.m、runTraditional.m、cylDistLE.m（同目录）。
%  运行：直接运行 Q2_montecarlo（可用 M=xxx 覆盖实验次数，默认 5000）。
%  输出：概率表（CSV）+ 多张 PDF 图（fig_Q2_*.pdf）+ fig_Q2_data.mat。
%% ============================================================

clc;
R = 30; H = 5000; HW = 5000; TOL = 1.8;
V_A   = pi * R^2 * H;
V_box = (2*HW)^3;
phi   = [0.005 0.006 0.007 0.010];        % 体积分数
if ~exist('M','var'), M = 5000; end       % 实验次数（可用 M=xxx 覆盖）
if ~exist('K','var'), K = 1000; end       % 每实验投掷根数上限（覆盖最大 N=707）
nw = 8;
Ns = round(phi * V_box / V_A);            % 各档介质数（四舍五入）

% 字体：单一字体 'Hiragino Sans GB'——数字与汉字同字体，基线必然一致（不依赖
% 字体回退，任何 PDF 阅读器渲染结果相同）；所有文字元素已显式指定 FontName，
% 避免默认字体（LucidaGrande 等）混入导致基线错乱
fn = 'Hiragino Sans GB';

fprintf('%s\n', repmat('=', 1, 76));
fprintf(' 问题2：增量投掷蒙特卡洛（M=%d 次实验，每次最多投 %d 根介质A）\n', M, K);
fprintf('%s\n', repmat('=', 1, 76));

% ---- 数据缓存（M/K 不变时复用，调图无需重算） ----
dataFile = 'fig_Q2_data.mat';
reuse = false;
if exist(dataFile,'file')
    S = load(dataFile);
    if isfield(S,'M') && S.M == M && S.K == K
        nCross = S.nCross; reuse = true;
        fprintf(' 检测到已有结果 %s（M=%d, K=%d），直接复用，跳过计算。\n', dataFile, M, K);
    end
end

% ---- 并行池 ----
if isempty(gcp('nocreate'))
    parpool('local', nw);
end

% ---- 增量投掷法主循环（计时 tInc） ----
if ~reuse
    t0 = tic;
    nCross = zeros(M, 1);
    parfor m = 1:M
        rng(2026 + m);                    % 每实验独立种子（可复现）
        nCross(m) = runSequence(K, R, H, HW, TOL);
    end
    tInc = toc(t0);
    fprintf(' 增量投掷法完成：%.0f s\n', tInc);
else
    tInc = S.tInc;
    fprintf(' 增量投掷法（缓存）：%.0f s\n', tInc);
end

% ---- 传统逐档独立抽样计时（同实现同并行，公平对比） ----
if ~reuse || ~isfield(S,'tTrad')
    tTrad = 0;
    for g = 1:4
        tg = tic;
        parfor m = 1:M
            rng(30000 + g*100000 + m);
            runTraditional(Ns(g), R, H, HW, TOL);
        end
        tTrad = tTrad + toc(tg);
        fprintf('   传统法 φ=%.2f%%（N=%d）：%.0f s\n', phi(g)*100, Ns(g), toc(tg));
    end
    save(dataFile,'nCross','M','K','tInc','tTrad');
    fprintf(' 传统逐档独立抽样合计：%.0f s\n', tTrad);
else
    tTrad = S.tTrad;
    fprintf(' 传统逐档独立抽样（缓存）：%.0f s\n', tTrad);
end

% ---- 各体积分数的概率与 95% Wilson 置信区间 ----
P = zeros(4,1); CIlo = zeros(4,1); CIhi = zeros(4,1);
z = 1.96;
fprintf('%s\n', repmat('-', 1, 76));
for g = 1:4
    k = sum(nCross <= Ns(g));
    p = k / M;
    den = 1 + z^2/M;
    ctr = (p + z^2/(2*M)) / den;
    wid = z * sqrt((p*(1-p) + z^2/(4*M)) / M) / den;
    P(g) = p; CIlo(g) = max(0, ctr - wid); CIhi(g) = min(1, ctr + wid);
    fprintf(' 体积分数 %.2f%%（N=%4d 根）：导通 %5d/%d 次，概率 = %.4f（95%%CI [%.4f, %.4f]）\n', ...
        phi(g)*100, Ns(g), k, M, p, CIlo(g), CIhi(g));
end
fprintf(' 首次导通根数：中位数 = %s，最小 = %d（%d 次实验中 %d 次在 %d 根内未导通）\n', ...
    num2str(median(nCross)), min(nCross), M, sum(isinf(nCross)), K);

% ---- 交叉验证：传统逐档独立抽样（同精度 M 次/档） ----
if ~reuse || ~isfield(S,'P_trad')
    P_trad = zeros(4,1); CIloT = zeros(4,1); CIhiT = zeros(4,1);
    for g = 1:4
        tg = tic; kk = 0;
        parfor m = 1:M
            rng(50000 + g*100000 + m);
            if runTraditional(Ns(g), R, H, HW, TOL), kk = kk + 1; end
        end
        p = kk/M;
        den = 1 + z^2/M; ctr = (p + z^2/(2*M))/den;
        wid = z*sqrt((p*(1-p) + z^2/(4*M))/M)/den;
        P_trad(g) = p; CIloT(g) = max(0,ctr-wid); CIhiT(g) = min(1,ctr+wid);
        fprintf('   传统独立抽样 φ=%.2f%%：p=%.4f [%.4f, %.4f]（%.0f s）\n', ...
            phi(g)*100, p, CIloT(g), CIhiT(g), toc(tg));
    end
    if reuse
        save(dataFile,'P_trad','CIloT','CIhiT','-append');
    else
        save(dataFile,'nCross','M','K','tInc','tTrad','P_trad','CIloT','CIhiT');
    end
else
    P_trad = S.P_trad; CIloT = S.CIloT; CIhiT = S.CIhiT;
    fprintf(' 传统独立抽样（缓存）：p=[%s]\n', sprintf('%.4f ', P_trad));
end
fprintf('%s\n', repmat('-', 1, 76));
fprintf('交叉验证（M=%d）：增量投掷法 vs 传统逐档独立抽样\n', M);
fprintf(' 体积分数 | 增量法 p | 传统法 p | |Δp| | 95%%CI 是否重叠\n');
for g = 1:4
    overlap = ~(CIhi(g) < CIloT(g) || CIhiT(g) < CIlo(g));
    fprintf('  %.2f%%  | %.4f  | %.4f  | %.4f | %s\n', ...
        phi(g)*100, P(g), P_trad(g), abs(P(g)-P_trad(g)), string(overlap));
end

% ---- 达到目标精度（95%%CI 半宽 <= 0.02）所需总试验次数 ----
% 传统逐档独立抽样：每档独立收敛到半宽 0.02，总次数 = 各档之和；
% 增量投掷法：一次实验共享 4 档，只需最坏档的次数。
wTarget = 0.02;
Mg = zeros(4,1);
for g = 1:4
    p = P(g);
    fun = @(Mm) (z*sqrt((p*(1-p) + z^2/(4*Mm))/Mm)/(1 + z^2/Mm)) - wTarget;
    Mg(g) = ceil(fzero(fun, [20 50000]));
end
trialsTrad = sum(Mg);      % 传统逐档独立：约 4600 次
trialsInc  = max(Mg);      % 增量共享：约 2400 次（与 ChatGPT 序贯法的 2400 一致）

% ---- 完整 p(N) 曲线（nCross 经验分布） ----
nc = nCross; nc(isinf(nc)) = K + 1;
cnt = histcounts(nc, 0.5:1:(K+1.5));
pN = cumsum(cnt) / M;
Naxis = 1:K;
phiaxis = Naxis * V_A / V_box * 100;

% ================= 图A：蒙特卡洛模拟（逐档独立抽样）4 点概率折线图 =================
figT = figure('Color','w','Position',[80 80 1040 680]);
axT = axes('Parent',figT,'FontName',fn);
hold(axT,'on'); grid(axT,'on'); axT.GridAlpha = 0.16; axT.GridColor = [0.55 0.6 0.65];
plot(axT, phi*100, P_trad, '-', 'Color',[0.09 0.33 0.72], 'LineWidth',2.2);
errorbar(axT, phi*100, P_trad, P_trad-CIloT, CIhiT-P_trad, 'd', ...
    'Color',[0.78 0.22 0.16], 'MarkerFaceColor',[0.95 0.60 0.08], ...
    'MarkerEdgeColor',[0.5 0.28 0.05], 'MarkerSize',11, 'LineWidth',1.5, 'CapSize',8);
for g = 1:4
    text(axT, phi(g)*100, P_trad(g) + 0.06, sprintf('%.3f', P_trad(g)), ...
        'FontSize',11, 'Color',[0.55 0.18 0.05], 'FontWeight','bold', ...
        'FontName',fn, 'HorizontalAlignment','center');
    text(axT, phi(g)*100 + 0.03, P_trad(g) - 0.025, sprintf('N=%d', Ns(g)), ...
        'FontSize',10, 'Color',[0.35 0.4 0.45], ...
        'FontName',fn, 'HorizontalAlignment','left', 'VerticalAlignment','middle');
end
xlim(axT,[0.35 1.15]); ylim(axT,[0 1.14]);
xlabel(axT,'介质A体积分数 (%)','FontWeight','bold','FontSize',14,'FontName',fn);
ylabel(axT,'微构体导通概率 p','FontWeight','bold','FontSize',14,'FontName',fn);
title(axT,sprintf('问题二：蒙特卡洛模拟的导通概率（M=%d，误差棒 = 95%% Wilson 置信区间）',M), ...
    'FontWeight','bold','FontSize',15,'FontName',fn);
set(axT,'FontSize',12);
legend(axT,{'概率折线','导通概率 ± 95%CI'}, ...
    'Location','northwest','FontSize',11,'Box','on','FontName',fn);
axT.Toolbar.Visible = 'off';
exportgraphics(figT,'fig_Q2_traditional.pdf','ContentType','vector');
fprintf('蒙特卡洛模拟 4 点图已保存为 fig_Q2_traditional.pdf（矢量 PDF）。\n');

% ================= 图1：问题二 4 个体积分数的导通概率折线图 =================
cBlue  = [0.09 0.33 0.72];
cOrange= [0.95 0.60 0.08];
cRed   = [0.78 0.22 0.16];
fig1 = figure('Color','w','Position',[80 80 1040 680]);
ax1 = axes('Parent',fig1,'FontName',fn);
hold(ax1,'on'); grid(ax1,'on'); ax1.GridAlpha = 0.16; ax1.GridColor = [0.55 0.6 0.65];
plot(ax1, phi*100, P, '-', 'Color',cBlue, 'LineWidth',2.2);               % 折线
errorbar(ax1, phi*100, P, P-CIlo, CIhi-P, 'd', ...
    'Color',cRed, 'MarkerFaceColor',cOrange, ...
    'MarkerEdgeColor',[0.5 0.28 0.05], 'MarkerSize',11, 'LineWidth',1.5, 'CapSize',8);
for g = 1:4
    text(ax1, phi(g)*100, P(g) + 0.06, sprintf('%.3f', P(g)), ...
        'FontSize',11, 'Color',[0.55 0.18 0.05], 'FontWeight','bold', ...
        'FontName',fn, 'HorizontalAlignment','center');
    text(ax1, phi(g)*100 + 0.03, P(g) - 0.025, sprintf('N=%d', Ns(g)), ...
        'FontSize',10, 'Color',[0.35 0.4 0.45], ...
        'FontName',fn, 'HorizontalAlignment','left', 'VerticalAlignment','middle');
end
xlim(ax1,[0.35 1.15]); ylim(ax1,[0 1.14]);
xlabel(ax1,'介质A体积分数 (%)','FontWeight','bold','FontSize',14,'FontName',fn);
ylabel(ax1,'微构体导通概率 p','FontWeight','bold','FontSize',14,'FontName',fn);
title(ax1,sprintf('问题二：本文方法（增量投掷蒙特卡洛）的导通概率\nM=%d，误差棒 = 95%% Wilson 置信区间',M), ...
    'FontWeight','bold','FontSize',15,'FontName',fn);
set(ax1,'FontSize',12);
legend(ax1,{'概率折线','导通概率 ± 95%CI'}, ...
    'Location','northwest','FontSize',11,'Box','on','FontName',fn);
ax1.Toolbar.Visible = 'off';
exportgraphics(fig1,'fig_Q2_probability.pdf','ContentType','vector');

% ================= 图：新方法完整导通概率曲线（每个投掷根数一个概率点） =================
figC = figure('Color','w','Position',[80 80 1060 700]);
axC = axes('Parent',figC,'FontName',fn);
hold(axC,'on'); grid(axC,'on'); axC.GridAlpha = 0.16; axC.GridColor = [0.55 0.6 0.65];
plot(axC, phiaxis, pN(1:K), '-', 'Color',cBlue, 'LineWidth',2.2);         % 完整经验曲线
errorbar(axC, phi*100, P, P-CIlo, CIhi-P, 'd', ...
    'Color',cRed, 'MarkerFaceColor',cOrange, ...
    'MarkerEdgeColor',[0.5 0.28 0.05], 'MarkerSize',10, 'LineWidth',1.4, 'CapSize',7);
for g = 1:4
    text(axC, phi(g)*100, P(g) + 0.045, sprintf('%.3f', P(g)), ...
        'FontSize',10.5, 'Color',[0.55 0.18 0.05], 'FontWeight','bold', ...
        'FontName',fn, 'HorizontalAlignment','center');
end
xlim(axC,[0.3 1.45]); ylim(axC,[0 1.05]);
xlabel(axC,'介质A体积分数 (%)','FontWeight','bold','FontSize',14,'FontName',fn);
ylabel(axC,'微构体导通概率 p','FontWeight','bold','FontSize',14,'FontName',fn);
title(axC,sprintf('本文方法（增量投掷蒙特卡洛）的完整导通概率曲线\n每个投掷根数对应一个概率估计点，M=%d，误差棒 = 95%% Wilson 置信区间',M), ...
    'FontWeight','bold','FontSize',14.5,'FontName',fn);
set(axC,'FontSize',12);
legend(axC,{'p(φ) 经验曲线','四个给定体积分数点（±95%CI）'}, ...
    'Location','northwest','FontSize',11,'Box','on','FontName',fn);
axC.Toolbar.Visible = 'off';
exportgraphics(figC,'fig_Q2_probability_curve.pdf','ContentType','vector');
fprintf('完整概率曲线图已保存为 fig_Q2_probability_curve.pdf（矢量 PDF）。\n');


% ================= 图2b：双指标成本对比 =================
figB = figure('Color','w','Position',[120 120 840 700]);
axB = axes('Parent',figB,'FontName',fn);
hold(axB,'on'); grid(axB,'on'); axB.GridAlpha = 0.16;
cTrad = [0.55 0.63 0.72]; cInc = [0.95 0.62 0.10];
pctT = (1 - tInc/tTrad)*100;
pctN = (1 - trialsInc/trialsTrad)*100;
xpos = [1 1.72 3.05 3.77];
vals = [100, 100*tInc/tTrad, 100, 100*trialsInc/trialsTrad];
b1 = bar(axB, [1 3.05], [100 100], 0.62, 'FaceColor',cTrad, 'EdgeColor','none');
b2 = bar(axB, [1.72 3.77], [vals(2) vals(4)], 0.62, 'FaceColor',cInc, 'EdgeColor','none');
% 柱顶实际数值
labs = {sprintf('%.0f s',tTrad), sprintf('%.0f s',tInc), ...
        sprintf('%.0f 次',trialsTrad), sprintf('%.0f 次',trialsInc)};
clab = [0.35 0.4 0.45; 0.7 0.35 0.05; 0.35 0.4 0.45; 0.7 0.35 0.05];
for k = 1:4
    text(axB, xpos(k), vals(k)+2.5, labs{k}, 'HorizontalAlignment','center', ...
        'FontSize',11,'FontWeight','bold','Color', clab(k,:), 'FontName',fn);
end
% 组标签与降低幅度
text(axB, 1.36, 128, '运行时长', 'HorizontalAlignment','center','FontSize',12, ...
    'FontWeight','bold','Color',[0.2 0.23 0.28], 'FontName',fn);
text(axB, 3.41, 128, sprintf('试验次数\n(半宽≤0.02)'), 'HorizontalAlignment','center','FontSize',11, ...
    'FontWeight','bold','Color',[0.2 0.23 0.28], 'FontName',fn);
text(axB, 1.36, 142, sprintf('降低 %.0f%%', pctT), 'HorizontalAlignment','center', ...
    'FontSize',13.5,'FontWeight','bold','Color',[0.85 0.3 0.1], 'FontName',fn);
text(axB, 3.41, 142, sprintf('降低 %.0f%%', pctN), 'HorizontalAlignment','center', ...
    'FontSize',13.5,'FontWeight','bold','Color',[0.85 0.3 0.1], 'FontName',fn);
ylim(axB,[0 160]);
set(axB,'XTick',[],'YTickLabel',{});
ylabel(axB,'相对量（传统 = 100%）','FontWeight','bold','FontSize',12,'FontName',fn);
title(axB,sprintf('相同精度下的成本对比：运行时长（8 核实测）与达到 95%%CI 半宽≤0.02 所需试验次数',M), ...
    'FontWeight','bold','FontSize',12,'FontName',fn);
% 底部优势说明
str = {sprintf('· 运行时长：%.0f s → %.0f s（减少 %.0f%%）', tTrad, tInc, pctT), ...
       sprintf('· 试验次数：%.0f → %.0f（减少 %.0f%%；逐档独立序贯时总次数可达近万次）', ...
           trialsTrad, trialsInc, pctN), ...
       '· 一次实验共享全部体积分数，额外给出完整 p(φ) 曲线（第三问直接复用）'};
text(axB, 0.03, 0.03, str, 'Units','normalized','FontSize',10.5, ...
    'VerticalAlignment','bottom','Color',[0.22 0.25 0.30], 'FontName',fn);
legend(axB,[b1 b2],{'传统逐档独立抽样','增量投掷法（本文）'}, ...
    'Location','north','FontSize',10.5,'Box','on','FontName',fn);
axB.Toolbar.Visible = 'off';
exportgraphics(figB,'fig_Q2_method_cost.pdf','ContentType','vector');

% ================= 图：方法一致性验证（增量投掷 vs 传统独立抽样） =================
figV = figure('Color','w','Position',[80 80 1040 680]);
axV = axes('Parent',figV,'FontName',fn);
hold(axV,'on'); grid(axV,'on'); axV.GridAlpha = 0.16;
plot(axV, phi*100, P_trad, '--', 'Color',[0.10 0.35 0.75], 'LineWidth',1.8);
errorbar(axV, phi*100, P_trad, P_trad-CIloT, CIhiT-P_trad, 'o', ...
    'Color',[0.10 0.35 0.75], 'MarkerFaceColor',[0.55 0.72 0.92], ...
    'MarkerEdgeColor',[0.1 0.25 0.5], 'MarkerSize',9, 'LineWidth',1.4, 'CapSize',7);
plot(axV, phi*100, P, '-', 'Color',[0.85 0.30 0.15], 'LineWidth',2.0);
errorbar(axV, phi*100, P, P-CIlo, CIhi-P, 'd', ...
    'Color',[0.85 0.30 0.15], 'MarkerFaceColor',[0.95 0.62 0.10], ...
    'MarkerEdgeColor',[0.5 0.28 0.05], 'MarkerSize',10, 'LineWidth',1.4, 'CapSize',7);
for g = 1:4
    text(axV, phi(g)*100 - 0.01, max(P(g),P_trad(g)) + 0.035, ...
        sprintf('Δ=%.4f', abs(P(g)-P_trad(g))), ...
        'HorizontalAlignment','right','FontSize',10.5,'FontWeight','bold', ...
        'Color',[0.25 0.28 0.32],'FontName',fn);
end
xlim(axV,[0.35 1.15]); ylim(axV,[0 1.16]);
xlabel(axV,'介质A体积分数 (%)','FontWeight','bold','FontSize',14,'FontName',fn);
ylabel(axV,'微构体导通概率 p','FontWeight','bold','FontSize',14,'FontName',fn);
title(axV,sprintf('新方法验证：增量投掷法与传统逐档独立抽样结果一致（M=%d）',M), ...
    'FontWeight','bold','FontSize',14.5,'FontName',fn);
set(axV,'FontSize',12);
legend(axV,{'传统逐档独立抽样','','增量投掷法（本文）',''}, ...
    'Location','northwest','FontSize',11,'Box','on','FontName',fn);
axV.Toolbar.Visible = 'off';
exportgraphics(figV,'fig_Q2_validation.pdf','ContentType','vector');
fprintf('一致性验证图已保存为 fig_Q2_validation.pdf（矢量 PDF）。\n');

plot_Q2_convergence(fn);
fprintf('\n完成：问题二结果图（建议展示顺序）：\n  fig_Q2_traditional.pdf（蒙特卡洛模拟）\n  fig_Q2_probability.pdf（本文增量投掷法）\n  fig_Q2_validation.pdf（两方法对比与验证）\n  fig_Q2_method_cost.pdf（计算成本对比）\n  fig_Q2_convergence_compare.pdf（收敛次数对比）\n');
