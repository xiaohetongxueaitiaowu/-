%% ======================= 问题 4 =======================
%% Q4_GA.m —— 遗传算法求解同一优化问题（与网格法对比验证）
%  ------------------------------------------------------------
%  方法：决策变量 N_A∈[0,600]（整数），成本为适应度（与 Q4_optimize
%    相同的 90% 分位→N_B→成本 口径）；锦标赛选择 + 算术交叉 +
%    高斯变异（幅度随代数衰减）+ 精英保留；适应度缓存复用。
%  公平对比：GA 与网格法最优方案均用 Mf=1000 重评（同口径比较）。
%  依赖：runSequenceQ4.m、cylDistLE.m（同目录）。
%  运行：直接运行 Q4_GA。
%  输出：两种方法对比表；fig_Q4_GA_*.pdf；fig_Q4_GA_data.mat。
%% ============================================================

clc;
%% ============ 1. 参数（与 Q4_optimize.m 完全一致） ============
RA = 30; H = 5000; RB = 200; HW = 5000; TOL = 1.8;
V_A = pi*RA^2*H;  V_B = (4/3)*pi*RB^3;
c_A = 1.05 * V_A/1e9;      % 元/个（nm^3 -> um^3）
c_B = 0.05 * V_B/1e9;
NBMAX = 25000;
Nmin = 0; Nmax = 600;
if ~exist('M','var'),  M  = 300; end    % GA 每次适应度评估的蒙特卡洛样本数
if ~exist('Mf','var'), Mf = 1000; end   % 决赛重评样本数（与网格法细筛一致）
if ~exist('pop','var'), pop = 16; end
if ~exist('maxGen','var'), maxGen = 26; end
nElite = 2; kTour = 3;
pc = 0.90; pm = 0.18; sigma0 = 60;   % 交叉概率 / 变异概率 / 初始变异步长
if ~exist('staleLim','var'), staleLim = 8; end  % 最优成本连续 staleLim 代无改善(相对0.5%)则提前停止
fn = 'Hiragino Sans GB';
rng(2026);                         % 可复现
fprintf('c_A = %.6f 元/个，c_B = %.6f 元/个，M=%d\n\n', c_A, c_B, M);

%% ============ 2. 载入网格法结果（对比基准） ============
S = load('fig_Q4_data.mat');
NAg = S.NA_all; nBg = S.nB_all; Cg = S.C_all;
NAg_best = S.NA_best; nBg_best = S.nB_best; Cg_best = S.C_best;
% 网格法仿真调用次数：粗筛 numel(NA1)*M1 + 细筛 numel(NA2)*M2（按脚本规则重建 NA2）
C1 = S.NA1*c_A + max(0, S.K1 - S.NA1)*c_B;
[~, ibC] = min(C1);
NA2r = max(0, S.NA1(ibC)-30):3:min(600, S.NA1(ibC)+30);
nSimGrid = numel(S.NA1)*S.M1 + numel(NA2r)*S.M2;   % 网格法仿真调用次数
fprintf('网格法已有结果：N_A*=%.0f, N_B*=%.0f, 成本=%.4f 元（仿真 %d 次）\n', ...
    NAg_best, nBg_best, Cg_best, nSimGrid);

%% ============ 3. 并行池 ============
if isempty(gcp('nocreate')), parpool('local', 8); end

%% ============ 4. 初始化种群 + 适应度缓存 ============
cache = containers.Map('KeyType','double','ValueType','any');  % NA -> K90(M口径)
popNA = randi([Nmin Nmax], 1, pop);
popNA(1) = Nmin; popNA(2) = Nmax;            % 覆盖设计域两端
histNA = []; histCost = [];                  % 全部被评估过的 (N_A, C) 点（散点图用）
bestSoFar = inf; bestNA = NaN;
genBest = NaN(1,maxGen); genMean = NaN(1,maxGen); genBestNA = NaN(1,maxGen);
tStart = tic; gEnd = maxGen;

%% ============ 5. 主进化循环 ============
for g = 1:maxGen
    % ---- 5.1 评估未缓存个体（parfor，M 次实验取 90% 分位）----
    need = false(1,pop);
    for i = 1:pop, need(i) = ~cache.isKey(popNA(i)); end
    if any(need)
        naList = popNA(need);
        K90 = zeros(1,numel(naList));
        parfor i = 1:numel(naList)
            k = zeros(M,1);
            for m = 1:M
                rng(naList(i)*100003 + m*7919);   % 每个(个体,样本)确定种子，可复现
                k(m) = runSequenceQ4(naList(i), NBMAX, RA, H, RB, HW, TOL);
            end
            ks = sort(k);
            K90(i) = ks(min(M, max(1, ceil(0.9*(M+1)))));   % 无偏 90% 分位
        end
        for i = 1:numel(naList), cache(naList(i)) = K90(i); end
    end
    % ---- 5.2 当前代适应度 ----
    Cpop = zeros(1,pop);
    for i = 1:pop
        K90 = cache(popNA(i));
        Cpop(i) = popNA(i)*c_A + max(0, K90 - popNA(i))*c_B;
    end
    [Cmin, im] = min(Cpop);
    if Cmin < bestSoFar, bestSoFar = Cmin; bestNA = popNA(im); end
    genBest(g) = bestSoFar; genBestNA(g) = bestNA; genMean(g) = mean(Cpop);
    % 记录本代被评估点（散点图用）
    histNA(end+1:end+pop) = popNA;          %#ok<AGROW>
    histCost(end+1:end+pop) = Cpop;         %#ok<AGROW>
    fprintf('gen %2d: best=%.4f (N_A=%3d) mean=%.4f | 累计评估%d点 | %.0fs\n', ...
        g, bestSoFar, bestNA, genMean(g), cache.Count, toc(tStart));
    % ---- 5.3 提前停止 ----
    if g > staleLim && genBest(g-staleLim) <= bestSoFar*(1+0.005)
        gEnd = g; fprintf('连续 %d 代无改善，提前停止。\n', staleLim); break;
    end
    if g == maxGen, break; end
    % ---- 5.4 选择 / 交叉 / 变异（生成子代） ----
    [~, order] = sort(Cpop);
    newpop = popNA(order(1:nElite));                 % 精英保留
    while numel(newpop) < pop
        p1 = tournSelect(popNA, Cpop, kTour);
        p2 = tournSelect(popNA, Cpop, kTour);
        if rand < pc
            a = 0.35 + 0.3*rand;                     % 算术交叉（偏向更优点）
            child = round(a*p1 + (1-a)*p2);
        else
            child = p1;
        end
        if rand < pm
            sigma = sigma0*(1 - g/maxGen) + 8;       % 变异幅度随代数衰减
            child = child + round(randn*sigma);
            if rand < 0.05, child = randi([Nmin Nmax]); end   % 小概率重新初始化
        end
        child = min(Nmax, max(Nmin, child));
        newpop(end+1) = child; %#ok<AGROW>
    end
    popNA = newpop;
end
genBest = genBest(1:gEnd); genMean = genMean(1:gEnd); genBestNA = genBestNA(1:gEnd);
nSimGA = cache.Count*M;                               % GA 过程仿真调用次数
fprintf('\nGA 结束：%d 代，共评估 %d 个不同 N_A，仿真 %d 次，耗时 %.0f s\n', ...
    gEnd, cache.Count, nSimGA, toc(tStart));

%% ============ 6. 决赛：最优候选（M=300 口径前3名）用 Mf=1000 重评 ============
allNA = cell2mat(cache.keys); allC = zeros(1,numel(allNA));
for i = 1:numel(allNA)
    K90 = cache(allNA(i));
    allC(i) = allNA(i)*c_A + max(0, K90 - allNA(i))*c_B;
end
[~, oo] = sort(allC);
top3 = allNA(oo(1:min(3,numel(allNA))));
Kf = zeros(1,numel(top3));
parfor i = 1:numel(top3)
    k = zeros(Mf,1);
    for m = 1:Mf
        rng(777000 + top3(i)*1000 + m);
        k(m) = runSequenceQ4(top3(i), NBMAX, RA, H, RB, HW, TOL);
    end
    ks = sort(k); Kf(i) = ks(min(Mf, max(1, ceil(0.9*(Mf+1)))));
end
[~, ib] = min(top3*c_A + max(0, Kf - top3)*c_B);
NA_ga = top3(ib); K90_ga = Kf(ib);
nB_ga = max(0, K90_ga - NA_ga);
C_ga = NA_ga*c_A + nB_ga*c_B;
% 网格法最优方案同口径重评（保证两种方法最终成本可比）
k = zeros(Mf,1);
parfor m = 1:Mf
    rng(778000 + NAg_best*1000 + m);
    k(m) = runSequenceQ4(NAg_best, NBMAX, RA, H, RB, HW, TOL);
end
ks = sort(k); K90_g2 = ks(min(Mf, max(1, ceil(0.9*(Mf+1)))));
nB_g2 = max(0, K90_g2 - NAg_best);
C_g2 = NAg_best*c_A + nB_g2*c_B;

%% ============ 7. 结果汇总与对比表 ============
vA = @(n) n*V_A/1e12*100;  vB = @(n) n*V_B/1e12*100;
fprintf('\n================ 两种方法结果对比 ================\n');
fprintf('%-28s %-18s %-18s\n', '指标', '网格法(粗筛+细筛)', '遗传算法(GA)');
fprintf('%-28s %-18d %-18d\n', '最优介质A数量 N_A*', NAg_best, NA_ga);
fprintf('%-28s %-18d %-18d\n', '最优介质B数量 N_B*', nBg_best, nB_ga);
fprintf('%-28s %-18s %-18s\n', '体积分数 A / B / 合计(%)', ...
    sprintf('%.4f/%.4f/%.4f', vA(NAg_best), vB(nBg_best), vA(NAg_best)+vB(nBg_best)), ...
    sprintf('%.4f/%.4f/%.4f', vA(NA_ga), vB(nB_ga), vA(NA_ga)+vB(nB_ga)));
fprintf('%-28s %-18.4f %-18.4f\n', '总成本（原口径，元）', Cg_best, min(allC));
fprintf('%-28s %-18.4f %-18.4f\n', '总成本（M=1000 同口径，元）', C_g2, C_ga);
fprintf('%-28s %-18d %-18d\n', '仿真调用次数', nSimGrid, nSimGA);
fprintf('%-28s %-18s %-18s\n', '收敛代数 / 用时', '-', sprintf('%d代 / %.0fs', gEnd, toc(tStart)));
fprintf('成本相对偏差 = %.2f%%\n', abs(C_ga - C_g2)/C_g2*100);
save('fig_Q4_GA_data.mat','NA_ga','nB_ga','C_ga','K90_ga','C_g2','nB_g2','K90_g2', ...
    'genBest','genMean','genBestNA','histNA','histCost','gEnd','M','Mf','pop','-v7');

%% ============ 8. 对比图（三张独立图，学术清爽风，仅 PDF） ============
C_BLUE = [0.31 0.45 0.67];  C_ORANGE = [0.87 0.55 0.33];  C_GRAY = [0.60 0.60 0.60];
C_GA_design = min(allC);                            % GA 设计阶段最优成本（M=300 口径）
NA_GA_design = allNA(oo(1));

% ---- 图(a)：成本景观 + GA 搜索轨迹 ----
fig1 = figure('Color','w','Position',[80 120 780 540]);
ax1 = axes('Parent',fig1,'FontName',fn);
hold(ax1,'on'); grid(ax1,'on');
ax1.GridAlpha = 0.14; ax1.GridLineStyle = ':'; ax1.Box = 'off';
plot(ax1, NAg, Cg, '-', 'Color',C_BLUE, 'LineWidth',1.6);                       % 网格法成本曲线
[un, ~, ui] = unique(histNA);
scatter(ax1, un, accumarray(ui, histCost, [], @mean), 4, C_GRAY, 'filled', ...
    'MarkerFaceAlpha',0.35);                                                     % GA 评估点
plot(ax1, genBestNA, genBest, '-', 'Color',C_ORANGE, 'LineWidth',1.3);           % GA 每代最优轨迹
plot(ax1, genBestNA, genBest, 'o', 'MarkerSize',3.5, 'Color',C_ORANGE, ...
    'MarkerFaceColor',C_ORANGE);
plot(ax1, NAg_best, Cg_best, 'o', 'MarkerSize',4.5, 'MarkerFaceColor',C_BLUE, ...
    'MarkerEdgeColor',C_BLUE);
plot(ax1, NA_GA_design, C_GA_design, 'o', 'MarkerSize',4.5, 'MarkerFaceColor',C_ORANGE, ...
    'MarkerEdgeColor',C_ORANGE);
text(ax1, NAg_best, Cg_best-0.6, sprintf('网格法 (%d, %.2f)', NAg_best, Cg_best), ...
    'FontSize',8.5, 'Color',[0.35 0.35 0.35], 'FontName',fn, 'HorizontalAlignment','center');
text(ax1, NA_GA_design, C_GA_design+0.6, sprintf('GA (%d, %.2f)', NA_GA_design, C_GA_design), ...
    'FontSize',8.5, 'Color',[0.35 0.35 0.35], 'FontName',fn, 'HorizontalAlignment','center');
xlim(ax1,[0 600]); ylim(ax1,[7.5 max(Cg)*1.02]);
xlabel(ax1,'介质A数量 N_A','FontSize',12,'FontName',fn);
ylabel(ax1,'总成本（元）','FontSize',12,'FontName',fn);
title(ax1,'GA 对比：成本景观与两种方法的最优解','FontSize',13,'FontName',fn);
set(ax1,'FontSize',10.5);
legend(ax1,{'网格法成本曲线 C(N_A)','GA 评估点','GA 每代最优','网格法最优点','GA 最优点'}, ...
    'Location','northeast','FontSize',9,'Box','off','FontName',fn);
ax1.Toolbar.Visible = 'off';
exportgraphics(fig1,'fig_Q4_GA_landscape.pdf','ContentType','vector');

% ---- 图(b)：GA 收敛曲线 ----
fig2 = figure('Color','w','Position',[120 120 780 540]);
ax2 = axes('Parent',fig2,'FontName',fn);
hold(ax2,'on'); grid(ax2,'on');
ax2.GridAlpha = 0.14; ax2.GridLineStyle = ':'; ax2.Box = 'off';
plot(ax2, 1:gEnd, genMean, '-', 'Color',[0.78 0.78 0.78], 'LineWidth',1.1);
plot(ax2, 1:gEnd, genBest, '-', 'Color',C_ORANGE, 'LineWidth',1.7);
yline(ax2, Cg_best, '--', 'Color',C_BLUE, 'LineWidth',1.1);
text(ax2, gEnd*0.62, Cg_best+0.22, sprintf('网格法最优 %.2f 元', Cg_best), ...
    'FontSize',8.5, 'Color',[0.35 0.35 0.35], 'FontName',fn);
xlim(ax2,[1 gEnd]);
xlabel(ax2,'进化代数','FontSize',12,'FontName',fn);
ylabel(ax2,'总成本（元）','FontSize',12,'FontName',fn);
title(ax2,'GA 收敛曲线（M=300 口径）','FontSize',13,'FontName',fn);
set(ax2,'FontSize',10.5);
legend(ax2,{'种群平均','GA 最优（迄今）','网格法最优（参考线）'}, ...
    'Location','northeast','FontSize',9,'Box','off','FontName',fn);
ax2.Toolbar.Visible = 'off';
exportgraphics(fig2,'fig_Q4_GA_convergence.pdf','ContentType','vector');

% ---- 图(c)：90% 导通边界与最优方案 ----
fig3 = figure('Color','w','Position',[80 120 780 540]);
ax3 = axes('Parent',fig3,'FontName',fn);
hold(ax3,'on'); grid(ax3,'on');
ax3.GridAlpha = 0.14; ax3.GridLineStyle = ':'; ax3.Box = 'off';
plot(ax3, NAg, nBg, '-', 'Color',C_BLUE, 'LineWidth',1.6);
NBiso = (Cg_best - NAg*c_A)/c_B; ok = NBiso >= 0;
plot(ax3, NAg(ok), NBiso(ok), '--', 'Color',[0.72 0.55 0.40], 'LineWidth',0.9);
plot(ax3, NAg_best, nBg_best, 'o', 'MarkerSize',4.5, 'MarkerFaceColor',C_BLUE, ...
    'MarkerEdgeColor',C_BLUE);
plot(ax3, NA_ga, nB_ga, 'o', 'MarkerSize',4.5, 'MarkerFaceColor',C_ORANGE, ...
    'MarkerEdgeColor',C_ORANGE);
xlim(ax3,[0 600]);
xlabel(ax3,'介质A数量 N_A','FontSize',12,'FontName',fn);
ylabel(ax3,'介质B数量 N_B','FontSize',12,'FontName',fn);
title(ax3,'GA 对比：90% 导通边界与最优方案','FontSize',13,'FontName',fn);
set(ax3,'FontSize',10.5);
legend(ax3,{'90% 导通边界 N_B*(N_A)','等成本线','网格法最优点','GA 最优点'}, ...
    'Location','northeast','FontSize',9,'Box','off','FontName',fn);
ax3.Toolbar.Visible = 'off';
exportgraphics(fig3,'fig_Q4_GA_boundary.pdf','ContentType','vector');
fprintf('\n图已保存（PDF）：fig_Q4_GA_landscape、fig_Q4_GA_convergence、fig_Q4_GA_boundary；数据：fig_Q4_GA_data.mat\n');

%% ---------------- 局部函数 ----------------
function w = tournSelect(popNA, Cpop, k)
% 锦标赛选择：随机取 k 个个体，返回成本最低者的基因
n = numel(popNA);
idx = randi(n, 1, k);
[~, im] = min(Cpop(idx));
w = popNA(idx(im));
end
