%% ======================= 问题 4 =======================
%% plot_Q4_four.m —— 四张核心图（5000 口径最优点）
%  ------------------------------------------------------------
%  图1 网格法成本曲线.pdf：成本 C(N_A) 曲线 + 最优点
%  图2 成本景观热力图.pdf：成本热力 + p=0.9 边界线 + 最优点
%  图3 成本体积权衡图.pdf：雷达图（纯A/混合/纯B 四维对比）
%  图4 网格GA对比-收敛曲线.pdf：GA 收敛过程 + 两条 M=5000 参考线
%  最优点统一：M=5000 口径 (479, 939)，紫色实心点+橙色细轮廓。
%  依赖：fig_Q4_data.mat、q4_landscape_data.mat、fig_Q4_GA_data.mat、
%        fig_Q4_3000_GA.mat（由对应脚本生成，放在运行目录）。
%  运行：直接运行 plot_Q4_four。
%% ============================================================

clear; close all;
fn = 'Hiragino Sans GB';
cA = 1.05*pi*30^2*5000/1e9;  cB = 0.05*(4/3)*pi*200^3/1e9;
VA = pi*30^2*5000; VB = (4/3)*pi*200^3; Vbox = 1e12;
% 最优点（M=5000 口径，用户已有数据）
NA_opt = 479; NB_opt = 939; C_opt = 8.684;
PURPLE = [0.72 0.55 0.88]; C_ORANGE = [0.8500 0.3250 0.0980];
optmark = @(ax,x,y) plot(ax,x,y,'o','MarkerSize',5,'MarkerFaceColor',PURPLE, ...
    'MarkerEdgeColor',C_ORANGE,'LineWidth',0.8);

S = load('fig_Q4_data.mat');
G = load('fig_Q4_GA_data.mat');
T = load('fig_Q4_3000_GA.mat');

%% 图1：网格法成本曲线（M=1000 曲线 + M=5000 最优点）
fig1 = figure('Color','w','Position',[80 120 780 500]);
ax1 = axes('Parent',fig1,'FontName',fn); hold on; grid on;
ax1.GridAlpha = 0.14; ax1.GridLineStyle = ':'; ax1.Box = 'off';
h1 = plot(ax1, S.NA_all, S.C_all, '-', 'Color',[0.31 0.45 0.67], 'LineWidth',1.6);
hs1 = optmark(ax1, NA_opt, C_opt);
xlim(ax1,[0 600]);
xlabel(ax1,'N_A','FontName',fn); ylabel(ax1,'总成本（元）','FontName',fn);
legend(ax1,[h1 hs1], {'网格法成本曲线（M=1000）','最优点 (479, 939)（M=5000）'}, ...
    'Location','northeast','FontName',fn);
exportgraphics(fig1,'网格法成本曲线.pdf','ContentType','vector');
fprintf('图1 已保存 → 网格法成本曲线.pdf\n');

%% 图2：成本景观热力图（图例修复：线=0.9边界，点=最优点；紫色点）
L = load('q4_landscape_data.mat');
NA = L.NA_grid; ks = L.ks;
nB = 0:60:3000;
p = zeros(numel(nB), numel(NA));
for j = 1:numel(NA)
    p(:,j) = mean(ks(:,j) <= nB, 1);
end
cost = cA*NA + cB*nB';
[NAu, ia] = unique(S.NA_all, 'last'); nBu = S.nB_all(ia);
fig2 = figure('Color','w','Position',[80 120 820 560]);
ax2 = axes('Parent',fig2,'FontName',fn); hold on;
Cext = cost; Cext(:, end+1) = Cext(:, end); Cext(end+1, :) = Cext(end, :);
pcolor(ax2, [NA 625], [nB 3060], Cext);
shading interp; colormap(ax2, sky);
cb = colorbar(ax2); cb.Label.String = '成本（元）'; cb.Label.FontName = fn;
h9 = plot(ax2, NAu, nBu, '-', 'Color',C_ORANGE, 'LineWidth',2);    % p=0.9 边界（线）
hs2 = optmark(ax2, NA_opt, NB_opt);                                % 最优点（点）
xlim(ax2,[0 600]); ylim(ax2,[0 3000]);
xlabel(ax2,'N_A','FontName',fn); ylabel(ax2,'N_B','FontName',fn);
legend(ax2,[h9 hs2], {'p = 0.9 边界','最优点 (479, 939)（M=5000）'}, ...
    'Location','northwest','FontName',fn);
exportgraphics(fig2,'成本景观热力图.pdf','ContentType','vector');
fprintf('图2 已保存 → 成本景观热力图.pdf\n');

%% 图3：成本体积权衡图（雷达，三方案；混合 = M=5000 最优）
sA = [624*cA, 624*VA/Vbox*100, 624, 0];
sM = [C_opt, (NA_opt*VA+NB_opt*VB)/Vbox*100, NA_opt, NB_opt];
sB = [16876*cB, 16876*VB/Vbox*100, 0, 16876];
D = [sA; sM; sB]; Dn = D ./ max(D, [], 1);
dims = {'总成本','体积分数','A 数量','B 数量'};
names = {sprintf('纯A (%d)', 624), sprintf('混合 (%d, %d)', NA_opt, NB_opt), sprintf('纯B (%d)', 16876)};
co = [0 0.4470 0.7410; 0.8500 0.3250 0.0980; 0.9290 0.6940 0.1250];
fig3 = figure('Color','w','Position',[80 120 700 600]);
ax3 = axes('Parent',fig3,'FontName',fn); axis equal; axis off; hold on;
ang = (0:3)/4*2*pi + pi/2;
for r = 0.25:0.25:1
    patch(ax3, r*cos([ang ang(1)]), r*sin([ang ang(1)]), [0.93 0.93 0.93], ...
        'EdgeColor',[0.8 0.8 0.8], 'FaceAlpha',0.35);
end
for k = 1:4
    plot(ax3, [0 cos(ang(k))], [0 sin(ang(k))], 'Color',[0.8 0.8 0.8]);
    text(ax3, 1.2*cos(ang(k)), 1.2*sin(ang(k)), dims{k}, ...
        'HorizontalAlignment','center','FontName',fn);
end
hp = gobjects(1,3);
for s = 1:3
    hp(s) = patch(ax3, cos([ang ang(1)]).*[Dn(s,:) Dn(s,1)], sin([ang ang(1)]).*[Dn(s,:) Dn(s,1)], ...
        co(s,:), 'FaceAlpha',0.2, 'EdgeColor',co(s,:), 'LineWidth',1.5);
end
legend(ax3, hp, names, 'Location','northwest','FontName',fn);
exportgraphics(fig3,'成本体积权衡图.pdf','ContentType','vector');
fprintf('图3 已保存 → 成本体积权衡图.pdf\n');

%% 图4：网格GA对比-收敛曲线（参考线 = M=5000 口径）
gEnd = G.gEnd;
fig4 = figure('Color','w','Position',[120 120 780 500]);
ax4 = axes('Parent',fig4,'FontName',fn); hold on; grid on;
ax4.GridAlpha = 0.14; ax4.GridLineStyle = ':'; ax4.Box = 'off';
plot(ax4, 1:gEnd, G.genMean, '-', 'Color',[0.78 0.78 0.78], 'LineWidth',1.1);
hG = plot(ax4, 1:gEnd, G.genBest, '-', 'Color',C_ORANGE, 'LineWidth',1.7);
yline(ax4, C_opt, '--', 'Color',[0.31 0.45 0.67], 'LineWidth',1.1);
yline(ax4, T.C_ga5, ':', 'Color',[0.4660 0.6740 0.1880], 'LineWidth',1.1);
xlim(ax4,[1 gEnd]);
xlabel(ax4,'进化代数','FontName',fn); ylabel(ax4,'总成本（元）','FontName',fn);
legend(ax4, {'种群平均（寻优 M=300）','GA 最优（寻优 M=300）', ...
    sprintf('网格法最优 %.3f 元（M=5000）', C_opt), ...
    sprintf('GA 最终 %.3f 元（M=5000 验证）', T.C_ga5)}, ...
    'Location','northeast','FontName',fn);
exportgraphics(fig4,'网格GA对比-收敛曲线.pdf','ContentType','vector');
fprintf('图4 已保存 → 网格GA对比-收敛曲线.pdf\n');
fprintf('全部完成。\n');
