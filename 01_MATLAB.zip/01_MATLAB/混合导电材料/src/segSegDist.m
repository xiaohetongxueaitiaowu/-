%% ======================= 问题 1 =======================
%% segSegDist.m —— 两空间线段间的最短距离（Ericson 算法）
%  ------------------------------------------------------------
%  用途：Q1 胶囊粗筛的"轴线距离"——两圆柱轴线（线段）最短距离 d_axis，
%    胶囊距离 d_cap = max(0, d_axis - 2r) 为真实距离下界；
%    d_cap > 1.8nm 可直接排除，否则进入 gjkDist 精细判定。
%  依赖：无。
%  输出：d = 最短距离。
%% ============================================================

function [d, p1, p2] = segSegDist(a1, a2, b1, b2)
%SEGSEGDIST  两条线段之间的最短距离与最近点对（经典算法，Ericson）。
%   [d, p1, p2] = segSegDist(a1, a2, b1, b2)
%   a1,a2: 线段1两端点(3x1)；b1,b2: 线段2两端点(3x1)。
%   d: 距离；p1,p2: 最近点对（分别在两线段上）。

d1 = a2 - a1;
d2 = b2 - b1;
r  = a1 - b1;
a  = d1'*d1;
e  = d2'*d2;
f  = d2'*r;
eps0 = 1e-14;

if a <= eps0 && e <= eps0
    s = 0; t = 0;
elseif a <= eps0
    s = 0;
    t = min(1, max(0, f/e));
else
    c = d1'*r;
    if e <= eps0
        t = 0;
        s = min(1, max(0, -c/a));
    else
        b = d1'*d2;
        denom = a*e - b*b;
        if denom <= eps0
            s = 0;
        else
            s = min(1, max(0, (b*f - c*e)/denom));
        end
        t = min(1, max(0, (b*s + f)/e));
        s = min(1, max(0, (b*t - c)/a));
    end
end

p1 = a1 + s*d1;
p2 = b1 + t*d2;
d  = norm(p1 - p2);
end
