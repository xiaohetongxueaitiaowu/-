%% ======================= 问题 3 =======================
%% Q3_threshold.m —— 导通概率 p>=90% 所需的最低体积分数
%  ------------------------------------------------------------
%  方法：由问题2 的增量实验数据（首次导通根数 nCross 样本）直接读出：
%    p(φ) = P(nCross <= N(φ))；90% 阈值对应 nCross 的 90% 分位 N*，
%    最低体积分数 φ* = N*·V_A / V_box。
%  依赖：fig_Q2_data.mat（Q2_montecarlo 生成）。
%  运行：直接运行 Q3_threshold。
%  输出：fig_Q3_threshold.pdf（N_c 直方图 + 90% 分位线）、
%        fig_Q3_curve.pdf（p(φ) 曲线与 p=0.9 交点）。
%% ============================================================

clc;
R = 30; H = 5000; HW = 5000; TOL = 1.8;
V_A   = pi * R^2 * H;
V_box = (2*HW)^3;
fn = 'Hiragino Sans GB';

S = load('fig_Q2_data.mat');
nCross = S.nCross; M = S.M; K = S.K;

% ---- 90% 分位：最小的 N 使 P(N_c<=N) >= 0.9 ----
nc = nCross; nc(isinf(nc)) = K + 1;
cnt = histcounts(nc, 0.5:1:(K+1.5));
pN = cumsum(cnt) / M;
Nstar = find(pN >= 0.9, 1, 'first');
phiStar = Nstar * V_A / V_box * 100;
pAtStar = pN(Nstar);
fprintf('N* = %d 根（P(N_c<=N*)=%.4f >= 0.9），最低体积分数 φ* = %.4f%%\n', ...
    Nstar, pAtStar, phiStar);

% ---- 图：直方图 + 90% 分位虚线 ----
fig = figure('Color','w','Position',[100 100 1000 680]);
ax = axes('Parent',fig,'FontName',fn);
hold(ax,'on'); grid(ax,'on'); ax.GridAlpha = 0.16;
ncV = nCross(~isinf(nCross));
histogram(ax, ncV, 0:25:1000, 'FaceColor',[0.30 0.55 0.85], ...
    'EdgeColor','none', 'FaceAlpha',0.85);
maxC = max(histcounts(ncV, 0:25:1000));
xline(ax, Nstar, '--', 'Color',[0.85 0.30 0.12], 'LineWidth',2.0);
text(ax, Nstar + 10, maxC*1.06, sprintf('90%% 分位：N* = %d 根\n对应体积分数 φ* = %.4f%%', Nstar, phiStar), ...
    'HorizontalAlignment','left','VerticalAlignment','bottom', ...
    'FontSize',12,'FontWeight','bold','Color',[0.7 0.18 0.06],'FontName',fn);
xlim(ax,[0 1000]); ylim(ax,[0 maxC*1.30]);
xlabel(ax,'首次导通时的投掷根数 N_c','FontWeight','bold','FontSize',14,'FontName',fn);
ylabel(ax,'实验次数','FontWeight','bold','FontSize',14,'FontName',fn);
title(ax,sprintf('问题三：由 N_c 分布确定 p≥90%% 的最低体积分数（M=%d）',M), ...
    'FontWeight','bold','FontSize',15,'FontName',fn);
set(ax,'FontSize',12);
ax.Toolbar.Visible = 'off';
exportgraphics(fig,'fig_Q3_threshold.pdf','ContentType','vector');
fprintf('问题三阈值图已保存为 fig_Q3_threshold.pdf（矢量 PDF）。\n');

% ---- 图2：p(φ) 曲线与 p=0.9 的交点 ----
phiaxis = (1:K) * V_A / V_box * 100;
fig2 = figure('Color','w','Position',[100 100 1060 700]);
ax2 = axes('Parent',fig2,'FontName',fn);
hold(ax2,'on'); grid(ax2,'on'); ax2.GridAlpha = 0.16;
plot(ax2, phiaxis, pN(1:K), '-', 'Color',[0.09 0.33 0.72], 'LineWidth',2.2);
yline(ax2, 0.9, '--', 'Color',[0.75 0.22 0.16], 'LineWidth',1.6);
xline(ax2, phiStar, '--', 'Color',[0.85 0.30 0.12], 'LineWidth',1.6);
plot(ax2, phiStar, 0.9, 'o', 'MarkerSize',11, 'MarkerFaceColor',[0.95 0.62 0.10], ...
    'MarkerEdgeColor',[0.5 0.28 0.05], 'LineWidth',1.5);
text(ax2, phiStar + 0.03, 0.855, sprintf('交点：φ* = %.4f%%\n（N* = %d 根）', phiStar, Nstar), ...
    'FontSize',11.5,'FontWeight','bold','Color',[0.7 0.18 0.06],'FontName',fn, ...
    'HorizontalAlignment','left','VerticalAlignment','top');
xlim(ax2,[0.3 1.45]); ylim(ax2,[0 1.05]);
xlabel(ax2,'介质A体积分数 (%)','FontWeight','bold','FontSize',14,'FontName',fn);
ylabel(ax2,'微构体导通概率 p','FontWeight','bold','FontSize',14,'FontName',fn);
title(ax2,sprintf('问题三：导通概率曲线与 p = 0.9 的交点确定最低体积分数（M=%d）',M), ...
    'FontWeight','bold','FontSize',14.5,'FontName',fn);
set(ax2,'FontSize',12);
legend(ax2,{'p(φ) 经验曲线','p = 0.9','φ* 分位线','交点'}, ...
    'Location','northwest','FontSize',11,'Box','on','FontName',fn);
ax2.Toolbar.Visible = 'off';
exportgraphics(fig2,'fig_Q3_curve.pdf','ContentType','vector');
fprintf('问题三交点图已保存为 fig_Q3_curve.pdf（矢量 PDF）。\n');
