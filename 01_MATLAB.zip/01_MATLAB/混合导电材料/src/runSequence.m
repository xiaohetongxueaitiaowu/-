%% ======================= 问题 2 =======================
%% runSequence.m —— 单次"增量投掷"实验内核（分批 40 根）
%  ------------------------------------------------------------
%  流程：逐批生成介质A → 折回成段 → 只计算新段与已投段的导通边 →
%    逐根激活并查集 → 左右带电面一旦连通立即返回该根数 nCross；
%    K 根内不导通则返回 inf（提前终止省掉后续全部计算）。
%  用途：Q2 主程序逐次调用，得到 nCross 经验分布。
%  依赖：cylDistLE.m、segSegDist.m（同目录）。
%  输出：nCross（首次导通时的投掷根数，或 inf）。
%% ============================================================

function nCross = runSequence(K, R, H, HW, TOL)
%RUNSEQUENCE  分批增量投掷蒙特卡洛实验。
%   每次实验把 K 根介质 A 逐批"投"入微构体：只计算新一批介质与已投介质
%   的导通关系，逐根激活并查集；一旦左右带电面连通立即返回该根数 nCross
%   （提前终止，省掉后续介质的所有计算）。K 根仍不导通则返回 inf。
%   模型与 Q1 一致：轴中心均匀 + 方向球面均匀 + 截断规则折回，
%   每段 = 独立介质 A，平底圆柱精确距离（cylDistLE）<= 1.8nm 导通。
B = 40;                                   % 批大小（根）
maxSeg = 3*K;
segs = zeros(maxSeg, 6);                  % 段库
parent = 1:(maxSeg+2);                    % 并查集：段 + 左/右带电面
LEFT = maxSeg+1; RIGHT = maxSeg+2;
S = 0;                                    % 已投段数

for kb = 1:B:K
    nb = min(B, K - kb + 1);              % 本批根数
    % ---- 生成本批 ----
    C = 2*HW*rand(3,nb) - HW;
    U = randn(3,nb); U = U ./ sqrt(sum(U.^2,1));
    V1 = C - (H/2)*U;  V2 = C + (H/2)*U;
    D = V2 - V1;
    % ---- 折回成段 ----
    [t1v, t2v] = clipSegVec(V1, V2, HW);
    newSegs = zeros(3*nb, 6); newOwn = zeros(3*nb, 1); n2 = 0;
    mk = t2v > t1v + 1e-9;
    if any(mk)
        idx = find(mk);
        p1 = V1(:,mk) + t1v(mk).*D(:,mk);
        p2 = V1(:,mk) + t2v(mk).*D(:,mk);
        nn = numel(idx);
        newSegs(n2+1:n2+nn,:) = [p1; p2]';
        newOwn(n2+1:n2+nn) = idx;
        n2 = n2 + nn;
    end
    mk = t1v > 1e-9;
    if any(mk)
        idx = find(mk);
        p1 = V1(:,mk); p2 = V1(:,mk) + t1v(mk).*D(:,mk);
        [q1,q2] = shiftSegmentVec(p1,p2,HW);
        [a,b] = clipSegVec(q1,q2,HW);
        m2 = b > a + 1e-9;
        if any(m2)
            pp1 = q1(:,m2) + a(m2).*(q2(:,m2)-q1(:,m2));
            pp2 = q1(:,m2) + b(m2).*(q2(:,m2)-q1(:,m2));
            nn = sum(m2);
            newSegs(n2+1:n2+nn,:) = [pp1; pp2]';
            newOwn(n2+1:n2+nn) = idx(m2);
            n2 = n2 + nn;
        end
    end
    mk = t2v < 1 - 1e-9;
    if any(mk)
        idx = find(mk);
        p1 = V1(:,mk) + t2v(mk).*D(:,mk); p2 = V2(:,mk);
        [q1,q2] = shiftSegmentVec(p1,p2,HW);
        [a,b] = clipSegVec(q1,q2,HW);
        m2 = b > a + 1e-9;
        if any(m2)
            pp1 = q1(:,m2) + a(m2).*(q2(:,m2)-q1(:,m2));
            pp2 = q1(:,m2) + b(m2).*(q2(:,m2)-q1(:,m2));
            nn = sum(m2);
            newSegs(n2+1:n2+nn,:) = [pp1; pp2]';
            newOwn(n2+1:n2+nn) = idx(m2);
            n2 = n2 + nn;
        end
    end
    if n2 == 0, continue; end
    newSegs = newSegs(1:n2,:); newOwn = newOwn(1:n2);
    glo = S + (1:n2)';                    % 新段全局索引
    % ---- 本批段几何 ----
    nax = newSegs(:,4:6) - newSegs(:,1:3);
    nL = sqrt(sum(nax.^2,2));
    nu = nax ./ nL;
    nux = nu(:,1);
    nreach = R*sqrt(max(0, 1 - nux.^2));
    dL = max(0, min(newSegs(:,1),newSegs(:,4)) + HW - nreach);
    dR = max(0, HW - max(newSegs(:,1),newSegs(:,4)) - nreach);
    ccN = (newSegs(:,1:3) + newSegs(:,4:6)) / 2;
    hhN = nL / 2;
    loN = min(newSegs(:,1:3), newSegs(:,4:6)) - R;
    hiN = max(newSegs(:,1:3), newSegs(:,4:6)) + R;
    % ---- 导通边：本批段内部 ----
    eA = []; eB = []; eAct = [];
    if n2 >= 2
        [ii,jj] = find(triu(true(n2),1));
        sep = max(0, loN(ii,:) - hiN(jj,:));
        sep = max(sep, loN(jj,:) - hiN(ii,:));
        okA = sqrt(sum(sep.^2,2)) <= TOL + 2*R;
        ii = ii(okA); jj = jj(okA);
        if ~isempty(ii)
            dseg = vecSegSegDistAll(newSegs(ii,1:3)', newSegs(ii,4:6)', ...
                                    newSegs(jj,1:3)', newSegs(jj,4:6)');
            cand = find(max(0, dseg - 2*R) <= TOL);
            if ~isempty(cand)
                okE = false(numel(cand),1);
                for kk = 1:numel(cand)
                    i = ii(cand(kk)); j = jj(cand(kk));
                    okE(kk) = cylDistLE(ccN(i,:)',nu(i,:)',hhN(i),R, ...
                                        ccN(j,:)',nu(j,:)',hhN(j),R,TOL);
                end
                eA = glo(ii(cand(okE))); eB = glo(jj(cand(okE)));
                eAct = max(newOwn(ii(cand(okE))), newOwn(jj(cand(okE))));
            end
        end
    end
    % ---- 导通边：本批段 vs 已投段 ----
    if S >= 1
        axA = segs(1:S,4:6) - segs(1:S,1:3);
        LA = sqrt(sum(axA.^2,2));
        ccA = (segs(1:S,1:3) + segs(1:S,4:6)) / 2;
        uA = axA ./ LA; hA = LA / 2;
        loA = min(segs(1:S,1:3), segs(1:S,4:6)) - R;
        hiA = max(segs(1:S,1:3), segs(1:S,4:6)) + R;
        [JJ, II] = meshgrid(glo, (1:S)');
        ii = II(:); jj = JJ(:);             % ii 已有段，jj 新段
        sep = max(0, loA(ii,:) - hiN(jj-S,:));
        sep = max(sep, loN(jj-S,:) - hiA(ii,:));
        okA = sqrt(sum(sep.^2,2)) <= TOL + 2*R;
        ii = ii(okA); jj = jj(okA);
        if ~isempty(ii)
            dseg = vecSegSegDistAll(segs(ii,1:3)', segs(ii,4:6)', ...
                                    newSegs(jj-S,1:3)', newSegs(jj-S,4:6)');
            cand = find(max(0, dseg - 2*R) <= TOL);
            if ~isempty(cand)
                okE = false(numel(cand),1);
                for kk = 1:numel(cand)
                    i = ii(cand(kk)); j = jj(cand(kk)) - S;
                    okE(kk) = cylDistLE(ccA(i,:)',uA(i,:)',hA(i),R, ...
                                        ccN(j,:)',nu(j,:)',hhN(j),R,TOL);
                end
                eA = [eA; ii(cand(okE))];
                eB = [eB; jj(cand(okE))];
                eAct = [eAct; newOwn(jj(cand(okE))-S)];
            end
        end
    end
    % ---- 批内逐根激活 ----
    for r = 1:nb
        segR = glo(newOwn == r);
        for i = segR'
            if dL(i-S) <= TOL, parent = ufUnion(parent, i, LEFT);  end
            if dR(i-S) <= TOL, parent = ufUnion(parent, i, RIGHT); end
        end
        if ~isempty(eA)
            for e = find(eAct == r)'
                parent = ufUnion(parent, eA(e), eB(e));
            end
        end
        if ufFind(parent, LEFT) == ufFind(parent, RIGHT)
            nCross = kb + r - 1;
            return;
        end
    end
    % ---- 并入段库 ----
    segs(S+1:S+n2,:) = newSegs;
    S = S + n2;
end
nCross = inf;
end

%% ---------------- 局部函数 ----------------
function [t1, t2] = clipSegVec(V1, V2, HW)
D = V2 - V1;
t1 = zeros(1, size(V1,2)); t2 = ones(1, size(V1,2));
for ax = 1:3
    da = D(ax,:); va = V1(ax,:);
    par = abs(da) < 1e-12;
    out = par & (va < -HW | va > HW);
    t1(out) = 1; t2(out) = 0;
    np = ~par;
    if any(np)
        ta = (-HW - va(np))./da(np);
        tb = ( HW - va(np))./da(np);
        lo = min(ta,tb); hi = max(ta,tb);
        t1(np) = max(t1(np),lo); t2(np) = min(t2(np),hi);
    end
end
end

function [q1, q2] = shiftSegmentVec(p1, p2, HW)
cm = (p1+p2)/2; sh = zeros(size(p1));
sh = sh - 2*HW*(cm > HW) + 2*HW*(cm < -HW);
q1 = p1 + sh; q2 = p2 + sh;
end

function d = vecSegSegDistAll(P1, P2, Q1, Q2)
d1 = P2-P1; d2 = Q2-Q1; r = P1-Q1;
a = sum(d1.*d1,1); e = sum(d2.*d2,1); b = sum(d1.*d2,1);
c = sum(d1.*r,1); f = sum(d2.*r,1);
eps0 = 1e-14; dmin = inf(1, size(P1,2));
dmin = min(dmin, sqrt(sum(r.*r,1)));
dmin = min(dmin, sqrt(sum((r+d2).^2,1)));
dmin = min(dmin, sqrt(sum((r-d1).^2,1)));
dmin = min(dmin, sqrt(sum((r-d1+d2).^2,1)));
ok = e > eps0;
t = zeros(size(a)); t(ok) = f(ok)./e(ok); t = max(0,min(1,t));
dmin = min(dmin, sqrt(sum((r+t.*d2).^2,1)));
t = zeros(size(a)); t(ok) = (f(ok)+b(ok))./e(ok); t = max(0,min(1,t));
dmin = min(dmin, sqrt(sum((r-d1+t.*d2).^2,1)));
ok = a > eps0;
s = zeros(size(a)); s(ok) = -c(ok)./a(ok); s = max(0,min(1,s));
dmin = min(dmin, sqrt(sum((r+s.*d1).^2,1)));
s = zeros(size(a)); s(ok) = (b(ok)-c(ok))./a(ok); s = max(0,min(1,s));
dmin = min(dmin, sqrt(sum((r+s.*d1-d2).^2,1)));
den = a.*e-b.*b; ok3 = den > eps0;
s = zeros(size(a)); t = zeros(size(a));
s(ok3) = (b(ok3).*f(ok3)-c(ok3).*e(ok3))./den(ok3);
t(ok3) = (b(ok3).*s(ok3)+f(ok3))./e(ok3);
in = ok3 & s >= 0 & s <= 1 & t >= 0 & t <= 1;
v = r+s.*d1-t.*d2;
dmin(in) = min(dmin(in), sqrt(sum(v(:,in).^2,1)));
d = dmin;
end

function p = ufUnion(parent, a, b)
ra = ufFind(parent, a); rb = ufFind(parent, b);
if ra ~= rb, parent(ra) = rb; end
p = parent;
end

function r = ufFind(parent, x)
r = x;
while parent(r) ~= r
    parent(r) = parent(parent(r)); r = parent(r);
end
end
