%% ======================= 问题 2 =======================
%% runTraditional.m —— 传统逐档独立抽样（单次实验）
%  ------------------------------------------------------------
%  流程：一次实验恰好生成 N 根介质A，折回后一次性计算全部段间距离
%    与面距离，判定左右带电面是否导通。
%  用途：仅用于与增量投掷法的"运行时长"公平对比（几何实现完全相同）。
%  依赖：cylDistLE.m、segSegDist.m（同目录）。
%  输出：flag（true = 导通）。
%% ============================================================

function flag = runTraditional(N, R, H, HW, TOL)
%RUNTRADITIONAL  传统逐档独立抽样：一次实验恰好生成 N 根介质 A，
%   折回后一次性计算全部段间距离与面距离，判定左右带电面是否导通。
%   与 runSequence 使用完全相同的几何/距离实现（向量化 + cylDistLE），
%   仅用于"运行时长"的公平对比（增量投掷法 vs 传统逐档抽样）。
% 生成
C = 2*HW*rand(3,N) - HW;
U = randn(3,N); U = U ./ sqrt(sum(U.^2,1));
V1 = C - (H/2)*U;  V2 = C + (H/2)*U;
D = V2 - V1;
% 折回成段
[t1v, t2v] = clipSegVec(V1, V2, HW);
segs = zeros(3*N, 6); S = 0;
mk = t2v > t1v + 1e-9;
if any(mk)
    p1 = V1(:,mk) + t1v(mk).*D(:,mk);
    p2 = V1(:,mk) + t2v(mk).*D(:,mk);
    n2 = sum(mk);
    segs(S+1:S+n2,:) = [p1; p2]'; S = S + n2;
end
mk = t1v > 1e-9;
if any(mk)
    p1 = V1(:,mk); p2 = V1(:,mk) + t1v(mk).*D(:,mk);
    [q1,q2] = shiftSegmentVec(p1,p2,HW);
    [a,b] = clipSegVec(q1,q2,HW);
    m2 = b > a + 1e-9;
    if any(m2)
        pp1 = q1(:,m2) + a(m2).*(q2(:,m2)-q1(:,m2));
        pp2 = q1(:,m2) + b(m2).*(q2(:,m2)-q1(:,m2));
        n2 = sum(m2);
        segs(S+1:S+n2,:) = [pp1; pp2]'; S = S + n2;
    end
end
mk = t2v < 1 - 1e-9;
if any(mk)
    p1 = V1(:,mk) + t2v(mk).*D(:,mk); p2 = V2(:,mk);
    [q1,q2] = shiftSegmentVec(p1,p2,HW);
    [a,b] = clipSegVec(q1,q2,HW);
    m2 = b > a + 1e-9;
    if any(m2)
        pp1 = q1(:,m2) + a(m2).*(q2(:,m2)-q1(:,m2));
        pp2 = q1(:,m2) + b(m2).*(q2(:,m2)-q1(:,m2));
        n2 = sum(m2);
        segs(S+1:S+n2,:) = [pp1; pp2]'; S = S + n2;
    end
end
segs = segs(1:S,:);
% 面距离
ax = segs(:,4:6) - segs(:,1:3);
L = sqrt(sum(ax.^2,2));
ux = ax(:,1)./L;
reach = R*sqrt(max(0,1-ux.^2));
dL = max(0, min(segs(:,1),segs(:,4)) + HW - reach);
dR = max(0, HW - max(segs(:,1),segs(:,4)) - reach);
parent = (1:S+2)'; LEFT = S+1; RIGHT = S+2;
for i = 1:S
    if dL(i) <= TOL, parent = ufUnion(parent, i, LEFT); end
    if dR(i) <= TOL, parent = ufUnion(parent, i, RIGHT); end
end
% 段间距离（全对）
if S >= 2
    [ii, jj] = find(triu(true(S), 1));
    lo = min(segs(:,1:3), segs(:,4:6)) - R;
    hi = max(segs(:,1:3), segs(:,4:6)) + R;
    sep = max(0, lo(ii,:) - hi(jj,:));
    sep = max(sep, lo(jj,:) - hi(ii,:));
    okA = sqrt(sum(sep.^2,2)) <= TOL + 2*R;
    ii = ii(okA); jj = jj(okA);
    if ~isempty(ii)
        dseg = vecSegSegDistAll(segs(ii,1:3)', segs(ii,4:6)', ...
                                segs(jj,1:3)', segs(jj,4:6)');
        cand = find(max(0, dseg - 2*R) <= TOL);
        if ~isempty(cand)
            cc = (segs(:,1:3)+segs(:,4:6))/2;
            uu = ax ./ L; hh = L/2;
            okE = false(numel(cand),1);
            for kk = 1:numel(cand)
                i = ii(cand(kk)); j = jj(cand(kk));
                okE(kk) = cylDistLE(cc(i,:)',uu(i,:)',hh(i),R, ...
                                    cc(j,:)',uu(j,:)',hh(j),R,TOL);
            end
            for kk = 1:numel(cand)
                if okE(kk)
                    parent = ufUnion(parent, ii(cand(kk)), jj(cand(kk)));
                end
            end
        end
    end
end
flag = ufFind(parent, LEFT) == ufFind(parent, RIGHT);
end

%% ---------------- 局部函数 ----------------
function [t1, t2] = clipSegVec(V1, V2, HW)
D = V2 - V1;
t1 = zeros(1, size(V1,2)); t2 = ones(1, size(V1,2));
for ax = 1:3
    da = D(ax,:); va = V1(ax,:);
    par = abs(da) < 1e-12;
    out = par & (va < -HW | va > HW);
    t1(out) = 1; t2(out) = 0;
    np = ~par;
    if any(np)
        ta = (-HW - va(np))./da(np);
        tb = ( HW - va(np))./da(np);
        lo = min(ta,tb); hi = max(ta,tb);
        t1(np) = max(t1(np),lo); t2(np) = min(t2(np),hi);
    end
end
end

function [q1, q2] = shiftSegmentVec(p1, p2, HW)
cm = (p1+p2)/2; sh = zeros(size(p1));
sh = sh - 2*HW*(cm > HW) + 2*HW*(cm < -HW);
q1 = p1 + sh; q2 = p2 + sh;
end

function d = vecSegSegDistAll(P1, P2, Q1, Q2)
d1 = P2-P1; d2 = Q2-Q1; r = P1-Q1;
a = sum(d1.*d1,1); e = sum(d2.*d2,1); b = sum(d1.*d2,1);
c = sum(d1.*r,1); f = sum(d2.*r,1);
eps0 = 1e-14; dmin = inf(1, size(P1,2));
dmin = min(dmin, sqrt(sum(r.*r,1)));
dmin = min(dmin, sqrt(sum((r+d2).^2,1)));
dmin = min(dmin, sqrt(sum((r-d1).^2,1)));
dmin = min(dmin, sqrt(sum((r-d1+d2).^2,1)));
ok = e > eps0;
t = zeros(size(a)); t(ok) = f(ok)./e(ok); t = max(0,min(1,t));
dmin = min(dmin, sqrt(sum((r+t.*d2).^2,1)));
t = zeros(size(a)); t(ok) = (f(ok)+b(ok))./e(ok); t = max(0,min(1,t));
dmin = min(dmin, sqrt(sum((r-d1+t.*d2).^2,1)));
ok = a > eps0;
s = zeros(size(a)); s(ok) = -c(ok)./a(ok); s = max(0,min(1,s));
dmin = min(dmin, sqrt(sum((r+s.*d1).^2,1)));
s = zeros(size(a)); s(ok) = (b(ok)-c(ok))./a(ok); s = max(0,min(1,s));
dmin = min(dmin, sqrt(sum((r+s.*d1-d2).^2,1)));
den = a.*e-b.*b; ok3 = den > eps0;
s = zeros(size(a)); t = zeros(size(a));
s(ok3) = (b(ok3).*f(ok3)-c(ok3).*e(ok3))./den(ok3);
t(ok3) = (b(ok3).*s(ok3)+f(ok3))./e(ok3);
in = ok3 & s >= 0 & s <= 1 & t >= 0 & t <= 1;
v = r+s.*d1-t.*d2;
dmin(in) = min(dmin(in), sqrt(sum(v(:,in).^2,1)));
d = dmin;
end

function p = ufUnion(parent, a, b)
ra = ufFind(parent, a); rb = ufFind(parent, b);
if ra ~= rb, parent(ra) = rb; end
p = parent;
end

function r = ufFind(parent, x)
r = x;
while parent(r) ~= r
    parent(r) = parent(parent(r)); r = parent(r);
end
end
