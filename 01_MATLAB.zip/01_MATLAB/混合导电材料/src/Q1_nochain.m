%% ======================= 问题 1 =======================
%% Q1_nochain.m —— 三个微构体（组1/组2/组3）是否导通的判定主程序
%  ------------------------------------------------------------
%  模型：附件每一行 = 一根独立介质A（平底直圆柱 r=30, h=5000nm）
%    · 两介质导通：平底圆柱最短距离 <= 1.8nm（GJK 精确距离；端面构型下
%      胶囊近似误差可达 r，必须用 gjkDist 精确判定）
%    · 介质与带电面 X=±5000：距离 <= 1.8nm 视为导通
%    · BFS：找 左带电面 → 右带电面 的完整通路并输出沿途距离
%  依赖：gjkDist.m、segSegDist.m（同目录）；附件.xlsx（运行目录）
%  运行：在附件所在目录直接运行 Q1_nochain
%  输出：命令行报告每组是否导通；并调用 plot_Q1.m 输出三维构型图
%% ============================================================

clear; clc; close all;
R = 30; TOL = 1.8; BOX = 5000;

groups = {'组1', '组2', '组3'};
results = cell(3, 1);

for g = 1:3
    name = groups{g};
    fprintf('\n%s\n', repmat('=', 1, 68));
    fprintf(' 微构体 %s', name);

    % ---------- 读数据 ----------
    raw = readmatrix('附件.xlsx', 'Sheet', name);
    raw = raw(~any(isnan(raw), 2), :);
    V1 = raw(:, 1:3);  V2 = raw(:, 4:6);
    len = sqrt(sum((V1 - V2).^2, 2));
    if any(len < 1e-9)
        fprintf('（剔除 %d 个零长度伪行）', sum(len < 1e-9));
        V1 = V1(len >= 1e-9, :);  V2 = V2(len >= 1e-9, :);
    end
    n = size(V1, 1);
    fprintf('：共 %d 个介质\n', n);
    fprintf('%s\n', repmat('-', 1, 68));

    % ---------- 圆柱参数 ----------
    cyl = cell(n, 1);
    for i = 1:n
        ax = V2(i,:)' - V1(i,:)'; L = norm(ax);
        if L < 1e-12
            cyl{i} = struct('c', V1(i,:)', 'u', [1;0;0], 'h', 0, 'r', R);
        else
            cyl{i} = struct('c', (V1(i,:)'+V2(i,:)')/2, 'u', ax/L, 'h', L/2, 'r', R);
        end
    end

    % ---------- 介质-带电面距离 ----------
    dL = zeros(n, 1);  dR = zeros(n, 1);
    for i = 1:n
        ux = cyl{i}.u(1);
        reach = R * sqrt(max(0, 1 - ux^2));
        dL(i) = max(0, min(V1(i,1), V2(i,1)) + BOX - reach);
        dR(i) = max(0, BOX - max(V1(i,1), V2(i,1)) - reach);
    end

    % ---------- 导通边（介质-介质：精确距离；介质-面） ----------
    LEFT = n + 1;  RIGHT = n + 2;
    eF = []; eT = []; eD = [];
    nNear = 0;                       % 需要精确计算的近邻对
    for i = 1:n-1
        for j = i+1:n
            dcap = max(0, segSegDist(V1(i,:)', V2(i,:)', V1(j,:)', V2(j,:)') - 2*R);
            if dcap <= TOL            % 胶囊下界 <= 1.8 才可能导通（下界>1.8 必不导通）
                nNear = nNear + 1;
                d = gjkDist(cyl{i}, cyl{j});
                if d <= TOL
                    eF(end+1) = i; eT(end+1) = j; eD(end+1) = d; %#ok<AGROW>
                end
            end
        end
    end
    nMedEdge = numel(eD);
    for i = 1:n
        if dL(i) <= TOL, eF(end+1) = i; eT(end+1) = LEFT;  eD(end+1) = dL(i); end %#ok<AGROW>
        if dR(i) <= TOL, eF(end+1) = i; eT(end+1) = RIGHT; eD(end+1) = dR(i); end %#ok<AGROW>
    end

    % ---------- 邻接表 + BFS 找通路 ----------
    adj = cell(n+2, 1);
    for k = 1:numel(eF)
        adj{eF(k)} = [adj{eF(k)}; eT(k) k]; %#ok<AGROW>
        adj{eT(k)} = [adj{eT(k)}; eF(k) k]; %#ok<AGROW>
    end
    [seq, dists] = findPathBFS(adj, eD, LEFT, RIGHT);

    % ---------- 输出 ----------
    lList = find(dL <= TOL);  rList = find(dR <= TOL);
    fprintf(' 与左带电面导通：%d 个介质：%s\n', numel(lList), fmtList(lList, 12));
    fprintf(' 与右带电面导通：%d 个介质：%s\n', numel(rList), fmtList(rList, 12));
    fprintf(' 介质间导通边：%d 条（精确距离 <= %.1f nm；需精确计算的近邻对 %d 个）\n', nMedEdge, TOL, nNear);

    if ~isempty(seq)
        fprintf(' >>> 判定：导 通\n');
        fprintf(' 完整通路（左带电面 → 右带电面，共 %d 个介质，括号内为相邻距离/nm）：\n', numel(seq)-2);
        fprintf('   左带电面');
        for k = 2:numel(seq)-1
            fprintf(' --(%.3f)--> A%d', dists(k-1), seq(k));
        end
        fprintf(' --(%.3f)--> 右带电面\n', dists(end));
        role = zeros(n, 1); role(seq(2:end-1)) = 1;
        bestPair = []; bestD = inf;
    else
        fprintf(' >>> 判定：不导通\n');
        visitedL = reachable(adj, LEFT);
        visitedR = reachable(adj, RIGHT);
        Lcomp = find(visitedL(1:n));  Rcomp = find(visitedR(1:n));
        fprintf(' 左组件介质：%s\n', fmtList(Lcomp, 20));
        fprintf(' 右组件介质：%s\n', fmtList(Rcomp, 20));
        % 左右组件之间的最近距离（精确）
        bestD = inf; bestPair = [];
        for i = Lcomp(:).'   % 转置后变列向量，for 只循环一次且 i 为整个向量；用 (:).' 展平
            for j = Rcomp(:).'
                dcap = max(0, segSegDist(V1(i,:)', V2(i,:)', V1(j,:)', V2(j,:)') - 2*R);
                if dcap < bestD
                    d = gjkDist(cyl{i}, cyl{j});
                    if d < bestD, bestD = d; bestPair = [i j]; end
                end
            end
        end
        fprintf(' 两组件最近距离：A%d 与 A%d 之间 = %.3f nm（> %.1f nm，故不导通）\n', ...
            bestPair(1), bestPair(2), bestD, TOL);
        role = zeros(n, 1); role(Lcomp) = 1; role(Rcomp) = 2;
    end

    results{g} = struct('name', name, 'V1', V1, 'V2', V2, 'n', n, ...
        'role', role, 'seq', seq, 'dists', dists, ...
        'connected', ~isempty(seq), 'bestPair', bestPair, 'bestD', bestD, ...
        'dL', dL, 'dR', dR);
end

%% ---------- 绘图 ----------
for g = 1:3
    plot_Q1(results{g});
end
fprintf('\n完成：三维构型图与结果图已生成（保存为 fig_g*_*.pdf，矢量）。\n');

%% ---------------- 局部函数 ----------------
function [seq, dists] = findPathBFS(adj, eD, LEFT, RIGHT)
% BFS 找 LEFT -> RIGHT 的一条通路；返回节点序列与相邻边距离
N = numel(adj);
visited = false(1, N); parent = zeros(1, N); pEdge = zeros(1, N);
q = LEFT; visited(LEFT) = true; found = false;
while ~isempty(q) && ~found
    cur = q(1); q(1) = [];
    for k = 1:size(adj{cur}, 1)
        nb = adj{cur}(k, 1); ei = adj{cur}(k, 2);
        if ~visited(nb)
            visited(nb) = true; parent(nb) = cur; pEdge(nb) = ei;
            q(end+1) = nb; %#ok<AGROW>
            if nb == RIGHT, found = true; break; end
        end
    end
end
if ~found
    seq = []; dists = []; return;
end
seq = RIGHT;
while seq(1) ~= LEFT
    seq = [parent(seq(1)), seq]; %#ok<AGROW>
end
dists = eD(pEdge(seq(2:end)));
end

function visited = reachable(adj, start)
N = numel(adj);
visited = false(1, N); q = start; visited(start) = true;
while ~isempty(q)
    cur = q(1); q(1) = [];
    for k = 1:size(adj{cur}, 1)
        nb = adj{cur}(k, 1);
        if ~visited(nb), visited(nb) = true; q(end+1) = nb; end %#ok<AGROW>
    end
end
end

function s = fmtList(v, cap)
if isempty(v)
    s = '';
elseif numel(v) <= cap
    s = strjoin(arrayfun(@(x) sprintf('A%d', x), v, 'UniformOutput', false), ', ');
else
    s = [strjoin(arrayfun(@(x) sprintf('A%d', x), v(1:cap), 'UniformOutput', false), ', ') ...
        sprintf(', …（共 %d 个）', numel(v))];
end
end
