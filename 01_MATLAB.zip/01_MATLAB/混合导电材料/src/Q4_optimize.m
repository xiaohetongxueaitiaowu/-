%% ======================= 问题 4 =======================
%% Q4_optimize.m —— 网格法求"p>=90% 且总成本最低"的混合方案
%  ------------------------------------------------------------
%  模型：A（1.05元/μm³ 圆柱 r=30,h=5000）+ B（0.05元/μm³ 球 r=200）；
%    对给定 N_A，用 runSequenceQ4 的共享序列求 90% 分位 K90，
%    所需 B 数 N_B = max(0, K90 - N_A)，成本 C = N_A·c_A + N_B·c_B。
%  策略：粗筛 N_A=0:25:600（M1=600）定位 → 细筛步长 3（M2=1000）精确定优。
%  依赖：runSequenceQ4.m、cylDistLE.m（同目录）。
%  运行：直接运行 Q4_optimize（结果缓存于 fig_Q4_data.mat，可复用）。
%  输出：最优 (N_A*, N_B*) 与成本；fig_Q4_cost.pdf、fig_Q4_design.pdf。
%% ============================================================

clc;
RA = 30; H = 5000; RB = 200; HW = 5000; TOL = 1.8;
V_A = pi*RA^2*H;  V_B = (4/3)*pi*RB^3;
c_A = 1.05 * V_A/1e9;      % 元/个（nm^3 -> um^3）
c_B = 0.05 * V_B/1e9;
NBMAX = 25000;
if ~exist('M1','var'), M1 = 600; end      % 粗筛实验次数
if ~exist('M2','var'), M2 = 1000; end     % 细筛实验次数
if isempty(gcp('nocreate')), parpool('local', 8); end
fn = 'Hiragino Sans GB';
fprintf('c_A = %.6f 元/个，c_B = %.6f 元/个\n\n', c_A, c_B);

% ============ 阶段1：粗筛 N_A = 0:25:600（缓存复用） ============
dataFile = 'fig_Q4_data.mat';
NA1 = 0:25:600;
reuseCoarse = false;
if exist(dataFile,'file')
    S4 = load(dataFile);
    if isfield(S4,'M1') && S4.M1 == M1 && isfield(S4,'NA1') && isfield(S4,'K1')
        K1 = S4.K1; reuseCoarse = true;
        fprintf('复用粗筛缓存（M1=%d）\n', M1);
    end
end
if ~reuseCoarse
    K1 = zeros(1,numel(NA1));
    parfor i = 1:numel(NA1)
        k = zeros(M1,1);
        for m = 1:M1
            rng(90000 + i*100000 + m);
            k(m) = runSequenceQ4(NA1(i), NBMAX, RA, H, RB, HW, TOL);
        end
        ks = sort(k);
        K1(i) = ks(min(M1, max(1, ceil(0.9*(M1+1)))));   % 无偏 90% 分位
    end
    if exist(dataFile,'file')
        save(dataFile,'NA1','K1','M1','-append');
    else
        save(dataFile,'NA1','K1','M1');
    end
end
nB1 = max(0, K1 - NA1);
C1 = NA1*c_A + nB1*c_B;
fprintf('===== 粗筛（M=%d，步长25，N_A 0~600） =====\n', M1);
for i = 1:numel(NA1)
    fprintf('  N_A=%4d: 90%%分位K=%6.0f, 需B=%6.0f, 成本=%.3f 元\n', NA1(i), K1(i), nB1(i), C1(i));
end
[~, ib] = min(C1);
fprintf('粗筛最低成本点：N_A=%d，成本 %.3f 元\n\n', NA1(ib), C1(ib));

% ============ 阶段2：细筛最优附近（步长3） ============
NA2 = max(0, NA1(ib)-30):3:min(600, NA1(ib)+30);
K2 = zeros(1,numel(NA2));
parfor i = 1:numel(NA2)
    k = zeros(M2,1);
    for m = 1:M2
        rng(91000 + i*100000 + m);
        k(m) = runSequenceQ4(NA2(i), NBMAX, RA, H, RB, HW, TOL);
    end
    ks = sort(k);
    K2(i) = ks(min(M2, max(1, ceil(0.9*(M2+1)))));   % 无偏 90% 分位
end
nB2 = max(0, K2 - NA2);
C2 = NA2*c_A + nB2*c_B;
fprintf('===== 细筛（M=%d，步长3，N_A %d~%d） =====\n', M2, NA2(1), NA2(end));
for i = 1:numel(NA2)
    fprintf('  N_A=%4d: 90%%分位K=%6.0f, 需B=%6.0f, 成本=%.3f 元\n', NA2(i), K2(i), nB2(i), C2(i));
end
[~, ib2] = min(C2);

% ============ 汇总最优 ============
NA_all = [NA1, NA2]; K_all = [K1, K2];
nB_all = max(0, K_all - NA_all);
C_all = NA_all*c_A + nB_all*c_B;
[NA_all, oi] = sort(NA_all); K_all = K_all(oi); nB_all = nB_all(oi); C_all = C_all(oi);
[~, ibest] = min(C_all);
NA_best = NA_all(ibest); nB_best = nB_all(ibest); C_best = C_all(ibest);
fprintf('\n========== 最优方案 ==========\n');
fprintf('介质A数量 N_A* = %d，介质B数量 N_B* = %d\n', NA_best, nB_best);
fprintf('对应体积分数：A = %.4f%%，B = %.4f%%，合计 = %.4f%%\n', ...
    NA_best*V_A/1e12*100, nB_best*V_B/1e12*100, (NA_best*V_A+nB_best*V_B)/1e12*100);
fprintf('最低总成本 = %.4f 元（A 占 %.4f 元，B 占 %.4f 元）\n', ...
    C_best, NA_best*c_A, nB_best*c_B);
save(dataFile,'NA_all','nB_all','C_all','NA_best','nB_best','C_best','M2','-append');

% ============ 图（学术清爽风：白底、低饱和配色、细线、小号实心圆点） ============
C_BLUE = [0.31 0.45 0.67];  C_ORANGE = [0.87 0.55 0.33];  C_DARK = [0.25 0.25 0.25];

% 图1：成本曲线
fig1 = figure('Color','w','Position',[80 120 780 540]);
ax1 = axes('Parent',fig1,'FontName',fn);
hold(ax1,'on'); grid(ax1,'on');
ax1.GridAlpha = 0.14; ax1.GridLineStyle = ':'; ax1.Box = 'off';
plot(ax1, NA_all, C_all, '-', 'Color',C_BLUE, 'LineWidth',1.6);
plot(ax1, NA_best, C_best, 'o', 'MarkerSize',4.5, 'MarkerFaceColor',C_ORANGE, ...
    'MarkerEdgeColor',C_ORANGE);
text(ax1, NA_best, C_best+0.8, sprintf('最优 (%d, %d)，成本 %.3f 元', NA_best, nB_best, C_best), ...
    'FontSize',9, 'Color',[0.35 0.35 0.35], 'FontName',fn, 'HorizontalAlignment','center');
xlabel(ax1,'介质A数量 N_A','FontSize',12,'FontName',fn);
ylabel(ax1,'最低总成本（元）','FontSize',12,'FontName',fn);
title(ax1,'问题四：导通概率≥90% 时最低成本随 N_A 变化','FontSize',13,'FontName',fn);
set(ax1,'FontSize',10.5);
ax1.Toolbar.Visible = 'off';
exportgraphics(fig1,'fig_Q4_cost.pdf','ContentType','vector');

% 图2：设计平面（90%边界 + 等成本线 + 最优点）
fig2 = figure('Color','w','Position',[120 120 780 540]);
ax2 = axes('Parent',fig2,'FontName',fn);
hold(ax2,'on'); grid(ax2,'on');
ax2.GridAlpha = 0.14; ax2.GridLineStyle = ':'; ax2.Box = 'off';
plot(ax2, NA_all, nB_all, '-', 'Color',C_BLUE, 'LineWidth',1.6);
for fac = [0.9 1.0 1.15]
    NBline = (C_best*fac - NA_all*c_A)/c_B;
    ok = NBline >= 0;
    plot(ax2, NA_all(ok), NBline(ok), '--', 'Color',[0.72 0.55 0.40], 'LineWidth',0.9);
end
plot(ax2, NA_best, nB_best, 'o', 'MarkerSize',4.5, 'MarkerFaceColor',C_ORANGE, ...
    'MarkerEdgeColor',C_ORANGE);
% 标注放在最优点上方空白区（该处无任何曲线经过）
text(ax2, NA_best, nB_best+1800, sprintf('最优点 (%d, %d)，成本 %.3f 元', NA_best, nB_best, C_best), ...
    'FontSize',9, 'Color',[0.35 0.35 0.35], 'FontName',fn, 'HorizontalAlignment','center');
xlabel(ax2,'介质A数量 N_A','FontSize',12,'FontName',fn);
ylabel(ax2,'介质B数量 N_B','FontSize',12,'FontName',fn);
title(ax2,'问题四：90% 导通边界与等成本线','FontSize',13,'FontName',fn);
set(ax2,'FontSize',10.5);
legend(ax2,{'90% 导通边界 N_B*(N_A)','等成本线','最优点'}, ...
    'Location','northeast','FontSize',9.5,'Box','off','FontName',fn);
ax2.Toolbar.Visible = 'off';
exportgraphics(fig2,'fig_Q4_design.pdf','ContentType','vector');
fprintf('图已保存：fig_Q4_cost、fig_Q4_design（PDF）。\n');
