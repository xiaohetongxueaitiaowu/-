%% ==================== 问题 2 / 4 =====================
%% cylDistLE.m —— 批量判定"平底圆柱间距离 <= tol"（GJK 阈值版）
%  ------------------------------------------------------------
%  方法：与 gjkDist 相同的 GJK，但只判断距离是否 <= tol（simplex
%    距离达到 tol 即返回 true，可提前终止，比求完整距离更快）。
%    同时支持一个圆柱 vs 一组圆柱的批量判定（数组化）。
%  用途：Q2（runSequence 段-段导通边）与 Q4（A 段-段）的快速连通判定。
%  依赖：无。
%  输出：逻辑数组 ok（true = 距离 <= tol）。
%% ============================================================

function ok = cylDistLE(c1, u1, h1, r1, c2, u2, h2, r2, tol)
%CYLDistLE  判断两个平底圆柱的最短距离是否 <= tol（GJK，数组实现 + 提前终止）。
%   只回答"是/否"，用于蒙特卡洛中的导通判定：
%   - 迭代中 simplex 最近点距离 |q| <= tol 时，由于 dist(0,K) <= |q|，
%     可直接判定"导通"提前返回（无需收敛到机器精度）；
%   - 相交（原点进入四面体）立即返回 true；
%   - 收敛且 |q| > tol 返回 false。
%   输入均为列向量/标量：中心 c、单位轴 u、半高 h、半径 r。
if nargin < 9, tol = 1.8; end

S = zeros(3,4);           % simplex（最多4点）
d = c2 - c1;
if d'*d < 1e-30, d = [1;0;0]; end
S(:,1) = cylSup(c1,u1,h1,r1,d) - cylSup(c2,u2,h2,r2,-d);
k = 1;
d = -S(:,1);
for it = 1:150
    dd = d'*d;
    if dd <= tol*tol, ok = true;  return; end   % 上界 <= tol：导通
    if dd < 1e-24,    ok = true;  return; end   % 原点在 simplex 内：相交
    p = cylSup(c1,u1,h1,r1,d) - cylSup(c2,u2,h2,r2,-d);
    if dd + p'*d <= 1e-14*max(1,dd), ok = false; return; end  % 收敛且 > tol
    k = k + 1; S(:,k) = p;
    if k == 2
        a = S(:,1); b = S(:,2); ab = b - a;
        tt = -(a'*ab)/(ab'*ab);
        if tt <= 0, q = a; S(:,1) = a; k = 1;
        elseif tt >= 1, q = b; S(:,1) = b; k = 1;
        else, q = a + tt*ab; end
    elseif k == 3
        [q, feat] = closestTri(S(:,1), S(:,2), S(:,3));
        switch feat
            case 0, S(:,1) = S(:,1); k = 1;
            case 1, S(:,1) = S(:,2); k = 1;
            case 2, k = 2;
            case 3, S(:,1) = S(:,3); k = 1;
            case 4, S(:,2) = S(:,3); k = 2;
            case 5, S(:,1) = S(:,2); S(:,2) = S(:,3); k = 2;
            case 6, k = 3;
        end
    else
        a = S(:,1); b = S(:,2); c = S(:,3); dd4 = S(:,4);
        if tetraInOrigin(a,b,c,dd4), ok = true; return; end
        F = cat(3, [a b c], [a c dd4], [a dd4 b], [b dd4 c]);
        best = inf; bestF = 1;
        for f = 1:4
            [qq, feat] = closestTri(F(:,1,f), F(:,2,f), F(:,3,f));
            if qq'*qq < best
                best = qq'*qq; q = qq; bestF = f;
                switch feat
                    case 0, keep = 1; sel = 1;
                    case 1, keep = 1; sel = 2;
                    case 2, keep = 2; sel = [1 2];
                    case 3, keep = 1; sel = 3;
                    case 4, keep = 2; sel = [1 3];
                    case 5, keep = 2; sel = [2 3];
                    case 6, keep = 3; sel = [1 2 3];
                end
            end
        end
        S(:,1:keep) = F(:,sel,bestF); k = keep;
    end
    d = -q;
end
ok = (d'*d <= tol*tol);
end

function p = cylSup(c, u, h, r, d)
% 平底圆柱支撑点（闭式）：端面边缘圆环或侧面
ud = d'*u;
if abs(ud) > 1e-30
    p = c + sign(ud)*h*u;
else
    p = c;
end
du = d - ud*u;
nd = norm(du);
if nd > 1e-30
    p = p + r*du/nd;
end
end

function [q, feat] = closestTri(a, b, c)
% 原点到三角形 abc 的最近点（Ericson），feat 标记特征
p = zeros(3,1);
ab = b - a; ac = c - a; ap = p - a;
d1 = ab'*ap; d2 = ac'*ap;
if d1 <= 0 && d2 <= 0, q = a; feat = 0; return; end
bp = p - b;
d3 = ab'*bp; d4 = ac'*bp;
if d3 >= 0 && d4 <= d3, q = b; feat = 1; return; end
vc = d1*d4 - d3*d2;
if vc <= 0 && d1 >= 0 && d3 <= 0
    v = d1/(d1 - d3); q = a + v*ab; feat = 2; return;
end
cp = p - c;
d5 = ab'*cp; d6 = ac'*cp;
if d6 >= 0 && d5 <= d6, q = c; feat = 3; return; end
vb = d5*d2 - d1*d6;
if vb <= 0 && d2 >= 0 && d6 <= 0
    w = d2/(d2 - d6); q = a + w*ac; feat = 4; return;
end
va = d3*d6 - d5*d4;
if va <= 0 && (d4-d3) >= 0 && (d5-d6) >= 0
    w = (d4-d3)/((d4-d3)+(d5-d6)); q = b + w*(c-b); feat = 5; return;
end
denom = 1/(va+vb+vc);
v = vb*denom; w = vc*denom;
q = a + ab*v + ac*w; feat = 6;
end

function in = tetraInOrigin(a, b, c, d)
s0 = det([b c d]); s1 = det([a d c]);
s2 = det([a b d]); s3 = det([a c b]);
eps0 = 1e-14;
in = ~(any([s0 s1 s2 s3] > eps0) && any([s0 s1 s2 s3] < -eps0));
end
