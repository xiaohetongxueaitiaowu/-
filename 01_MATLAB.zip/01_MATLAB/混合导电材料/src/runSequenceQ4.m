%% ======================= 问题 4 =======================
%% runSequenceQ4.m —— Q4 单次实验内核（增量投掷：A 折回 + B 逐球）
%  ------------------------------------------------------------
%  流程：N_A 根介质A（折回成段、段独立）一次性加入 → 逐个投掷 B 球
%    （球心均匀于 [-4800,4800]^3，软球允许重叠）→ 逐单位激活并查集；
%    首次连通 左带电面↔右带电面 的投掷单位序号即 k*（未通返回 inf）。
%  要点：球-球连接半径 2R_B+1.8；球-柱 <= R_B+R_A+1.8；cell list 加速；
%    k* 提前终止省算力；P(N_A, n) = P(k* <= N_A+n)。
%  依赖：cylDistLE.m、segSegDist.m（同目录）。
%  输出：k*（首次导通单位序号，或 inf）。
%% ============================================================

function kstar = runSequenceQ4(N_A, N_Bmax, RA, H, RB, HW, TOL)
%RUNSEQUENCEQ4 问题4单次实验（增量版）：N_A 根介质A（折回，段独立）+ 最多 N_Bmax 个介质B。
%   固定顺序：全部 A 根（每根的段同时加入）→ 逐个 B 球；逐单位增量并查集，
%   首次使左右带电面连通的"投掷单位序号"即 k*（A 根 1..N_A，B 球 N_A+1..；未通返回 inf）。
%   p(N_A, n) = P(k* <= N_A + n)，90% 分位直接给出所需 B 数。
%   增量实现：球逐颗生成并只与已投介质判定，k* 提前终止可省掉后续全部计算。
RA = 30; RB = 200; TOL = 1.8; HW = 5000; H = 5000;

% ---------- 1. 介质A：生成 + 折回（向量化） ----------
C = 2*HW*rand(3,N_A) - HW;
U = randn(3,N_A); U = U ./ sqrt(sum(U.^2,1));
V1 = C - (H/2)*U;  V2 = C + (H/2)*U;
D = V2 - V1;
[t1v, t2v] = clipSegVec(V1, V2, HW);
maxSegA = 3*N_A;
segs = zeros(maxSegA, 6); ownA = zeros(maxSegA, 1); SA = 0;
mk = t2v > t1v + 1e-9;
if any(mk)
    idx = find(mk); p1 = V1(:,mk) + t1v(mk).*D(:,mk); p2 = V1(:,mk) + t2v(mk).*D(:,mk);
    nn = numel(idx); segs(SA+1:SA+nn,:) = [p1; p2]'; ownA(SA+1:SA+nn) = idx; SA = SA + nn;
end
mk = t1v > 1e-9;
if any(mk)
    idx = find(mk); p1 = V1(:,mk); p2 = V1(:,mk) + t1v(mk).*D(:,mk);
    [q1,q2] = shiftSegmentVec(p1,p2,HW); [a,b] = clipSegVec(q1,q2,HW);
    m2 = b > a + 1e-9;
    if any(m2)
        pp1 = q1(:,m2) + a(m2).*(q2(:,m2)-q1(:,m2)); pp2 = q1(:,m2) + b(m2).*(q2(:,m2)-q1(:,m2));
        nn = sum(m2); segs(SA+1:SA+nn,:) = [pp1; pp2]'; ownA(SA+1:SA+nn) = idx(m2); SA = SA + nn;
    end
end
mk = t2v < 1 - 1e-9;
if any(mk)
    idx = find(mk); p1 = V1(:,mk) + t2v(mk).*D(:,mk); p2 = V2(:,mk);
    [q1,q2] = shiftSegmentVec(p1,p2,HW); [a,b] = clipSegVec(q1,q2,HW);
    m2 = b > a + 1e-9;
    if any(m2)
        pp1 = q1(:,m2) + a(m2).*(q2(:,m2)-q1(:,m2)); pp2 = q1(:,m2) + b(m2).*(q2(:,m2)-q1(:,m2));
        nn = sum(m2); segs(SA+1:SA+nn,:) = [pp1; pp2]'; ownA(SA+1:SA+nn) = idx(m2); SA = SA + nn;
    end
end
segs = segs(1:SA,:); ownA = ownA(1:SA);
axA = segs(:,4:6) - segs(:,1:3); LA = sqrt(sum(axA.^2,2));
ccA = (segs(:,1:3)+segs(:,4:6))/2; uA = axA./LA; hA = LA/2;
uxA = axA(:,1)./LA;
reachA = RA*sqrt(max(0,1-uxA.^2));
dLA = max(0, min(segs(:,1),segs(:,4)) + HW - reachA);
dRA = max(0, HW - max(segs(:,1),segs(:,4)) - reachA);

% ---------- 2. A段-A段导通边（激活 = max 根号） ----------
eU = []; eV = []; eAct = [];
if SA >= 2
    loA = min(segs(:,1:3),segs(:,4:6)) - RA; hiA = max(segs(:,1:3),segs(:,4:6)) + RA;
    [ii,jj] = find(triu(true(SA),1));
    sep = max(0, loA(ii,:)-hiA(jj,:)); sep = max(sep, loA(jj,:)-hiA(ii,:));
    okA = sqrt(sum(sep.^2,2)) <= TOL + 2*RA;
    ii = ii(okA); jj = jj(okA);
    if ~isempty(ii)
        dseg = vecSegSegDistAll(segs(ii,1:3)',segs(ii,4:6)',segs(jj,1:3)',segs(jj,4:6)');
        cand = find(max(0,dseg-2*RA) <= TOL);
        if ~isempty(cand)
            okE = false(numel(cand),1);
            for kk = 1:numel(cand)
                i = ii(cand(kk)); j = jj(cand(kk));
                okE(kk) = cylDistLE(ccA(i,:)',uA(i,:)',hA(i),RA, ccA(j,:)',uA(j,:)',hA(j),RA,TOL);
            end
            eU = [eU; ii(cand(okE))]; eV = [eV; jj(cand(okE))];
            eAct = [eAct; max(ownA(ii(cand(okE))), ownA(jj(cand(okE))))];
        end
    end
end

% ---------- 3. 并查集初始化 + A 阶段激活 ----------
parent = (1:(SA + N_Bmax + 2))';
LEFT = SA + N_Bmax + 1; RIGHT = LEFT + 1;
for r = 1:N_A
    segR = find(ownA == r);
    for i = segR'
        if dLA(i) <= TOL, parent = ufUnion(parent, i, LEFT); end
        if dRA(i) <= TOL, parent = ufUnion(parent, i, RIGHT); end
    end
    if ~isempty(eU)
        for e = find(eAct == r)'
            parent = ufUnion(parent, eU(e), eV(e));
        end
    end
    if ufFind(parent, LEFT) == ufFind(parent, RIGHT)
        kstar = r; return;
    end
end

% ---------- 4. B 阶段：逐球生成 + 增量 cell list + 距离 + 激活 ----------
halfB = HW - RB;                     % 4800
Rc = 2*RB + TOL;                     % 球-球连接半径 401.8
gs = Rc;
ng = ceil(2*halfB / gs);             % 每轴格数
gridC = cell(ng,ng,ng);
Cb0 = zeros(3, N_Bmax);          % 预分配：防止偶发越界（AGROW 版在极端序列下可能读到未赋值列）
halfB2 = halfB;
for n = 1:N_Bmax
    bn = SA + n;                     % 球节点号
    % 生成球 n
    cb = 2*halfB2*rand(3,1) - halfB2;
    ix = min(ng, max(1, floor((cb(1)+halfB2)/gs) + 1));
    iy = min(ng, max(1, floor((cb(2)+halfB2)/gs) + 1));
    iz = min(ng, max(1, floor((cb(3)+halfB2)/gs) + 1));
    % 面边
    if cb(1) <= -halfB2 + TOL, parent = ufUnion(parent, bn, LEFT); end
    if cb(1) >=  halfB2 - TOL, parent = ufUnion(parent, bn, RIGHT); end
    % 球 vs 已投球（27 邻格）
    for dx = -1:1
        for dy = -1:1
            for dz = -1:1
                gx = ix+dx; gy = iy+dy; gz = iz+dz;
                if gx < 1 || gx > ng || gy < 1 || gy > ng || gz < 1 || gz > ng, continue; end
                nbrs = gridC{gx,gy,gz};
                for kk = 1:numel(nbrs)
                    m = nbrs(kk);
                    if sum((cb - Cb0(:,m)).^2) <= Rc^2
                        parent = ufUnion(parent, bn, SA + m);
                    end
                end
            end
        end
    end
    % 球 vs A 段（点到平底圆柱 <= RB+RA+TOL）
    if SA >= 1
        dvec = cb - ccA';                  % 3xSA
        t = sum(uA .* dvec', 2);           % SAx1 轴向投影
        rho = sqrt(max(0, sum(dvec.^2,1)' - t.^2));   % SAx1 径向距
        d = zeros(SA,1);
        inT = abs(t) <= hA;
        d(inT) = max(0, rho(inT) - RA);
        o1 = ~inT & t > hA;  o2 = ~inT & t < -hA;
        d(o1) = sqrt((t(o1)-hA(o1)).^2 + max(0,rho(o1)-RA).^2);
        d(o2) = sqrt((t(o2)+hA(o2)).^2 + max(0,rho(o2)-RA).^2);
        hit = find(d <= RB + RA + TOL);
        for kk = 1:numel(hit)
            parent = ufUnion(parent, bn, hit(kk));
        end
    end
    % 插入 cell list
    gridC{ix,iy,iz}(end+1) = n; %#ok<AGROW>
    Cb0(:,n) = cb; %#ok<AGROW>
    % 检查连通
    if ufFind(parent, LEFT) == ufFind(parent, RIGHT)
        kstar = N_A + n; return;
    end
end
kstar = inf;
end

%% ---------------- 局部函数 ----------------
function [t1, t2] = clipSegVec(V1, V2, HW)
D = V2 - V1;
t1 = zeros(1, size(V1,2)); t2 = ones(1, size(V1,2));
for ax = 1:3
    da = D(ax,:); va = V1(ax,:);
    par = abs(da) < 1e-12;
    out = par & (va < -HW | va > HW);
    t1(out) = 1; t2(out) = 0;
    np = ~par;
    if any(np)
        ta = (-HW - va(np))./da(np);
        tb = ( HW - va(np))./da(np);
        lo = min(ta,tb); hi = max(ta,tb);
        t1(np) = max(t1(np),lo); t2(np) = min(t2(np),hi);
    end
end
end

function [q1, q2] = shiftSegmentVec(p1, p2, HW)
cm = (p1+p2)/2; sh = zeros(size(p1));
sh = sh - 2*HW*(cm > HW) + 2*HW*(cm < -HW);
q1 = p1 + sh; q2 = p2 + sh;
end

function d = vecSegSegDistAll(P1, P2, Q1, Q2)
d1 = P2-P1; d2 = Q2-Q1; r = P1-Q1;
a = sum(d1.*d1,1); e = sum(d2.*d2,1); b = sum(d1.*d2,1);
c = sum(d1.*r,1); f = sum(d2.*r,1);
eps0 = 1e-14; dmin = inf(1, size(P1,2));
dmin = min(dmin, sqrt(sum(r.*r,1)));
dmin = min(dmin, sqrt(sum((r+d2).^2,1)));
dmin = min(dmin, sqrt(sum((r-d1).^2,1)));
dmin = min(dmin, sqrt(sum((r-d1+d2).^2,1)));
ok = e > eps0;
t = zeros(size(a)); t(ok) = f(ok)./e(ok); t = max(0,min(1,t));
dmin = min(dmin, sqrt(sum((r+t.*d2).^2,1)));
t = zeros(size(a)); t(ok) = (f(ok)+b(ok))./e(ok); t = max(0,min(1,t));
dmin = min(dmin, sqrt(sum((r-d1+t.*d2).^2,1)));
ok = a > eps0;
s = zeros(size(a)); s(ok) = -c(ok)./a(ok); s = max(0,min(1,s));
dmin = min(dmin, sqrt(sum((r+s.*d1).^2,1)));
s = zeros(size(a)); s(ok) = (b(ok)-c(ok))./a(ok); s = max(0,min(1,s));
dmin = min(dmin, sqrt(sum((r+s.*d1-d2).^2,1)));
den = a.*e-b.*b; ok3 = den > eps0;
s = zeros(size(a)); t = zeros(size(a));
s(ok3) = (b(ok3).*f(ok3)-c(ok3).*e(ok3))./den(ok3);
t(ok3) = (b(ok3).*s(ok3)+f(ok3))./e(ok3);
in = ok3 & s >= 0 & s <= 1 & t >= 0 & t <= 1;
v = r+s.*d1-t.*d2;
dmin(in) = min(dmin(in), sqrt(sum(v(:,in).^2,1)));
d = dmin;
end

function p = ufUnion(parent, a, b)
ra = ufFind(parent, a); rb = ufFind(parent, b);
if ra ~= rb, parent(ra) = rb; end
p = parent;
end

function r = ufFind(parent, x)
r = x;
while parent(r) ~= r
    parent(r) = parent(parent(r)); r = parent(r);
end
end
