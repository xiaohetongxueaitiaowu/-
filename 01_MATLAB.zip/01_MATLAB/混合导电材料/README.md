# 混合导电材料

按原目录关系保留程序、辅助函数和随附数据；独立图表统一归入 `03_论文/图表/混合导电材料`。

本次仅拆分与静态核对，未运行 MATLAB 求解，也未修改算法或补造数据。`src` 保留原程序相对目录；运行时需按脚本要求设置工作目录。

## 未随资料提供的输入或结果文件

- `src/Q1_nochain.m` 引用 `附件.xlsx`。
- `src/Q3_threshold.m` 引用 `fig_Q2_data.mat`。
- `src/Q4_GA.m` 引用 `fig_Q4_data.mat`。
- `src/plot_Q4_four.m` 引用 `fig_Q4_3000_GA.mat`。
- `src/plot_Q4_four.m` 引用 `fig_Q4_GA_data.mat`。
- `src/plot_Q4_four.m` 引用 `fig_Q4_data.mat`。
- `src/plot_Q4_four.m` 引用 `q4_landscape_data.mat`。
