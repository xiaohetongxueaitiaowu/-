using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EchoWechatDesktop {
public partial class MainForm {
    Label homeWechatHealth,homeModelHealth,homeReportHealth,adviceProgress,adviceReason;
    ComboBox adviceVariant,jsonModeChoice;
    RichTextBox adviceDiff;
    FlowLayoutPanel adviceCopyButtons;
    readonly List<Dictionary<string,object>> adviceVariants=new List<Dictionary<string,object>>();
    TableLayoutPanel adviceCompare,adviceStack;
    Panel adviceContainer,reportPreviewPanel;
    WebBrowser reportBrowser;
    string adviceOriginal="";
    bool resizingAdvice;
    double runStartedUnix;
    string lastRunFailure="";

    void BuildReliabilityUI(){
        // Compact home: the useful previews stay above the fold.
        var stack=homeContainer.Controls[0] as TableLayoutPanel;
        homeContainer.Height=690;
        int[] heights={56,8,62,10,40,68,330,10,48};
        for(int i=0;i<heights.Length;i++)stack.RowStyles[i].Height=heights[i];
        homeGreeting.Font=new Font(normal.FontFamily,15F,FontStyle.Bold);homeGreeting.Top=6;homeGreeting.Height=27;
        secretarySummary.SetBounds(22,33,980,24);
        foreach(Label metric in new[]{homeRunValue,homePeopleValue,homePendingValue,homeFeaturesValue}){
            metric.Font=new Font(normal.FontFamily,13F,FontStyle.Bold);metric.Height=24;metric.Parent.Padding=new Padding(10);
            foreach(Control heading in metric.Parent.Controls)if(heading!=metric)heading.Height=22;
        }
        homePendingValue.Parent.BackColor=Color.FromArgb(255,248,231);
        homePendingValue.ForeColor=Color.FromArgb(157,91,5);
        var health=HomeRow(3,68);stack.Controls.Add(health,0,5);
        homeWechatHealth=MakeLabel("微信读取：未检查",0,0,300,60);homeModelHealth=MakeLabel("模型：未测试",0,0,300,60);homeReportHealth=MakeLabel("简报：尚未生成",0,0,300,60);
        int column=0;foreach(Label item in new[]{homeWechatHealth,homeModelHealth,homeReportHealth}){item.Dock=DockStyle.Fill;item.Padding=new Padding(8,10,6,2);item.Margin=new Padding(0);health.Controls.Add(item,column++,0);}
        BuildAdviceComparison();BuildReportPreview();
        var setting=mainProductTabs.TabPages[0];var last=setting.Controls.Cast<Control>().OrderByDescending(c=>c.Bottom).First();
        var box=new Panel{Location=new Point(25,last.Bottom+22),Size=new Size(930,180),BackColor=Color.FromArgb(248,250,253)};
        box.Controls.Add(MakeLabel("结构化输出兼容",20,16,890,30,true));
        jsonModeChoice=MakeCombo(20,60,860,new[]{"自动检测 · 不支持结构化参数时改用提示词JSON","仅提示词JSON · 用于不支持结构化参数的模型"});box.Controls.Add(jsonModeChoice);
        box.Controls.Add(MakeLabel("格式错误时仅修复一次；连接失败或输出截断不会盲目重试。失败保留旧结果，首页显示最近连接情况。关闭分析或屏蔽会话时，消息建议只使用你填写的原稿与要求。",20,108,890,58));setting.Controls.Add(box);
    }
    void BuildAdviceComparison(){
        var page=mainProductTabs.TabPages[10];page.Controls.Clear();readingHeights.Remove(advisorResults);
        adviceContainer=new Panel{Dock=DockStyle.Top,Height=1040,Padding=new Padding(24,12,12,24)};page.Controls.Add(adviceContainer);
        adviceStack=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=9,Margin=new Padding(0)};adviceStack.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
        foreach(int h in new[]{34,46,410,48,28,84,46,42,260})adviceStack.RowStyles.Add(new RowStyle(SizeType.Absolute,h));adviceContainer.Controls.Add(adviceStack);
        var heading=MakeLabel("消息建议 · 原稿与方案并排对照",0,0,900,32,true);heading.Dock=DockStyle.Fill;adviceStack.Controls.Add(heading,0,0);
        var toolbar=HomeRow(3,46);toolbar.ColumnStyles.Clear();toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,60));toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,20));toolbar.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,20));
        advisorContact.Dock=DockStyle.Fill;advisorContact.Margin=new Padding(0,6,12,8);toolbar.Controls.Add(advisorContact,0,0);
        HomeLink(toolbar,1,"导入好友",()=>{var ignored=ReadContactCatalog("friend");});HomeLink(toolbar,2,"导入群",()=>{var ignored=ReadContactCatalog("group");});adviceStack.Controls.Add(toolbar,0,1);
        adviceCompare=HomeRow(2,410);
        var original=HomeCard("我的原稿 · 可以继续编辑");advisorDraft.Dock=DockStyle.Fill;advisorDraft.BorderStyle=BorderStyle.None;advisorDraft.ScrollBars=ScrollBars.None;original.Controls.Add(advisorDraft);advisorDraft.BringToFront();adviceCompare.Controls.Add(original,0,0);
        var suggestion=HomeCard("AI 方案 · 不覆盖原稿");var choose=new Panel{Dock=DockStyle.Top,Height=38};
        adviceVariant=MakeCombo(0,2,350,new[]{"尚未生成建议"});adviceVariant.Dock=DockStyle.Fill;choose.Controls.Add(adviceVariant);suggestion.Controls.Add(choose);
        adviceReason=MakeLabel("生成后这里显示修改理由和原意核验。",0,0,500,76);adviceReason.Dock=DockStyle.Bottom;suggestion.Controls.Add(adviceReason);
        advisorResults.Dock=DockStyle.Fill;advisorResults.ScrollBars=RichTextBoxScrollBars.None;suggestion.Controls.Add(advisorResults);advisorResults.BringToFront();adviceCompare.Controls.Add(suggestion,1,0);adviceStack.Controls.Add(adviceCompare,0,2);
        adviceCopyButtons=new FlowLayoutPanel{Dock=DockStyle.Top,Height=44,WrapContents=true,AutoScroll=false,Padding=new Padding(0,4,0,0)};suggestion.Controls.Add(adviceCopyButtons);adviceStack.RowStyles[3].Height=0;
        var suggestionHeading=suggestion.Controls.Cast<Control>().First(c=>c is Label&&c.Text.StartsWith("AI 方案"));suggestion.Controls.SetChildIndex(advisorResults,0);suggestion.Controls.SetChildIndex(adviceReason,1);suggestion.Controls.SetChildIndex(adviceCopyButtons,2);suggestion.Controls.SetChildIndex(choose,3);suggestion.Controls.SetChildIndex(suggestionHeading,4);
        adviceStack.Controls.Add(MakeLabel("补充要求 · 不改变事实、条件和承诺程度",0,0,900,28),0,4);
        advisorRequirements.Dock=DockStyle.Fill;advisorRequirements.Margin=new Padding(0,0,14,8);adviceStack.Controls.Add(advisorRequirements,0,5);
        var actions=HomeRow(2,46);advisorGenerate.Dock=DockStyle.Fill;advisorGenerate.Margin=new Padding(0,4,14,4);actions.Controls.Add(advisorGenerate,0,0);HomeLink(actions,1,"和 AI 讨论修改要求",()=>OpenFeatureDialogue("adviser"));adviceStack.Controls.Add(actions,0,6);
        adviceProgress=MakeLabel("尚未生成。选择联系人并写原稿。不会自动发送微信。",0,0,900,40);adviceProgress.Dock=DockStyle.Fill;adviceStack.Controls.Add(adviceProgress,0,7);
        var differences=HomeCard("具体修改 · 红色为删改的原文，绿色为新增表达");adviceDiff=new EchoReadingBox{Dock=DockStyle.Fill,ReadOnly=true,ScrollBars=RichTextBoxScrollBars.None,BorderStyle=BorderStyle.None,DetectUrls=false};differences.Controls.Add(adviceDiff);adviceDiff.BringToFront();adviceStack.Controls.Add(differences,0,8);
        adviceVariant.SelectedIndexChanged+=delegate{ShowAdviceVariant();};
        advisorDraft.TextChanged+=delegate{if(adviceVariants.Count>0&&advisorDraft.Text!=adviceOriginal){adviceProgress.Text="原稿已改变；旧方案仅供对照，请重新生成后再使用。";adviceProgress.ForeColor=Color.FromArgb(166,85,10);foreach(Control c in adviceCopyButtons.Controls)c.Enabled=false;}ResizeAdviceComparison();};
        advisorContact.SelectedIndexChanged+=delegate{if(!populatingAdvisor){ClearAdviceVariants();}};
        advisorResults.ContentsResized+=delegate{ResizeAdviceComparison();};adviceCompare.Resize+=delegate{ResizeAdviceComparison();};
        adviceDiff.ContentsResized+=delegate(object sender,ContentsResizedEventArgs e){int index=adviceStack.RowCount>9?11:8;float height=Math.Max(UiPixel(220),Math.Min(30000,e.NewRectangle.Height+UiPixel(100)));if(Math.Abs(adviceStack.RowStyles[index].Height-height)>1){adviceStack.RowStyles[index].Height=height;ResizeAdviceComparison();}};
        Shown+=delegate{ResizeAdviceComparison();};
    }
    void ResizeAdviceComparison(){
        if(resizingAdvice||adviceCompare==null||!IsHandleCreated)return;resizingAdvice=true;
        try{int width=Math.Max(100,advisorDraft.ClientSize.Width-UiPixel(24));int first=TextRenderer.MeasureText(advisorDraft.Text+"\n",normal,new Size(width,100000),TextFormatFlags.WordBreak|TextFormatFlags.TextBoxControl).Height;int second=TextRenderer.MeasureText(advisorResults.Text+"\n",readingFont,new Size(width,100000),TextFormatFlags.WordBreak|TextFormatFlags.TextBoxControl).Height;
            int height=Math.Max(UiPixel(400),Math.Min(UiPixel(8000),Math.Max(first+UiPixel(120),second)+UiPixel(210)));adviceStack.RowStyles[adviceStack.RowCount>9?5:2].Height=height;adviceContainer.Height=(int)Math.Ceiling(adviceStack.RowStyles.Cast<RowStyle>().Sum(x=>x.Height))+adviceContainer.Padding.Vertical+UiPixel(8);
        }finally{resizingAdvice=false;}
    }
    void ClearAdviceVariants(){adviceVariants.Clear();if(adviceVariant==null)return;adviceVariant.Items.Clear();adviceVariant.Items.Add("尚未生成建议");adviceVariant.SelectedIndex=0;while(adviceCopyButtons.Controls.Count>0)adviceCopyButtons.Controls[0].Dispose();adviceDiff.Clear();adviceReason.Text="选择联系人并生成方案。";adviceProgress.Text="旧联系人建议已清除。";}
    void DisplayAdvice(Dictionary<string,object> result,string original){
        ClearAdviceVariants();adviceOriginal=original;adviceVariant.Items.Clear();
        foreach(object obj in (IList)result["variants"]){var item=obj as Dictionary<string,object>;if(item==null)continue;int index=adviceVariants.Count;adviceVariants.Add(item);adviceVariant.Items.Add(Str(item,"title"));var copy=MakeButton("复制 · "+Str(item,"title"),0,0,UiPixel(120),UiPixel(32));copy.Margin=new Padding(0,0,UiPixel(8),0);copy.Click+=delegate{if(advisorDraft.Text!=adviceOriginal){status.Text="原稿已经修改，请先重新生成。";return;}Clipboard.SetText(Str(adviceVariants[index],"text"));status.Text="已复制“"+Str(adviceVariants[index],"title")+"”正文，未包含修改理由。";};adviceCopyButtons.Controls.Add(copy);}
        adviceCopyButtons.Height=UiPixel(adviceVariants.Count>3?80:44);
        if(adviceVariants.Count>0)adviceVariant.SelectedIndex=0;
        var rejected=result.ContainsKey("rejectedVariants")?result["rejectedVariants"] as IList:null;
        ShowAdviceContext(result);
        adviceProgress.Text=(Bool(result,"cached",false)?"已读取核验缓存。":"生成与核验已完成。")+" "+Str(result,"referenceMode")+((rejected!=null&&rejected.Count>0)?"；"+rejected.Count+" 个方案因原意不符被移除。":"")+" 最终请你确认。";adviceProgress.ForeColor=muted;
        ResizeAdviceComparison();
    }
    void ShowAdviceVariant(){if(adviceVariant==null||adviceVariant.SelectedIndex<0||adviceVariant.SelectedIndex>=adviceVariants.Count)return;var item=adviceVariants[adviceVariant.SelectedIndex];SetReading(advisorResults,Str(item,"text"));adviceReason.Text="修改理由："+Str(item,"reason")+"\r\n原意核验："+(Str(item,"meaningCheck").Length==0?"请核对原意":Str(item,"meaningCheck"));
        adviceDiff.Clear();adviceDiff.Font=normal;adviceDiff.SelectionColor=muted;adviceDiff.AppendText("修改理由："+Str(item,"reason")+"\n原意核验："+Str(item,"meaningCheck")+"\n\n");var changes=item.ContainsKey("changes")?item["changes"] as IList:null;if(changes==null||changes.Count==0){adviceDiff.AppendText(Str(item,"text")==adviceOriginal?"方案与原稿相同。":"本次方案没有逐段变更数据；请并排核对。");return;}
        foreach(object obj in changes){var change=obj as Dictionary<string,object>;if(change==null)continue;string before=Str(change,"before"),after=Str(change,"after");if(before.Length>0){adviceDiff.SelectionColor=Color.FromArgb(173,48,58);adviceDiff.AppendText("原文："+before+"\n");}if(after.Length>0){adviceDiff.SelectionColor=Color.FromArgb(0,119,93);adviceDiff.AppendText("改为："+after+"\n");}adviceDiff.AppendText("\n");}adviceDiff.Select(0,0);adviceDiff.ScrollToCaret();}
    Dictionary<string,object> LocalHealth(string filename){try{var path=Path.Combine(settingsDir,filename);return File.Exists(path)?json.Deserialize<Dictionary<string,object>>(File.ReadAllText(path,Encoding.UTF8)):new Dictionary<string,object>();}catch{return new Dictionary<string,object>();}}
    static double HealthNumber(Dictionary<string,object> data,string name){double n;return Double.TryParse(Str(data,name),out n)?n:0;}
    static string HealthTime(double stamp){return stamp<=0?"尚无成功记录":DateTimeOffset.FromUnixTimeSeconds((long)stamp).LocalDateTime.ToString("MM-dd HH:mm:ss");}
    static bool HealthProcessAlive(Dictionary<string,object> data){try{using(var process=System.Diagnostics.Process.GetProcessById(Int(data,"pid",0)))return !process.HasExited;}catch{return false;}}
    bool RefreshHealthSummary(){
        if(homeWechatHealth==null)return false;double now=DateTimeOffset.Now.ToUnixTimeSeconds();bool error=false;
        var read=LocalHealth("bridge-state.json");var archive=LocalHealth("health-archive.json");double readAt=Math.Max(HealthNumber(read,"lastReadAt"),HealthNumber(archive,"lastReadAt"));
        bool replies=bridge!=null&&!bridge.HasExited;bool live=replies?Int(read,"pid",0)==bridge.Id&&Str(read,"status")=="listening"&&now-HealthNumber(read,"updatedAt")<35&&HealthNumber(read,"lastReadAt")>=runStartedUnix&&HealthNumber(read,"lastReadAt")>0:runActive&&HealthNumber(archive,"lastReadAt")>=runStartedUnix&&now-HealthNumber(archive,"lastReadAt")<360;
        var wechatState=LocalHealth("health-wechat.json");bool wechatFailed=runActive&&HealthNumber(wechatState,"updatedAt")>=runStartedUnix&&Str(wechatState,"status")=="error";
        bool readError=wechatFailed||replies&&Str(read,"status")=="read_error"||HealthNumber(archive,"updatedAt")>=runStartedUnix&&Str(archive,"status")=="error";
        string wechat=!runActive?"已停止":readError?"读取失败":live?"读取正常":readAt>0?"读取未确认 / 已过期":"等待首次读取";
        bool connecting=runActive&&!live&&!readError&&now-runStartedUnix<60;
        if(connecting)wechat="正在连接 / 等待首次读取";
        string connection=ConnectionPhase(runActive,checkingWechatConnection||localConnectionBusy,live,readError,now-runStartedUnix,localConnectionPhase);
        if(runActive&&!localConnectionBusy&&!checkingWechatConnection)localConnectionPhase=connection;
        homeWechatHealth.Text="微信连接 · "+connection+"\r\n"+wechat+" · "+HealthTime(readAt);homeWechatHealth.ForeColor=connection=="连接失败"?Color.FromArgb(176,50,62):connection=="连接成功"?Color.FromArgb(22,128,80):muted;error=runActive&&connection=="连接失败";
        if(wechatConnectionResult!=null)wechatConnectionResult.Text="微信连接："+connection+"\r\n"+(runActive?(live?"正在监听新消息。发送结果见首页消息列表。":readError?"微信读取失败，请检查微信登录状态。":"正在启动监听，等待首次读取；超过 60 秒显示连接失败。"):localConnectionMessage.Length>0?localConnectionMessage:"当前未开启消息监听。点击开始运行连接微信。");
        var modelState=LocalHealth("health-model.json");string modelStatus=Str(modelState,"status");string modelText=modelStatus=="error"?"最近请求失败 · "+HealthCause(modelState):modelStatus=="requesting"?"正在请求 · 未确认完成":modelStatus=="ok"?"最近请求成功":"尚未测试";
        if(modelStatus=="requesting"&&(!HealthProcessAlive(modelState)||now-HealthNumber(modelState,"updatedAt")>180)){modelText="上次请求未确认完成";modelStatus="error";}
        bool currentModel=runActive&&HealthNumber(modelState,"updatedAt")>=runStartedUnix;
        if(!currentModel)modelText=runActive?"本次尚未请求":"上次记录 · "+modelText;
        else if(Str(modelState,"error").StartsWith("BudgetExceeded"))modelText="请求次数保护已暂停 · 到设置 / 高级选项调整";
        homeModelHealth.Text="模型 · "+modelText+"\r\n"+HealthTime(HealthNumber(modelState,"lastSuccessAt"));homeModelHealth.ForeColor=currentModel&&modelStatus=="error"?Color.FromArgb(176,50,62):muted;error|=currentModel&&modelStatus=="error";
        var reportState=LocalHealth("health-report.json");var information=LocalHealth("information-state.json");string reportStatus=Str(reportState,"status");
        string reportText=reportStatus=="blocked"?Str(reportState,"error"):reportStatus=="error"?"整理失败 · "+HealthCause(reportState):reportStatus=="analysing"?"正在整理 · "+Str(reportState,"phase"):reportStatus=="ok"?"最近生成成功":Str(information,"lastError").Length>0?"上次整理失败 · "+Str(information,"lastError"):"尚未生成";
        if(reportStatus=="analysing"&&!HealthProcessAlive(reportState))reportText="上次整理未确认完成";
        bool reportsEnabled=dailyReport.Checked||weeklyReport.Checked||importantReminders.Checked;
        bool currentReport=runActive&&reportsEnabled&&HealthNumber(reportState,"updatedAt")>=runStartedUnix;
        if(!reportsEnabled)reportText="日报、周报和提醒已关闭";
        else if(!currentReport)reportText=runActive?"等待本次定时整理":"上次记录 · "+reportText;
        else if(reportStatus=="error")reportText="整理未完成 · "+HealthDiagnosis(reportState);
        if(currentReport&&reportStatus!="analysing"&&reportStatus!="error"&&DateTime.Now>=DateTime.Today.AddHours(23).AddMinutes(5)){
            if(dailyReport.Checked&&!CurrentReportReady("日报",DateTime.Today.AddHours(23)))reportText="今日日报待补齐";
            if(weeklyReport.Checked&&DateTime.Now.DayOfWeek==DayOfWeek.Sunday&&!CurrentReportReady("周报",DateTime.Today.AddHours(23)))reportText="本周周报待补齐";
        }
        homeReportHealth.Text="整理 · "+reportText+"\r\n"+HealthTime(HealthNumber(reportState,"lastSuccessAt"));homeReportHealth.ForeColor=currentReport&&reportStatus=="error"?Color.FromArgb(176,50,62):muted;error|=currentReport&&reportStatus=="error";
        if(homeIssueDetail!=null)homeIssueDetail.Text=!runActive?(lastRunFailure.Length>0?"上次启动未完成："+lastRunFailure:""):error?"需要处理："+(readError||!live&&!connecting?"微信："+(wechatFailed?HealthDiagnosis(wechatState):"读取未确认。请确认电脑微信已登录，重新连接；读取正常前不显示为连接成功。")+"\r\n":"")+(currentModel&&modelStatus=="error"?FeatureErrorCaption(Str(modelState,"feature"))+"："+HealthDiagnosis(modelState)+"\r\n":"")+(currentReport&&reportStatus=="error"?"后台整理："+HealthDiagnosis(reportState):""):connecting?"正在连接微信，首次读取完成后显示消息；功能按当前开关执行。":"本次运行无已知错误；各功能的执行情况见上方与消息列表。";
        bool sendFailed=runActive&&Int(read,"blockedConversations",0)>0&&Str(read,"lastError").Length>0;
        if(sendFailed){error=true;if(homeIssueDetail!=null)homeIssueDetail.Text="本次发送异常："+Str(read,"lastError")+"。其他会话继续监听，未确认的消息不会重复发送。";}
        if(homeIssueDetail!=null){homeIssueDetail.Text=ReplyRunExplanation(read)+(homeIssueDetail.Text.Length>0?"\r\n"+homeIssueDetail.Text:"");}
        ResizeHomeLayout();return error||(!runActive&&lastRunFailure.Length>0);
    }
    string ReplyRunExplanation(Dictionary<string,object> read){
        bool listener=bridge!=null&&!bridge.HasExited;
        if(!privateEnabled.Checked&&!groupEnabled.Checked)return "自动回复：已关闭；可以继续使用本机记录和整理。";
        if(!runActive)return "自动回复：尚未启动。点击“保存设置”或底部“开始运行”，保存并立即启动微信监听。";
        if(!listener)return "自动回复：监听尚未启动；当前只有后台记录。点击底部“开始运行”重新按当前设置启动。";
        if(Str(read,"status")!="listening")return "自动回复：正在连接微信，等待首次成功读取。";
        string rule=contactMode.SelectedIndex==1?"只回复星标好友":contactMode.SelectedIndex==2?"私聊只回复问题":"按允许名单回复";
        int available=Int(read,"autoReplyConversations",0),paused=Int(read,"manualTakeoverConversations",0),blocked=Int(read,"blockedConversations",0);
        string labels="";var values=read.ContainsKey("pausedLabels")?read["pausedLabels"] as System.Collections.IList:null;if(values!=null)labels=String.Join("、",values.Cast<object>().Select(x=>Convert.ToString(x)).Take(5));
        bool personal=WechatProvider()=="native_windows";
        string blockedText="";var reasons=read.ContainsKey("blockedReasons")?read["blockedReasons"] as System.Collections.IList:null;if(reasons!=null)blockedText=String.Join("；",reasons.Cast<object>().Select(x=>Convert.ToString(x)).Take(5));
        return "自动回复：监听中 · "+rule+" · "+available+" 个会话可自动回复；"+(personal?"Windows 本机后台接口。":"群聊须 @你。")+(paused>0?"\r\n本次运行检测到本人发信，人工接管暂停 "+paused+" 个会话"+(labels.Length>0?"（"+labels+"）":"")+"，选中后可恢复代管。":"")+(blocked>0?"\r\n需处理暂停 "+blocked+" 个会话："+blockedText:"")+"\r\n开始运行按当前设置启用，旧暂停不自动沿用；旧消息不补发。";
    }
    string FeatureErrorCaption(string feature){int i=Array.IndexOf(routedFeatures,feature);return i<0?"模型请求":routedCaptions[i];}
    string HealthCause(Dictionary<string,object> data){string title=Str(data,"errorTitle");return title.Length>0?title:HealthError(Str(data,"error"));}
    string HealthDiagnosis(Dictionary<string,object> data){string title=Str(data,"errorTitle"),action=Str(data,"errorAction");return title.Length>0?title+"。"+action:HealthError(Str(data,"error"));}
    string HealthError(string value){
        if(value.StartsWith("BudgetExceeded"))return "达到每日请求次数上限（设置 → 高级选项）；不等于账户余额不足";
        if(value.Contains("HTTP 401"))return "API 密钥无效。到设置 → API 配置检查密钥";
        if(value.Contains("HTTP 402"))return "接口账户余额不足。请查看此 API 服务商账户";
        if(value.Contains("HTTP 429"))return "接口限流。稍后再试；不能据此判断余额不足";
        if(value.Contains("Timeout"))return "请求超时。检查网络与接口服务状态";
        if(value.Length==0||value=="ValueError"||value=="HTTPError"||value=="URLError")return "原因未确认，请查看本功能运行记录；不能据此判断余额不足";
        return value;
    }
    bool CurrentReportReady(string kind,DateTime since){var index=LocalHealth("information-report-index.json");foreach(var pair in index){var spec=pair.Value as Dictionary<string,object>;DateTime end;if(spec!=null&&pair.Key.StartsWith("信息"+kind+"-")&&Str(spec,"reportStyle")=="secretary-v2"&&DateTime.TryParse(Str(spec,"end"),out end)&&end>=since)return true;}return false;}
    void BuildReportPreview(){
        var page=mainProductTabs.TabPages[3];reportList.Top+=46;reportView.Top+=46;var full=MakeButton("查看完整事件",295,120,220,34);full.Click+=delegate{if(reportList.SelectedItem==null)return;string name=Path.GetFileName(reportList.SelectedItem.ToString());string path=Path.Combine(AppPaths.Storage,"报告","完整事件",name);if(File.Exists(path))ShowInternalFile("完整事件 · "+name,path);else status.Text="旧版报告没有完整事件附录，请重新生成。";};page.Controls.Add(full);
        var preview=MakeButton("A4 页面预览",530,120,220,34);preview.Click+=delegate{ShowReportPagePreview();};page.Controls.Add(preview);
        reportPreviewPanel=new Panel{Dock=DockStyle.Fill,Visible=false,BackColor=Color.White};var close=MakeButton("返回简报阅读",0,0,200,38);close.Dock=DockStyle.Top;close.Click+=delegate{CloseReportPagePreview();};
        reportBrowser=new WebBrowser{Dock=DockStyle.Fill,AllowWebBrowserDrop=false,IsWebBrowserContextMenuEnabled=false,WebBrowserShortcutsEnabled=false,ScriptErrorsSuppressed=true};reportBrowser.Navigating+=delegate(object sender,WebBrowserNavigatingEventArgs e){if(e.Url.ToString()!="about:blank")e.Cancel=true;};reportPreviewPanel.Controls.Add(reportBrowser);reportPreviewPanel.Controls.Add(close);page.Controls.Add(reportPreviewPanel);
    }
    void ShowReportPagePreview(){if(reportList.SelectedItem==null)return;string name=Path.GetFileName(reportList.SelectedItem.ToString()),path=Path.Combine(AppPaths.Storage,"报告","页面预览",name+".html");if(!File.Exists(path)){status.Text="这份旧报告还没有页面排版，请重新生成。";return;}mainProductTabs.TabPages[3].AutoScrollPosition=Point.Empty;mainProductTabs.TabPages[3].AutoScroll=false;reportContainer.Visible=false;reportBrowser.DocumentText=File.ReadAllText(path,Encoding.UTF8);reportPreviewPanel.Visible=true;reportPreviewPanel.BringToFront();}
}
}
