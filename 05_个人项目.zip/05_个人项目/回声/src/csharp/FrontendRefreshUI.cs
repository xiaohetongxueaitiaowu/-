﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EchoWechatDesktop {
public partial class MainForm {
    Panel reportContainer,reportDocumentPanel;
    TableLayoutPanel reportLayout,reportColumns;
    FlowLayoutPanel reportToolbar,reportBatchToolbar;
    Label reportHeading,reportHint;
    bool reportResizing;
    TableLayoutPanel homePreviewGrid;
    Panel[] homeTaskTiles=new Panel[2],homeBriefTiles=new Panel[2];
    Label[] homeTaskWho=new Label[2],homeTaskWhat=new Label[2],homeTaskDue=new Label[2],homeBriefWho=new Label[2],homeBriefWhat=new Label[2];
    TabControl profileViews;
    Panel profileContainer;
    TextBox feedbackAddressBox;
    Label feedbackStatus;
    Button feedbackCopy;

    void ResetPageViewport(TabPage page){if(page==null||IsDisposed)return;page.AutoScrollPosition=Point.Empty;if(IsHandleCreated)BeginInvoke(new Action(delegate{if(!IsDisposed&&mainProductTabs.SelectedTab==page)page.AutoScrollPosition=Point.Empty;}));}
    void BuildFrontendRefresh(){
        RebuildReportLayout();RebuildHomePreviews();RebuildProfileLayout();
        mainProductTabs.SelectedIndexChanged+=delegate{ResetPageViewport(mainProductTabs.SelectedTab);};
        Shown+=delegate{ResizeReportLayout();ResizeHomeLayout();ResizeProfileLayout();};
    }
    void RebuildReportLayout(){
        var page=mainProductTabs.TabPages[3];var buttons=page.Controls.Cast<Control>().OfType<Button>().ToList();page.Controls.Clear();
        reportContainer=new Panel{Dock=DockStyle.Top,Height=900,Padding=new Padding(24,16,24,20)};page.Controls.Add(reportContainer);
        reportLayout=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=5,Margin=new Padding(0)};reportLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));foreach(int h in new[]{34,32,96,40,700})reportLayout.RowStyles.Add(new RowStyle(SizeType.Absolute,h));reportContainer.Controls.Add(reportLayout);
        reportHeading=MakeLabel("日报与周报",0,0,900,34,true);reportHeading.Dock=DockStyle.Fill;reportLayout.Controls.Add(reportHeading,0,0);
        reportHint=MakeLabel("按事件阅读朋友的进展和群里的重点；选择左侧日期查看。",0,0,900,32);reportHint.Dock=DockStyle.Fill;reportLayout.Controls.Add(reportHint,0,1);
        reportToolbar=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=true,Padding=new Padding(0,3,0,0),Margin=new Padding(0)};
        reportKind.Dock=DockStyle.None;reportKind.Width=120;reportKind.Margin=new Padding(0,4,14,6);reportToolbar.Controls.Add(reportKind);
        string[] names={"生成当前进度","刷新列表","查看本期全部原文","查看完整事件","A4 页面预览"};
        foreach(string name in names){var button=buttons.FirstOrDefault(x=>x.Text==name);if(button==null)continue;button.Dock=DockStyle.None;button.Size=new Size(name=="刷新列表"?105:name=="查看本期全部原文"?160:name=="生成当前进度"?145:135,34);button.Margin=new Padding(0,2,10,6);reportToolbar.Controls.Add(button);}reportLayout.Controls.Add(reportToolbar,0,2);
        reportBatchToolbar=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=true,Margin=new Padding(0)};
        foreach(string name in new[]{"全选","合并查看所选","隐藏所选","恢复全部显示"}){var button=buttons.FirstOrDefault(x=>x.Text==name);if(button==null)continue;button.Dock=DockStyle.None;button.Size=new Size(name=="全选"?85:145,32);button.Margin=new Padding(0,0,10,4);reportBatchToolbar.Controls.Add(button);}reportLayout.Controls.Add(reportBatchToolbar,0,3);
        reportColumns=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=new Padding(0)};reportColumns.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,240));reportColumns.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));reportColumns.RowStyles.Add(new RowStyle(SizeType.Percent,100));reportLayout.Controls.Add(reportColumns,0,4);
        var listCard=new Panel{Dock=DockStyle.Fill,Margin=new Padding(0,0,20,0),BackColor=Color.FromArgb(247,249,252),Padding=new Padding(12)};
        var caption=MakeLabel("日期 / 期次 · 可多选",0,0,210,30,true);caption.Dock=DockStyle.Top;listCard.Controls.Add(caption);reportList.Dock=DockStyle.Fill;reportList.IntegralHeight=false;reportList.BorderStyle=BorderStyle.None;listCard.Controls.Add(reportList);reportList.BringToFront();reportColumns.Controls.Add(listCard,0,0);
        reportDocumentPanel=new Panel{Dock=DockStyle.Fill,Margin=new Padding(0),Padding=new Padding(0),BackColor=Color.White};reportView.Dock=DockStyle.None;reportView.Location=Point.Empty;reportView.ScrollBars=RichTextBoxScrollBars.None;reportDocumentPanel.Controls.Add(reportView);reportColumns.Controls.Add(reportDocumentPanel,1,0);
        page.Controls.Add(reportPreviewPanel);reportPreviewPanel.BringToFront();
        page.SizeChanged+=delegate{ResizeReportLayout();};reportDocumentPanel.SizeChanged+=delegate{ResizeReportLayout();};reportToolbar.SizeChanged+=delegate{if(IsHandleCreated&&!IsDisposed)BeginInvoke(new Action(ResizeReportLayout));};reportView.ContentsResized+=delegate{if(IsHandleCreated&&!IsDisposed)BeginInvoke(new Action(ResizeReportLayout));};
    }
    void ResizeReportLayout(){if(reportResizing||reportContainer==null||!IsHandleCreated)return;reportResizing=true;try{
        reportColumns.ColumnStyles[0].Width=UiPixel(mainProductTabs.ClientSize.Width<UiPixel(900)?200:240);
        int width=Math.Max(UiPixel(220),reportDocumentPanel.ClientSize.Width);reportView.Width=width;
        int content=TextRenderer.MeasureText(reportView.Text+"\n",readingFont,new Size(Math.Max(100,width-UiPixel(44)),100000),TextFormatFlags.WordBreak|TextFormatFlags.TextBoxControl).Height;
        int body=Math.Max(UiPixel(430),Math.Min(40000,Math.Max(content+UiPixel(90),readingHeights.ContainsKey(reportView)?readingHeights[reportView]:0)));reportView.Height=body;
        int toolbarWidth=Math.Max(1,reportToolbar.ClientSize.Width),rows=1,used=0;foreach(Control c in reportToolbar.Controls){int need=c.Width+c.Margin.Horizontal;if(used>0&&used+need>toolbarWidth){rows++;used=0;}used+=need;}
        reportLayout.RowStyles[2].Height=UiPixel(42)*rows;reportLayout.RowStyles[4].Height=body;
        reportContainer.Height=(int)Math.Ceiling(reportLayout.RowStyles.Cast<RowStyle>().Sum(x=>x.Height))+reportContainer.Padding.Vertical;
        reportContainer.PerformLayout();reportLayout.PerformLayout();
    }finally{reportResizing=false;}}
    void CloseReportPagePreview(){reportPreviewPanel.Visible=false;reportContainer.Visible=true;mainProductTabs.TabPages[3].AutoScroll=true;ResizeReportLayout();ResetPageViewport(mainProductTabs.TabPages[3]);}
    Label PreviewLabel(int height,bool boldText=false){return new Label{Dock=DockStyle.Top,Height=height,Font=boldText?bold:normal,ForeColor=navy,AutoEllipsis=true,Margin=new Padding(0)};}
    void RebuildHomePreviews(){
        var stack=homeContainer.Controls[0] as TableLayoutPanel;homePreviewGrid=stack.GetControlFromPosition(0,6) as TableLayoutPanel;
        var taskCard=secretaryTasks.Parent;var briefCard=secretaryBrief.Parent;secretaryTasks.Visible=false;secretaryBrief.Visible=false;
        foreach(Control card in new[]{taskCard,briefCard})card.Padding=new Padding(14);
        var tasks=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=2,Margin=new Padding(0)};tasks.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));tasks.RowStyles.Add(new RowStyle(SizeType.Percent,50));tasks.RowStyles.Add(new RowStyle(SizeType.Percent,50));taskCard.Controls.Add(tasks);tasks.BringToFront();
        var briefs=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=2,Margin=new Padding(0)};briefs.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));briefs.RowStyles.Add(new RowStyle(SizeType.Percent,50));briefs.RowStyles.Add(new RowStyle(SizeType.Percent,50));briefCard.Controls.Add(briefs);briefs.BringToFront();
        for(int i=0;i<2;i++){int index=i;homeTaskTiles[i]=new Panel{Dock=DockStyle.Fill,Margin=new Padding(0,0,0,6),Padding=new Padding(8),BackColor=Color.White,Cursor=Cursors.Hand};homeTaskWho[i]=PreviewLabel(24,true);homeTaskWhat[i]=PreviewLabel(32);homeTaskDue[i]=PreviewLabel(20);homeTaskDue[i].ForeColor=Color.FromArgb(145,88,12);homeTaskTiles[i].Controls.Add(homeTaskDue[i]);homeTaskTiles[i].Controls.Add(homeTaskWhat[i]);homeTaskTiles[i].Controls.Add(homeTaskWho[i]);tasks.Controls.Add(homeTaskTiles[i],0,i);foreach(Control c in homeTaskTiles[i].Controls)c.Click+=delegate{OpenWorkspacePage(4);LoadReminders();};homeTaskTiles[i].Click+=delegate{OpenWorkspacePage(4);LoadReminders();};
            homeBriefTiles[i]=new Panel{Dock=DockStyle.Fill,Margin=new Padding(0,0,0,6),Padding=new Padding(8),BackColor=Color.White,Cursor=Cursors.Hand};homeBriefWho[i]=PreviewLabel(24,true);homeBriefWhat[i]=PreviewLabel(42);homeBriefWhat[i].ForeColor=muted;homeBriefTiles[i].Controls.Add(homeBriefWhat[i]);homeBriefTiles[i].Controls.Add(homeBriefWho[i]);briefs.Controls.Add(homeBriefTiles[i],0,i);Action open=()=>{if(index<homeReportNames.Count){reportKind.SelectedIndex=homeReportNames[index].Contains("周报")?1:0;OpenWorkspacePage(3);LoadReportList();reportList.SelectedItem=homeReportNames[index];}};homeBriefTiles[i].Click+=delegate{open();};foreach(Control c in homeBriefTiles[i].Controls)c.Click+=delegate{open();};}
        stack.GetControlFromPosition(0,8).Visible=false;stack.RowStyles[8].Height=0;
        var welcome=homeGreeting.Parent;welcome.Controls.Clear();welcome.Padding=new Padding(12,8,12,8);var welcomeText=SingleStack(24,20);welcome.Controls.Add(welcomeText);homeGreeting.Dock=DockStyle.Fill;homeGreeting.Margin=new Padding(0);secretarySummary.Dock=DockStyle.Fill;secretarySummary.Padding=new Padding(0);secretarySummary.Margin=new Padding(0);welcomeText.Controls.Add(homeGreeting,0,0);welcomeText.Controls.Add(secretarySummary,0,1);
        mainProductTabs.TabPages[11].SizeChanged+=delegate{ResizeHomeLayout();};
    }
    void ResizeHomeLayout(){if(homeContainer==null||homePreviewGrid==null||!IsHandleCreated)return;var stack=homeContainer.Controls[0] as TableLayoutPanel;if(stack.RowCount>9){int[] feedHeights={60,4,62,8,0,48,32,300,300,8,0};for(int i=0;i<feedHeights.Length;i++)stack.RowStyles[i].Height=UiPixel(feedHeights[i]);if(homeIssueDetail!=null){int height=homeIssueDetail.Text.Length==0?0:TextRenderer.MeasureText(homeIssueDetail.Text,normal,new Size(Math.Max(100,stack.ClientSize.Width-UiPixel(24)),10000),TextFormatFlags.WordBreak).Height+UiPixel(16);stack.RowStyles[6].Height=height;}homeContainer.Height=(int)stack.RowStyles.Cast<RowStyle>().Sum(x=>x.Height)+homeContainer.Padding.Vertical;return;}int[] heights={60,6,72,8,38,56,330,8,0};for(int i=0;i<heights.Length;i++)if(i!=6)stack.RowStyles[i].Height=UiPixel(heights[i]);int staticHeight=(int)stack.RowStyles.Cast<RowStyle>().Where((x,i)=>i!=6).Sum(x=>x.Height)+homeContainer.Padding.Vertical;stack.RowStyles[6].Height=Math.Max(UiPixel(330),mainProductTabs.ClientSize.Height-staticHeight);homeContainer.Height=staticHeight+(int)stack.RowStyles[6].Height;}
    void RefreshHomeTiles(){if(homeTaskWho[0]==null)return;IList pending;try{pending=HomePending();}catch{pending=new object[0];}
        for(int i=0;i<2;i++){homeTaskTiles[i].Visible=i<pending.Count||i==0;if(i<pending.Count){var task=pending[i] as Dictionary<string,object>;string who=Str(task,"asker"),source=Str(task,"source");homeTaskWho[i].Text=who==source?who:who+" · "+source;string text=Str(task,"task");homeTaskWhat[i].Text=text.Length==0?Str(task,"text"):text;string due=ReminderDue(task);int original=due.IndexOf("（原话：",StringComparison.Ordinal);if(original>=0)due=due.Substring(0,original);if(Str(task,"dueAt").Length==0&&Str(task,"calendarPrecision")=="待核对"&&!due.Contains("核对")&&!due.Contains("未"))due+=" · 日期待核对";homeTaskDue[i].Text="期限："+(due.Length==0?"原话未明确":due);}else{homeTaskWho[i].Text="当前没有待处理事项";homeTaskWhat[i].Text="重要事项会显示在这里。";homeTaskDue[i].Text="";}
            homeBriefTiles[i].Visible=i<homeReportNames.Count||i==0;if(i<homeReportNames.Count){string name=homeReportNames[i];homeBriefWho[i].Text=name.Replace("信息","").Replace(".md","").Replace("-当前"," · 当前进度");var index=LocalHealth("information-report-index.json");var spec=index.ContainsKey(name)?index[name] as Dictionary<string,object>:null;homeBriefWhat[i].Text=spec!=null&&Str(spec,"reportStyle")=="secretary-v2"?"点击阅读本期事件与朋友进展":"旧版报告 · 需要重新生成";}else{homeBriefWho[i].Text="还没有简报";homeBriefWhat[i].Text="生成后会按日期显示在这里。";}}
    }
    TableLayoutPanel SingleStack(params int[] heights){var stack=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=heights.Length,Margin=new Padding(0)};stack.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));foreach(int h in heights)stack.RowStyles.Add(new RowStyle(SizeType.Absolute,h));stack.ControlAdded+=delegate(object sender,ControlEventArgs e){if(e.Control is Label)e.Control.Dock=DockStyle.Fill;};return stack;}
    void RebuildProfileLayout(){
        var page=mainProductTabs.TabPages[13];page.Controls.Clear();profileContainer=new Panel{Dock=DockStyle.Top,Height=850,Padding=new Padding(24,12,24,20)};page.Controls.Add(profileContainer);
        var stack=SingleStack(40,32,730);profileContainer.Controls.Add(stack);var heading=MakeLabel("个人中心",0,0,900,38,true);heading.Dock=DockStyle.Fill;stack.Controls.Add(heading,0,0);var subtitle=MakeLabel("个人资料与反馈联系方式。",0,0,900,30);subtitle.Dock=DockStyle.Fill;stack.Controls.Add(subtitle,0,1);
        profileViews=new TabControl{Dock=DockStyle.Fill};stack.Controls.Add(profileViews,0,2);TabPage personal=new EchoPage("个人资料"),feedback=new EchoPage("意见反馈");profileViews.TabPages.AddRange(new[]{personal,feedback});
        var personStack=SingleStack(42,82,28,46,38,55,50);var personPanel=new Panel{Dock=DockStyle.Top,Height=450,Padding=new Padding(20)};personal.Controls.Add(personPanel);personPanel.Controls.Add(personStack);profileName.Dock=DockStyle.Fill;personStack.Controls.Add(profileName,0,0);profileDetails.Dock=DockStyle.Fill;personStack.Controls.Add(profileDetails,0,1);personStack.Controls.Add(MakeLabel("在回声中显示的称呼",0,0,800,28),0,2);var nameRow=HomeRow(2,46);nameRow.ColumnStyles[0].Width=75;nameRow.ColumnStyles[1].Width=25;profileDisplayName.Dock=DockStyle.Fill;profileDisplayName.Margin=new Padding(0,3,12,6);nameRow.Controls.Add(profileDisplayName,0,0);HomeLink(nameRow,1,"保存称呼",SaveLocalProfile,true);personStack.Controls.Add(nameRow,0,3);personStack.Controls.Add(MakeLabel("称呼用于回声首页，保存在本机。",0,0,800,36),0,4);var links=HomeRow(3,50);HomeLink(links,0,"功能设置",()=>OpenWorkspacePage(0));HomeLink(links,1,"导出规则",ExportRules);HomeLink(links,2,"使用说明",()=>ShowInternalFile("回声使用说明",Path.Combine(AppPaths.Docs,"秘书版说明.md")));personStack.Controls.Add(links,0,5);
        var feedbackPanel=new Panel{Dock=DockStyle.Top,Height=280,Padding=new Padding(20)};feedback.Controls.Add(feedbackPanel);
        var form=SingleStack(38,52,68,40);feedbackPanel.Controls.Add(form);
        var title=MakeLabel("问题与建议",0,0,800,36,true);title.Dock=DockStyle.Fill;form.Controls.Add(title,0,0);
        var address=HomeRow(2,52);address.ColumnStyles[0].Width=75;address.ColumnStyles[1].Width=25;
        feedbackAddressBox=MakeText(0,0,500);feedbackAddressBox.Text="请联系提供本软件的人";feedbackAddressBox.ReadOnly=true;feedbackAddressBox.Dock=DockStyle.Fill;feedbackAddressBox.Margin=new Padding(0,8,16,8);address.Controls.Add(feedbackAddressBox,0,0);
        feedbackCopy=MakeButton("复制邮箱",0,0,140,36,true);feedbackCopy.Dock=DockStyle.Fill;feedbackCopy.Margin=new Padding(0,6,0,6);feedbackCopy.Enabled=false;feedbackCopy.Text="未设置邮箱";address.Controls.Add(feedbackCopy,1,0);form.Controls.Add(address,0,1);
        var help=MakeLabel("反馈时请描述操作步骤、出现的问题和期望效果，可附截图。纯净版没有预置个人联系方式。",0,0,800,68);help.Dock=DockStyle.Fill;form.Controls.Add(help,0,2);
        feedbackStatus=MakeLabel("本软件没有预置反馈发送服务。",0,0,800,40);feedbackStatus.Dock=DockStyle.Fill;form.Controls.Add(feedbackStatus,0,3);
        profileViews.SelectedIndexChanged+=delegate{ResizeProfileLayout();ResetPageViewport(page);};page.SizeChanged+=delegate{ResizeProfileLayout();};
    }
    void ResizeProfileLayout(){if(profileContainer==null||!IsHandleCreated)return;var stack=profileContainer.Controls[0] as TableLayoutPanel;int height=UiPixel(profileViews.SelectedIndex==0?450:330);stack.RowStyles[2].Height=height;profileContainer.Height=height+UiPixel(56)+profileContainer.Padding.Vertical;}
}
}
