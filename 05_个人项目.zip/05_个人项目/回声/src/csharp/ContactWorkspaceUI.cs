using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EchoWechatDesktop {
public partial class MainForm {
    CheckBox contactAIEnabled,contactAutoRefresh;
    TabPage contactAITab;
    Panel contactAIContainer;
    TableLayoutPanel contactAIStack;
    RichTextBox contactLatest,contactConversation,contactSuggestion;
    TextBox contactDraft,contactQuestion,contactReceived,contactRequirements;
    ComboBox contactVariant;
    FlowLayoutPanel contactCopies;
    Label contactReadStatus,contactAIProgress,contactSuggestionReason;
    Button contactAsk,contactGenerate,contactRefresh;
    readonly List<Dictionary<string,object>> contactVariants=new List<Dictionary<string,object>>();
    string contactLoadedId="",contactOriginal="";
    long contactEpoch;
    bool contactBusy,contactLoading,contactDirty,contactResizing;
    System.Windows.Forms.Timer contactSaveTimer;

    void BuildContactWorkspace(){
        contactAITab=new EchoPage("联系人 AI"){BackColor=Color.White,AutoScroll=false};memoryViews.TabPages.Add(contactAITab);
        contactAIContainer=new Panel{Dock=DockStyle.Top,Height=1700,Padding=new Padding(16,12,16,20)};contactAITab.Controls.Add(contactAIContainer);
        contactAIStack=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=13,Margin=new Padding(0)};contactAIStack.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));
        foreach(int h in new[]{42,46,60,230,38,110,360,28,76,28,100,48,400})contactAIStack.RowStyles.Add(new RowStyle(SizeType.Absolute,h));contactAIContainer.Controls.Add(contactAIStack);
        var title=MakeLabel("只和这个人的 AI 讨论 · 最新消息、回复草稿、人物问题",0,0,890,40,true);title.Dock=DockStyle.Fill;contactAIStack.Controls.Add(title,0,0);
        var toolbar=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false};
        contactRefresh=MakeButton("获取最新消息",0,0,170,36,true);contactRefresh.Click+=async delegate{await ContactAction("refresh");};toolbar.Controls.Add(contactRefresh);
        var jump=MakeButton("直接提问 ↓",0,0,120,36);jump.Click+=delegate{var outer=mainProductTabs.TabPages[6];int offset=-outer.AutoScrollPosition.Y+contactQuestion.PointToScreen(Point.Empty).Y-outer.PointToScreen(Point.Empty).Y-UiPixel(45);outer.AutoScrollPosition=new Point(0,Math.Max(0,offset));contactQuestion.Focus();};toolbar.Controls.Add(jump);
        contactAutoRefresh=new CheckBox{Text="提问 / 生成前自动读取此人最新消息",Checked=true,AutoSize=true,Margin=new Padding(12,10,10,0)};toolbar.Controls.Add(contactAutoRefresh);
        var clear=MakeButton("清空此人AI对话",0,0,175,36);clear.Click+=async delegate{await ContactAction("clear");};toolbar.Controls.Add(clear);contactAIStack.Controls.Add(toolbar,0,1);
        contactReadStatus=MakeLabel("请选择联系人。读取本机消息不调用模型。",0,0,890,60);contactReadStatus.Dock=DockStyle.Fill;contactAIStack.Controls.Add(contactReadStatus,0,2);
        var latestCard=HomeCard("此人的最近消息 · 时间与双方身份");contactLatest=ReadingBox();contactLatest.Dock=DockStyle.Fill;contactLatest.ScrollBars=RichTextBoxScrollBars.None;latestCard.Controls.Add(contactLatest);contactLatest.BringToFront();contactAIStack.Controls.Add(latestCard,0,3);
        var paste=MakeButton("也可以粘贴对方刚发的消息（可选）",0,0,410,32);paste.Click+=delegate{contactReceived.Focus();};contactAIStack.Controls.Add(paste,0,4);
        contactReceived=MakeText(0,0,890,100,true);contactReceived.MaxLength=6000;contactReceived.Dock=DockStyle.Fill;contactReceived.Margin=new Padding(0,0,0,10);contactAIStack.Controls.Add(contactReceived,0,5);
        var compare=HomeRow(2,360);
        var draftCard=HomeCard("我的回复草稿 · 原稿保留");contactDraft=MakeText(0,0,400,260,true);contactDraft.MaxLength=6000;contactDraft.Dock=DockStyle.Fill;contactDraft.BorderStyle=BorderStyle.None;contactDraft.ScrollBars=ScrollBars.None;draftCard.Controls.Add(contactDraft);contactDraft.BringToFront();compare.Controls.Add(draftCard,0,0);
        var suggestionCard=HomeCard("结合最新消息的建议 · 逐个复制");contactVariant=MakeCombo(0,0,350,new[]{"尚未生成"});contactVariant.Dock=DockStyle.Top;contactVariant.Height=36;suggestionCard.Controls.Add(contactVariant);
        contactCopies=new FlowLayoutPanel{Dock=DockStyle.Top,Height=44,WrapContents=true};suggestionCard.Controls.Add(contactCopies);
        contactSuggestionReason=MakeLabel("生成会保留原意并独立核验。",0,0,400,70);contactSuggestionReason.Dock=DockStyle.Bottom;suggestionCard.Controls.Add(contactSuggestionReason);
        contactSuggestion=ReadingBox();contactSuggestion.Dock=DockStyle.Fill;contactSuggestion.ScrollBars=RichTextBoxScrollBars.None;suggestionCard.Controls.Add(contactSuggestion);
        var suggestionTitle=suggestionCard.Controls.Cast<Control>().First(c=>c is Label&&c.Text.StartsWith("结合最新"));
        suggestionCard.Controls.SetChildIndex(contactSuggestion,0);suggestionCard.Controls.SetChildIndex(contactSuggestionReason,1);suggestionCard.Controls.SetChildIndex(contactCopies,2);suggestionCard.Controls.SetChildIndex(contactVariant,3);suggestionCard.Controls.SetChildIndex(suggestionTitle,4);compare.Controls.Add(suggestionCard,1,0);contactAIStack.Controls.Add(compare,0,6);
        contactAIStack.Controls.Add(MakeLabel("修改要求（可选）",0,0,890,28),0,7);contactRequirements=MakeText(0,0,890,70,true);contactRequirements.MaxLength=1500;contactRequirements.Dock=DockStyle.Fill;contactRequirements.Margin=new Padding(0,0,0,8);contactAIStack.Controls.Add(contactRequirements,0,8);
        contactAIStack.Controls.Add(MakeLabel("问这个人的 AI · 比如他最近有什么事、怎么回应更合适、相处要注意什么",0,0,890,28,true),0,9);
        contactQuestion=MakeText(0,0,890,95,true);contactQuestion.MaxLength=1500;contactQuestion.Dock=DockStyle.Fill;contactQuestion.Margin=new Padding(0,0,0,8);contactAIStack.Controls.Add(contactQuestion,0,10);
        var actions=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=false};contactAsk=MakeButton("询问此人的 AI",0,0,185,38,true);contactAsk.Click+=async delegate{await ContactAction("chat");};actions.Controls.Add(contactAsk);
        contactGenerate=MakeButton("结合消息修改草稿",0,0,215,38,true);contactGenerate.Click+=async delegate{await ContactAction("advise");};actions.Controls.Add(contactGenerate);
        var relationship=MakeButton("查看人物分析",0,0,170,38);relationship.Click+=delegate{memoryViews.SelectedIndex=0;};actions.Controls.Add(relationship);
        var save=MakeButton("保存此人草稿",0,0,155,38);save.Click+=async delegate{await SaveContactInputs();};actions.Controls.Add(save);contactAIStack.Controls.Add(actions,0,11);
        var replies=HomeCard("和此人的 AI 对话 · 回答、依据与读取情况");contactAIProgress=MakeLabel("只按你选的人提问，不会发送微信。",0,0,890,56);contactAIProgress.Dock=DockStyle.Top;replies.Controls.Add(contactAIProgress);
        contactConversation=ReadingBox();contactConversation.Dock=DockStyle.Fill;contactConversation.ScrollBars=RichTextBoxScrollBars.None;replies.Controls.Add(contactConversation);contactConversation.BringToFront();contactAIStack.Controls.Add(replies,0,12);
        contactVariant.SelectedIndexChanged+=delegate{ShowContactVariant();};
        foreach(TextBox input in new[]{contactDraft,contactReceived,contactRequirements})input.TextChanged+=delegate{if(!contactLoading){contactDirty=true;contactSaveTimer.Stop();contactSaveTimer.Start();}if(contactVariants.Count>0&&contactDraft.Text!=contactOriginal){foreach(Control b in contactCopies.Controls)b.Enabled=false;contactSuggestionReason.Text="原稿已改变，旧建议仅作对照，请重新生成。";}ResizeContactWorkspace();};
        contactSaveTimer=new System.Windows.Forms.Timer{Interval=900};contactSaveTimer.Tick+=async delegate{contactSaveTimer.Stop();await SaveContactInputs(false);};
        foreach(RichTextBox box in new[]{contactLatest,contactSuggestion,contactConversation})box.ContentsResized+=delegate{ResizeContactWorkspace();};
        contactAITab.SizeChanged+=delegate{ResizeContactWorkspace();};
        memoryViews.SelectedIndexChanged+=async delegate{if(memoryViews.SelectedTab==contactAITab)await LoadContactWorkspace();ResizeContactWorkspace();};
        var adviceActions=adviceStack.GetControlFromPosition(0,6) as TableLayoutPanel;
        var oldDiscuss=adviceActions.GetControlFromPosition(1,0);
        // Replace the earlier general-feature click with a focused contact entry.
        adviceActions.Controls.Remove(oldDiscuss);oldDiscuss.Dispose();HomeLink(adviceActions,1,"问此人的 AI / 看最新消息",OpenContactFromAdvice);
        FormClosing+=delegate{contactSaveTimer.Stop();if(contactDirty&&contactLoadedId.Length>0){try{LocalCall("contact_workspace.py",ContactInputsValue());}catch{}}contactSaveTimer.Dispose();};
        Shown+=async delegate{await LoadContactWorkspace();ResizeContactWorkspace();};
    }
    void OpenContactFromAdvice(){var selected=advisorContact.SelectedItem as AdvisorContact;if(selected==null){Notice("请先选择联系人。");return;}PopulateMemoryContacts();MemoryContact match=null;foreach(object obj in memoryContact.Items){var person=obj as MemoryContact;if(person!=null&&person.Id==selected.Id){match=person;break;}}if(match==null){match=new MemoryContact{Id=selected.Id,Label=selected.Label,Kind=selected.Id.EndsWith("@chatroom")?"group":"friend"};memoryContact.Items.Add(match);}memoryContact.SelectedItem=match;OpenWorkspacePage(6);memoryViews.SelectedTab=contactAITab;}
    Dictionary<string,object> ContactInputsValue(){return new Dictionary<string,object>{{"action","save"},{"identifier",contactLoadedId},{"draft",contactDraft.Text},{"receivedMessage",contactReceived.Text},{"requirements",contactRequirements.Text}};}
    async Task SaveContactInputs(bool notify=true){if(!contactDirty||contactLoadedId.Length==0||contactLoading)return;var value=ContactInputsValue();string id=contactLoadedId;contactDirty=false;try{await Task.Run(()=>LocalCall("contact_workspace.py",value));if(notify&&!IsDisposed&&contactLoadedId==id)Notice("此人的草稿与修改要求已保存到本机。");}catch(Exception error){if(!IsDisposed&&contactLoadedId==id){contactDirty=true;Notice("草稿保存失败："+error.Message);}}}
    async Task LoadContactWorkspace(){if(contactAIStack==null)return;var selected=memoryContact.SelectedItem as MemoryContact;string id=selected==null?"":selected.Id;if(id==contactLoadedId)return;
        await SaveContactInputs(false);if(IsDisposed)return;var current=memoryContact.SelectedItem as MemoryContact;if((current==null?"":current.Id)!=id)return;long epoch=++contactEpoch;contactLoadedId=id;contactLoading=true;contactDraft.Clear();contactReceived.Clear();contactRequirements.Clear();contactQuestion.Clear();contactLatest.Clear();contactConversation.Clear();ClearContactVariants();contactDirty=false;
        if(id.Length==0){contactReadStatus.Text="请选择联系人。";contactLoading=false;return;}contactReadStatus.Text="正在读取“"+selected.Label+"”的本机消息与专属 AI 对话…";
        try{var data=await Task.Run(()=>LocalCall("contact_workspace.py",new Dictionary<string,object>{{"action","read"},{"identifier",id}}));if(IsDisposed||epoch!=contactEpoch||contactLoadedId!=id)return;var inputs=data["inputs"] as Dictionary<string,object>;if(inputs!=null){contactDraft.Text=Str(inputs,"draft");contactReceived.Text=Str(inputs,"receivedMessage");contactRequirements.Text=Str(inputs,"requirements");}ShowContactState(data);ShowContactConversation(data);contactAIProgress.Text="“"+selected.Label+"”的专属对话已打开；发问只参考此人，草稿独立保存。";}catch(Exception error){if(!IsDisposed&&epoch==contactEpoch)contactReadStatus.Text="读取失败："+error.Message;}finally{if(epoch==contactEpoch)contactLoading=false;}
    }
    async Task ContactAction(string action){if(contactBusy){Notice("请等待本次读取或回答完成，也可点击停止全部。");return;}var person=memoryContact.SelectedItem as MemoryContact;if(contactLoading||person==null||person.Id!=contactLoadedId){Notice("请先选择联系人，等本机资料读取完成。");return;}
        if((action=="chat"||action=="advise")&&!contactAIEnabled.Checked){Notice("请到设置开启联系人 AI 问答。");return;}if(action=="chat"&&String.IsNullOrWhiteSpace(contactQuestion.Text)){Notice("请写下与此人有关的问题。");return;}if(action=="advise"&&String.IsNullOrWhiteSpace(contactDraft.Text)){Notice("请先写你的回复草稿。");return;}
        long epoch=contactEpoch,generation=stopGeneration;string original=contactDraft.Text,question=contactQuestion.Text;var value=ContactInputsValue();value["action"]=action;value["question"]=question;value["refreshLatest"]=contactAutoRefresh.Checked;var config=Config();config["apiKey"]=key.Text.Trim();value["config"]=config;
        contactBusy=true;contactAsk.Enabled=false;contactGenerate.Enabled=false;contactRefresh.Enabled=false;contactAIProgress.Text=action=="refresh"?"正在单独读取此联系人的微信消息，不调用模型…":action=="clear"?"正在清空此人的 AI 对话，草稿保留…":"正在读取此人的最新消息，并结合历史回答…";
        try{var data=await Task.Run(()=>LocalCall("contact_workspace.py",value,generation));if(IsDisposed||generation!=stopGeneration||epoch!=contactEpoch||person.Id!=contactLoadedId)return;ShowContactState(data);
            if(action=="advise"){if(contactDraft.Text!=original){contactAIProgress.Text="原稿已改变，本次建议已丢弃，请重新生成。";return;}DisplayContactAdvice(data["advice"] as Dictionary<string,object>,original);contactAIProgress.Text="回复建议已生成并独立核验；可单独复制，原稿保持不变。";}
            else{ShowContactConversation(data);if(action=="chat"&&contactQuestion.Text==question)contactQuestion.Clear();contactAIProgress.Text=action=="refresh"?"此人消息已读取；读取状态见上方。":action=="clear"?"此人的 AI 对话已清空，草稿和人物分析保留。":Str(data,"referenceMode")+"；回答来源已列在下方。";}
        }catch(Exception error){if(!IsDisposed&&epoch==contactEpoch)contactAIProgress.Text=generation!=stopGeneration?"本次已停止；草稿保留。":"未完成："+error.Message;}finally{contactBusy=false;if(!IsDisposed){contactAsk.Enabled=true;contactGenerate.Enabled=true;contactRefresh.Enabled=true;ResizeContactWorkspace();}}
    }
    void ShowContactState(Dictionary<string,object> data){var freshness=data.ContainsKey("freshness")?data["freshness"] as Dictionary<string,object>:null;if(freshness!=null){string mode=Str(freshness,"status");contactReadStatus.Text=(mode=="fresh"?"已单独读取此人的最新微信消息":mode=="failed"?"最新读取失败，以下为本机旧记录："+Str(freshness,"error"):"当前为本机保存记录，尚未进行本次最新读取")+(Str(freshness,"checkedAt").Length>0?"\n上次单独读取："+Str(freshness,"checkedAt"):"");}
        var messages=data.ContainsKey("messages")?data["messages"] as IList:null;if(messages!=null){var text=new StringBuilder();int first=Math.Max(0,messages.Count-12);for(int i=first;i<messages.Count;i++){var row=messages[i] as Dictionary<string,object>;if(row==null)continue;text.AppendLine(Str(row,"time")+" · "+Str(row,"speaker")).AppendLine(Str(row,"text")).AppendLine();}SetReading(contactLatest,text.Length==0?"还没有此人的本机消息。打开微信后点击“获取最新消息”，或粘贴对方刚发的内容。":text.ToString());}}
    void ShowContactConversation(Dictionary<string,object> data){var text=new StringBuilder();var history=data.ContainsKey("history")?data["history"] as IList:null;if(history!=null)foreach(object obj in history){var row=obj as Dictionary<string,object>;if(row==null)continue;text.AppendLine(Str(row,"role")=="user"?"## 我问":"## 此人的 AI 回答").AppendLine(Str(row,"text")).AppendLine();}var sources=data.ContainsKey("sources")?data["sources"] as IList:null;if(sources!=null&&sources.Count>0){text.AppendLine("## 本次回答依据");foreach(object obj in sources){var row=obj as Dictionary<string,object>;if(row!=null)text.AppendLine(Str(row,"time")+" · "+Str(row,"speaker")+"："+Str(row,"text"));}}SetReading(contactConversation,text.Length==0?"可以问：他最近希望我做什么？\n结合我写的草稿，这样回复合适吗？\n从双方历史看，我和他相处时有哪些需要核对或注意的地方？":text.ToString());}
    void ClearContactVariants(){contactVariants.Clear();contactVariant.Items.Clear();contactVariant.Items.Add("尚未生成");contactVariant.SelectedIndex=0;while(contactCopies.Controls.Count>0)contactCopies.Controls[0].Dispose();contactSuggestion.Clear();contactSuggestionReason.Text="生成会保留原意并独立核验。";}
    void DisplayContactAdvice(Dictionary<string,object> data,string original){ClearContactVariants();contactOriginal=original;contactVariant.Items.Clear();foreach(object obj in (IList)data["variants"]){var item=obj as Dictionary<string,object>;if(item==null)continue;int index=contactVariants.Count;contactVariants.Add(item);contactVariant.Items.Add(Str(item,"title"));var copy=MakeButton("复制 · "+Str(item,"title"),0,0,UiPixel(120),UiPixel(32));copy.Click+=delegate{if(contactDraft.Text!=contactOriginal){Notice("原稿已变，请重新生成。");return;}Clipboard.SetText(Str(contactVariants[index],"text"));Notice("已复制正文，请在微信自行发送。");};contactCopies.Controls.Add(copy);}if(contactVariants.Count>0)contactVariant.SelectedIndex=0;if(!String.IsNullOrWhiteSpace(Str(data,"notes")))SetReading(contactConversation,contactConversation.Text+"\n\n## 草稿需要核对的内容\n"+Str(data,"notes"));}
    void ShowContactVariant(){int index=contactVariant.SelectedIndex;if(index<0||index>=contactVariants.Count)return;var row=contactVariants[index];SetReading(contactSuggestion,Str(row,"text"));contactSuggestionReason.Text="修改理由："+Str(row,"reason")+"\n原意核验："+Str(row,"meaningCheck");}
    void ResizeContactWorkspace(){if(contactResizing||contactAIStack==null||!IsHandleCreated)return;contactResizing=true;try{int width=Math.Max(100,contactLatest.ClientSize.Width-UiPixel(18));Func<string,int> measure=text=>TextRenderer.MeasureText(text+"\n",normal,new Size(width,100000),TextFormatFlags.WordBreak|TextFormatFlags.TextBoxControl).Height;
        contactAIStack.RowStyles[3].Height=Math.Max(UiPixel(180),Math.Min(30000,measure(contactLatest.Text)+UiPixel(60)));
        contactAIStack.RowStyles[2].Height=Math.Max(UiPixel(55),measure(contactReadStatus.Text)+UiPixel(12));
        int half=Math.Max(100,contactDraft.ClientSize.Width-UiPixel(18));int draftHeight=TextRenderer.MeasureText(contactDraft.Text+"\n",normal,new Size(half,100000),TextFormatFlags.WordBreak|TextFormatFlags.TextBoxControl).Height;int suggestionHeight=TextRenderer.MeasureText(contactSuggestion.Text+"\n",readingFont,new Size(half,100000),TextFormatFlags.WordBreak|TextFormatFlags.TextBoxControl).Height;contactAIStack.RowStyles[6].Height=Math.Max(UiPixel(320),Math.Min(12000,Math.Max(draftHeight,suggestionHeight)+UiPixel(200)));
        contactAIStack.RowStyles[12].Height=Math.Max(UiPixel(380),Math.Min(30000,measure(contactConversation.Text)+UiPixel(130)));contactAIContainer.Height=(int)Math.Ceiling(contactAIStack.RowStyles.Cast<RowStyle>().Sum(x=>x.Height))+contactAIContainer.Padding.Vertical;
        if(memoryViews.SelectedTab==contactAITab)memoryViews.Height=contactAIContainer.Height+UiPixel(40);
    }finally{contactResizing=false;}}
}
}
