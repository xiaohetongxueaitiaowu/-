using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EchoWechatDesktop {
public partial class MainForm {
    bool populatingMemoryContacts;
    string memoryReadingId="";
    async void RefreshSelectedMemoryContact(){
        if(populatingMemoryContacts||filteringContact||IsDisposed)return;
        ShowAnalysis();await RefreshMemory();
        if(contactAITab!=null&&!IsDisposed)await LoadContactWorkspace();
    }
    string PickerContactId(object item){var m=item as MemoryContact;var a=item as AdvisorContact;return m!=null?m.Id:a!=null?a.Id:item==null?"":item.ToString();}
    sealed class ContactViewport:IDisposable {
        readonly MainForm owner;readonly TabPage page;
        readonly Dictionary<ScrollableControl,Point> positions=new Dictionary<ScrollableControl,Point>();
        public ContactViewport(MainForm owner){this.owner=owner;page=owner.mainProductTabs.SelectedTab;if(page!=null)Capture(page);}
        void Capture(Control root){var scroll=root as ScrollableControl;if(scroll!=null&&scroll.AutoScroll)positions[scroll]=new Point(-scroll.AutoScrollPosition.X,-scroll.AutoScrollPosition.Y);foreach(Control child in root.Controls)Capture(child);}
        public void Dispose(){if(owner.IsDisposed||owner.mainProductTabs.SelectedTab!=page)return;foreach(var pair in positions)if(!pair.Key.IsDisposed)pair.Key.AutoScrollPosition=pair.Value;}
    }
    string ContactRowKey(ListViewItem row){if(row==null)return "";var choice=row.Tag as ContactChoice;return choice==null?row.Text:choice.Kind+":"+choice.Id;}
    sealed class ContactListState {
        public HashSet<string> Selected;public string Top,Focus;public int TopIndex;
    }
    ContactListState CaptureContactList(ListView list){
        var state=new ContactListState{Selected=new HashSet<string>(list.SelectedItems.Cast<ListViewItem>().Select(ContactRowKey),StringComparer.Ordinal),Top="",Focus="",TopIndex=0};
        if(list.IsHandleCreated&&list.Items.Count>0){var top=list.TopItem;if(top!=null){state.Top=ContactRowKey(top);state.TopIndex=top.Index;}state.Focus=ContactRowKey(list.FocusedItem);}return state;
    }
    void RestoreContactList(ListView list,ContactListState state){
        ListViewItem top=null;foreach(ListViewItem row in list.Items){string id=ContactRowKey(row);row.Selected=state.Selected.Contains(id);if(id==state.Focus)row.Focused=true;if(id==state.Top)top=row;}
        if(list.IsHandleCreated&&list.Items.Count>0)list.TopItem=top??list.Items[Math.Min(state.TopIndex,list.Items.Count-1)];
    }
}
}
