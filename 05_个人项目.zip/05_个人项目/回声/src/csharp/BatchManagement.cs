﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EchoWechatDesktop {
public partial class MainForm {
    sealed class ContactChoice {public string Id,Label,Nickname,Alias,Kind;public ListViewItem Existing;}
    ListView contactBatchList;
    TextBox contactBatchSearch,contactBatchPaste;
    ComboBox contactBatchKind,contactBatchMode,contactBatchRelation,contactBatchDepth;
    CheckBox batchChangeMode,batchChangeStar,batchStarValue,batchChangeRelation,showDraftTools;
    Label batchContactStatus;
    Dictionary<string,object> batchOverview=new Dictionary<string,object>();
    Dictionary<string,string> batchResults=new Dictionary<string,string>();
    Panel draftTools;
    bool batchRendering,catalogBusy,batchOperationBusy,batchCancelRequested;
    List<ContactChoice> contactChoices=new List<ContactChoice>();
    HashSet<string> contactChecked=new HashSet<string>(StringComparer.Ordinal);
    List<ContactChoice> lastRemovedContacts=new List<ContactChoice>();

    void ToggleDraftTools(){
        if(draftTools==null)return;draftTools.Visible=showDraftTools.Checked;
        int top=showDraftTools.Checked?draftTools.Bottom+UiPixel(20):UiPixel(75);
        foreach(Control child in diagnosis.Parent.Controls)if(child is Label&&child.Text.StartsWith("运行诊断"))child.Top=top;
        diagnosis.Top=top+UiPixel(40);diagnosis.Height=UiPixel(400);
    }
    void ExpandManagementLayout(){
        var screen=Screen.FromControl(this).WorkingArea;float scale;using(var graphics=Graphics.FromHwnd(IntPtr.Zero))scale=graphics.DpiX/96F;
        Size=new Size(Math.Min(1480,Math.Max(1080,(int)(screen.Width/scale)-36)),Math.Min(900,Math.Max(580,(int)(screen.Height/scale)-40)));
        foreach(TabPage page in mainProductTabs.TabPages){
            int boundary=0,shift=0;
            if(page.Text=="回复规则"){friendList.Height=320;groupList.Height=320;}
            if(page.Text=="批量管理"){contactBatchList.Height=430;}
            if(page.Text=="重要提醒"){reminderList.Height=510;boundary=550;shift=120;reminderDetail.Height=210;}
            if(shift>0)foreach(Control child in page.Controls)if(child.Top>=boundary)child.Top+=shift;
            if(page.Text!="人物记忆"&&page.Text!="资料与帮助"&&page.Text!="设置")foreach(Control child in page.Controls){if(child.Dock!=DockStyle.None)continue;child.Top=(int)Math.Round(child.Top*1.18);if(child is Button)child.Height=Math.Max(38,(int)(child.Height*1.18));else if(child is ListView||child is TextBox&&((TextBox)child).Multiline)child.Height=(int)(child.Height*1.12);else if(child is Label)child.Height=Math.Max(child.Height,30);}
        }
        if(memoryList!=null){Control parent=memoryList.Parent;memoryList.Height=300;foreach(Control child in parent.Controls)if(child!=memoryList&&child.Top>=190)child.Top+=145;memoryEdit.Height=100;}
        EnlargeInputs(this);ToggleDraftTools();
    }
    void EnlargeInputs(Control parent){foreach(Control child in parent.Controls){
        if(child is NumericUpDown){child.Font=new Font("Microsoft YaHei UI",13F);child.Height=36;child.Width=Math.Max(95,child.Width);}
        var combo=child as ComboBox;if(combo!=null){combo.Font=new Font("Microsoft YaHei UI",11F);combo.DrawMode=DrawMode.OwnerDrawFixed;combo.ItemHeight=30;combo.DropDownHeight=320;combo.IntegralHeight=false;combo.DrawItem+=delegate(object sender,DrawItemEventArgs e){e.DrawBackground();if(e.Index>=0)TextRenderer.DrawText(e.Graphics,Convert.ToString(((ComboBox)sender).Items[e.Index]),e.Font,e.Bounds,e.ForeColor,TextFormatFlags.Left|TextFormatFlags.VerticalCenter);e.DrawFocusRectangle();};}
        var list=child as ListView;if(list!=null){list.Font=normal;var images=new ImageList();images.ImageSize=new Size(1,34);list.SmallImageList=images;list.Disposed+=delegate{images.Dispose();};}
        EnlargeInputs(child);
    }}
    HashSet<string> HiddenReports(){string path=Path.Combine(settingsDir,"report-visibility.json");try{return new HashSet<string>(json.Deserialize<string[]>(File.ReadAllText(path,Encoding.UTF8)),StringComparer.Ordinal);}catch{return new HashSet<string>(StringComparer.Ordinal);}}
    void HideSelectedReports(bool restore){var hidden=HiddenReports();if(restore)hidden.Clear();else foreach(object item in reportList.SelectedItems)hidden.Add(Convert.ToString(item));Directory.CreateDirectory(settingsDir);var names=new List<string>(hidden);File.WriteAllText(Path.Combine(settingsDir,"report-visibility.json"),json.Serialize(names),Encoding.UTF8);LoadReportList();Notice(restore?"所有报告已恢复显示。":"所选报告已从列表隐藏，原文件保留，可一键恢复。");}
    void ReadSelectedReports(){var content=new StringBuilder();foreach(object selected in reportList.SelectedItems){string name=Path.GetFileName(Convert.ToString(selected));string path=Path.Combine(AppPaths.Storage,"报告",name);if(File.Exists(path)){content.AppendLine("# "+name);content.AppendLine(File.ReadAllText(path,Encoding.UTF8));content.AppendLine();}}SetReading(reportView,content.ToString());}

    static List<ListViewItem> BatchRows(ListView list){
        var result=new List<ListViewItem>();
        if(list.CheckedItems.Count>0){foreach(ListViewItem row in list.CheckedItems)result.Add(row);}
        else foreach(ListViewItem row in list.SelectedItems)result.Add(row);
        return result;
    }
    static HashSet<string> CheckedIds(ListView list){var ids=new HashSet<string>(StringComparer.Ordinal);foreach(ListViewItem row in list.CheckedItems){var value=row.Tag as Dictionary<string,object>;if(value!=null)ids.Add(Str(value,"id"));}return ids;}
    static void BatchList(ListView list){list.CheckBoxes=true;list.MultiSelect=true;list.KeyDown+=delegate(object sender,KeyEventArgs e){if(e.Control&&e.KeyCode==Keys.A){foreach(ListViewItem row in list.Items)row.Checked=true;e.SuppressKeyPress=true;}};}
    void BatchSelectButtons(Control parent,ListView list,int x,int y){
        Button all=MakeButton("全选",x,y,70,28);all.Click+=delegate{foreach(ListViewItem row in list.Items)row.Checked=true;};parent.Controls.Add(all);
        Button clear=MakeButton("清空选择",x+80,y,100,28);clear.Click+=delegate{foreach(ListViewItem row in list.Items){row.Checked=false;row.Selected=false;}};parent.Controls.Add(clear);
    }
    void BuildContactManagement(TabControl tabs){
        TabPage p=MakeTab("批量管理");tabs.TabPages.Add(p);p.Enter+=delegate{if(contactChoices.Count==0)UseConfiguredContacts();};
        p.Controls.Add(MakeLabel("好友、群和已有对象分别查看；勾选后从小三角下拉菜单选择批量操作。",25,20,930,40,true));
        contactBatchKind=MakeCombo(25,75,200,new string[]{"已有管理对象","好友","群"});contactBatchKind.SelectedIndexChanged+=delegate{contactChecked.Clear();RenderContactChoices();};p.Controls.Add(contactBatchKind);
        Button readFriends=MakeButton("导入微信好友",240,72,205,40,true);readFriends.Click+=async delegate{await ReadContactCatalog("friend");};p.Controls.Add(readFriends);
        Button readGroups=MakeButton("导入微信群",460,72,205,40,true);readGroups.Click+=async delegate{await ReadContactCatalog("group");};p.Controls.Add(readGroups);
        contactBatchSearch=MakeText(685,76,270);contactBatchSearch.TextChanged+=delegate{RenderContactChoices();};p.Controls.Add(contactBatchSearch);
        var oneFriend=MakeButton("单个添加好友",25,130,195,38);oneFriend.Click+=delegate{ManageSingleContact("friend");};p.Controls.Add(oneFriend);
        var oneGroup=MakeButton("单个添加群",235,130,195,38);oneGroup.Click+=delegate{ManageSingleContact("group");};p.Controls.Add(oneGroup);
        var editOne=MakeButton("修改当前项",445,130,195,38);editOne.Click+=delegate{ManageSingleContact("edit");};p.Controls.Add(editOne);
        var removeOne=MakeButton("移除当前项",655,130,195,38);removeOne.Click+=delegate{ManageSingleContact("remove");};p.Controls.Add(removeOne);
        contactBatchList=new ListView{Location=new Point(25,135),Size=new Size(930,430),View=View.Details,FullRowSelect=true,HideSelection=false};BatchList(contactBatchList);
        foreach(var column in new string[]{"类型","称呼 / 备注","星标","关系","深度","回复模式","日报周报","重要提醒","历史条数","整理结果","唯一身份"})contactBatchList.Columns.Add(column,column=="唯一身份"?240:column=="整理结果"?320:column=="称呼 / 备注"?150:column=="类型"||column=="星标"?55:column=="历史条数"?90:120);
        contactBatchList.DoubleClick+=delegate{ManageSingleContact("edit");};
        contactBatchList.ItemChecked+=delegate(object sender,ItemCheckedEventArgs e){if(batchRendering)return;var c=e.Item.Tag as ContactChoice;if(c==null)return;string key=c.Kind+":"+c.Id;if(e.Item.Checked)contactChecked.Add(key);else contactChecked.Remove(key);};p.Controls.Add(contactBatchList);
        batchAction=MakeCombo(25,595,330,new string[]{"选择批量操作 ▼","添加所选对象","移除所选对象","撤销上次移除","设为星标","取消星标","改为自动回复","改为只记录","改为草稿确认","屏蔽日报周报","恢复日报周报","屏蔽重要提醒","恢复重要提醒","修改关系与分析深度","整理历史、精炼与人物分析","应用补充的专属表达要求","应用下方组合设置"});p.Controls.Add(batchAction);
        var execute=MakeButton("执行操作",370,592,180,36,true);execute.Click+=async delegate{await ExecuteBatchAction();};p.Controls.Add(execute);BatchSelectButtons(p,contactBatchList,610,595);
        batchChangeMode=MakeCheck("修改模式",25,660,140);batchChangeMode.Checked=true;p.Controls.Add(batchChangeMode);contactBatchMode=MakeCombo(180,657,230,new string[]{"自动回复","只记录","草稿确认（可选）"});p.Controls.Add(contactBatchMode);
        batchChangeStar=MakeCheck("修改星标",445,660,140);p.Controls.Add(batchChangeStar);batchStarValue=MakeCheck("设为星标",610,660,170);p.Controls.Add(batchStarValue);
        batchChangeRelation=MakeCheck("修改关系与深度",25,715,210);p.Controls.Add(batchChangeRelation);contactBatchRelation=MakeCombo(255,712,220,new string[]{"尚未指定","一般关系","关系较近","关系很近"});p.Controls.Add(contactBatchRelation);contactBatchDepth=MakeCombo(490,712,180,new string[]{"自动选择","简要","详细","深入"});p.Controls.Add(contactBatchDepth);
        var stop=MakeButton("停止整理",690,710,180,36);stop.Click+=delegate{StopAllWork();};p.Controls.Add(stop);
        p.Controls.Add(MakeLabel("批量粘贴：每行一个微信号 / wxid / 准确昵称，制表符后可填写称呼。",25,780,930,35));contactBatchPaste=MakeText(25,825,930,150,true);p.Controls.Add(contactBatchPaste);
        var paste=MakeButton("添加全部行",25,1000,250,42);paste.Click+=async delegate{var before=new HashSet<string>();foreach(ListViewItem row in friendList.Items)before.Add(row.Text);foreach(ListViewItem row in groupList.Items)before.Add(row.Text);AddPastedContacts();foreach(ListViewItem row in contactBatchList.Items){var choice=row.Tag as ContactChoice;row.Checked=choice!=null&&choice.Existing!=null&&!before.Contains(choice.Existing.Text);}await UpdateBatchAnalyses();};p.Controls.Add(paste);
        batchContactStatus=MakeLabel("读取本机联系人分类资料；好友列表不混入仅群成员。已有对象独立查看，可批量修改。",25,1070,930,90);p.Controls.Add(batchContactStatus);
        p.Controls.Add(MakeLabel("所选对象的专属回复要求（批量操作选择“应用专属表达要求”；留空可清除）",25,1180,930,40));batchPersonaText=MakeText(25,1235,930,120,true);p.Controls.Add(batchPersonaText);
        foreach(Control child in p.Controls)if(child==contactBatchList||child.Top>=590)child.Top+=70;
        p.SizeChanged+=delegate{contactBatchList.Width=Math.Max(100,p.ClientSize.Width-contactBatchList.Left-UiPixel(24));};
    }
    void OpenContactManagement(){UseConfiguredContacts();SelectMainTab("联系人管理");}
    void UseConfiguredContacts(){
        contactChoices.Clear();contactChecked.Clear();
        foreach(ListView list in new ListView[]{friendList,groupList})foreach(ListViewItem row in list.Items)contactChoices.Add(new ContactChoice{Id=row.Text,Label=row.SubItems[1].Text,Kind=list==groupList?"group":"friend",Existing=row,Nickname="",Alias=""});
        contactBatchKind.SelectedIndex=0;RenderContactChoices();
    }
    Dictionary<string,object> ContactMappings(){try{var result=LocalCall("assistant_features.py",new Dictionary<string,object>{{"action","contact_map"}});batchOverview=result.ContainsKey("overview")?result["overview"] as Dictionary<string,object>??new Dictionary<string,object>():new Dictionary<string,object>();return result["identifiers"] as Dictionary<string,object>??new Dictionary<string,object>();}catch{return new Dictionary<string,object>();}}
    void AssociateContacts(){
        var map=ContactMappings();
        foreach(var choice in contactChoices){choice.Existing=null;ListView list=choice.Kind=="group"?groupList:friendList;foreach(ListViewItem row in list.Items){string canonical=map.ContainsKey(row.Text)?Convert.ToString(map[row.Text]):row.Text;if(canonical==choice.Id||row.Text==choice.Id){choice.Existing=row;break;}}}
    }
    async Task ReadContactCatalog(string kind){
        if(kind!="friend"&&kind!="group")throw new ArgumentException("请选择好友或群");
        if(catalogBusy)return;catalogBusy=true;batchContactStatus.Text=kind=="friend"?"正在单独导入微信好友……":"正在单独导入微信群……";
        try{
            string executable=pythonPath.Text.Trim(),script=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"contact_catalog.py");
            var info=new ProcessStartInfo(executable,"-X utf8 -u \""+script+"\" --kind "+kind);info.UseShellExecute=false;info.CreateNoWindow=true;info.WorkingDirectory=AppDomain.CurrentDomain.BaseDirectory;info.RedirectStandardOutput=true;info.RedirectStandardError=true;info.StandardOutputEncoding=Encoding.UTF8;info.StandardErrorEncoding=Encoding.UTF8;
            var outcome=await Task.Run(()=>RunCaptured(info,null,90000));if(IsDisposed)return;
            if(outcome.Item1!=0)throw new InvalidOperationException("请保持电脑微信已登录，也可以直接批量粘贴微信号。");
            var data=json.Deserialize<Dictionary<string,object>>(outcome.Item2.Trim());var values=data["items"] as IList;if(values==null)throw new InvalidOperationException("返回名单不完整");
            if(Str(data,"requestedKind")!=kind)throw new InvalidOperationException("导入分类不一致，未更新列表");
            foreach(object value in values)if(Str((Dictionary<string,object>)value,"kind")!=kind)throw new InvalidOperationException("导入结果混入其他类型，未更新列表");
            contactChoices.RemoveAll(c=>c.Kind==kind);contactChecked.Clear();contactBatchSearch.Clear();
            foreach(object value in values){var item=(Dictionary<string,object>)value;contactChoices.Add(new ContactChoice{Id=Str(item,"identifier"),Label=Str(item,"label"),Nickname=Str(item,"nickname"),Alias=Str(item,"alias"),Kind=kind});}
            MergeManagedContacts();contactBatchKind.SelectedIndex=kind=="friend"?1:2;RenderContactChoices();PopulateAdvisorContacts();batchContactStatus.Text="已单独导入 "+values.Count+" 个"+(kind=="friend"?"微信好友":"微信群")+"供选择；没有自动加入管理名单。另一类名单和单个添加入口保留。";
        }catch(Exception error){if(!IsDisposed)batchContactStatus.Text="读取失败："+error.Message;}finally{catalogBusy=false;}
    }
    void RenderContactChoices(){
        if(contactBatchList==null)return;var viewport=new ContactViewport(this);var listState=CaptureContactList(contactBatchList);batchRendering=true;contactBatchList.BeginUpdate();
        var cachedMap=ContactMappings();Func<string,string> ContactMappingsCached=delegate(string id){return cachedMap.ContainsKey(id)?Convert.ToString(cachedMap[id]):id;};
        SortManagedLists(cachedMap);
        try{contactBatchList.Items.Clear();string query=contactBatchSearch==null?"":contactBatchSearch.Text.Trim();int kind=contactBatchKind==null?0:contactBatchKind.SelectedIndex;
            foreach(var choice in SortContactChoices(contactChoices,cachedMap)){if(kind==0&&choice.Existing==null||kind==1&&choice.Kind!="friend"||kind==2&&choice.Kind!="group")continue;if(query.Length>0&&(choice.Id+" "+choice.Label+" "+choice.Nickname+" "+choice.Alias).IndexOf(query,StringComparison.OrdinalIgnoreCase)<0)continue;
                string canonical=ContactMappingsCached(choice.Id);
                var detail=batchOverview.ContainsKey(canonical)?batchOverview[canonical] as Dictionary<string,object>:null;
                string relation=detail==null?"unspecified":Str(detail,"relation"),depth=detail==null?"auto":Str(detail,"depth");
                string relationText=relation=="very_close"?"关系很近":relation=="close"?"关系较近":relation=="general"?"一般关系":"尚未指定";
                string depthText=depth=="deep"?"深入":depth=="detailed"?"详细":depth=="brief"?"简要":"自动选择";
                var row=new ListViewItem(choice.Kind=="group"?"群":"好友");
                row.SubItems.Add(choice.Existing==null?choice.Label:choice.Existing.SubItems[1].Text);
                row.SubItems.Add(choice.Kind=="group"?"—":choice.Existing!=null&&choice.Existing.SubItems[2].Text=="★"?"★":"—");
                row.SubItems.Add(relationText);row.SubItems.Add(depthText);
                row.SubItems.Add(choice.Existing==null?"未添加":choice.Existing.SubItems[choice.Kind=="group"?2:3].Text);
                bool allowed=analysisScope!=null&&analysisScope.SelectedIndex!=2&&(analysisScope.SelectedIndex==0||choice.Existing!=null);
                row.SubItems.Add(reportExcluded.Contains(canonical)?"已屏蔽":!allowed?"分析关闭":dailyReport.Checked||weeklyReport.Checked?"参与整理":"日报周报关闭");
                row.SubItems.Add(reminderExcluded.Contains(canonical)?"已屏蔽":!allowed?"分析关闭":importantReminders.Checked?"参与提醒":"提醒关闭");
                row.SubItems.Add(detail==null?"—":Str(detail,"history"));
                string result=batchResults.ContainsKey(canonical)?batchResults[canonical]:detail==null?"尚未整理":Str(detail,"status");
                row.SubItems.Add(String.IsNullOrWhiteSpace(result)?"尚未整理":result);row.SubItems.Add(choice.Id);
                row.Tag=choice;contactBatchList.Items.Add(row);row.Checked=contactChecked.Contains(choice.Kind+":"+choice.Id);}

        }finally{RestoreContactList(contactBatchList,listState);contactBatchList.EndUpdate();batchRendering=false;viewport.Dispose();}
    }
    List<ContactChoice> ChosenContacts(){var selected=new List<ContactChoice>();foreach(var row in BatchRows(contactBatchList))selected.Add((ContactChoice)row.Tag);return selected;}
    void MergeManagedContacts(){var map=ContactMappings();foreach(ListView list in new[]{friendList,groupList})foreach(ListViewItem row in list.Items){string kind=list==groupList?"group":"friend",id=map.ContainsKey(row.Text)?Convert.ToString(map[row.Text]):row.Text;if(!contactChoices.Exists(c=>c.Kind==kind&&c.Id==id))contactChoices.Add(new ContactChoice{Id=id,Label=row.SubItems[1].Text,Kind=kind,Existing=row,Nickname="",Alias=""});}AssociateContacts();}
    void ManageSingleContact(string operation){
        ContactChoice chosen=contactBatchList.SelectedItems.Count==1?contactBatchList.SelectedItems[0].Tag as ContactChoice:null;
        if(operation=="remove"){if(chosen==null||chosen.Existing==null){Notice("请点击一项已管理对象；单个移除只处理当前项。");return;}lastRemovedContacts.Clear();lastRemovedContacts.Add(new ContactChoice{Id=chosen.Id,Label=chosen.Label,Kind=chosen.Kind,Existing=chosen.Existing});(chosen.Kind=="group"?groupList:friendList).Items.Remove(chosen.Existing);contactChecked.Remove(chosen.Kind+":"+chosen.Id);SaveContactBatch("已单独移除当前对象，其余勾选项保留。");return;}
        string before=json.Serialize(FriendConfigs())+json.Serialize(GroupConfigs());
        if(operation=="friend")PromptFriend(null);else if(operation=="group")PromptGroup(null);else if(operation=="edit"){if(chosen==null||chosen.Existing==null){Notice("请点击一项已管理对象，再修改当前项。");return;}if(chosen.Kind=="group")PromptGroup(chosen.Existing);else PromptFriend(chosen.Existing);}else return;
        if(before!=json.Serialize(FriendConfigs())+json.Serialize(GroupConfigs())){MergeManagedContacts();SaveContactBatch("单个对象已保存，与批量管理共用同一份名单。");PopulateAdvisorContacts();}
    }
    string BatchMode(){return contactBatchMode.SelectedIndex==1?"record":contactBatchMode.SelectedIndex==2?"draft":"auto";}
    string UniqueContactLabel(string label,string id){string result=String.IsNullOrWhiteSpace(label)?id:label;int number=1;bool found;do{found=false;foreach(ListView list in new ListView[]{friendList,groupList})foreach(ListViewItem row in list.Items)if(String.Equals(row.SubItems[1].Text,result,StringComparison.OrdinalIgnoreCase)){found=true;break;}if(found)result=label+"（"+(number++)+"）";}while(found);return result;}
    bool AddContactChoice(ContactChoice choice,string mode){
        ListView list=choice.Kind=="group"?groupList:friendList;int count=list.Items.Count;
        string label=UniqueContactLabel(choice.Label,choice.Id);
        if(choice.Kind=="group")AddGroupEntry(choice.Id,label,mode);else AddFriendEntry(choice.Id,label,batchChangeStar.Checked&&batchStarValue.Checked,mode);
        if(list.Items.Count==count)return false;choice.Existing=list.Items[list.Items.Count-1];return true;
    }
    void SaveContactBatch(string message){SyncContacts();SyncGroups();if(SaveSettings(true,false)){PopulateMemoryContacts();batchContactStatus.Text=message+" 已保存并按最新名单生效；历史聊天和分析文件保留。";status.Text=batchContactStatus.Text;}else batchContactStatus.Text="保存失败，请检查设置后重试。";AssociateContacts();RenderContactChoices();}
    void AddCheckedContacts(){int count=0;foreach(var choice in ChosenContacts())if(choice.Existing==null&&AddContactChoice(choice,BatchMode()))count++;if(count==0){batchContactStatus.Text="请勾选尚未添加的对象；重复身份不会重复添加。";return;}SaveContactBatch("已添加 "+count+" 个对象。");}
    void RemoveCheckedContacts(){var selected=ChosenContacts();lastRemovedContacts.Clear();foreach(var choice in selected)if(choice.Existing!=null){lastRemovedContacts.Add(new ContactChoice{Id=choice.Id,Label=choice.Label,Kind=choice.Kind,Existing=choice.Existing});(choice.Kind=="group"?groupList:friendList).Items.Remove(choice.Existing);}if(lastRemovedContacts.Count>0)SaveContactBatch("已移除 "+lastRemovedContacts.Count+" 个对象。");else batchContactStatus.Text="请勾选名单中的对象。";}
    void RemoveRuleRows(ListView list){var selected=BatchRows(list);if(selected.Count==0)return;lastRemovedContacts.Clear();foreach(var row in selected){lastRemovedContacts.Add(new ContactChoice{Id=row.Text,Label=row.SubItems[1].Text,Kind=list==groupList?"group":"friend",Existing=row});list.Items.Remove(row);}SaveContactBatch("已移除 "+selected.Count+" 个对象。");}
    void UndoContactRemoval(){int count=0;foreach(var choice in lastRemovedContacts){ListView list=choice.Kind=="group"?groupList:friendList;bool exists=false;foreach(ListViewItem row in list.Items)if(row.Text==choice.Id){exists=true;break;}if(!exists&&choice.Existing!=null){list.Items.Add(choice.Existing);count++;}}lastRemovedContacts.Clear();if(count>0)SaveContactBatch("已恢复 "+count+" 个对象。");}
    void AddPastedContacts(){int count=0;string mode=BatchMode();foreach(string line in contactBatchPaste.Text.Split(new char[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries)){string[] parts=line.Split('\t');string id=parts[0].Trim();if(id.Length==0)continue;var choice=new ContactChoice{Id=id,Label=parts.Length>1?parts[1].Trim():id,Kind=id.EndsWith("@chatroom")||contactBatchKind.SelectedIndex==2?"group":"friend"};if(AddContactChoice(choice,mode))count++;}if(count==0){batchContactStatus.Text="没有可添加的新对象，请按每行一个身份填写。";return;}MergeManagedContacts();SaveContactBatch("批量粘贴添加了 "+count+" 个对象。");}
    async Task ApplyContactBatch(){
        if(batchOperationBusy)return;var selected=ChosenContacts();if(selected.Count==0){batchContactStatus.Text="请先勾选对象。";return;}batchOperationBusy=true;
        try{
            if(!batchChangeMode.Checked&&!batchChangeStar.Checked&&!batchChangeRelation.Checked){batchContactStatus.Text="请选择需要修改的设置。";return;}
            var map=ContactMappings();var ids=new List<string>();
            foreach(var choice in selected){if(choice.Existing==null)continue;var row=choice.Existing;ids.Add(map.ContainsKey(row.Text)?Convert.ToString(map[row.Text]):row.Text);if(batchChangeMode.Checked)row.SubItems[choice.Kind=="group"?2:3].Text=ModeText(BatchMode());if(batchChangeStar.Checked&&choice.Kind!="group")row.SubItems[2].Text=batchStarValue.Checked?"★":"";}
            if(ids.Count==0){batchContactStatus.Text="请先添加所选对象。";return;}
            if(batchChangeRelation.Checked){string relation=new string[]{"unspecified","general","close","very_close"}[Math.Max(0,contactBatchRelation.SelectedIndex)],depth=new string[]{"auto","brief","detailed","deep"}[Math.Max(0,contactBatchDepth.SelectedIndex)];await Task.Run(()=>LocalCall("assistant_features.py",new Dictionary<string,object>{{"action","memory_options_many"},{"ids",ids},{"relation",relation},{"depth",depth}}));}
            SaveContactBatch("已批量修改 "+ids.Count+" 个对象。分析深度在下次更新时使用。");
        }catch(Exception error){batchContactStatus.Text="批量修改失败："+error.Message;}finally{batchOperationBusy=false;}
    }
    async Task UpdateBatchAnalyses(){
        if(memorySyncRunning||insightRunning||batchOperationBusy){batchContactStatus.Text="另一项整理正在运行，请待其完成。";return;}
        var selected=ChosenContacts().FindAll(delegate(ContactChoice c){return c.Existing!=null;});if(selected.Count==0){batchContactStatus.Text="请勾选已添加的对象。";return;}
        bool externalAnalysis=analysisScope.SelectedIndex!=2;
        if(externalAnalysis&&!FeatureRouteReady("memory")){batchContactStatus.Text="对象已保存；分析需要 API Key，填写后选择整理即可继续。";return;}
        long generation=stopGeneration;memorySyncRunning=true;batchOperationBusy=true;batchCancelRequested=false;int success=0,failed=0;
        try{
            var map=ContactMappings();string executable=pythonPath.Text.Trim();var original=Config();string apiKey=key.Text.Trim();
            for(int i=0;i<selected.Count;i++){if(IsDisposed||batchCancelRequested||generation!=stopGeneration)break;var choice=selected[i];batchContactStatus.Text="正在整理 "+(i+1)+" / "+selected.Count+"："+choice.Existing.SubItems[1].Text;
                bool personAnalysis=externalAnalysis&&!reportExcluded.Contains(map.ContainsKey(choice.Id)?Convert.ToString(map[choice.Id]):choice.Id);
                var config=new Dictionary<string,object>(original);config["apiKey"]=apiKey;config["memoryTarget"]=new Dictionary<string,object>{{"identifier",map.ContainsKey(choice.Id)?map[choice.Id]:(object)choice.Id},{"label",choice.Existing.SubItems[1].Text},{"kind",choice.Kind}};
                string payload=json.Serialize(config)+"\n";var info=new ProcessStartInfo(executable,"-X utf8 -u \""+Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"memory_manager.py")+"\" --selected"+(personAnalysis?"":" --local-only"));info.UseShellExecute=false;info.CreateNoWindow=true;info.WorkingDirectory=AppDomain.CurrentDomain.BaseDirectory;info.RedirectStandardInput=true;info.RedirectStandardOutput=true;info.RedirectStandardError=true;info.StandardOutputEncoding=Encoding.UTF8;info.StandardErrorEncoding=Encoding.UTF8;
                var result=await Task.Run(()=>RunCaptured(info,payload,1800000,delegate(Process worker){memoryWorker=worker;TrackJob(worker,generation);if(IsDisposed)worker.Kill();}));memoryWorker=null;string resultId=map.ContainsKey(choice.Id)?Convert.ToString(map[choice.Id]):choice.Id;if(result.Item1==0){success++;batchResults[resultId]=personAnalysis?"历史、精炼与分析已完成":"历史已导入；分析关闭";}else{failed++;batchResults[resultId]="未完成；旧分析保留；"+BatchFailureReason(result.Item2,"");}RenderContactChoices();
            }
            if(!IsDisposed){PopulateMemoryContacts();batchContactStatus.Text="批量整理结束：成功 "+success+"，未完成 "+failed+"。每项结果已显示；未完成对象保留旧分析，可重新选择整理。";}
        }catch(Exception error){if(!IsDisposed)batchContactStatus.Text="批量整理中断："+error.Message+"；已完成结果保留。";}finally{memoryWorker=null;memorySyncRunning=false;batchOperationBusy=false;}
    }
    static string BatchFailureReason(string output,string error){
        string text=(output+"\n"+error).Trim();string[] lines=text.Split(new char[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries);
        return lines.Length==0?"请查看连接日志":lines[lines.Length-1].Replace("ValueError: ","").Replace("RuntimeError: ","");
    }
    void ShowExtractionDiagnostics(){
        string path=Path.Combine(settingsDir,"information-state.json");var text=new StringBuilder("筛选原因：过滤结果不作为待办；待核对结果可在重要提醒核对原话。\r\n\r\n");
        if(File.Exists(path)){var data=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(path,Encoding.UTF8));IList entries=data.ContainsKey("extractionDiagnostics")?data["extractionDiagnostics"] as IList:null;if(entries!=null)foreach(object entry in entries){var row=entry as Dictionary<string,object>;if(row!=null){text.AppendLine(Str(row,"time")+" · "+Str(row,"source")+" · "+Str(row,"sender"));text.AppendLine("消息 "+Str(row,"messageId")+" · "+Str(row,"field")+" · "+Str(row,"reason"));text.AppendLine();}}}
        ShowInternalDocument("提醒筛选原因",text.ToString());
    }
    async Task ChangeMemoryKinds(){MemoryContact contact=memoryContact.SelectedItem as MemoryContact;if(contact==null)return;var ids=new List<string>();foreach(var row in BatchRows(memoryList))ids.Add(Str((Dictionary<string,object>)row.Tag,"id"));if(ids.Count==0)return;string kind=memoryKind.Text;try{await Task.Run(()=>LocalCall("assistant_features.py",new Dictionary<string,object>{{"action","memory_kind_many"},{"identifier",contact.Id},{"ids",ids},{"kind",kind}}));await RefreshMemory();Notice("已批量修改记忆分类。");}catch(Exception error){Notice(error.Message);}}
    async Task AddMemoryLines(){MemoryContact contact=memoryContact.SelectedItem as MemoryContact;if(contact==null)return;var texts=new List<string>();foreach(string line in memoryEdit.Text.Split(new char[]{'\r','\n'},StringSplitOptions.RemoveEmptyEntries))if(line.Trim().Length>0)texts.Add(line.Trim());if(texts.Count==0)return;var value=new Dictionary<string,object>{{"action","memory_save_many"},{"identifier",contact.Id},{"texts",texts},{"kind",memoryKind.Text},{"source",memorySource.Text}};try{var result=await Task.Run(()=>LocalCall("assistant_features.py",value));await RefreshMemory();Notice("已批量新增 "+Str(result,"changed")+" 条手动记忆。");}catch(Exception error){Notice(error.Message);}}
}
}
