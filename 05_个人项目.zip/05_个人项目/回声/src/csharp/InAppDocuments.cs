using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace EchoWechatDesktop {
static class ExistingEchoWindow {
    delegate bool Callback(IntPtr window,IntPtr state);
    [DllImport("user32.dll")] static extern bool EnumWindows(Callback callback,IntPtr state);
    [DllImport("user32.dll",CharSet=CharSet.Unicode)] static extern int GetWindowText(IntPtr window,StringBuilder text,int count);
    [DllImport("user32.dll")] static extern bool ShowWindowAsync(IntPtr window,int command);
    [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr window);
    internal static void Activate(){EnumWindows(delegate(IntPtr window,IntPtr state){var title=new StringBuilder(256);GetWindowText(window,title,256);if(title.ToString()=="回声 Echo · 当前模型 微信机器人"){ShowWindowAsync(window,9);SetForegroundWindow(window);return false;}return true;},IntPtr.Zero);}
}
public partial class MainForm {
    TabControl mainProductTabs, memoryViews;
    TabPage documentTab;
    RichTextBox documentView, relationshipView, digestView, memoryEvidenceView;
    Label documentTitle, memoryReadingStatus;
    TextBox documentSearch;
    ComboBox relationshipChoice, analysisDepth, memorySection, documentKind;
    NumericUpDown closeMemorySampleChars;
    Button updateSelectedMemory;

    void Notice(string text,string title="提示"){if(status!=null)status.Text=text;}
    void Notice(Form dialog,string text,string title="提示"){Notice(text,title);dialog.Text=title+" · "+text;}
    void BuildDocumentTab(TabControl tabs){
        mainProductTabs=tabs;documentTab=MakeTab("资料与帮助");tabs.TabPages.Add(documentTab);
        documentKind=MakeCombo(25,20,310,new string[]{"使用说明","人物分析与内置阅读说明","修复说明","功能说明","批量管理与提醒修复说明","界面与字体说明","本次需求升级说明","秘书版使用说明","可靠性改进说明","联系人AI与即时沟通说明","前端与反馈说明"});documentTab.Controls.Add(documentKind);
        Button load=MakeButton("在这里查看",350,18,130,32);load.Click+=delegate{string[] names={"使用说明.md","人物分析与内置阅读说明.md","复测问题修复说明.md","功能升级与轻量化说明.md","批量管理与提醒修复说明.md","界面与字体说明.md","需求升级说明.md","秘书版说明.md","可靠性改进说明.md","联系人AI与即时沟通说明.md","前端与反馈说明.md"};ShowInternalFile(documentKind.Text,Path.Combine(AppPaths.Docs,names[Math.Max(0,documentKind.SelectedIndex)]));};documentTab.Controls.Add(load);
        documentSearch=MakeText(500,21,260);documentTab.Controls.Add(documentSearch);
        Button search=MakeButton("查找",775,18,85,32);search.Click+=delegate{FindInDocument(documentView,documentSearch.Text);};documentTab.Controls.Add(search);
        Button copy=MakeButton("复制",875,18,80,32);copy.Click+=delegate{if(!String.IsNullOrEmpty(documentView.SelectedText))Clipboard.SetText(documentView.SelectedText);else if(!String.IsNullOrEmpty(documentView.Text))Clipboard.SetText(documentView.Text);};documentTab.Controls.Add(copy);
        documentTitle=MakeLabel("报告、分析、原话、日志和识别结果都在 App 内查看。",25,65,930,42,true);documentTab.Controls.Add(documentTitle);
        documentView=ReadingBox();documentView.Location=new Point(25,115);documentView.Size=new Size(930,500);documentTab.Controls.Add(documentView);documentTab.AutoScroll=false;
        documentTab.SizeChanged+=delegate{documentView.Size=new Size(Math.Max(700,documentTab.ClientSize.Width-documentView.Left-UiPixel(24)),documentView.Height);};
    }
    RichTextBox ReadingBox(){var box=new EchoReadingBox();box.ReadOnly=true;box.DetectUrls=false;box.BackColor=Color.White;box.Font=normal;box.BorderStyle=BorderStyle.FixedSingle;box.WordWrap=true;return box;}
    void SetReading(RichTextBox box,string text){RenderReading(box,text);}
    void FindInDocument(RichTextBox box,string query){if(String.IsNullOrWhiteSpace(query))return;int next=box.Find(query,Math.Min(box.TextLength,box.SelectionStart+box.SelectionLength),RichTextBoxFinds.None);if(next<0)next=box.Find(query,0,RichTextBoxFinds.None);if(next<0)Notice("没有找到“"+query+"”。");else box.ScrollToCaret();}
    void ShowInternalDocument(string title,string text){if(documentView==null)return;documentTitle.Text=title;SetReading(documentView,text);mainProductTabs.SelectedTab=documentTab;}
    void ShowInternalFile(string title,string path,bool tail=false){try{if(!File.Exists(path)){ShowInternalDocument(title,"暂无这份本机资料。");return;}string text;using(var stream=File.OpenRead(path)){bool truncated=stream.Length>2000000;if(truncated&&tail)stream.Seek(-2000000,SeekOrigin.End);using(var reader=new StreamReader(stream,Encoding.UTF8,true)){char[] chars=new char[2000000];int used=0,read;while(used<chars.Length&&(read=reader.Read(chars,used,chars.Length-used))>0)used+=read;text=new string(chars,0,used);if(truncated)text=(tail?"（显示最近约 2 MB 记录）\n":"（内容较长，显示前约 200 万字）\n")+text;}}ShowInternalDocument(title,text);}catch(Exception error){ShowInternalDocument(title,"读取失败："+error.GetType().Name);}}
    void SelectMainTab(string name){foreach(TabPage tab in mainProductTabs.TabPages)if(tab.Text==name){mainProductTabs.SelectedTab=tab;return;}}

    void BuildRelationshipMemory(TabPage p){
        p.Controls.Add(MakeLabel("关系近的人可以深入分析；事实、分析解释、待确认推测分开，附原话与时间。查看资料不打开外部窗口。",25,18,930,48,true));
        memoryContact=MakeCombo(25,78,440,new string[]{"请选择联系人"});memoryContact.SelectedIndexChanged+=delegate{RefreshSelectedMemoryContact();};p.Controls.Add(memoryContact);
        Button reload=MakeButton("读取本机分析",485,76,150,34);reload.Click+=delegate{ShowAnalysis();};p.Controls.Add(reload);
        updateSelectedMemory=MakeButton("更新此人分析",650,76,170,34,true);updateSelectedMemory.Click+=async delegate{await UpdateSelectedAnalysis();};p.Controls.Add(updateSelectedMemory);
        p.Controls.Add(MakeLabel("关系程度",25,128,80,25));relationshipChoice=MakeCombo(110,125,230,new string[]{"尚未指定","一般关系","关系较近","关系很近"});p.Controls.Add(relationshipChoice);
        p.Controls.Add(MakeLabel("分析深度",355,128,80,25));analysisDepth=MakeCombo(440,125,190,new string[]{"自动选择","简要","详细","深入"});p.Controls.Add(analysisDepth);
        Button save=MakeButton("保存此人设置",650,123,170,34);save.Click+=async delegate{await SaveMemoryOptions();};p.Controls.Add(save);
        p.Controls.Add(MakeLabel("详细/深入摘录上限",25,176,220,25));closeMemorySampleChars=new NumericUpDown();closeMemorySampleChars.Minimum=3500;closeMemorySampleChars.Maximum=18000;closeMemorySampleChars.Increment=1000;closeMemorySampleChars.Value=12000;closeMemorySampleChars.Location=new Point(255,173);closeMemorySampleChars.Width=120;p.Controls.Add(closeMemorySampleChars);
        p.Controls.Add(MakeLabel("普通分析最多 1 次请求；详细/深入最多 2 次（分析+核验）。重复读取和查看不收费。",395,173,560,45));
        memoryReadingStatus=MakeLabel("",25,218,930,35);p.Controls.Add(memoryReadingStatus);
        foreach(Control child in p.Controls){if(child.Top>=218)child.Top=197;else if(child.Top>=173)child.Top-=22;else if(child.Top>=123)child.Top-=17;else if(child.Top>=76)child.Top-=12;}
        memoryViews=new TabControl();memoryViews.Location=new Point(25,230);memoryViews.Size=new Size(930,450);p.Controls.Add(memoryViews);p.AutoScroll=false;
        p.SizeChanged+=delegate{memoryViews.Size=new Size(Math.Max(700,p.ClientSize.Width-memoryViews.Left-UiPixel(24)),memoryViews.Height);};
        var analysis=new EchoPage("关系分析");var digest=new EchoPage("对话精炼");var evidence=new EchoPage("引用原话");var edit=new EchoPage("手动记忆");
        memoryViews.TabPages.AddRange(new TabPage[]{analysis,digest,evidence,edit});
        relationshipView=ReadingBox();relationshipView.Dock=DockStyle.Fill;
        var toolbar=new Panel();toolbar.Dock=DockStyle.Top;toolbar.Height=38;
        memorySection=MakeCombo(8,5,275,new string[]{"全部分析"});memorySection.SelectedIndexChanged+=delegate{if(memorySection.SelectedIndex>0)JumpToReadingHeading(memorySection.Text);};toolbar.Controls.Add(memorySection);
        var query=MakeText(295,6,310);toolbar.Controls.Add(query);Button find=MakeButton("查找",615,4,80,30);find.Click+=delegate{FindInDocument(relationshipView,query.Text);};toolbar.Controls.Add(find);
        analysis.Controls.Add(relationshipView);analysis.Controls.Add(toolbar);
        digestView=ReadingBox();digestView.Dock=DockStyle.Fill;digest.Controls.Add(digestView);
        memoryEvidenceView=ReadingBox();memoryEvidenceView.Dock=DockStyle.Fill;evidence.Controls.Add(memoryEvidenceView);
        BuildManualMemories(edit);
    }
    void BuildManualMemories(TabPage p){
        p.AutoScroll=true;memoryList=new ListView();memoryList.Location=new Point(10,10);memoryList.Size=new Size(870,170);memoryList.View=View.Details;memoryList.FullRowSelect=true;memoryList.HideSelection=false;memoryList.Columns.Add("分类",85);memoryList.Columns.Add("内容",535);memoryList.Columns.Add("来源",230);
        BatchList(memoryList);
        memoryList.SelectedIndexChanged+=delegate{if(memoryList.SelectedItems.Count==0)return;var row=(Dictionary<string,object>)memoryList.SelectedItems[0].Tag;selectedMemoryId=Str(row,"id");memoryKind.Text=Str(row,"kind");memoryEdit.Text=Str(row,"text");memorySource.Text=Str(row,"source");};p.Controls.Add(memoryList);
        memoryKind=MakeCombo(10,193,170,new string[]{"事实","偏好","推测"});p.Controls.Add(memoryKind);memoryEdit=MakeText(10,238,870,85,true);p.Controls.Add(memoryEdit);
        p.Controls.Add(MakeLabel("来源（主人手动填写不标为已核实原话）",10,332,870,25));memorySource=MakeText(10,367,870);p.Controls.Add(memorySource);
        Button add=MakeButton("新增",10,415,120,32);add.Click+=delegate{selectedMemoryId=null;memoryEdit.Clear();memorySource.Clear();memoryList.SelectedItems.Clear();};p.Controls.Add(add);
        Button save=MakeButton("保存记忆",145,415,140,32,true);save.Click+=async delegate{await EditMemory(false);};p.Controls.Add(save);
        Button delete=MakeButton("删除所选",300,415,150,32);delete.Click+=async delegate{await EditMemory(true);};p.Controls.Add(delete);
        BatchSelectButtons(p,memoryList,465,415);Button kind=MakeButton("批量修改分类",665,415,175,32);kind.Click+=async delegate{await ChangeMemoryKinds();};p.Controls.Add(kind);
        Button many=MakeButton("批量新增（内容每行一条）",10,460,280,36);many.Click+=async delegate{await AddMemoryLines();};p.Controls.Add(many);
    }
    string MemoryFolder(MemoryContact contact){string found=null;bool labelMatch=false;DateTime stamp=DateTime.MinValue;foreach(string name in new string[]{"用户","群"}){string root=Path.Combine(AppPaths.Storage,name);if(!Directory.Exists(root))continue;foreach(string path in Directory.GetFiles(root,"联系人.json",SearchOption.AllDirectories)){try{var meta=new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(path,Encoding.UTF8));if(Str(meta,"username")!=contact.Id&&Str(meta,"identifier")!=contact.Id)continue;string folder=Path.GetDirectoryName(path);bool current=Str(meta,"label")==contact.Label;DateTime updated=File.GetLastWriteTimeUtc(Path.Combine(folder,"人物分析.md"));if(found==null||current&&!labelMatch||current==labelMatch&&updated>stamp){found=folder;labelMatch=current;stamp=updated;}}catch{}}}return found;}
    void LoadRelationshipReading(){
        if(relationshipView==null)return;MemoryContact contact=memoryContact.SelectedItem as MemoryContact;
        string id=contact==null?"":contact.Id;bool same=memoryReadingId==id;string section=same?memorySection.Text:"全部分析";memoryReadingId=id;
        if(contact==null){SetReading(relationshipView,"");SetReading(digestView,"");SetReading(memoryEvidenceView,"");return;}string folder=MemoryFolder(contact);
        if(folder==null){SetReading(relationshipView,"暂无此人的人物分析。");SetReading(digestView,"暂无此人的对话精炼。");SetReading(memoryEvidenceView,"暂无此人的引用原话。");memoryReadingStatus.Text="尚未匹配到身份明确的本机分析；点击“更新此人分析”会按准确微信号匹配。";return;}
        using(var viewport=new ContactViewport(this)){
        try{
            string profile=Path.Combine(folder,"人物分析.md"),digest=Path.Combine(folder,"对话精炼.md");
            string profileContents=File.Exists(profile)?File.ReadAllText(profile,Encoding.UTF8):"暂无人物分析。";SetReading(relationshipView,profileContents);
            SetReading(digestView,File.Exists(digest)?File.ReadAllText(digest,Encoding.UTF8):"暂无对话精炼。");
            var headings=new List<string>{"全部分析"};foreach(Match header in Regex.Matches(profileContents,@"(?m)^## (.+)$"))headings.Add(header.Groups[1].Value.Trim());
            if(!memorySection.Items.Cast<object>().Select(x=>x.ToString()).SequenceEqual(headings)){memorySection.BeginUpdate();memorySection.Items.Clear();memorySection.Items.AddRange(headings.Cast<object>().ToArray());memorySection.SelectedIndex=0;memorySection.EndUpdate();}if(headings.Contains(section))memorySection.SelectedItem=section;
            string proof=Path.Combine(folder,"分析证据.json");var text=new StringBuilder();
            if(File.Exists(proof)){var data=new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(proof,Encoding.UTF8));IList entries=data.ContainsKey("evidence")?data["evidence"] as IList:null;if(entries!=null)foreach(object obj in entries){var item=obj as Dictionary<string,object>;if(item==null)continue;text.AppendLine("["+Str(item,"messageId")+"] "+Str(item,"time")+" · "+(Str(item,"speaker")=="SELF"?"我方":"对方"));text.AppendLine(Str(item,"content"));text.AppendLine();}}
            SetReading(memoryEvidenceView,text.Length==0?"旧分析尚无结构化来源。更新此人分析后可在这里查看原话、身份及时间。":text.ToString());
            string state=Path.Combine(folder,"整理状态.md");memoryReadingStatus.Text=File.Exists(state)?File.ReadAllText(state,Encoding.UTF8).Replace("\n"," ").Trim():"读取的是本机保存的分析。";
        }catch(Exception error){memoryReadingStatus.Text="读取分析失败："+error.GetType().Name;}
        }
    }
    async Task<bool> SaveMemoryOptions(){MemoryContact contact=memoryContact.SelectedItem as MemoryContact;if(contact==null)return false;try{string relation=new string[]{"unspecified","general","close","very_close"}[Math.Max(0,relationshipChoice.SelectedIndex)];string depth=new string[]{"auto","brief","detailed","deep"}[Math.Max(0,analysisDepth.SelectedIndex)];await Task.Run(()=>LocalCall("assistant_features.py",new Dictionary<string,object>{{"action","memory_options"},{"identifier",contact.Id},{"relation",relation},{"depth",depth}}));Notice("此人的关系与深度已保存；点击“更新此人分析”生成新分析。查看已有分析不调用模型。");return true;}catch(Exception error){Notice(error.Message);return false;}}
    void ApplyMemoryOptions(Dictionary<string,object> data){var options=data.ContainsKey("options")?data["options"] as Dictionary<string,object>:null;relationshipChoice.SelectedIndex=Math.Max(0,Array.IndexOf(new string[]{"unspecified","general","close","very_close"},options==null?"unspecified":Str(options,"relation")));analysisDepth.SelectedIndex=Math.Max(0,Array.IndexOf(new string[]{"auto","brief","detailed","deep"},options==null?"auto":Str(options,"depth")));}
    async Task UpdateSelectedAnalysis(){
        MemoryContact contact=memoryContact.SelectedItem as MemoryContact;if(contact==null)return;
        if(memorySyncRunning||insightRunning){Notice("另一项整理正在运行，请待其完成。");return;}
        if(!FeatureRouteReady("memory")){Notice("人物分析的 API 地址、模型或密钥尚未配置，请到设置查看“人物与记忆”对应的服务。");return;}
        long generation=stopGeneration;updateSelectedMemory.Enabled=false;memorySyncRunning=true;
        try{
        if(!await SaveMemoryOptions()||IsDisposed||generation!=stopGeneration)return;
        var config=Config();config["apiKey"]=key.Text.Trim();config["memoryTarget"]=new Dictionary<string,object>{{"identifier",contact.Id},{"label",contact.Label},{"kind",contact.Kind}};
        string payload=new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(config)+"\n",executable=pythonPath.Text.Trim();
        var info=new ProcessStartInfo(executable,"-X utf8 -u \""+Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"memory_manager.py")+"\" --selected");info.UseShellExecute=false;info.CreateNoWindow=true;info.WorkingDirectory=AppDomain.CurrentDomain.BaseDirectory;info.RedirectStandardInput=true;info.RedirectStandardOutput=true;info.RedirectStandardError=true;info.StandardOutputEncoding=Encoding.UTF8;info.StandardErrorEncoding=Encoding.UTF8;
        Notice("正在更新“"+contact.Label+"”的分析；结果会显示在当前页面。");
        var result=await Task.Run(()=>RunCaptured(info,payload,1800000,delegate(Process worker){memoryWorker=worker;TrackJob(worker,generation);if(IsDisposed)worker.Kill();}));if(IsDisposed||generation!=stopGeneration)return;Notice(result.Item1==0?"此人分析已更新，可以查看关系分析、对话精炼和引用原话。":"分析未完成，旧内容保留；"+(result.Item1==-1?"操作超时，已停止；没有自动重试。":BatchFailureReason(result.Item2,"")));PopulateMemoryContacts();ShowAnalysis();}
        catch(Exception error){if(!IsDisposed)Notice("更新失败："+error.Message);}
        finally{memoryWorker=null;memorySyncRunning=false;if(!IsDisposed)updateSelectedMemory.Enabled=true;}
    }
}
}
