﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace EchoWechatDesktop {
public partial class MainForm {
    TabControl settingsViews;
    readonly Dictionary<string,Label> routeDescriptions=new Dictionary<string,Label>();
    readonly Dictionary<ComboBox,TextBox> contactSearches=new Dictionary<ComboBox,TextBox>();
    readonly Dictionary<ComboBox,List<object>> contactSearchPools=new Dictionary<ComboBox,List<object>>();
    bool filteringContact;
    Label homeIssueDetail;
    RichTextBox adviceReferences;
    TabControl adviceReferenceTabs;
    void BuildDesignRefinement(){
        // Layout changes stay in the native workspace; existing actions retain their handlers.
        Text="回声 · 私人助手";
        navigationPanel.BackColor=Color.FromArgb(247,248,252);mainNavigation.BackColor=navigationPanel.BackColor;
        foreach(Control c in navigationPanel.Controls)if(c is Label){c.Text="你的私人助手";c.ForeColor=muted;}
        mainNavigation.ItemHeight=46;
        ThemeDesignTabs(mainProductTabs);
        RefineHomeDesign();
        RefineContactManagement();
        RefineAdviceDesign();
        RefineSettingsDesign();
        RefineMemoryReading();
        RefineReportDesign();
        RefineActionFeedback();
        RefineResponsiveDesign();
        RefineFinalWorkspace();
    }
    void RefineFinalWorkspace(){
        var stack=(TableLayoutPanel)homeContainer.Controls[0];var feed=incomingList.Parent;var todo=homePreviewGrid.GetControlFromPosition(0,0);var briefs=homePreviewGrid.GetControlFromPosition(1,0);stack.Controls.Remove(homePreviewGrid);stack.Controls.Remove(feed);homePreviewGrid.Controls.Remove(todo);homePreviewGrid.Controls.Remove(briefs);homePreviewGrid=HomeRow(2,300);homePreviewGrid.ColumnStyles[0].Width=62;homePreviewGrid.ColumnStyles[1].Width=38;feed.Visible=true;feed.Dock=DockStyle.Fill;feed.Margin=new Padding(0,0,14,0);homePreviewGrid.Controls.Add(feed,0,0);homePreviewGrid.Controls.Add(todo,1,0);stack.Controls.Remove(homeIssueDetail);stack.Controls.Add(homeIssueDetail,0,6);stack.Controls.Add(homePreviewGrid,0,7);stack.Controls.Add(briefs,0,8);feed.Padding=new Padding(14);feed.BackColor=Color.FromArgb(249,250,253);stack.GetControlFromPosition(0,4).Visible=false;
        incomingScope.TextChanged+=delegate{if(designIncomingEmpty!=null)designIncomingEmpty.Visible=incomingList.Items.Count==0;};
        var original=adviceCompare.GetControlFromPosition(0,0);var oldRequirements=advisorRequirements.Parent;var requirementLabel=oldRequirements.Controls.OfType<Label>().First();oldRequirements.Controls.Remove(advisorRequirements);oldRequirements.Controls.Remove(requirementLabel);original.Controls.Remove(oldRequirements);oldRequirements.Dispose();
        var peer=adviceStack.GetControlFromPosition(0,3);adviceStack.Controls.Remove(peer);var inputs=HomeRow(2,85);peer.Margin=new Padding(0,0,14,0);inputs.Controls.Add(peer,0,0);var requirement=new Panel{Dock=DockStyle.Fill,Margin=new Padding(0,0,14,0)};requirementLabel.Text="修改要求（可选） · 保留事实与承诺程度";requirementLabel.Dock=DockStyle.Top;requirementLabel.Height=24;advisorRequirements.Dock=DockStyle.Fill;requirement.Controls.Add(advisorRequirements);requirement.Controls.Add(requirementLabel);inputs.Controls.Add(requirement,1,0);adviceStack.Controls.Add(inputs,0,3);adviceStack.RowStyles[3].Height=85;
        foreach(Button button in designContacts.Controls.Cast<Control>().SelectMany(x=>x.Controls.Cast<Control>()).SelectMany(x=>x.Controls.Cast<Control>()).OfType<Button>())if(button.Text.StartsWith("导入")){var b=button as EchoButton;if(b!=null)b.primary=false;}
        var profileStack=(TableLayoutPanel)profileContainer.Controls[0];profileStack.RowStyles[0].Height=32;profileStack.RowStyles[1].Height=24;
        ThemeDesignTabs(designContacts);ResizeHomeLayout();
        var common=settingsViews.TabPages[1].Controls[0].Controls.OfType<TableLayoutPanel>().First();foreach(Button b in common.Controls.OfType<Button>()){b.Dock=DockStyle.Top;b.Height=36;}
        foreach(var section in settingsViews.TabPages[1].Controls[0].Controls.OfType<TableLayoutPanel>())foreach(var flow in section.Controls.OfType<FlowLayoutPanel>()){flow.WrapContents=true;flow.Height=88;}
        var dates=reportColumns.GetControlFromPosition(0,0);var caption=dates.Controls.OfType<Label>().First();reportBatchToolbar.FlowDirection=FlowDirection.LeftToRight;reportBatchToolbar.WrapContents=true;reportBatchToolbar.Height=80;foreach(Control b in reportBatchToolbar.Controls){b.Width=98;b.Height=32;b.Margin=new Padding(0,4,6,4);}dates.Controls.SetChildIndex(reportList,0);dates.Controls.SetChildIndex(reportBatchToolbar,1);dates.Controls.SetChildIndex(caption,2);
    }
    void RefineResponsiveDesign(){
        var dates=reportColumns.GetControlFromPosition(0,0);reportBatchToolbar.Dock=DockStyle.Top;reportBatchToolbar.SendToBack();dates.Resize+=delegate{int width=Math.Max(UiPixel(80),(dates.ClientSize.Width-dates.Padding.Horizontal)/2-UiPixel(6));foreach(Control b in reportBatchToolbar.Controls)b.Width=width;};
        var adviceActions=(FlowLayoutPanel)adviceStack.GetControlFromPosition(0,2);adviceActions.Margin=new Padding(0);adviceActions.WrapContents=true;foreach(Control c in adviceActions.Controls)c.Margin=new Padding(0,2,8,2);designAdviceReady.AutoSize=false;designAdviceReady.Width=310;designAdviceReady.Height=28;designAdviceReady.TextAlign=ContentAlignment.MiddleLeft;
        advisorContact.DropDownWidth=650;memoryContact.DropDownWidth=650;
        var features=settingsViews.TabPages[0].Controls.OfType<TableLayoutPanel>().First();foreach(var line in features.Controls.OfType<TableLayoutPanel>().Where(x=>x.ColumnCount==3)){line.Height=46;foreach(TableLayoutPanel inner in line.Controls.OfType<TableLayoutPanel>())if(inner.RowCount==2){inner.RowStyles[0].Height=24;inner.RowStyles[1].Height=18;}}
        features.GetControlFromPosition(0,0).Height=24;features.GetControlFromPosition(0,1).Height=26;foreach(TabPage p in settingsViews.TabPages)p.Padding=new Padding(12);
        contactBatchList.Resize+=delegate{ResizeDesignContactColumns();};Shown+=delegate{BeginInvoke(new Action(ResizeDesignContactColumns));};
        KeyPreview=true;KeyDown+=delegate(object sender,KeyEventArgs e){if(e.Control&&e.KeyCode==Keys.F){TextBox search=mainProductTabs.SelectedIndex==9?contactBatchSearch:mainProductTabs.SelectedIndex==10?contactSearches[advisorContact]:mainProductTabs.SelectedIndex==6?contactSearches[memoryContact]:null;if(search!=null){search.Focus();search.SelectAll();e.Handled=true;e.SuppressKeyPress=true;}}};
    }
    void ResizeDesignContactColumns(){if(contactBatchList.Columns.Count!=11)return;int width=Math.Max(500,contactBatchList.ClientSize.Width-UiPixel(8));int[] shares={6,14,5,9,8,10,11,11,7,12,7};for(int i=0;i<shares.Length;i++)contactBatchList.Columns[i].Width=width*shares[i]/100;}
    Label designAdviceReady;
    void RefineActionFeedback(){
        var actions=(FlowLayoutPanel)adviceStack.GetControlFromPosition(0,2);designAdviceReady=new Label{AutoSize=true,Font=normal,ForeColor=muted,Margin=new Padding(12,8,0,0)};actions.Controls.Add(designAdviceReady);
        advisorDraft.TextChanged+=delegate{RefreshAdviceEntry();};advisorContact.SelectedIndexChanged+=delegate{RefreshAdviceEntry();};messageAdviceEnabled.CheckedChanged+=delegate{RefreshAdviceEntry();};adviceProgress.TextChanged+=delegate{RefreshAdviceEntry();};Shown+=delegate{RefreshAdviceEntry();};

    }
    void RefreshAdviceEntry(){if(designAdviceReady==null)return;bool selected=advisorContact.SelectedItem is AdvisorContact,written=!String.IsNullOrWhiteSpace(advisorDraft.Text);advisorGenerate.Enabled=messageAdviceEnabled.Checked&&selected&&written&&!advisorBusy;designAdviceReady.Text=!messageAdviceEnabled.Checked?"消息建议已关闭 · 在设置开启":!selected?"先选择联系人":!written?"写入原稿后可生成":advisorBusy?"正在生成，请稍候":"只生成建议，由你决定是否发送";}
    void RefineReportDesign(){
        reportHeading.Text="日报与周报";reportHeading.Font=new Font(normal.FontFamily,16F,FontStyle.Bold);reportHint.Font=new Font(normal.FontFamily,9.5F);
        reportHint.Text="简报看进展与有价值的信息；需要你行动的事项，在待办提醒单独处理。";
        foreach(Button b in reportToolbar.Controls.OfType<Button>())if(b.Text=="生成当前进度")b.Text="生成本期简报";
        var dates=reportColumns.GetControlFromPosition(0,0);reportLayout.Controls.Remove(reportBatchToolbar);reportLayout.RowStyles[3].Height=8;reportBatchToolbar.Dock=DockStyle.Bottom;reportBatchToolbar.Height=164;reportBatchToolbar.FlowDirection=FlowDirection.TopDown;reportBatchToolbar.WrapContents=false;dates.Controls.Add(reportBatchToolbar);reportBatchToolbar.BringToFront();foreach(Control b in reportBatchToolbar.Controls){b.Width=190;b.Height=32;b.Margin=new Padding(0,4,0,4);}
        reportList.BackColor=Color.FromArgb(247,249,252);reportDocumentPanel.Padding=new Padding(0);reportDocumentPanel.Paint+=delegate(object sender,PaintEventArgs e){using(var pen=new Pen(EchoVisual.Line))e.Graphics.DrawLine(pen,0,0,0,reportDocumentPanel.Height);};
    }
    void RefineMemoryReading(){
        var page=mainProductTabs.TabPages[6];foreach(Label label in page.Controls.OfType<Label>())if(label.Text.StartsWith("人物记忆"))label.Text="人物与关系 · 原话、变化与相处参考";
        var analysis=memoryViews.TabPages[0];var old=analysis.Controls.OfType<Panel>().FirstOrDefault();if(old!=null){var children=old.Controls.Cast<Control>().ToArray();var query=children.OfType<TextBox>().First();var find=children.OfType<Button>().First();old.Controls.Clear();old.Height=42;old.Padding=new Padding(12,4,12,4);old.BackColor=Color.FromArgb(247,248,252);var row=HomeRow(3,34);row.Dock=DockStyle.Fill;row.ColumnStyles.Clear();row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,40));row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,45));row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,15));foreach(Control c in new Control[]{memorySection,query,find}){c.Dock=DockStyle.Fill;c.Margin=new Padding(0,0,10,0);}row.Controls.Add(memorySection,0,0);row.Controls.Add(query,1,0);row.Controls.Add(find,2,0);old.Controls.Add(row);Cue(query,"在分析中查找文字");}
        readingFont=new Font("Microsoft YaHei UI",11F);readingHeading=new Font("Microsoft YaHei UI",14F,FontStyle.Bold);
        foreach(var box in new[]{relationshipView,digestView,memoryEvidenceView,adviceReferences})box.Font=readingFont;
    }
    void RefineSettingsDesign(){
        var features=settingsViews.TabPages[0];var table=features.Controls.OfType<TableLayoutPanel>().First();table.Padding=new Padding(10);table.BackColor=Color.White;
        foreach(Control c in table.Controls){c.Margin=new Padding(0,0,0,3);var line=c as TableLayoutPanel;if(line!=null&&line.ColumnCount==3){line.Height=52;line.Padding=new Padding(8,2,8,2);line.BackColor=Color.FromArgb(248,249,253);foreach(TableLayoutPanel inner in line.Controls.OfType<TableLayoutPanel>()){if(inner.RowCount==2){inner.RowStyles[0].Height=28;inner.RowStyles[1].Height=18;}}foreach(Label hint in line.Controls.Cast<Control>().SelectMany(x=>x.Controls.Cast<Control>()).OfType<Label>())hint.Font=hint.Font.Bold?bold:new Font(normal.FontFamily,9F);}}
        table.GetControlFromPosition(0,0).Height=26;table.GetControlFromPosition(0,1).Height=30;
        var services=settingsViews.TabPages[1];var sections=services.Controls.OfType<TableLayoutPanel>().Reverse().ToArray();services.Controls.Clear();var columns=HomeRow(2,650);columns.AutoSize=false;columns.Height=820;services.Controls.Add(columns);
        for(int i=0;i<sections.Length;i++){sections[i].Dock=DockStyle.Top;sections[i].Margin=new Padding(i==0?0:10,0,i==0?10:0,0);columns.Controls.Add(sections[i],i,0);}
    }
    void RefineAdviceDesign(){
        var original=adviceCompare.GetControlFromPosition(0,0);original.BackColor=Color.White;var suggestion=adviceCompare.GetControlFromPosition(1,0);suggestion.BackColor=Color.FromArgb(247,248,255);
        foreach(Control card in adviceCompare.Controls){card.Padding=new Padding(14);card.Paint+=delegate(object sender,PaintEventArgs e){var c=(Control)sender;using(var pen=new Pen(EchoVisual.Line))e.Graphics.DrawRectangle(pen,0,0,c.Width-1,c.Height-1);};}
        advisorDraft.BackColor=Color.White;advisorResults.BackColor=suggestion.BackColor;
        var requirementLabel=adviceStack.GetControlFromPosition(0,7);adviceStack.Controls.Remove(requirementLabel);adviceStack.Controls.Remove(advisorRequirements);adviceStack.RowStyles[7].Height=0;adviceStack.RowStyles[8].Height=0;
        var requests=new Panel{Dock=DockStyle.Bottom,Height=114,Padding=new Padding(0,8,0,0),BackColor=Color.White};original.Controls.Add(requests);requirementLabel.Text="补充要求 · 只用于此人的本次修改";requirementLabel.Dock=DockStyle.Top;requirementLabel.Height=28;advisorRequirements.Dock=DockStyle.Fill;advisorRequirements.Margin=new Padding(0);advisorRequirements.BorderStyle=BorderStyle.FixedSingle;requests.Controls.Add(advisorRequirements);requests.Controls.Add(requirementLabel);requests.BringToFront();
        advisorGenerate.Text="生成回复建议";advisorGenerate.Width=180;
        adviceCopyButtons.Visible=adviceVariants.Count>0;adviceVariant.SelectedIndexChanged+=delegate{adviceCopyButtons.Visible=adviceVariants.Count>0;};
        adviceReason.Text="每个方案附修改理由和原意核验。你确认后再复制到微信。";
        adviceStack.RowStyles[0].Height=32;adviceStack.RowStyles[1].Height=42;adviceStack.RowStyles[3].Height=60;adviceStack.RowStyles[4].Height=38;
        ThemeDesignTabs(adviceReferenceTabs.Parent);
    }
    Panel designContacts;
    Label designSelection;
    void RefineContactManagement(){
        var page=mainProductTabs.TabPages[9];var old=page.Controls.Cast<Control>().ToArray();Func<string,Button> find=name=>old.OfType<Button>().FirstOrDefault(x=>x.Text==name)??old.SelectMany(c=>c.Controls.Cast<Control>()).OfType<Button>().FirstOrDefault(x=>x.Text==name);
        var imports=new[]{find("导入微信好友"),find("导入微信群"),find("单个添加好友"),find("单个添加群"),find("修改当前项"),find("移除当前项")};Button execute=find("执行操作"),all=find("全选"),none=find("清空选择"),paste=find("添加全部行"),stop=find("停止整理");
        page.Controls.Clear();designContacts=new Panel{Dock=DockStyle.Top,Height=1170,Padding=new Padding(24,16,24,24)};page.Controls.Add(designContacts);
        var stack=SingleStack(34,30,42,42,42,28,400,66,380);designContacts.Controls.Add(stack);
        stack.Controls.Add(Note("联系人管理",34,true),0,0);stack.Controls.Add(Note("好友、群聊分别导入。先勾选，再选择批量操作；单人和批量使用同一套整理流程。",30),0,1);
        var filters=HomeRow(3,42);filters.ColumnStyles[0].Width=23;filters.ColumnStyles[1].Width=48;filters.ColumnStyles[2].Width=29;foreach(Control c in new Control[]{contactBatchKind,contactBatchSearch,contactSortChoice}){c.Dock=DockStyle.Fill;c.Margin=new Padding(0,2,12,5);}filters.Controls.Add(contactBatchKind,0,0);filters.Controls.Add(contactBatchSearch,1,0);filters.Controls.Add(contactSortChoice,2,0);stack.Controls.Add(filters,0,2);
        var actions=new FlowLayoutPanel{Dock=DockStyle.Fill,WrapContents=true,Margin=new Padding(0)};foreach(var b in imports)if(b!=null){b.Size=new Size(b.Text.StartsWith("导入")?120:112,32);b.Margin=new Padding(0,0,8,6);actions.Controls.Add(b);}stack.Controls.Add(actions,0,3);
        var batch=HomeRow(4,42);batch.ColumnStyles.Clear();foreach(int share in new[]{46,22,14,18})batch.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,share));foreach(Control c in new Control[]{batchAction,execute,all,none}){if(c==null)continue;c.Dock=DockStyle.Fill;c.Margin=new Padding(0,2,10,5);}batch.Controls.Add(batchAction,0,0);if(execute!=null)batch.Controls.Add(execute,1,0);if(all!=null)batch.Controls.Add(all,2,0);if(none!=null)batch.Controls.Add(none,3,0);stack.Controls.Add(batch,0,4);
        designSelection=Note("",28);designSelection.ForeColor=EchoVisual.Blue;stack.Controls.Add(designSelection,0,5);contactBatchList.Dock=DockStyle.Fill;contactBatchList.Margin=new Padding(0);stack.Controls.Add(contactBatchList,0,6);batchContactStatus.Dock=DockStyle.Fill;batchContactStatus.Margin=new Padding(0,8,0,0);stack.Controls.Add(batchContactStatus,0,7);
        var options=new TabControl{Dock=DockStyle.Fill};stack.Controls.Add(options,0,8);EchoPage combination=new EchoPage("组合设置"),pasted=new EchoPage("按行添加"),persona=new EchoPage("专属表达要求");options.TabPages.AddRange(new[]{combination,pasted,persona});foreach(TabPage tab in options.TabPages){tab.Padding=new Padding(16);tab.AutoScroll=true;}
        var combinationTable=SectionTable(combination,"批量组合设置","只修改勾选的项目；关系和分析深度由你指定。");AddSectionControl(combinationTable,batchChangeMode);AddField(combinationTable,"回复模式",contactBatchMode);var stars=HomeRow(2,38);stars.Controls.Add(batchChangeStar,0,0);stars.Controls.Add(batchStarValue,1,0);AddSectionControl(combinationTable,stars);AddSectionControl(combinationTable,batchChangeRelation);AddField(combinationTable,"关系程度",contactBatchRelation);AddField(combinationTable,"分析深度",contactBatchDepth);if(stop!=null)AddSectionControl(combinationTable,stop);
        var pastedTable=SectionTable(pasted,"批量填写身份","每行一个微信号 / wxid / 准确昵称，制表符后可填写称呼。");contactBatchPaste.Height=150;AddSectionControl(pastedTable,contactBatchPaste);if(paste!=null)AddSectionControl(pastedTable,paste);
        var personaTable=SectionTable(persona,"专属表达要求","批量操作选择“应用补充的专属表达要求”。要求只写入勾选的对象，留空可清除。");batchPersonaText.Height=140;AddSectionControl(personaTable,batchPersonaText);
        contactBatchList.ItemChecked+=delegate{RefreshDesignSelection();};contactBatchKind.SelectedIndexChanged+=delegate{RefreshDesignSelection();};contactBatchSearch.TextChanged+=delegate{RefreshDesignSelection();};page.Enter+=delegate{RefreshDesignSelection();};
        page.SizeChanged+=delegate{if(IsHandleCreated){stack.RowStyles[6].Height=Math.Max(UiPixel(320),page.ClientSize.Height-UiPixel(355));designContacts.Height=(int)stack.RowStyles.Cast<RowStyle>().Sum(x=>x.Height)+designContacts.Padding.Vertical;}};
    }
    void RefreshDesignSelection(){if(designSelection!=null)designSelection.Text="当前显示 "+contactBatchList.Items.Count+" 项  ·  已勾选 "+contactBatchList.CheckedItems.Count+" 项  ·  可查看星标、关系、深度和整理结果";}
    void RefineHomeDesign(){
        var stack=(TableLayoutPanel)homeContainer.Controls[0];var feed=stack.GetControlFromPosition(0,6);stack.SetRow(homePreviewGrid,6);stack.SetRow(feed,8);
        homeGreeting.Parent.Parent.BackColor=Color.White;
        foreach(Label metric in new[]{homeRunValue,homePeopleValue,homePendingValue,homeFeaturesValue})metric.Font=new Font(normal.FontFamily,16F,FontStyle.Bold);
        foreach(Control card in homePreviewGrid.Controls){card.BackColor=Color.White;card.Paint+=delegate(object sender,PaintEventArgs e){var p=(Control)sender;using(var pen=new Pen(EchoVisual.Line))e.Graphics.DrawRectangle(pen,0,0,p.Width-1,p.Height-1);};}
        incomingList.BorderStyle=BorderStyle.None;incomingList.Paint+=delegate{};
        var empty=new Label{Text="开始运行后，来访消息与处理结果会显示在这里。",Dock=DockStyle.Bottom,Height=28,Font=normal,ForeColor=muted,TextAlign=ContentAlignment.MiddleLeft};designIncomingEmpty=empty;feed.Controls.Add(empty);empty.BringToFront();
        incomingList.ItemSelectionChanged+=delegate{empty.Visible=incomingList.Items.Count==0;};
    }
    Label designIncomingEmpty;
    void ThemeDesignTabs(Control parent){foreach(Control c in parent.Controls){var tabs=c as TabControl;if(tabs!=null&&!(tabs is EchoPages)){tabs.DrawMode=TabDrawMode.OwnerDrawFixed;tabs.Padding=new Point(16,9);tabs.DrawItem+=delegate(object sender,DrawItemEventArgs e){var t=(TabControl)sender;bool active=e.Index==t.SelectedIndex;using(var b=new SolidBrush(Color.White))e.Graphics.FillRectangle(b,e.Bounds);TextRenderer.DrawText(e.Graphics,t.TabPages[e.Index].Text,normal,e.Bounds,active?EchoVisual.Blue:muted,TextFormatFlags.VerticalCenter|TextFormatFlags.HorizontalCenter);if(active)using(var p=new Pen(EchoVisual.Blue,UiPixel(2)))e.Graphics.DrawLine(p,e.Bounds.Left+UiPixel(8),e.Bounds.Bottom-2,e.Bounds.Right-UiPixel(8),e.Bounds.Bottom-2);};}ThemeDesignTabs(c);}}
    void DrawDesignNavigation(object sender,DrawItemEventArgs e){if(e.Index<0)return;bool selected=e.Index==WorkspaceGroup(mainProductTabs.SelectedIndex);e.Graphics.SmoothingMode=System.Drawing.Drawing2D.SmoothingMode.AntiAlias;using(var b=new SolidBrush(navigationPanel.BackColor))e.Graphics.FillRectangle(b,e.Bounds);var r=new RectangleF(e.Bounds.Left,e.Bounds.Top+UiPixel(3),e.Bounds.Width-UiPixel(2),e.Bounds.Height-UiPixel(6));using(var path=EchoVisual.Rounded(r,UiPixel(8)))using(var b=new SolidBrush(selected?Color.FromArgb(233,236,255):navigationPanel.BackColor))e.Graphics.FillPath(b,path);
        Color ink=selected?EchoVisual.Blue:muted;int x=e.Bounds.Left+UiPixel(13),y=e.Bounds.Top+(e.Bounds.Height-UiPixel(16))/2,s=UiPixel(16);using(var p=new Pen(ink,UiPixel(1))){if(e.Index==0){e.Graphics.DrawLines(p,new[]{new Point(x,y+6),new Point(x+s/2,y),new Point(x+s,y+6)});e.Graphics.DrawRectangle(p,x+3,y+6,s-6,s-6);}else if(e.Index==3){e.Graphics.DrawEllipse(p,x+5,y,s-10,s/2);e.Graphics.DrawArc(p,x,y+8,s,s,180,180);}else if(e.Index==4||e.Index==6){e.Graphics.DrawRectangle(p,x,y,s,s-3);e.Graphics.DrawLine(p,x+3,y+s-3,x+3,y+s+2);}else if(e.Index==5){e.Graphics.DrawEllipse(p,x,y,s,s);e.Graphics.DrawEllipse(p,x+5,y+5,s-10,s-10);}else {e.Graphics.DrawRectangle(p,x,y,s,s);e.Graphics.DrawLine(p,x+4,y+5,x+s-3,y+5);e.Graphics.DrawLine(p,x+4,y+10,x+s-5,y+10);}}
        TextRenderer.DrawText(e.Graphics,mainNavigation.Items[e.Index].ToString(),selected?bold:normal,new Rectangle(x+s+UiPixel(12),e.Bounds.Top,e.Bounds.Width-s-UiPixel(30),e.Bounds.Height),ink,TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPadding);
    }

    void BuildExperienceRefresh(){
        RebuildSettingsExperience();
        AddContactSearch(advisorContact);AddContactSearch(memoryContact);AddContactSearch(featureTarget);
        contactBatchSearch.AccessibleName="搜索称呼、昵称、微信号";Cue(contactBatchSearch,"搜索称呼、昵称、微信号");
        var stack=homeContainer.Controls[0] as TableLayoutPanel;
        homeIssueDetail=MakeLabel("",0,0,900,30);homeIssueDetail.Dock=DockStyle.Fill;homeIssueDetail.ForeColor=Color.FromArgb(168,65,45);
        stack.Controls.Add(homeIssueDetail,0,7);stack.RowStyles[7].Height=32;
        adviceStack.RowCount++;adviceStack.RowStyles.Add(new RowStyle(SizeType.Absolute,280));
        adviceReferenceTabs=new TabControl{Dock=DockStyle.Fill};var refs=new EchoPage("参考的双方对话与关系");var differences=new EchoPage("原稿与建议的差异");adviceReferenceTabs.TabPages.AddRange(new[]{refs,differences});
        adviceReferences=ReadingBox();adviceReferences.Dock=DockStyle.Fill;adviceReferences.ScrollBars=RichTextBoxScrollBars.Vertical;refs.Controls.Add(adviceReferences);
        adviceStack.Controls.Remove(adviceDiff);adviceDiff.Dock=DockStyle.Fill;differences.Controls.Add(adviceDiff);adviceStack.Controls.Add(adviceReferenceTabs,0,11);adviceStack.RowStyles[12].Height=0;
        adviceContext.Text="先选人、写原稿，再生成。参考对话、关系依据与修改理由会分别显示；资料不足会提示。";
        advisorContact.SelectedIndexChanged+=delegate{adviceReferences.Clear();};
        adviceStack.GetControlFromPosition(0,0).Text="消息与回复 · 结合双方关系，保留你的原意";
        var toolbar=adviceStack.GetControlFromPosition(0,1) as TableLayoutPanel;
        toolbar.ColumnStyles[0].Width=78;toolbar.ColumnStyles[1].Width=11;toolbar.ColumnStyles[2].Width=11;
        foreach(Control c in toolbar.Controls)if(c is Button)c.Text=c.Text.Contains("好友")?"找好友":"找群";
        apiBase.TextChanged+=delegate{RefreshRouteDescriptions();};model.TextChanged+=delegate{RefreshRouteDescriptions();};
        foreach(var pair in routePickers)pair.Value.SelectedIndexChanged+=delegate{RefreshRouteDescriptions();};
        Shown+=delegate{RefreshRouteDescriptions();RefreshContactSearch(advisorContact);RefreshContactSearch(memoryContact);};
    }
    void RebuildSettingsExperience(){
        var page=mainProductTabs.TabPages[0];page.Controls.Clear();page.AutoScroll=false;
        settingsViews=new TabControl{Dock=DockStyle.Fill,Padding=new Point(16,9)};page.Controls.Add(settingsViews);
        EchoPage features=new EchoPage("功能与 API"),services=new EchoPage("API 配置"),range=new EchoPage("运行与范围"),advanced=new EchoPage("高级选项");
        settingsViews.TabPages.AddRange(new[]{features,services,range,advanced});
        foreach(TabPage tab in settingsViews.TabPages){tab.AutoScroll=true;tab.Padding=new Padding(18);}
        var functional=SectionTable(features,"每个功能使用哪个 API", "在这里开启功能，并选择它使用的服务。下方直接显示实际接口地址和模型。");
        var switches=new CheckBox[]{privateEnabled,dailyReport,weeklyReport,importantReminders,autoRefreshMemory,messageAdviceEnabled,contactAIEnabled};
        var estimates=new[]{"自动回应允许名单","每天 23:00 整理","按周串联事件进展","谁找你、需要做什么","精炼历史与关系证据","保留你的风格与原意","只询问所选人物"};
        for(int i=0;i<routedFeatures.Length;i++){
            string feature=routedFeatures[i];var line=new TableLayoutPanel{Dock=DockStyle.Top,Height=62,ColumnCount=3,RowCount=1,Margin=new Padding(0,0,0,4),BackColor=Color.White,Padding=new Padding(12,8,12,8)};
            line.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,28));line.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,20));line.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,52));
            var title=SingleStack(25,23);var label=MakeLabel(routedCaptions[i],0,0,300,28,true);title.Controls.Add(label,0,0);var hint=MakeLabel(estimates[i],0,0,300,26);hint.ForeColor=muted;title.Controls.Add(hint,0,1);line.Controls.Add(title,0,0);
            var check=switches[i];check.Text=feature=="reply"?"私聊":"开启";check.AutoSize=true;check.Dock=DockStyle.None;check.Margin=new Padding(0,8,0,0);
            var on=new FlowLayoutPanel{Dock=DockStyle.Fill,FlowDirection=FlowDirection.LeftToRight,WrapContents=false};check.Margin=new Padding(0,8,8,0);on.Controls.Add(check);
            if(feature=="reply"){groupEnabled.Text="群 @我";groupEnabled.AutoSize=true;groupEnabled.Margin=new Padding(0,8,0,0);on.Controls.Add(groupEnabled);}line.Controls.Add(on,1,0);
            var service=SingleStack(32,22);var picker=routePickers[feature];picker.Dock=DockStyle.Fill;picker.Margin=new Padding(0,0,0,3);service.Controls.Add(picker,0,0);
            var address=MakeLabel("",0,0,500,30);address.AutoEllipsis=true;address.Font=new Font(normal.FontFamily,9F);address.ForeColor=muted;routeDescriptions[feature]=address;service.Controls.Add(address,0,1);line.Controls.Add(service,2,0);AddSectionControl(functional,line);
        }
        var links=new FlowLayoutPanel{Dock=DockStyle.Top,Height=44,WrapContents=false};var configure=MakeButton("填写 / 测试 API",0,0,180,34,true);configure.Click+=delegate{settingsViews.SelectedIndex=1;};links.Controls.Add(configure);var save=MakeButton("保存当前设置",0,0,170,34);save.Click+=delegate{SaveSettings(true,false);RefreshRouteDescriptions();};links.Controls.Add(save);AddSectionControl(functional,links);
        AddSectionControl(functional,Note("用量：回复中幅；日报、周报、提醒大幅；深入人物分析可达巨幅；手动建议与问答按次增加。看本机资料不调用模型。各功能调整对话沿用这一行的服务。",65));

        var common=SectionTable(services,"共用 API", "功能选择“共用服务”时使用这里的地址、模型和密钥。独立服务可在下方添加。");
        AddField(common,"服务类型",providerChoice);AddField(common,"API 接口地址",apiBase);AddField(common,"模型名称",model);AddField(common,"API Key · 本机加密",key);AddField(common,"JSON 输出兼容",jsonModeChoice);
        var test=MakeButton("测试共用 API",0,0,210,36,true);test.Click+=async delegate{await TestKey();};AddSectionControl(common,test);
        var profiles=SectionTable(services,"独立 API 服务", "例如创建“便宜日常”和“深入分析”，再回到“功能与 API”逐项分配。");
        AddField(profiles,"选择 / 新建服务",profilePicker);AddField(profiles,"服务名称",profileTitle);AddField(profiles,"接口协议",profileProtocol);AddField(profiles,"API 接口地址",profileUrl);AddField(profiles,"模型名称",profileModel);AddField(profiles,"API Key · 本机加密",profileKey);AddField(profiles,"JSON 输出",profileJson);AddField(profiles,"模型最大输出额度",profileOutputLimit);
        var edit=new FlowLayoutPanel{Dock=DockStyle.Top,Height=44,WrapContents=false};var saveProfile=MakeButton("添加 / 保存服务",0,0,175,34,true);saveProfile.Click+=delegate{SaveProfileEditor();};edit.Controls.Add(saveProfile);var testProfile=MakeButton("测试此服务",0,0,145,34);testProfile.Click+=async delegate{await TestProfile();};edit.Controls.Add(testProfile);var remove=MakeButton("删除此服务",0,0,145,34);remove.Click+=delegate{RemoveProfile();};edit.Controls.Add(remove);AddSectionControl(profiles,edit);routeInfo.Dock=DockStyle.Top;routeInfo.Height=64;AddSectionControl(profiles,routeInfo);

        var recording=SectionTable(range,"本机记录与分析范围", "开启记录才会保存聊天。允许上传的范围与本机记录范围分别设置。");
        foreach(var c in new[]{recordChats,useMemory,mediaEnabled,showDraftTools}){c.Text=c==recordChats?"保存近 60 天聊天（本机）":c==useMemory?"自动回复参考人物记忆":c==mediaEnabled?"本机图片 / WAV 识别":"显示 AI 代回复草稿确认";AddSectionControl(recording,c);}
        AddField(recording,"本机记录范围",recordScopeChoice);AddField(recording,"可发送到 AI 的范围",analysisScope);AddField(recording,"人物更新间隔 / 天",memoryRefreshDays);AddSectionControl(recording,includePublicGroupTasks);
        var operation=SectionTable(range,"运行与人工接管", "底部开始运行直接保存当前设置并启动。你在微信手动回复后，该会话的 AI 暂停。");
        AddField(operation,"私聊回复对象",contactMode);AddSectionControl(operation,quietEnabled);AddField(operation,"免打扰开始 / 小时",quietStart);AddField(operation,"免打扰结束 / 小时",quietEnd);AddField(operation,"禁止回复的好友 / 群",blocked,80);AddField(operation,"消息关键词条件",keywords);AddSectionControl(operation,Note("名单、星标、关系、分析深度和排序都在“联系人与记忆”。群回复必须 @你当前登录的微信账号。",50));
        var safeguards=SectionTable(advanced,"请求次数保护 · 可选", "不开启就不限制每日请求次数。达到上限会显示暂停原因，不会伪装成连接异常。");
        budgetEnabled.Text="限制每日模型请求次数";AddSectionControl(safeguards,budgetEnabled);AddSectionControl(safeguards,splitBudgets);AddField(safeguards,"自动回复每日上限",dailyRequestLimit);AddField(safeguards,"后台分析每日上限",dailyAnalysisRequestLimit);AddField(safeguards,"手动建议每日上限",dailyAssistRequestLimit);
        budgetEnabled.CheckedChanged+=delegate{foreach(var n in new[]{dailyRequestLimit,dailyAnalysisRequestLimit,dailyAssistRequestLimit})n.Enabled=budgetEnabled.Checked;splitBudgets.Enabled=budgetEnabled.Checked;};
        var tuning=SectionTable(advanced,"历史、输出与更新", "资料不足会明确提示，分析失败会保留旧结果。缓存只复用同一功能的有效结果。");
        AddSectionControl(tuning,analysisCache);AddField(tuning,"回复历史字数上限",contextChars);AddField(tuning,"回复输出上限",replyMaxTokens);AddField(tuning,"连续消息合并 / 秒",mergeSeconds);AddField(tuning,"提醒刷新 / 分钟",reminderRefreshMinutes);AddField(tuning,"普通人物摘录上限",memorySampleChars);AddField(tuning,"助手名称",botName);AddField(tuning,"运行组件 Python",pythonPath);
    }
    TableLayoutPanel SectionTable(TabPage page,string title,string subtitle){
        var section=new TableLayoutPanel{Dock=DockStyle.Top,AutoSize=true,AutoSizeMode=AutoSizeMode.GrowAndShrink,ColumnCount=1,RowCount=0,Padding=new Padding(14),Margin=new Padding(0,0,0,14),BackColor=Color.FromArgb(246,248,251)};
        section.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));page.Controls.Add(section);section.BringToFront();
        AddSectionControl(section,Note(title,34,true));AddSectionControl(section,Note(subtitle,34));return section;
    }
    Label Note(string text,int height,bool strong=false){var label=MakeLabel(text,0,0,900,height,strong);label.Dock=DockStyle.Top;return label;}
    void AddSectionControl(TableLayoutPanel section,Control c){int row=section.RowCount++;section.RowStyles.Add(new RowStyle(SizeType.AutoSize));c.Margin=new Padding(0,0,0,8);if(c is CheckBox){c.Dock=DockStyle.Top;c.AutoSize=false;c.Height=36;}section.Controls.Add(c,0,row);}
    void AddField(TableLayoutPanel section,string caption,Control field,int height=38){var line=HomeRow(2,height);line.ColumnStyles[0].Width=32;line.ColumnStyles[1].Width=68;line.Margin=new Padding(0,0,0,8);var label=MakeLabel(caption,0,0,300,height-2);label.Dock=DockStyle.Fill;line.Controls.Add(label,0,0);field.Dock=DockStyle.Fill;field.Margin=new Padding(0,1,0,3);line.Controls.Add(field,1,0);AddSectionControl(section,line);}
    void RefreshRouteDescriptions(){if(routeDescriptions.Count==0)return;foreach(var feature in routedFeatures){var choice=routePickers[feature].SelectedItem as ProfileChoice;string id=choice==null?"default":choice.Id;var p=id=="default"?null:modelProfiles.ContainsKey(id)?modelProfiles[id] as Dictionary<string,object>:null;p=p??new Dictionary<string,object>();string url=id=="default"?apiBase.Text:Str(p,"apiBaseUrl"),name=id=="default"?model.Text:Str(p,"model");routeDescriptions[feature].Text=(name.Length==0?"未填模型":name)+"  ·  "+(url.Length==0?"未填接口地址":url);routeDescriptions[feature].AccessibleDescription=routeDescriptions[feature].Text;if(choice!=null&&id=="default")choice.Title="共用服务 · "+(name.Length==0?"待配置":name);routePickers[feature].Invalidate();}}
    void ShowAdviceReferences(Dictionary<string,object> result){if(adviceReferences==null)return;var refs=result.ContainsKey("references")?result["references"] as Dictionary<string,object>:null;if(refs==null){SetReading(adviceReferences,"本次未附资料依据；降级结果不代表已结合关系。请重新生成。");return;}var text=new System.Text.StringBuilder();text.AppendLine("# 本次参考范围").AppendLine(Str(refs,"referenceMode")).AppendLine("\n# 双方对话");var messages=refs.ContainsKey("messages")?refs["messages"] as System.Collections.IList:null;if(messages!=null)foreach(object obj in messages){var m=obj as Dictionary<string,object>;if(m!=null)text.AppendLine(Str(m,"time")+" · "+Str(m,"speaker")).AppendLine(Str(m,"text")).AppendLine();}if(messages==null||messages.Count==0)text.AppendLine("没有可用的双方历史，无法据此判断表达习惯。");text.AppendLine("\n# 人物与关系参考（仍需核对）").AppendLine(Str(refs,"profile").Length==0?"缺少人物分析；建议仅依据可用对话及你的要求。":Str(refs,"profile"));SetReading(adviceReferences,text.ToString());}
    void AddContactSearch(ComboBox picker){if(picker==null||picker.Parent==null)return;var parent=picker.Parent;var bounds=picker.Bounds;var dock=picker.Dock;var margin=picker.Margin;var row=parent as TableLayoutPanel;var cell=row==null?new TableLayoutPanelCellPosition():row.GetPositionFromControl(picker);
        var line=HomeRow(2,38);line.ColumnStyles[0].Width=65;line.ColumnStyles[1].Width=35;line.Dock=dock;line.Bounds=bounds;line.Margin=margin;line.Anchor=picker.Anchor;
        parent.Controls.Remove(picker);if(row==null)parent.Controls.Add(line);else row.Controls.Add(line,cell.Column,cell.Row);picker.Dock=DockStyle.Fill;picker.Margin=new Padding(0,0,8,0);line.Controls.Add(picker,0,0);
        var search=MakeText(0,0,250);search.Dock=DockStyle.Fill;search.Margin=new Padding(0);search.AccessibleName="搜索联系人称呼 / 昵称 / 微信号";Cue(search,"搜索称呼、昵称、微信号");line.Controls.Add(search,1,0);contactSearches[picker]=search;contactSearchPools[picker]=picker.Items.Cast<object>().ToList();search.TextChanged+=delegate{FilterContactSearch(picker);};
    }
    void Cue(TextBox field,string text){field.HandleCreated+=delegate{SetSearchCue(field.Handle,0x1501,(IntPtr)1,text);};}
    [System.Runtime.InteropServices.DllImport("user32.dll",EntryPoint="SendMessageW",CharSet=System.Runtime.InteropServices.CharSet.Unicode)]static extern IntPtr SetSearchCue(IntPtr h,int message,IntPtr w,string text);
    void RefreshContactSearch(ComboBox picker){if(picker==null||!contactSearches.ContainsKey(picker)||filteringContact)return;contactSearchPools[picker]=picker.Items.Cast<object>().ToList();FilterContactSearch(picker);}
    string ContactSearchText(object item){var a=item as AdvisorContact;var m=item as MemoryContact;string id=a!=null?a.Id:m!=null?m.Id:"";var known=contactChoices.FirstOrDefault(x=>x.Id==id);return item.ToString()+(known==null?"":" "+known.Label+" "+known.Nickname+" "+known.Alias);}
    void FilterContactSearch(ComboBox picker){
        if(filteringContact)return;string previous=PickerContactId(picker.SelectedItem);filteringContact=true;
        using(var viewport=new ContactViewport(this)){
            try{string query=contactSearches[picker].Text.Trim();object selected=picker.SelectedItem;var items=contactSearchPools[picker].Where(x=>query.Length==0||ContactSearchText(x).IndexOf(query,StringComparison.CurrentCultureIgnoreCase)>=0).ToArray();
                if(!picker.Items.Cast<object>().SequenceEqual(items)){picker.BeginUpdate();try{picker.Items.Clear();picker.Items.AddRange(items);if(selected!=null&&items.Contains(selected))picker.SelectedItem=selected;else picker.SelectedIndex=-1;}finally{picker.EndUpdate();}}
            }finally{filteringContact=false;}
        }
        if(picker==memoryContact&&!populatingMemoryContacts&&previous!=PickerContactId(picker.SelectedItem))RefreshSelectedMemoryContact();
    }
}
}
