using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EchoWechatDesktop {
public partial class MainForm {
    ComboBox providerChoice,recordScopeChoice,batchAction,advisorContact;
    CheckBox messageAdviceEnabled,includePublicGroupTasks,splitBudgets;
    NumericUpDown dailyAnalysisRequestLimit,dailyAssistRequestLimit,analysisCostLimit,assistCostLimit;
    HashSet<string> reportExcluded=new HashSet<string>(StringComparer.Ordinal),reminderExcluded=new HashSet<string>(StringComparer.Ordinal);
    Dictionary<string,string> contactPersonas=new Dictionary<string,string>(StringComparer.Ordinal);
    TextBox advisorDraft,advisorRequirements,batchPersonaText;
    RichTextBox advisorResults;
    Button advisorGenerate;
    string previousAdvice="",adviceContactId="";
    bool advisorBusy,runActive,populatingAdvisor;
    long stopGeneration;
    ConcurrentDictionary<int,Process> backgroundJobs=new ConcurrentDictionary<int,Process>();
    Dictionary<RichTextBox,int> readingHeights=new Dictionary<RichTextBox,int>();
    sealed class AdvisorContact {public string Id,Label;public override string ToString(){return Label+"（"+Id+"）";}}

    void BuildRequirementUpgrade(){
        stopLive.Enabled=true;
        contactAIEnabled=new CheckBox{Text="联系人 AI 问答 · 每次手动提问中幅增加，长历史可达大幅",Checked=false};
        providerChoice=MakeCombo(25,25,500,new string[]{"DeepSeek · Chat Completions","自定义 · OpenAI兼容接口","Ollama · 本机接口","LM Studio · 本机接口","Anthropic · Messages"});
        providerChoice.SelectedIndexChanged+=delegate{if(providerChoice.SelectedIndex==0)apiBase.Text="https://api.deepseek.com";else if(providerChoice.SelectedIndex==2)apiBase.Text="http://localhost:11434/v1";else if(providerChoice.SelectedIndex==3)apiBase.Text="http://localhost:1234/v1";else if(providerChoice.SelectedIndex==4)apiBase.Text="https://api.anthropic.com";};
        recordScopeChoice=MakeCombo(25,25,600,new string[]{"保存所有可读取会话（近60天）","只保存已有管理对象（近60天）"});
        messageAdviceEnabled=MakeCheck("启用我手写原稿的消息修改建议",25,25,900);messageAdviceEnabled.Checked=false;
        includePublicGroupTasks=MakeCheck("提醒可包含群公开行动要求（默认只收与我有关的私聊及群@）",25,25,900);
        splitBudgets=MakeCheck("分别限制自动回复、后台分析和手动建议，避免分析占用回复次数",25,25,900);splitBudgets.Checked=true;
        dailyAnalysisRequestLimit=NewNumber(0,10000,30);dailyAssistRequestLimit=NewNumber(0,10000,20);
        analysisCostLimit=NewNumber(0,1000,0,2);assistCostLimit=NewNumber(0,1000,0,2);
        tone.Items.Clear();tone.Items.AddRange(new string[]{"温和自然","简短直接","专业清晰","熟悉轻松","认真细致","克制礼貌","自定义（按下方设定）"});tone.SelectedIndex=0;
        preset.Items.AddRange(new string[]{"熟悉自然","学习搭档"});
        BuildUnifiedSettings();BuildAdvisor();BuildRunPage();BuildRuleOverview();BuildPersonaOverview();CompactMemoryHeader();
        SetupReadingGrowth();
        FormClosing+=delegate{StopAllWork();};
        Shown+=delegate{BeginInvoke(new Action(delegate{SetupFooterActions();ResizeReadingAreas();}));};
    }
    NumericUpDown NewNumber(decimal min,decimal max,decimal value,int decimals=0){var n=new NumericUpDown{Minimum=min,Maximum=max,Value=value,DecimalPlaces=decimals,Width=160};return n;}
    void MoveSetting(Panel card,string label,Control control,ref int top,int height=40){
        if(control.Parent!=null)control.Parent.Controls.Remove(control);card.Controls.Add(control);
        if(control is CheckBox){control.SetBounds(20,top,890,32);}
        else {card.Controls.Add(MakeLabel(label,20,top+3,265,30));control.SetBounds(300,top,590,height);}
        top+=Math.Max(44,height+12);
    }
    Panel SettingsCard(TabPage page,string title,ref int top){var p=new Panel{Location=new Point(25,top),Size=new Size(930,100),BackColor=Color.FromArgb(248,250,253)};p.Controls.Add(MakeLabel(title,20,15,890,32,true));p.SizeChanged+=delegate{foreach(Control child in p.Controls)if(child.Left>=UiPixel(290)||child is CheckBox||child.Top<UiPixel(50))child.Width=Math.Max(UiPixel(80),p.ClientSize.Width-child.Left-UiPixel(20));};page.Controls.Add(p);return p;}
    void FinishCard(Panel card,int height,ref int top){card.Height=height+15;top+=card.Height+22;}
    void BuildUnifiedSettings(){
        var page=mainProductTabs.TabPages[0];page.Text="设置";page.Controls.Clear();mainProductTabs.TabPages[7].Text="连接日志";
        recordChats.Text="本机记录近60天聊天 · 不增加Token用量";useMemory.Text="回复参考人物记忆 · 小幅增加";
        dailyReport.Text="生成每日重点 · 大幅增加（首次大量补齐可达巨幅）";weeklyReport.Text="生成每周重点 · 大幅至巨幅增加（跨天进展整理与完整语境核验）";
        importantReminders.Text="提取与我有关的提醒 · 大幅增加（随聊天量变化）";autoRefreshMemory.Text="定期人物分析 · 大幅增加（近关系深入分析可达巨幅）";
        messageAdviceEnabled.Text="手写原稿修改建议 · 每次手动生成中幅增加（包含独立原意核验）";mediaEnabled.Text="手动本机图片 / WAV识别 · 不增加模型Token用量";
        analysisCache.Text="复用已有分析缓存 · 降低重复请求用量";enabled.Text="启用运行 · 开关本身不增加用量";
        privateEnabled.Text="允许名单私聊回复 · 中幅增加";groupEnabled.Text="允许名单群@我回复 · 大幅增加（活跃群可达巨幅）";
        includePublicGroupTasks.Text="收取群公开行动提醒 · 大幅至巨幅增加（默认只收私聊和群@我）";
        budgetEnabled.Text="启用每日请求次数保护（不是费用估算）";showCosts.Checked=false;
        int top=25,row=60;Panel card=SettingsCard(page,"功能开关 · 按需开启",ref top);
        MoveSetting(card,"",recordChats,ref row);MoveSetting(card,"",dailyReport,ref row);MoveSetting(card,"",weeklyReport,ref row);MoveSetting(card,"",importantReminders,ref row);MoveSetting(card,"",includePublicGroupTasks,ref row);MoveSetting(card,"",autoRefreshMemory,ref row);MoveSetting(card,"",useMemory,ref row);MoveSetting(card,"",messageAdviceEnabled,ref row);MoveSetting(card,"",contactAIEnabled,ref row);MoveSetting(card,"",mediaEnabled,ref row);MoveSetting(card,"",showDraftTools,ref row);
        card.Controls.Add(MakeLabel("用量档位：略微 < 小幅 < 中幅 < 大幅 < 巨幅。这里是相对提示，不是账单预测；消息量、分析深度和更新频率会改变实际消耗。只查看本机已有内容不调用模型。",20,row,890,85));row+=95;FinishCard(card,row,ref top);
        row=60;card=SettingsCard(page,"监测范围和人物更新",ref top);MoveSetting(card,"本机记录范围",recordScopeChoice,ref row);MoveSetting(card,"可发送到模型的分析范围",analysisScope,ref row);MoveSetting(card,"人物更新间隔 / 天",memoryRefreshDays,ref row);
        var media=MakeButton("选择图片 / WAV语音进行本机识别",20,row,500,40);media.Click+=async delegate{await ReadImage();};card.Controls.Add(media);row+=55;
        card.Controls.Add(MakeLabel("全部会话分析比只分析名单消耗更多。首次导入大量历史后分析可能巨幅增加；之后只整理新内容。日报周报和提醒的单独屏蔽在批量管理设置，不影响本机监测。",20,row,890,85));row+=95;FinishCard(card,row,ref top);
        row=60;card=SettingsCard(page,"运行、回复与人工接管",ref top);MoveSetting(card,"",enabled,ref row);MoveSetting(card,"",privateEnabled,ref row);MoveSetting(card,"",groupEnabled,ref row);MoveSetting(card,"好友回复条件",contactMode,ref row);MoveSetting(card,"",quietEnabled,ref row);MoveSetting(card,"免打扰开始（小时）",quietStart,ref row);MoveSetting(card,"免打扰结束（小时）",quietEnd,ref row);MoveSetting(card,"不允许回复的好友/群",blocked,ref row,80);MoveSetting(card,"关键词筛选",keywords,ref row);card.Controls.Add(MakeLabel("群自动回复必须 @当前登录微信账号。你在微信手动回复后，该会话AI暂停，等待你主动恢复。",20,row,890,55));row+=65;FinishCard(card,row,ref top);
        row=60;card=SettingsCard(page,"模型服务 · 可自由填写地址和模型",ref top);MoveSetting(card,"接口类型",providerChoice,ref row);MoveSetting(card,"接口地址",apiBase,ref row);MoveSetting(card,"模型名称（可输入）",model,ref row);MoveSetting(card,"API Key（仅本机加密）",key,ref row);MoveSetting(card,"助手名称",botName,ref row);MoveSetting(card,"运行组件 Python 路径",pythonPath,ref row);
        Button test=MakeButton("测试当前模型连接 · 略微增加用量",20,row,500,40,true);test.Click+=async delegate{await TestKey();};card.Controls.Add(test);row+=55;FinishCard(card,row,ref top);
        row=60;card=SettingsCard(page,"节省用量和请求保护",ref top);MoveSetting(card,"",analysisCache,ref row);MoveSetting(card,"",budgetEnabled,ref row);MoveSetting(card,"",splitBudgets,ref row);MoveSetting(card,"自动回复每日请求上限",dailyRequestLimit,ref row);MoveSetting(card,"后台分析每日请求上限",dailyAnalysisRequestLimit,ref row);MoveSetting(card,"手动建议每日请求上限",dailyAssistRequestLimit,ref row);MoveSetting(card,"回复历史字数上限",contextChars,ref row);MoveSetting(card,"回复输出上限",replyMaxTokens,ref row);MoveSetting(card,"连续消息合并等待 / 秒",mergeSeconds,ref row);MoveSetting(card,"提醒刷新间隔 / 分钟",reminderRefreshMinutes,ref row);MoveSetting(card,"普通人物分析摘录上限",memorySampleChars,ref row);
        card.Controls.Add(MakeLabel("历史越长、更新越频繁，消耗越大。降低摘录量和输出上限可减少用量。关闭对应功能后不再自动发起该功能请求。金额与单价无需在回声填写，账单请到模型服务查看。",20,row,890,85));row+=95;FinishCard(card,row,ref top);
    }
    void BuildRunPage(){
        var p=mainProductTabs.TabPages[7];p.Controls.Clear();p.Controls.Add(MakeLabel("连接与运行",25,25,930,35,true));p.Controls.Add(MakeLabel("所有连接参数、功能开关和范围都在设置；在这里查看连接日志。停止运行会同时停止后台整理。",25,70,930,60));
        startLive.SetBounds(25,145,220,40);stopLive.SetBounds(260,145,140,40);installBridge.SetBounds(415,145,200,40);p.Controls.Add(startLive);p.Controls.Add(stopLive);p.Controls.Add(installBridge);
        var settings=MakeButton("打开设置",630,145,210,40);settings.Click+=delegate{SelectMainTab("设置");};p.Controls.Add(settings);
        liveLog.SetBounds(25,215,930,480);p.Controls.Add(liveLog);
    }
    void BuildRuleOverview(){
        var page=mainProductTabs.TabPages[1];page.Controls.Clear();page.Controls.Add(MakeLabel("已管理好友与群 · 回复条件和屏蔽分别在设置调整",25,25,930,40,true));
        var button=MakeButton("打开批量管理 ▼",25,85,240,40,true);button.Click+=delegate{OpenContactManagement();};page.Controls.Add(button);
        page.Controls.Add(MakeLabel("好友",25,145,930,30,true));friendList.SetBounds(25,185,930,320);page.Controls.Add(friendList);
        page.Controls.Add(MakeLabel("群",25,545,930,30,true));groupList.SetBounds(25,585,930,320);page.Controls.Add(groupList);
    }
    void BuildPersonaOverview(){var p=mainProductTabs.TabPages[2];p.Controls.Clear();p.Controls.Add(MakeLabel("自由定义助手人设与表达",25,25,930,35,true));p.Controls.Add(MakeLabel("全局风格",25,85,930,30));tone.SetBounds(25,125,600,40);p.Controls.Add(tone);p.Controls.Add(MakeLabel("自定义设定 · 写明身份、语气、答复范围及交给你本人处理的情况",25,195,930,40));prompt.SetBounds(25,250,930,380);p.Controls.Add(prompt);p.Controls.Add(MakeLabel("不同联系人的专属要求在批量管理填写。AI参考双方历史的称呼和表达习惯，关系程度由你指定。",25,660,930,65));buildMemory.SetBounds(25,750,300,42);p.Controls.Add(buildMemory);p.Controls.Add(MakeLabel("人物更新开关与频率集中在设置。查看已有分析不会调用模型。",25,815,930,60));}
    void CompactMemoryHeader(){
        var page=mainProductTabs.TabPages[6];Button reload=null,save=null;foreach(Control c in page.Controls)if(c is Button){if(c.Text=="读取本机分析")reload=(Button)c;else if(c.Text=="保存此人设置")save=(Button)c;}
        page.Controls.Clear();page.Controls.Add(MakeLabel("人物记忆 · 阅读充分展开，使用外层页面上下滚动",25,8,930,28,true));memoryContact.SetBounds(25,45,390,35);page.Controls.Add(memoryContact);
        reload.SetBounds(435,43,150,35);page.Controls.Add(reload);updateSelectedMemory.SetBounds(600,43,180,35);page.Controls.Add(updateSelectedMemory);
        var advanced=new Panel{Location=new Point(25,95),Size=new Size(930,185),Visible=false};
        advanced.Controls.Add(MakeLabel("关系程度",0,8,110,30));relationshipChoice.SetBounds(120,5,260,35);advanced.Controls.Add(relationshipChoice);advanced.Controls.Add(MakeLabel("分析深度",400,8,100,30));analysisDepth.SetBounds(510,5,230,35);advanced.Controls.Add(analysisDepth);
        advanced.Controls.Add(MakeLabel("深入摘录上限",0,65,210,30));closeMemorySampleChars.SetBounds(220,60,160,35);advanced.Controls.Add(closeMemorySampleChars);save.SetBounds(510,58,230,38);advanced.Controls.Add(save);memoryReadingStatus.SetBounds(0,115,900,60);advanced.Controls.Add(memoryReadingStatus);page.Controls.Add(advanced);
        var expand=MakeButton("人物设置 ▼",795,43,160,35);expand.Click+=delegate{advanced.Visible=!advanced.Visible;expand.Text=advanced.Visible?"收起设置 ▲":"人物设置 ▼";memoryViews.Top=advanced.Visible?advanced.Bottom+UiPixel(15):UiPixel(82);};page.Controls.Add(expand);
        memoryViews.Location=new Point(25,82);page.Controls.Add(memoryViews);page.AutoScroll=true;
    }
    void BuildAdvisor(){
        var page=MakeTab("消息建议");mainProductTabs.TabPages.Add(page);
        page.Controls.Add(MakeLabel("你写原稿，AI在下方提供表达方案 · 原稿保留，结合双方历史和人物分析",25,20,930,55,true));
        advisorContact=MakeCombo(25,90,430,new string[]{"请选择联系人"});advisorContact.SelectedIndexChanged+=delegate{if(populatingAdvisor)return;previousAdvice="";adviceContactId="";if(advisorResults!=null)SetReading(advisorResults,"请选择联系人并填写原稿。切换联系人后，旧建议已清除。");};page.Controls.Add(advisorContact);
        var readFriends=MakeButton("导入微信好友",480,88,220,40);readFriends.Click+=async delegate{await ReadContactCatalog("friend");};page.Controls.Add(readFriends);
        var readGroups=MakeButton("导入微信群",715,88,230,40);readGroups.Click+=async delegate{await ReadContactCatalog("group");};page.Controls.Add(readGroups);
        page.Controls.Add(MakeLabel("我的原稿（不会被建议覆盖）",25,150,930,30,true));advisorDraft=MakeText(25,195,930,230,true);page.Controls.Add(advisorDraft);
        page.Controls.Add(MakeLabel("补充修改要求（可以继续补充，重新生成）",25,445,930,30));advisorRequirements=MakeText(25,490,930,95,true);page.Controls.Add(advisorRequirements);
        advisorGenerate=MakeButton("生成 / 继续调整建议",25,610,300,42,true);advisorGenerate.Click+=async delegate{await GenerateAdvice();};page.Controls.Add(advisorGenerate);
        var copy=MakeButton("复制选中的建议文字",345,610,300,42);copy.Click+=delegate{if(!String.IsNullOrWhiteSpace(advisorResults.SelectedText))Clipboard.SetText(advisorResults.SelectedText);else Notice("在下方选中需要复制的建议文字。");};page.Controls.Add(copy);
        page.Controls.Add(MakeLabel("AI修改建议 · 独立区域，可自行选择使用",25,690,930,35,true));advisorResults=ReadingBox();advisorResults.SetBounds(25,740,930,380);page.Controls.Add(advisorResults);
        page.Enter+=delegate{PopulateAdvisorContacts();};
    }
    void PopulateAdvisorContacts(){
        if(advisorContact==null)return;var old=advisorContact.SelectedItem as AdvisorContact;var options=new Dictionary<string,AdvisorContact>(StringComparer.Ordinal);var map=ContactMappings();
        foreach(ListView list in new ListView[]{friendList,groupList})foreach(ListViewItem row in list.Items){string id=map.ContainsKey(row.Text)?Convert.ToString(map[row.Text]):row.Text;options[id]=new AdvisorContact{Id=id,Label=row.SubItems[1].Text};}
        foreach(var c in contactChoices)if(!options.ContainsKey(c.Id))options[c.Id]=new AdvisorContact{Id=c.Id,Label=c.Label};
        populatingAdvisor=true;advisorContact.BeginUpdate();advisorContact.Items.Clear();AdvisorContact restore=null;foreach(var option in options.Values.OrderBy(x=>x.Label,StringComparer.CurrentCultureIgnoreCase)){advisorContact.Items.Add(option);if(old!=null&&old.Id==option.Id)restore=option;}advisorContact.EndUpdate();
        if(restore!=null)advisorContact.SelectedItem=restore;else if(advisorContact.Items.Count>0)advisorContact.SelectedIndex=0;
        populatingAdvisor=false;RefreshContactSearch(advisorContact);if(restore==null){previousAdvice="";adviceContactId="";}
    }
    async Task GenerateAdvice(){
        if(advisorBusy)return;var person=advisorContact.SelectedItem as AdvisorContact;if(person==null||String.IsNullOrWhiteSpace(advisorDraft.Text)){Notice("请选择联系人并写入原稿。");return;}
        if(!messageAdviceEnabled.Checked){Notice("消息建议功能已关闭。");return;}
        string original=advisorDraft.Text;long generation=stopGeneration;advisorBusy=true;advisorGenerate.Enabled=false;
        adviceProgress.Text="正在生成并独立核对原意…";adviceProgress.ForeColor=muted;
        var config=Config();config["apiKey"]=key.Text.Trim();var value=new Dictionary<string,object>{{"config",config},{"identifier",person.Id},{"draft",original},{"requirements",advisorRequirements.Text},{"receivedMessage",advisorReceived.Text},{"refreshLatest",true},{"previousSuggestions",person.Id==adviceContactId?previousAdvice:""}};
        try{
            var info=PythonInfo("compose_advisor.py");string payload=json.Serialize(value)+"\n";
            var result=await Task.Run(()=>RunCaptured(info,payload,120000,delegate(Process worker){TrackJob(worker,generation);}));
            if(IsDisposed||generation!=stopGeneration)return;
            if(result.Item1!=0){string failure="建议生成未完成；原稿已保留。";try{var failed=json.Deserialize<Dictionary<string,object>>(result.Item2.Trim());if(failed.ContainsKey("error"))failure=Str(failed,"error");}catch{}throw new Exception(failure);}
            var data=json.Deserialize<Dictionary<string,object>>(result.Item2);if(data.ContainsKey("error"))throw new Exception(Str(data,"error"));var output=new StringBuilder("# 消息修改建议\n\n");
            foreach(object v in (IList)data["variants"]){var variant=(Dictionary<string,object>)v;output.AppendLine("## "+Str(variant,"title")).AppendLine().AppendLine(Str(variant,"text")).AppendLine().AppendLine("修改理由："+Str(variant,"reason")).AppendLine();}
            output.AppendLine(Str(data,"notes"));output.AppendLine("历史参考："+Str(data,"historyMessages")+" 条身份明确消息；人物分析作为待核对参考。");
            var selected=advisorContact.SelectedItem as AdvisorContact;if(selected==null||selected.Id!=person.Id){Notice("联系人已切换，旧对象结果已丢弃。");return;}
            if(advisorDraft.Text!=original){Notice("原稿已修改，本次旧原稿的建议已丢弃，请重新生成。");return;}
            previousAdvice=output.ToString();adviceContactId=person.Id;DisplayAdvice(data,original);status.Text="建议已并排显示；每个方案可单独复制正文，原稿没有改动。";
        }catch(Exception error){if(!IsDisposed){adviceProgress.Text="未完成："+error.Message;adviceProgress.ForeColor=Color.FromArgb(176,50,62);status.Text=error.Message;}}finally{advisorBusy=false;if(!IsDisposed)RefreshAdviceEntry();}
    }
    ProcessStartInfo PythonInfo(string module){var info=new ProcessStartInfo(pythonPath.Text.Trim(),"-X utf8 -u \""+Path.Combine(AppDomain.CurrentDomain.BaseDirectory,module)+"\"");info.UseShellExecute=false;info.CreateNoWindow=true;info.WorkingDirectory=AppDomain.CurrentDomain.BaseDirectory;info.RedirectStandardInput=true;info.RedirectStandardOutput=true;info.RedirectStandardError=true;info.StandardOutputEncoding=Encoding.UTF8;info.StandardErrorEncoding=Encoding.UTF8;return info;}
    void TrackJob(Process process,long generation){int id=process.Id;backgroundJobs[id]=process;process.Exited+=delegate{Process removed;backgroundJobs.TryRemove(id,out removed);};process.EnableRaisingEvents=true;if(generation!=System.Threading.Interlocked.Read(ref stopGeneration)){try{process.Kill();}catch{}}if(process.HasExited){Process removed;backgroundJobs.TryRemove(id,out removed);}}
    bool IsLocalModel(){Uri uri;return Uri.TryCreate(apiBase.Text,UriKind.Absolute,out uri)&&(uri.Host=="localhost"||uri.Host=="127.0.0.1"||uri.Host=="[::1]"||uri.Host=="::1");}
    void StopAllWork(){StopRunWork(true);}
    void StopRunWork(bool disconnectWechat){
        if(disconnectWechat){localConnectionPhase="未连接";localConnectionMessage="连接已停止，后台监听已关闭。";}
        lastRunFailure="";
        liveSettingsTimer.Stop();
        runActive=false;System.Threading.Interlocked.Increment(ref stopGeneration);batchCancelRequested=true;
        if(advisorBusy&&adviceProgress!=null){adviceProgress.Text="本次生成已停止；原稿和已有方案保留。";adviceProgress.ForeColor=muted;}
        if(contactBusy&&contactAIProgress!=null)contactAIProgress.Text="本次联系人问答或读取已停止；草稿保留。";
        if(memoryTimer!=null)memoryTimer.Stop();if(insightTimer!=null)insightTimer.Stop();
        StopMemorySync();foreach(var item in backgroundJobs){try{if(!item.Value.HasExited)item.Value.Kill();}catch{}Process removed;backgroundJobs.TryRemove(item.Key,out removed);}
        StopBridge();if(status!=null)status.Text="已停止监听和后台分析；没有新任务会自动启动。手动生成需重新点击对应按钮。";
    }
    void StartBackgroundRun(){runStartedUnix=DateTimeOffset.Now.ToUnixTimeSeconds();runActive=true;memoryTimer.Start();insightTimer.Start();long generation=stopGeneration;BeginInvoke(new Action(async delegate{await Task.Delay(2000);if(!IsDisposed&&runActive&&generation==stopGeneration&&!memorySyncRunning)await UpdateInformation("tick");}));}
    void SetupFooterActions(){
        var shell=Controls[0] as TableLayoutPanel;var foot=shell.GetControlFromPosition(0,2);
        footerRun=MakeButton("开始运行",0,UiPixel(6),UiPixel(100),UiPixel(35),true);footerRun.Click+=delegate{StartCurrentSettings();};var start=footerRun;var stop=MakeButton("停止全部",0,UiPixel(6),UiPixel(100),UiPixel(35));stop.Click+=delegate{StopAllWork();RefreshHomeDashboard();};var settings=MakeButton("设置",0,UiPixel(6),UiPixel(105),UiPixel(35));settings.Click+=delegate{SelectMainTab("设置");};foot.Controls.Add(start);foot.Controls.Add(stop);foot.Controls.Add(settings);
        Action place=delegate{settings.Left=foot.ClientSize.Width-UiPixel(120);stop.Left=settings.Left-UiPixel(110);start.Left=stop.Left-UiPixel(110);status.Width=Math.Max(100,start.Left-UiPixel(35));};foot.Resize+=delegate{place();};place();
    }
    void AddRequirementConfig(Dictionary<string,object> c){
        c["jsonMode"]=jsonModeChoice!=null&&jsonModeChoice.SelectedIndex==1?"prompt":"auto";c["provider"]=providerChoice.SelectedIndex;c["apiProtocol"]=providerChoice.SelectedIndex==4?"anthropic":"openai";c["recordScope"]=recordScopeChoice.SelectedIndex==1?"selected":"all";c["reportExcluded"]=new List<string>(reportExcluded);c["reminderExcluded"]=new List<string>(reminderExcluded);c["contactPersonas"]=contactPersonas;
        c["contactAIEnabled"]=contactAIEnabled.Checked;c["messageAdviceEnabled"]=messageAdviceEnabled.Checked;c["includePublicGroupTasks"]=includePublicGroupTasks.Checked;c["splitBudgets"]=splitBudgets.Checked;c["dailyAnalysisRequestLimit"]=(int)dailyAnalysisRequestLimit.Value;c["dailyAssistRequestLimit"]=(int)dailyAssistRequestLimit.Value;c["analysisCostLimit"]=0;c["assistCostLimit"]=0;c["dailyCostLimit"]=0;c["inputPrice"]=0;c["outputPrice"]=0;c["cacheInputPrice"]=0;c["showCosts"]=false;
    }
    void LoadRequirementConfig(Dictionary<string,object> c){
        if(jsonModeChoice!=null)jsonModeChoice.SelectedIndex=Str(c,"jsonMode")=="prompt"?1:0;string endpoint=apiBase.Text;providerChoice.SelectedIndex=Math.Max(0,Math.Min(4,Int(c,"provider",Str(c,"apiProtocol")=="anthropic"?4:0)));apiBase.Text=endpoint;recordScopeChoice.SelectedIndex=Str(c,"recordScope")=="all"?0:1;
        reportExcluded=Strings(c,"reportExcluded");reminderExcluded=Strings(c,"reminderExcluded");contactPersonas.Clear();var persons=c.ContainsKey("contactPersonas")?c["contactPersonas"] as Dictionary<string,object>:null;if(persons!=null)foreach(var p in persons)contactPersonas[p.Key]=Convert.ToString(p.Value);
        contactAIEnabled.Checked=Bool(c,"contactAIEnabled",false);messageAdviceEnabled.Checked=Bool(c,"messageAdviceEnabled",false);includePublicGroupTasks.Checked=Bool(c,"includePublicGroupTasks",false);splitBudgets.Checked=Bool(c,"splitBudgets",true);
        showCosts.Checked=false;dailyCostLimit.Value=0;analysisCostLimit.Value=0;assistCostLimit.Value=0;inputPrice.Value=0;outputPrice.Value=0;cacheInputPrice.Value=0;
        dailyAnalysisRequestLimit.Value=Math.Max(0,Math.Min(10000,Int(c,"dailyAnalysisRequestLimit",30)));dailyAssistRequestLimit.Value=Math.Max(0,Math.Min(10000,Int(c,"dailyAssistRequestLimit",20)));
        decimal number;if(c.ContainsKey("analysisCostLimit")&&Decimal.TryParse(Convert.ToString(c["analysisCostLimit"]),out number))analysisCostLimit.Value=Math.Max(0,Math.Min(1000,number));if(c.ContainsKey("assistCostLimit")&&Decimal.TryParse(Convert.ToString(c["assistCostLimit"]),out number))assistCostLimit.Value=Math.Max(0,Math.Min(1000,number));
    }
    static HashSet<string> Strings(Dictionary<string,object> c,string key){var result=new HashSet<string>(StringComparer.Ordinal);var values=c.ContainsKey(key)?c[key] as IList:null;if(values!=null)foreach(object value in values)if(value is string)result.Add((string)value);return result;}
    void ReleaseSnoozed(){
        string path=Path.Combine(settingsDir,"important-actions.json");if(!File.Exists(path))return;
        var actions=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(path,Encoding.UTF8));int count=0;
        foreach(var value in actions.Values){var a=value as Dictionary<string,object>;DateTime until;if(a!=null&&Str(a,"status")=="snoozed"&&DateTime.TryParse(Str(a,"until"),out until)&&until<=DateTime.Now){a["status"]="pending";a["resumedAt"]=DateTime.Now.ToString("s");count++;}}
        if(count==0)return;string temporary=path+".new";File.WriteAllText(temporary,json.Serialize(actions),Encoding.UTF8);File.Replace(temporary,path,null);if(status!=null)status.Text=count+" 条延后提醒已到时间，恢复待处理。";
    }
    void SetupReadingGrowth(){
        foreach(var box in new RichTextBox[]{reportView,documentView,relationshipView,digestView,memoryEvidenceView,advisorResults}){
            box.Dock=DockStyle.None;box.ScrollBars=RichTextBoxScrollBars.None;readingHeights[box]=380;
            box.ContentsResized+=delegate(object sender,ContentsResizedEventArgs e){var view=(RichTextBox)sender;int oldHeight;if(!readingHeights.TryGetValue(view,out oldHeight))return;int height=Math.Max(UiPixel(320),Math.Min(30000,e.NewRectangle.Height+UiPixel(65)));if(oldHeight==height)return;readingHeights[view]=height;if(IsHandleCreated&&!IsDisposed)BeginInvoke(new Action(ResizeReadingAreas));};
        }
        mainProductTabs.TabPages[6].AutoScroll=true;documentTab.AutoScroll=true;
        memoryViews.SelectedIndexChanged+=delegate{ResizeReadingAreas();};
    }
    void ResizeReadingAreas(){
        using(var viewport=new ContactViewport(this)){
        foreach(var pair in readingHeights.ToArray()){var box=pair.Key;if(box.IsDisposed)continue;int expanded=Math.Max(pair.Value,(int)(mainProductTabs.ClientSize.Height*.8));box.Height=expanded;
            if(box==relationshipView)box.SetBounds(0,UiPixel(45),Math.Max(100,box.Parent.ClientSize.Width-UiPixel(8)),expanded);
            else if(box==digestView||box==memoryEvidenceView)box.SetBounds(0,0,Math.Max(100,box.Parent.ClientSize.Width-UiPixel(8)),expanded);
        }
        int selected=memoryViews.SelectedIndex;RichTextBox current=selected==0?relationshipView:selected==1?digestView:selected==2?memoryEvidenceView:null;
        memoryViews.Height=current==null?UiPixel(1000):current.Bottom+UiPixel(50);
        if(memoryViews.SelectedTab==contactAITab)ResizeContactWorkspace();
        ResizeReportLayout();
        foreach(Control child in reportView.Parent.Controls)if(child is Button&&(child.Text=="合并查看所选"||child.Text=="隐藏所选"||child.Text=="恢复全部显示"||child.Text=="全选"))child.Top=Math.Max(reportView.Bottom,reportList.Bottom)+UiPixel(20);
        }
    }
    async Task ExecuteBatchAction(){
        int operation=batchAction.SelectedIndex;var selected=ChosenContacts();
        if(operation==1){AddCheckedContacts();await UpdateBatchAnalyses();return;}if(operation==2){RemoveCheckedContacts();return;}if(operation==3){UndoContactRemoval();return;}if(operation==14){await UpdateBatchAnalyses();return;}
        if(selected.Count==0){Notice("请先勾选对象。");return;}
        if(operation>=9&&operation<=12){var map=ContactMappings();var set=operation<=10?reportExcluded:reminderExcluded;foreach(var c in selected){string id=map.ContainsKey(c.Id)?Convert.ToString(map[c.Id]):c.Id;if(operation==9||operation==11)set.Add(id);else set.Remove(id);}SaveContactBatch("已调整所选对象的"+(operation<=10?"日报周报":"重要提醒")+"范围；本机监测设置保留。");return;}
        if(operation==15){string text=batchPersonaText.Text.Trim();var map=ContactMappings();foreach(var c in selected){string id=map.ContainsKey(c.Id)?Convert.ToString(map[c.Id]):c.Id;if(text.Length==0)contactPersonas.Remove(id);else contactPersonas[id]=text;}SaveContactBatch(text.Length==0?"已清除所选对象的专属表达要求。":"已保存所选对象的专属回复要求。");return;}
        if(operation>=4&&operation<=8){batchChangeMode.Checked=operation>=6;batchChangeStar.Checked=operation<=5;batchChangeRelation.Checked=false;if(operation<=5)batchStarValue.Checked=operation==4;else contactBatchMode.SelectedIndex=operation==6?0:operation==7?1:2;}
        if(operation==13){batchChangeRelation.Checked=true;batchChangeMode.Checked=false;batchChangeStar.Checked=false;}
        if(operation>=4)await ApplyContactBatch();else Notice("请在小三角下拉菜单选择操作。");
    }
}
}
