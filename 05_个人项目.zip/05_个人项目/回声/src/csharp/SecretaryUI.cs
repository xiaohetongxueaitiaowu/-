using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EchoWechatDesktop {
static class AppPaths {
    internal static readonly string Code=AppDomain.CurrentDomain.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar);
    internal static readonly bool Organized=Path.GetFileName(Code)=="程序";
    internal static readonly string Root=Organized?Path.GetDirectoryName(Code):Code;
    internal static readonly string Storage=Organized?Path.Combine(Root,"资料"):Root;
    internal static readonly string Docs=Organized?Path.Combine(Root,"说明"):Root;
}
public partial class MainForm {
    readonly string[] workspaceNames={"首页","日报与周报","待办提醒","联系人与记忆","消息与回复","设置与运行","和 AI 调整","个人中心"};
    readonly int[][] workspacePages={new[]{11},new[]{3},new[]{4},new[]{9,6},new[]{10,1,2},new[]{0,5,7,8},new[]{12},new[]{13}};
    FlowLayoutPanel workspaceSubnav;
    RichTextBox secretaryBrief,secretaryTasks,featureConversation;
    Label secretarySummary;
    ComboBox featureChoice,featureTarget;
    TextBox featureQuestion,featureRequirements;
    Button featureSend,featureSave,featureUpdate;
    string featureDocument="";
    long dialogueEpoch;
    bool dialogueBusy,loadingFeature;

    int WorkspaceGroup(int page){for(int i=0;i<workspacePages.Length;i++)if(Array.IndexOf(workspacePages[i],page)>=0)return i;return 5;}
    void OpenWorkspacePage(int page){mainProductTabs.SelectedIndex=page;UpdateWorkspaceSubnav();ResetPageViewport(mainProductTabs.TabPages[page]);}
    void UpdateWorkspaceSubnav(){
        if(workspaceSubnav==null)return;while(workspaceSubnav.Controls.Count>0)workspaceSubnav.Controls[0].Dispose();int group=WorkspaceGroup(mainProductTabs.SelectedIndex);
        foreach(int page in workspacePages[group]){int target=page;var button=MakeButton(mainProductTabs.TabPages[page].Text,0,0,170,36,page==mainProductTabs.SelectedIndex);button.Margin=new Padding(UiPixel(4),UiPixel(8),UiPixel(4),0);button.Click+=delegate{OpenWorkspacePage(target);};workspaceSubnav.Controls.Add(button);}
        if(group!=6 && group!=0 && group!=7){string feature=group==1?(reportKind.SelectedIndex==1?"weekly":"daily"):group==2?"reminders":group==3?"memory":"adviser";
            if(mainProductTabs.SelectedIndex==1||mainProductTabs.SelectedIndex==2)feature="reply";
            if(group!=5){string selectedFeature=feature;var adjust=MakeButton("和 AI 调整此功能",0,0,190,36);adjust.Margin=new Padding(UiPixel(12),UiPixel(8),0,0);adjust.Click+=delegate{OpenFeatureDialogue(selectedFeature);};workspaceSubnav.Controls.Add(adjust);}
        }
        var work=workspaceSubnav.Parent as TableLayoutPanel;if(work!=null)work.RowStyles[0].Height=(group==0||group==7)?0:UiPixel(42);
        mainNavigation.Invalidate();
    }
    void BuildSecretaryWorkspace(){
        documentKind.SelectedIndex=7;
        // The batch action belongs above the objects it operates on.
        var contactsPage=mainProductTabs.TabPages[9];batchAction.SetBounds(25,190,330,38);contactBatchList.SetBounds(25,250,930,430);
        contactBatchKind.SetBounds(25,75,200,34);contactBatchSearch.SetBounds(685,75,270,34);
        foreach(Control child in contactsPage.Controls){if(child is Label&&child.Text.StartsWith("好友、群和已有")){child.Text="联系人 · 好友与群分开导入，勾选后批量操作。";child.SetBounds(25,20,650,34);}else if(child is Button&&child.Text=="导入微信好友")child.SetBounds(240,72,205,38);else if(child is Button&&child.Text=="导入微信群")child.SetBounds(460,72,205,38);else if(child is Button&&child.Text=="单个添加好友")child.SetBounds(25,125,195,38);else if(child is Button&&child.Text=="单个添加群")child.SetBounds(235,125,195,38);else if(child is Button&&child.Text=="修改当前项")child.SetBounds(445,125,195,38);else if(child is Button&&child.Text=="移除当前项")child.SetBounds(655,125,195,38);else if(child is Button&&child.Text=="执行操作")child.SetBounds(370,190,180,36);else if(child is Button&&child.Text=="全选")child.SetBounds(610,190,75,38);else if(child is Button&&child.Text=="清空选择")child.SetBounds(700,190,140,38);else if(child.Top>=850)child.Top-=120;}
        contactsPage.Controls.Add(MakeLabel("搜索名称 / 微信号",685,50,270,22));

        var home=MakeTab("首页");mainProductTabs.TabPages.Add(home);
        var page=MakeTab("和 AI 调整");mainProductTabs.TabPages.Add(page);
        page.Controls.Add(MakeLabel("直接告诉 AI：你希望怎么改",25,20,930,36,true));
        page.Controls.Add(MakeLabel("各个功能分开对话。建议在下方展示；长期要求可编辑后保存，下一次生成会使用。",25,63,930,45));
        featureChoice=MakeCombo(25,122,280,new[]{"秘书日报","秘书周报","待办提醒","人物与关系","消息建议","自动回复"});page.Controls.Add(featureChoice);
        featureTarget=MakeCombo(325,122,600,new[]{"此功能的通用要求"});page.Controls.Add(featureTarget);
        featureChoice.SelectedIndexChanged+=async delegate{if(loadingFeature)return;featureDocument="";PopulateFeatureTargets();await LoadFeatureDialogue();};
        featureTarget.SelectedIndexChanged+=async delegate{if(!loadingFeature)await LoadFeatureDialogue();};
        featureConversation=new EchoReadingBox{Location=new Point(25,412),Size=new Size(930,580),ReadOnly=true,ScrollBars=RichTextBoxScrollBars.None,DetectUrls=false,BorderStyle=BorderStyle.None};page.Controls.Add(featureConversation);SetReading(featureConversation,"选择功能，写下你希望怎样调整。AI 的回答会显示在这里。\n\n长期要求可保存给以后的生成使用，原有来源校验继续生效。");page.Enter+=async delegate{await LoadFeatureDialogue();};
        page.Controls.Add(MakeLabel("补充要求或提问",25,176,900,28,true));
        featureQuestion=MakeText(25,220,930,100,true);featureQuestion.MaxLength=1500;page.Controls.Add(featureQuestion);
        featureSend=MakeButton("发送给 AI",25,336,160,38,true);featureSend.Click+=async delegate{await SendFeatureQuestion();};page.Controls.Add(featureSend);
        var clear=MakeButton("清空本功能对话",205,336,190,38);clear.Click+=async delegate{await FeatureLocalAction("clear");};page.Controls.Add(clear);
        page.Controls.Add(MakeLabel("以后按这个要求做 · 你可以直接编辑",25,1020,930,34,true));
        featureRequirements=MakeText(25,1060,930,180,true);featureRequirements.MaxLength=1500;page.Controls.Add(featureRequirements);
        featureSave=MakeButton("保存长期要求",25,1260,180,38,true);featureSave.Click+=async delegate{await FeatureLocalAction("save");};page.Controls.Add(featureSave);
        featureUpdate=MakeButton("保存要求并重新生成",225,1260,250,38);featureUpdate.Click+=async delegate{if(await FeatureLocalAction("save")){string selected=FeatureId();if(selected=="daily"||selected=="weekly"){OpenWorkspacePage(3);await UpdateInformation(selected=="weekly"?"manual-weekly":"manual-daily");}else if(selected=="reminders"){OpenWorkspacePage(4);await UpdateInformation("refresh");}else if(selected=="memory"){if(!SelectFeaturePerson(true)){status.Text="请先选择要更新的人物。";return;}OpenWorkspacePage(6);await UpdateSelectedAnalysis();}else if(selected=="adviser"){if(!SelectFeaturePerson(false)){status.Text="请先选择联系人，并在消息建议页写原稿。";return;}OpenWorkspacePage(10);await GenerateAdvice();}else status.Text="自动回复表达要求已保存，后续回复会使用。";}};page.Controls.Add(featureUpdate);
        page.Controls.Add(MakeLabel("未打开此功能时不会自动调用模型；只有发问或重新生成才产生请求。对话不负责发送微信。",25,1320,930,52));
        // Keep the header focused; presets live with the reply persona.
        var shell=Controls[0] as TableLayoutPanel;var header=shell.GetControlFromPosition(0,0);
        var hide=new List<Control>();foreach(Control child in header.Controls)if(child is ComboBox || child is Button && child.Text!="保存设置")hide.Add(child);foreach(Control child in hide)child.Visible=false;
        foreach(Control child in header.Controls)if(child is Button&&child.Text=="保存设置"){child.Anchor=AnchorStyles.Top|AnchorStyles.Right;child.Left=header.Width-150;}
        foreach(Control child in mainProductTabs.TabPages[3].Controls){var label=child as Label;if(label!=null&&label.Text.StartsWith("每天 23:00"))label.Text="秘书简报 · 这一期发生了什么，哪些朋友有新进展，群里有什么值得知道。";}
        reportList.DrawMode=DrawMode.OwnerDrawFixed;reportList.ItemHeight=40;reportList.BorderStyle=BorderStyle.None;reportList.DrawItem+=delegate(object sender,DrawItemEventArgs e){if(e.Index<0)return;e.DrawBackground();string name=reportList.Items[e.Index].ToString().Replace("信息","").Replace(".md","").Replace("-当前"," · 当前进度");TextRenderer.DrawText(e.Graphics,name,normal,e.Bounds,e.ForeColor,TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis);};
        mainProductTabs.TabPages[3].Text="日报与周报";mainProductTabs.TabPages[9].Text="联系人管理";mainProductTabs.TabPages[10].Text="消息建议";
        foreach(Control child in mainProductTabs.TabPages[3].Controls){var label=child as Label;if(label!=null&&label.Text.Contains("原文交给"))label.Text="按事件整理，来源可核对。";}
        reportKind.SelectedIndexChanged+=delegate{UpdateWorkspaceSubnav();};
        BuildHomeProfile();
        Shown+=delegate{PopulateFeatureTargets();RegisterSecretaryReading(featureConversation,580);};
    }
    void RegisterSecretaryReading(RichTextBox box,int minimum){var original=new Dictionary<Control,int>();int originalHeight=box.Height;foreach(Control control in box.Parent.Controls)if(control!=box&&control.Top>=box.Bottom)original[control]=control.Top;box.ContentsResized+=delegate(object sender,ContentsResizedEventArgs e){int height=Math.Max(UiPixel(minimum),Math.Min(30000,e.NewRectangle.Height+UiPixel(65)));box.Height=height;foreach(var entry in original)entry.Key.Top=entry.Value+height-originalHeight;};}
    void RefreshSecretaryHome(){RefreshHomeDashboard();}
    bool SelectFeaturePerson(bool memory){string id=FeatureTargetId();if(id.Length==0)return false;ComboBox choice=memory?memoryContact:advisorContact;if(memory)PopulateMemoryContacts();else PopulateAdvisorContacts();foreach(object item in choice.Items){var a=item as AdvisorContact;var m=item as MemoryContact;string candidate=a!=null?a.Id:m!=null?m.Id:"";if(candidate==id){choice.SelectedItem=item;return true;}}return false;}
    string FeatureId(){return new[]{"daily","weekly","reminders","memory","adviser","reply"}[Math.Max(0,featureChoice.SelectedIndex)];}
    string FeatureTargetId(){var target=featureTarget.SelectedItem as AdvisorContact;return target==null?"":target.Id;}
    void PopulateFeatureTargets(){loadingFeature=true;try{featureTarget.Items.Clear();featureTarget.Items.Add("此功能的通用要求");string feature=FeatureId();if(feature=="memory"||feature=="adviser"||feature=="reply"){
        var seen=new HashSet<string>();var map=ContactMappings();foreach(ListView list in new[]{friendList,groupList})foreach(ListViewItem row in list.Items){string id=map.ContainsKey(row.Text)?Convert.ToString(map[row.Text]):row.Text;if(seen.Add(id))featureTarget.Items.Add(new AdvisorContact{Id=id,Label=row.SubItems.Count>1?row.SubItems[1].Text:row.Text});}if(feature=="adviser"){PopulateAdvisorContacts();foreach(object obj in advisorContact.Items){var person=obj as AdvisorContact;if(person!=null&&seen.Add(person.Id))featureTarget.Items.Add(new AdvisorContact{Id=person.Id,Label=person.Label});}}
    }featureTarget.SelectedIndex=0;}finally{loadingFeature=false;}RefreshContactSearch(featureTarget);}
    async void OpenFeatureDialogue(string feature){loadingFeature=true;featureChoice.SelectedIndex=Array.IndexOf(new[]{"daily","weekly","reminders","memory","adviser","reply"},feature);loadingFeature=false;PopulateFeatureTargets();
        string id="";var selected=memoryContact.SelectedItem as MemoryContact;var advice=advisorContact.SelectedItem as AdvisorContact;
        if(feature=="memory"&&selected!=null)id=selected.Id;if(feature=="adviser"&&advice!=null)id=advice.Id;
        loadingFeature=true;for(int i=1;i<featureTarget.Items.Count;i++){var target=featureTarget.Items[i] as AdvisorContact;if(target!=null&&target.Id==id){featureTarget.SelectedIndex=i;break;}}loadingFeature=false;
        featureDocument=(feature=="daily"||feature=="weekly")&&reportList.SelectedItem!=null?reportList.SelectedItem.ToString():"";OpenWorkspacePage(12);await LoadFeatureDialogue();
    }
    Dictionary<string,object> FeatureRequest(string action){return new Dictionary<string,object>{{"action",action},{"feature",FeatureId()},{"target",FeatureTargetId()},{"document",featureDocument}};}
    void ShowFeatureConversation(Dictionary<string,object> data){var text=new StringBuilder();var history=data.ContainsKey("history")?data["history"] as IList:null;if(history!=null)foreach(var obj in history){var entry=obj as Dictionary<string,object>;if(entry==null)continue;text.AppendLine(Str(entry,"role")=="user"?"## 我的要求":"## AI 的建议").AppendLine().AppendLine(Str(entry,"text")).AppendLine();}SetReading(featureConversation,text.Length==0?"还没有本功能的调整对话。\r\n\r\n例如：这周只汇报朋友的重要进展和群里的安排变化，别放闲聊。\r\n也可以问：这次为什么选择这些内容？":text.ToString());}
    async Task LoadFeatureDialogue(){long epoch=++dialogueEpoch;featureQuestion.Clear();featureSend.Enabled=!dialogueBusy;try{var value=FeatureRequest("read");var data=await Task.Run(()=>LocalCall("feature_dialogue.py",value));if(IsDisposed||epoch!=dialogueEpoch)return;ShowFeatureConversation(data);featureRequirements.Text=Str(data,"preference");}catch(Exception error){status.Text="读取调整记录失败："+error.Message;}}
    async Task<bool> FeatureLocalAction(string action){if(dialogueBusy){status.Text="先等待本次 AI 回答完成。";return false;}long epoch=dialogueEpoch;try{var value=FeatureRequest(action);value["text"]=featureRequirements.Text;var data=await Task.Run(()=>LocalCall("feature_dialogue.py",value));if(IsDisposed||epoch!=dialogueEpoch)return false;ShowFeatureConversation(data);featureRequirements.Text=Str(data,"preference");status.Text=action=="save"?"长期要求已保存。下一次生成使用此要求，事实和发送规则仍由本机核对。":"此功能对话已清空，长期要求保留。";return true;}catch(Exception error){status.Text=error.Message;return false;}}
    async Task SendFeatureQuestion(){if(dialogueBusy||String.IsNullOrWhiteSpace(featureQuestion.Text))return;long epoch=dialogueEpoch,generation=stopGeneration;var value=FeatureRequest("chat");value["question"]=featureQuestion.Text;if(FeatureId()=="adviser"){value["ownerDraft"]=advisorDraft.Text;value["currentSuggestions"]=advisorResults.Text;}var config=Config();config["apiKey"]=key.Text.Trim();value["config"]=config;dialogueBusy=true;featureSend.Enabled=false;status.Text="AI 正在查看所选功能的资料…";
        try{var data=await Task.Run(()=>LocalCall("feature_dialogue.py",value,generation));if(IsDisposed||generation!=stopGeneration||epoch!=dialogueEpoch)return;ShowFeatureConversation(data);string proposed=Str(data,"suggestedPreference");if(!String.IsNullOrWhiteSpace(proposed))featureRequirements.Text=proposed;featureQuestion.Clear();status.Text="回答已在本页显示。可以继续补充，或保存下方长期要求。";}catch(Exception error){if(!IsDisposed&&generation==stopGeneration&&epoch==dialogueEpoch)status.Text="本次未完成："+error.Message;}finally{dialogueBusy=false;if(!IsDisposed)featureSend.Enabled=true;}
    }
}
}
