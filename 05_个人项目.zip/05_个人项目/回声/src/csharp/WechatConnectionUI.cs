using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace EchoWechatDesktop {
public partial class MainForm {
    Label wechatConnectionResult;
    CheckBox nativeBackgroundConsent;
    bool checkingWechatConnection,localConnectionBusy;
    long localConnectionGeneration=-1;
    string localConnectionPhase="未连接",localConnectionMessage="";
    static string ConnectionPhase(bool running,bool checking,bool live,bool failed,double age,string probe){
        if(checking)return "连接中";
        if(running)return failed?"连接失败":live?"连接成功":age<60?"连接中":"连接失败";
        return probe=="连接失败"?"连接失败":probe=="连接成功"?"连接成功":"未连接";
    }
    void BuildWechatConnectionUI(){
        var page=new EchoPage("微信连接"){AutoScroll=true,Padding=new Padding(16)};
        settingsViews.TabPages.Add(page);
        var section=SectionTable(page,"Windows 后台连接","直接连接电脑上的微信。回声是独立 App，不安装 Linux、虚拟机或付费代管服务。");
        AddSectionControl(section,Note("保留当前微信版本，在后台读取与发送。不会移动系统鼠标、键盘或剪贴板；你正在使用微信或输入框已有草稿时，本次回复会暂缓。当前已验证微信 4.1.15.13。",90));
        nativeBackgroundConsent=new CheckBox{Text="允许 Windows 后台处理（临时启用微信无障碍控件，并保护窗口不抢焦点）",AutoSize=true,Padding=new Padding(0,10,0,10)};
        AddSectionControl(section,nativeBackgroundConsent);
        var actions=new FlowLayoutPanel{Dock=DockStyle.Top,Height=48,WrapContents=true};
        var check=MakeButton("检查后台连接",0,0,160,34,true);check.Click+=async delegate{await CheckWechatConnection();};actions.Controls.Add(check);
        AddSectionControl(section,actions);
        wechatConnectionResult=Note("微信连接：未连接。点击开始运行连接并监听微信。",120);AddSectionControl(section,wechatConnectionResult);
        AddSectionControl(section,Note("不兼容时会显示当前版本和原因。更换微信版本、关闭微信或重新登录前，会先征求你同意。旧网页版扫码入口已移除。",70));
    }
    string WechatProvider(){return "native_windows";}
    void SaveWechatConnectionSecrets(){}
    void AddWechatConnectionConfig(Dictionary<string,object> config){config["wechatConnection"]=new Dictionary<string,object>{{"provider","native_windows"},{"allowHostDesktop",false},{"allowNativeAccessibility",nativeBackgroundConsent!=null&&nativeBackgroundConsent.Checked},{"allowNativeWindowEvents",nativeBackgroundConsent!=null&&nativeBackgroundConsent.Checked}};}
    void LoadWechatConnectionConfig(Dictionary<string,object> config){object raw;if(nativeBackgroundConsent!=null&&config.TryGetValue("wechatConnection",out raw)){var value=raw as Dictionary<string,object>;if(value!=null)nativeBackgroundConsent.Checked=Bool(value,"allowNativeAccessibility",false)&&Bool(value,"allowNativeWindowEvents",false);}}
    void SetLocalConnectionState(string phase,string message){localConnectionPhase=phase;localConnectionMessage=message;if(wechatConnectionResult!=null)wechatConnectionResult.Text="微信连接："+phase+"\r\n"+message;if(!runActive&&status!=null)status.Text="微信连接："+phase+" · "+message;RefreshHomeDashboard();}
    async Task CheckWechatConnection(){
        if(checkingWechatConnection)return;checkingWechatConnection=true;long generation=stopGeneration;
        try{SetLocalConnectionState("连接中","正在检查 Windows 微信后台连接…");var config=Config();var response=await Task.Run(()=>LocalCall("native_windows_check.py",config,generation));if(IsDisposed||generation!=stopGeneration)return;checkingWechatConnection=false;SetLocalConnectionState(Bool(response,"ready",false)?"连接成功":"连接失败",Str(response,"message")+(Bool(response,"ready",false)&&!runActive?" 尚未开启消息监听，点击开始运行。":""));}
        catch(Exception error){if(!IsDisposed&&generation==stopGeneration){checkingWechatConnection=false;SetLocalConnectionState("连接失败","检查未完成："+error.Message);}}
        finally{checkingWechatConnection=false;if(!IsDisposed)RefreshHomeDashboard();}
    }
    async void StartNativeWindowsBridge(){
        if(localConnectionBusy&&localConnectionGeneration==stopGeneration){status.Text="正在检查后台连接，请稍候。";return;}
        long generation=stopGeneration;localConnectionGeneration=generation;localConnectionBusy=true;SetLocalConnectionState("连接中","正在检查 Windows 微信后台接口…");
        try{var config=Config();var result=await Task.Run(()=>LocalCall("native_windows_check.py",config,generation));if(IsDisposed||generation!=stopGeneration)return;if(Bool(result,"ready",false)){lastRunFailure="";SetLocalConnectionState("连接中","后台接口可用，正在启动消息监听…");StartBridgeChecked(true);return;}lastRunFailure=Str(result,"message");if(lastRunFailure.Length==0)lastRunFailure="后台连接未完成，未启动代管。";localConnectionBusy=false;SetLocalConnectionState("连接失败",lastRunFailure);WriteStartAttempt("未启动",lastRunFailure);}
        catch(Exception error){if(!IsDisposed&&generation==stopGeneration){localConnectionBusy=false;lastRunFailure="本机环境检查失败："+error.Message;SetLocalConnectionState("连接失败",lastRunFailure);WriteStartAttempt("未启动",lastRunFailure);}}
        finally{if(localConnectionGeneration==generation)localConnectionBusy=false;if(!IsDisposed)RefreshHomeDashboard();}
    }
}
}
