﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace EchoWechatDesktop {
static class EchoVisual {
    internal static readonly Color Ink=Color.FromArgb(30,40,58),Soft=Color.FromArgb(246,248,251),Line=Color.FromArgb(224,229,237),Blue=Color.FromArgb(74,83,220);
    internal static GraphicsPath Rounded(RectangleF r,float radius){var path=new GraphicsPath();float d=radius*2;path.AddArc(r.X,r.Y,d,d,180,90);path.AddArc(r.Right-d,r.Y,d,d,270,90);path.AddArc(r.Right-d,r.Bottom-d,d,d,0,90);path.AddArc(r.X,r.Bottom-d,d,d,90,90);path.CloseFigure();return path;}
}
sealed class EchoButton:Button {
    internal bool primary;bool hover,pressed;
    internal EchoButton(bool isPrimary){primary=isPrimary;SetStyle(ControlStyles.UserPaint|ControlStyles.AllPaintingInWmPaint|ControlStyles.OptimizedDoubleBuffer,true);Cursor=Cursors.Hand;UseVisualStyleBackColor=false;}
    protected override void OnMouseEnter(EventArgs e){hover=true;Invalidate();base.OnMouseEnter(e);}
    protected override void OnMouseLeave(EventArgs e){hover=false;pressed=false;Invalidate();base.OnMouseLeave(e);}
    protected override void OnMouseDown(MouseEventArgs e){pressed=true;Invalidate();base.OnMouseDown(e);}
    protected override void OnMouseUp(MouseEventArgs e){pressed=false;Invalidate();base.OnMouseUp(e);}
    protected override void OnPaint(PaintEventArgs e){
        float scale=e.Graphics.DpiX/96F;e.Graphics.Clear(Parent==null?Color.White:Parent.BackColor);e.Graphics.SmoothingMode=SmoothingMode.AntiAlias;
        Color fill=!Enabled?Color.FromArgb(241,243,247):primary?(pressed?Color.FromArgb(29,78,216):hover?Color.FromArgb(30,88,226):EchoVisual.Blue):(pressed?Color.FromArgb(227,234,245):hover?Color.FromArgb(245,248,253):Color.White);
        using(var path=EchoVisual.Rounded(new RectangleF(.7F,.7F,Width-1.4F,Height-1.4F),7*scale))using(var brush=new SolidBrush(fill))using(var pen=new Pen(primary?fill:EchoVisual.Line,scale)){e.Graphics.FillPath(brush,path);e.Graphics.DrawPath(pen,path);}
        var text=new Rectangle((int)(7*scale),1,Width-(int)(14*scale),Height-2);
        TextRenderer.DrawText(e.Graphics,Text,Font,text,!Enabled?Color.FromArgb(140,150,166):primary?Color.White:EchoVisual.Ink,TextFormatFlags.HorizontalCenter|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|TextFormatFlags.SingleLine|TextFormatFlags.NoPadding);
        if(Focused&&ShowFocusCues)ControlPaint.DrawFocusRectangle(e.Graphics,Rectangle.Inflate(ClientRectangle,-(int)(5*scale),-(int)(5*scale)),primary?Color.White:EchoVisual.Blue,fill);
        if(Focused&&ShowFocusCues)ControlPaint.DrawFocusRectangle(e.Graphics,new Rectangle(4,4,Width-8,Height-8));
    }
}
sealed class EchoPages:TabControl {
    internal EchoPages(){Appearance=TabAppearance.FlatButtons;ItemSize=new Size(1,1);SizeMode=TabSizeMode.Fixed;DrawMode=TabDrawMode.OwnerDrawFixed;TabStop=false;}
    protected override void OnDrawItem(DrawItemEventArgs e){}
    protected override void WndProc(ref Message m){if(m.Msg==0x1328){m.Result=(IntPtr)1;return;}base.WndProc(ref m);}
}
sealed class EchoPage:TabPage {
    internal EchoPage(string title):base(title){SetStyle(ControlStyles.OptimizedDoubleBuffer,true);}
    // Keep the user's viewport while focus changes. Explicit scroll actions still work.
    protected override Point ScrollToControl(Control activeControl){return AutoScrollPosition;}
}
sealed class EchoReadingBox:RichTextBox {
    [StructLayout(LayoutKind.Sequential)]struct Rect {public int left,top,right,bottom;}
    [DllImport("user32.dll")]static extern IntPtr SendMessage(IntPtr h,int m,IntPtr p,ref Rect r);
    protected override void OnResize(EventArgs e){base.OnResize(e);Inset();}
    protected override void OnHandleCreated(EventArgs e){base.OnHandleCreated(e);Inset();}
    void Inset(){if(!IsHandleCreated)return;int gap;using(var g=CreateGraphics())gap=(int)(18*g.DpiX/96F);var rect=new Rect{left=gap,top=gap,right=Math.Max(gap+40,ClientSize.Width-gap),bottom=Math.Max(gap+40,ClientSize.Height-gap)};SendMessage(Handle,0xB3,IntPtr.Zero,ref rect);}
    protected override void WndProc(ref Message m){if(m.Msg==0x20A&&ScrollBars==RichTextBoxScrollBars.None){Control parent=Parent;while(parent!=null){var scroll=parent as ScrollableControl;if(scroll!=null&&scroll.AutoScroll&&scroll.VerticalScroll.Visible){int delta=(short)((m.WParam.ToInt64()>>16)&65535);int offset=-scroll.AutoScrollPosition.Y-delta/120*Font.Height*3;scroll.AutoScrollPosition=new Point(-scroll.AutoScrollPosition.X,Math.Max(0,Math.Min(scroll.VerticalScroll.Maximum,offset)));return;}parent=parent.Parent;}}base.WndProc(ref m);}
}
public partial class MainForm {
    ListBox mainNavigation;
    Panel navigationPanel;
    bool syncingNavigation;
    bool visualScaleApplied;
    bool fittingPages;
    Dictionary<Control,Rectangle> pageBounds=new Dictionary<Control,Rectangle>();
    List<IntPtr> nativeFonts=new List<IntPtr>();
    HashSet<ListView> styledLists=new HashSet<ListView>();
    Dictionary<ColumnHeader,int> columnWidths=new Dictionary<ColumnHeader,int>();
    [StructLayout(LayoutKind.Sequential,CharSet=CharSet.Unicode)]struct LogFont {public int height,width,escapement,orientation,weight;public byte italic,underline,strikeOut,charSet,outPrecision,clipPrecision,quality,pitch;[MarshalAs(UnmanagedType.ByValTStr,SizeConst=32)]public string face;}
    [DllImport("gdi32.dll",CharSet=CharSet.Unicode)]static extern IntPtr CreateFontIndirect(ref LogFont font);
    [DllImport("gdi32.dll")]static extern bool DeleteObject(IntPtr value);
    [DllImport("user32.dll")]static extern IntPtr SendMessage(IntPtr h,int m,IntPtr p,IntPtr q);
    Font readingFont=new Font("Microsoft YaHei UI",12F,FontStyle.Regular),readingHeading=new Font("Microsoft YaHei UI",15F,FontStyle.Bold);
    Dictionary<RichTextBox,Dictionary<string,int>> readingHeadings=new Dictionary<RichTextBox,Dictionary<string,int>>();
    [DllImport("user32.dll")]static extern uint GetDpiForWindow(IntPtr window);
    int UiPixel(int logical){return (int)Math.Round(logical*(visualScaleApplied&&IsHandleCreated?GetDpiForWindow(Handle)/96.0:1.0));}
    void ApplyInitialDpiScale(){
        float dpi=GetDpiForWindow(Handle);float factor=dpi/96F;visualScaleApplied=true;
        if(Math.Abs(factor-1F)>.01F)Scale(new SizeF(factor,factor));
        AutoScaleDimensions=new SizeF(dpi,dpi);AutoScaleMode=AutoScaleMode.Dpi;
        var available=Screen.FromHandle(Handle).WorkingArea;
        MinimumSize=new Size(Math.Min(UiPixel(1000),available.Width-UiPixel(24)),Math.Min(UiPixel(580),available.Height-UiPixel(24)));
        Size=new Size(Math.Min(Width,available.Width-UiPixel(24)),Math.Min(Height,available.Height-UiPixel(24)));
        StartPosition=FormStartPosition.Manual;Location=new Point(available.Left+(available.Width-Width)/2,available.Top+(available.Height-Height)/2);
        foreach(TabPage page in mainProductTabs.TabPages)foreach(Control child in page.Controls)pageBounds[child]=child.Bounds;
        memoryViews.Font=normal;
        mainProductTabs.SizeChanged+=delegate{FitPageWidths();};
        Shown+=delegate{FitPageWidths();ApplyNativeFonts(this);};FitPageWidths();
        DpiChanged+=delegate(object sender,DpiChangedEventArgs e){float change=e.DeviceDpiNew/(float)e.DeviceDpiOld;var keys=new List<Control>(pageBounds.Keys);foreach(Control child in keys){var r=pageBounds[child];pageBounds[child]=new Rectangle((int)(r.X*change),(int)(r.Y*change),(int)(r.Width*change),(int)(r.Height*change));}BeginInvoke(new Action(delegate{FitPageWidths();ApplyNativeFonts(this);}));};
        Disposed+=delegate{foreach(IntPtr font in nativeFonts)DeleteObject(font);};
    }
    void ApplyNativeFonts(Control parent){foreach(Control child in parent.Controls){
        var input=child as TextBox;if(input!=null&&!input.Multiline){input.AutoSize=false;input.Height=UiPixel(input.Parent is NumericUpDown?28:32);}
        var number=child as NumericUpDown;if(number!=null){number.AutoSize=false;number.Font=new Font(normal.FontFamily,normal.SizeInPoints*GetDpiForWindow(Handle)/96F);number.Height=UiPixel(34);}
        if(child is TextBox||child is ListView||child is TabControl||child is NumericUpDown||child is ComboBox){
            float points=child is NumericUpDown||child.Parent is NumericUpDown?normal.SizeInPoints:child.Font.SizeInPoints;
            var spec=new LogFont{height=-(int)Math.Round(points*GetDpiForWindow(Handle)/72F),weight=child.Font.Bold?700:400,charSet=1,quality=5,face=child.Font.Name};
            IntPtr font=CreateFontIndirect(ref spec);if(font!=IntPtr.Zero){nativeFonts.Add(font);SendMessage(child.Handle,0x30,font,(IntPtr)1);}
        }
        var list=child as ListView;if(list!=null){if(list.SmallImageList!=null)list.SmallImageList.ImageSize=new Size(1,UiPixel(34));foreach(ColumnHeader column in list.Columns){if(!columnWidths.ContainsKey(column))columnWidths[column]=column.Width;column.Width=UiPixel(columnWidths[column]);}StyleList(list);}
        ApplyNativeFonts(child);
    }}
    void StyleList(ListView list){
        if(!styledLists.Add(list))return;
        list.OwnerDraw=true;
        list.DrawColumnHeader+=delegate(object sender,DrawListViewColumnHeaderEventArgs e){using(var brush=new SolidBrush(Color.FromArgb(248,250,253)))e.Graphics.FillRectangle(brush,e.Bounds);TextRenderer.DrawText(e.Graphics,e.Header.Text,normal,new Rectangle(e.Bounds.Left+UiPixel(8),e.Bounds.Top,e.Bounds.Width-UiPixel(12),e.Bounds.Height),navy,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPadding);};
        list.DrawItem+=delegate(object sender,DrawListViewItemEventArgs e){if(list.View!=View.Details)e.DrawDefault=true;};
        list.DrawSubItem+=delegate(object sender,DrawListViewSubItemEventArgs e){var bounds=new Rectangle(e.Bounds.Left,e.Bounds.Top,Math.Min(e.Bounds.Width,e.Header.Width),e.Bounds.Height);using(var brush=new SolidBrush(e.Item.Selected?Color.FromArgb(237,244,255):Color.White))e.Graphics.FillRectangle(brush,bounds);int gap=UiPixel(8);if(e.ColumnIndex==0&&list.CheckBoxes){var state=e.Item.Checked?System.Windows.Forms.VisualStyles.CheckBoxState.CheckedNormal:System.Windows.Forms.VisualStyles.CheckBoxState.UncheckedNormal;Size size=CheckBoxRenderer.GetGlyphSize(e.Graphics,state);CheckBoxRenderer.DrawCheckBox(e.Graphics,new Point(bounds.Left+UiPixel(4),bounds.Top+(bounds.Height-size.Height)/2),state);gap=UiPixel(24);}TextRenderer.DrawText(e.Graphics,e.SubItem.Text,normal,new Rectangle(bounds.Left+gap,bounds.Top,Math.Max(1,bounds.Width-gap-UiPixel(4)),bounds.Height),navy,TextFormatFlags.Left|TextFormatFlags.VerticalCenter|TextFormatFlags.EndEllipsis|TextFormatFlags.SingleLine|TextFormatFlags.NoPadding);};
    }
    void FitPageWidths(){
        if(fittingPages||pageBounds.Count==0)return;fittingPages=true;
        try{foreach(TabPage page in mainProductTabs.TabPages){float ratio=Math.Min(1F,(page.ClientSize.Width-UiPixel(12))/(float)UiPixel(980));
            foreach(Control child in page.Controls){Rectangle original;if(child.Dock!=DockStyle.None||!pageBounds.TryGetValue(child,out original))continue;
                child.Left=(int)Math.Round(original.Left*ratio);
                child.Width=Math.Max(20,(int)Math.Round(original.Width*ratio));
                if(child==memoryViews||child==documentView||child==contactBatchList||child==secretaryBrief||child==secretaryTasks||child==secretarySummary||child==featureConversation||child==featureQuestion||child==featureRequirements||child==feedbackText)child.Width=Math.Max(100,page.ClientSize.Width-child.Left-UiPixel(24));
            }
        }}finally{fittingPages=false;}
    }
    void ApplyVisualTheme(){
        var shell=Controls[0] as TableLayoutPanel;if(shell==null)return;
        shell.RowStyles[0].Height=50;shell.RowStyles[2].Height=48;
        var header=shell.GetControlFromPosition(0,0) as Panel;header.BackColor=Color.White;
        foreach(Control child in header.Controls){var label=child as Label;if(label==null)continue;label.ForeColor=label.Font.Size>=18?navy:muted;if(label.Font.Size>=18){label.Text="回声";label.Font=new Font("Microsoft YaHei UI",16F,FontStyle.Bold);label.Location=new Point(26,3);label.Height=26;}else{label.Text="私人秘书 · 简报 / 待办 / 关系 / 消息";label.Location=new Point(29,28);label.Height=18;label.Font=new Font("Microsoft YaHei UI",9F);}}
        foreach(Control button in header.Controls)if(button is Button){button.Top=8;button.Height=32;}
        header.Paint+=delegate(object sender,PaintEventArgs e){using(var pen=new Pen(EchoVisual.Line))e.Graphics.DrawLine(pen,0,header.Height-1,header.Width,header.Height-1);};
        var foot=shell.GetControlFromPosition(0,2);foot.BackColor=Color.White;status.Font=new Font("Microsoft YaHei UI",10F);status.ForeColor=muted;status.Height=30;status.Top=9;status.AutoEllipsis=true;foot.Resize+=delegate{status.Width=Math.Max(300,foot.ClientSize.Width-40);};
        shell.Controls.Remove(mainProductTabs);
        var work=new TableLayoutPanel();work.Dock=DockStyle.Fill;work.Margin=new Padding(0);work.RowCount=2;work.ColumnCount=2;work.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,168));work.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));work.RowStyles.Add(new RowStyle(SizeType.Absolute,42));work.RowStyles.Add(new RowStyle(SizeType.Percent,100));shell.Controls.Add(work,0,1);
        navigationPanel=new Panel();navigationPanel.Dock=DockStyle.Fill;navigationPanel.Margin=new Padding(0);navigationPanel.BackColor=Color.FromArgb(24,36,53);work.Controls.Add(navigationPanel,0,0);work.SetRowSpan(navigationPanel,2);
        var caption=new Label{Text="我的工作空间",Font=new Font("Microsoft YaHei UI",9.5F),ForeColor=Color.FromArgb(148,166,190),Location=new Point(22,18),Size=new Size(135,25)};navigationPanel.Controls.Add(caption);
        mainNavigation=new ListBox();mainNavigation.Location=new Point(10,53);mainNavigation.Size=new Size(148,490);mainNavigation.Anchor=AnchorStyles.Top|AnchorStyles.Left|AnchorStyles.Right|AnchorStyles.Bottom;mainNavigation.BorderStyle=BorderStyle.None;mainNavigation.DrawMode=DrawMode.OwnerDrawFixed;mainNavigation.ItemHeight=44;mainNavigation.Font=normal;mainNavigation.IntegralHeight=false;mainNavigation.BackColor=Color.FromArgb(24,36,53);
        foreach(string name in workspaceNames)mainNavigation.Items.Add(name);navigationPanel.Controls.Add(mainNavigation);
        navigationPanel.SizeChanged+=delegate{mainNavigation.SetBounds(UiPixel(10),UiPixel(53),Math.Max(120,navigationPanel.ClientSize.Width-UiPixel(20)),Math.Max(100,navigationPanel.ClientSize.Height-UiPixel(65)));};
        mainNavigation.DrawItem+=DrawDesignNavigation;
        mainNavigation.SelectedIndexChanged+=delegate{if(syncingNavigation||mainNavigation.SelectedIndex<0)return;OpenWorkspacePage(workspacePages[mainNavigation.SelectedIndex][0]);};
        mainProductTabs.SelectedIndexChanged+=delegate{syncingNavigation=true;mainNavigation.SelectedIndex=WorkspaceGroup(mainProductTabs.SelectedIndex);syncingNavigation=false;UpdateWorkspaceSubnav();mainNavigation.Invalidate();};mainNavigation.SelectedIndex=WorkspaceGroup(mainProductTabs.SelectedIndex);
        mainProductTabs.BackColor=bg;mainProductTabs.Padding=new Point(0,0);workspaceSubnav=new FlowLayoutPanel{Dock=DockStyle.Fill,Margin=new Padding(0),BackColor=Color.White,WrapContents=false,AutoScroll=true,Padding=new Padding(16,0,0,0)};work.Controls.Add(workspaceSubnav,1,0);work.Controls.Add(mainProductTabs,1,1);UpdateWorkspaceSubnav();
        PolishControls(mainProductTabs);
        reportView.Font=readingFont;reportView.ForeColor=navy;reportView.BackColor=Color.White;reportView.BorderStyle=BorderStyle.None;
        foreach(RichTextBox view in new RichTextBox[]{documentView,relationshipView,digestView,memoryEvidenceView,secretaryBrief,secretaryTasks,featureConversation}){view.Font=readingFont;view.ForeColor=navy;view.BackColor=Color.White;view.BorderStyle=BorderStyle.None;}
        FormClosed+=delegate{readingFont.Dispose();readingHeading.Dispose();};
    }
    void PolishControls(Control parent){foreach(Control control in parent.Controls){
        var label=control as Label;if(label!=null){label.UseCompatibleTextRendering=false;if(label.BorderStyle==BorderStyle.FixedSingle){label.BorderStyle=BorderStyle.None;label.BackColor=Color.FromArgb(239,244,252);}if(label.Text.Length>28)label.Font=normal;label.AutoEllipsis=false;}
        var list=control as ListView;if(list!=null){list.BackColor=Color.White;list.ForeColor=navy;list.BorderStyle=BorderStyle.FixedSingle;list.ShowItemToolTips=true;list.GridLines=false;}
        var text=control as TextBox;if(text!=null){text.Font=normal;text.ForeColor=navy;if(text.ReadOnly)text.BackColor=Color.FromArgb(249,250,253);}
        var numeric=control as NumericUpDown;if(numeric!=null){numeric.Font=normal;numeric.BackColor=Color.White;numeric.ForeColor=navy;numeric.BorderStyle=BorderStyle.FixedSingle;numeric.TextAlign=HorizontalAlignment.Center;}
        var check=control as CheckBox;if(check!=null){check.Font=normal;check.ForeColor=navy;check.UseCompatibleTextRendering=false;}
        var combo=control as ComboBox;if(combo!=null){combo.Font=normal;combo.ForeColor=navy;combo.BackColor=Color.White;}
        var tabs=control as TabControl;if(tabs!=null && !(tabs is EchoPages)){tabs.Font=normal;tabs.Padding=new Point(14,7);}
        if(control is TabPage){control.BackColor=Color.White;}
        PolishControls(control);
    }}
    void RenderReading(RichTextBox box,string value){
        string source=(value??"").Replace("\r\n","\n");bool plain=box==memoryEvidenceView;
        var builder=new StringBuilder();var headings=new Dictionary<string,int>();var ranges=new List<KeyValuePair<int,int>>();
        foreach(string line in source.Split('\n')){var match=plain?Match.Empty:Regex.Match(line,@"^#{1,3} (.+)$");string rendered=match.Success?match.Groups[1].Value:line;if(!plain)rendered=Regex.Replace(rendered,@"^\s*- ","  • ");int offset=builder.Length;if(match.Success){headings[rendered]=offset;ranges.Add(new KeyValuePair<int,int>(offset,rendered.Length));}builder.Append(rendered).Append('\n');}
        string renderedText=builder.ToString().TrimEnd('\n');if(box.Text==renderedText&&readingHeadings.ContainsKey(box))return;
        box.Font=readingFont;box.ForeColor=navy;box.Text=renderedText;readingHeadings[box]=headings;
        box.SelectAll();box.SelectionFont=readingFont;box.SelectionColor=navy;box.SelectionIndent=0;box.SelectionRightIndent=0;
        foreach(var range in ranges){box.Select(range.Key,range.Value);box.SelectionFont=readingHeading;box.SelectionColor=navy;}
        box.Select(0,0);
    }
    void JumpToReadingHeading(string name){Dictionary<string,int> headings;int position;if(readingHeadings.TryGetValue(relationshipView,out headings)&&headings.TryGetValue(name,out position)){relationshipView.Select(position,0);relationshipView.ScrollToCaret();}}
}
}
