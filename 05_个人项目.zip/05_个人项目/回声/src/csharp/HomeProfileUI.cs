﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace EchoWechatDesktop {
public partial class MainForm {
    const string ReleaseLabel="回声 V2 · 2026.10.06.45 · 纯净版";
    const string FeedbackAddress="";
    Label homeGreeting,homeRunValue,homePeopleValue,homePendingValue,homeFeaturesValue,profileName,profileDetails;
    TextBox profileDisplayName,feedbackText;
    ComboBox feedbackKind;
    readonly List<string> homeReportNames=new List<string>();
    string localDisplayName="";
    PictureBox homeLogo;
    Panel homeContainer;
    readonly System.Windows.Forms.Timer homeRefreshTimer=new System.Windows.Forms.Timer();

    Panel HomeCard(string title){var panel=new Panel{Dock=DockStyle.Fill,BackColor=Color.FromArgb(248,250,253),Margin=new Padding(0,0,14,0),Padding=new Padding(18)};var heading=new Label{Text=title,Dock=DockStyle.Top,Height=32,Font=bold,ForeColor=navy};panel.Controls.Add(heading);return panel;}
    Label HomeMetric(TableLayoutPanel grid,int column,string caption){var card=HomeCard(caption);var value=new Label{Text="—",Dock=DockStyle.Bottom,Height=42,Font=new Font(normal.FontFamily,20F,FontStyle.Bold),ForeColor=navy};card.Controls.Add(value);grid.Controls.Add(card,column,0);return value;}
    TableLayoutPanel HomeRow(int columns,int height){var row=new TableLayoutPanel{Dock=DockStyle.Top,Height=height,ColumnCount=columns,RowCount=1,Margin=new Padding(0),Padding=new Padding(0)};for(int i=0;i<columns;i++)row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100F/columns));row.RowStyles.Add(new RowStyle(SizeType.Percent,100));return row;}
    void HomeLink(TableLayoutPanel row,int column,string title,Action action,bool primary=false){var button=MakeButton(title,0,0,180,40,primary);button.Dock=DockStyle.Fill;button.Margin=new Padding(0,4,14,4);button.Click+=delegate{action();};row.Controls.Add(button,column,0);}
    void BuildHomeProfile(){
        mainProductTabs.TabPages[11].Text="首页";var home=mainProductTabs.TabPages[11];foreach(Control old in home.Controls.Cast<Control>().ToArray())old.Dispose();home.Controls.Clear();
        homeContainer=new Panel{Dock=DockStyle.Top,Height=760,Padding=new Padding(24,20,10,24),BackColor=Color.White};home.Controls.Add(homeContainer);
        var stack=new TableLayoutPanel{Dock=DockStyle.Fill,ColumnCount=1,RowCount=9,Margin=new Padding(0),Padding=new Padding(0)};stack.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));foreach(int height in new[]{106,16,110,18,52,24,295,18,70})stack.RowStyles.Add(new RowStyle(SizeType.Absolute,height));homeContainer.Controls.Add(stack);
        var welcome=new Panel{Dock=DockStyle.Fill,BackColor=Color.FromArgb(238,243,255),Padding=new Padding(20),Margin=new Padding(0,0,14,0)};
        homeGreeting=new Label{Text="你好，欢迎回到回声",Location=new Point(22,18),Size=new Size(650,36),Font=new Font(normal.FontFamily,20F,FontStyle.Bold),ForeColor=navy};welcome.Controls.Add(homeGreeting);
        secretarySummary=MakeLabel("一眼看清消息状态，再决定今天交给回声做什么。",22,63,850,28);welcome.Controls.Add(secretarySummary);stack.Controls.Add(welcome,0,0);
        var metrics=HomeRow(4,110);homeRunValue=HomeMetric(metrics,0,"运行状态");homePeopleValue=HomeMetric(metrics,1,"好友 / 群");homePendingValue=HomeMetric(metrics,2,"待处理事项");homeFeaturesValue=HomeMetric(metrics,3,"已开启功能");stack.Controls.Add(metrics,0,2);
        var shortcuts=HomeRow(4,52);HomeLink(shortcuts,0,"管理好友与群",()=>OpenContactManagement(),true);HomeLink(shortcuts,1,"查看日报周报",()=>{OpenWorkspacePage(3);LoadReportList();});HomeLink(shortcuts,2,"写消息 / 改表达",()=>OpenWorkspacePage(10));HomeLink(shortcuts,3,"功能与接口设置",()=>OpenWorkspacePage(0));stack.Controls.Add(shortcuts,0,4);
        var overview=HomeRow(2,295);
        var todo=HomeCard("需要你处理");secretaryTasks=new EchoReadingBox{Dock=DockStyle.Fill,ReadOnly=true,DetectUrls=false,ScrollBars=RichTextBoxScrollBars.None,BorderStyle=BorderStyle.None,BackColor=Color.FromArgb(248,250,253)};
        var todoOpen=MakeButton("打开待办提醒 →",0,0,200,36);todoOpen.Dock=DockStyle.Bottom;todoOpen.Click+=delegate{OpenWorkspacePage(4);LoadReminders();};todo.Controls.Add(todoOpen);todo.Controls.Add(secretaryTasks);secretaryTasks.BringToFront();overview.Controls.Add(todo,0,0);
        var brief=HomeCard("最近的简报");secretaryBrief=new EchoReadingBox{Dock=DockStyle.Fill,ReadOnly=true,DetectUrls=false,ScrollBars=RichTextBoxScrollBars.None,BorderStyle=BorderStyle.None,BackColor=Color.FromArgb(248,250,253)};
        var reportOpen=MakeButton("查看最近简报 →",0,0,200,36);reportOpen.Dock=DockStyle.Bottom;reportOpen.Click+=delegate{if(homeReportNames.Count>0){reportKind.SelectedIndex=homeReportNames[0].Contains("周报")?1:0;OpenWorkspacePage(3);LoadReportList();reportList.SelectedItem=homeReportNames[0];}else OpenWorkspacePage(3);};brief.Controls.Add(reportOpen);brief.Controls.Add(secretaryBrief);secretaryBrief.BringToFront();overview.Controls.Add(brief,1,0);stack.Controls.Add(overview,0,6);
        var bottom=HomeRow(3,52);HomeLink(bottom,0,"人物与关系",()=>{OpenWorkspacePage(6);PopulateMemoryContacts();});HomeLink(bottom,1,"和 AI 调整要求",()=>OpenFeatureDialogue("daily"));HomeLink(bottom,2,"个人中心 / 意见反馈",()=>OpenWorkspacePage(13));stack.Controls.Add(bottom,0,8);
        home.Enter+=delegate{RefreshHomeDashboard();};
        var profile=MakeTab("个人中心");mainProductTabs.TabPages.Add(profile);
        profile.Controls.Add(MakeLabel("个人中心",25,22,900,36,true));
        profileName=MakeLabel("我的回声",25,80,900,36,true);profile.Controls.Add(profileName);
        profileDetails=MakeLabel(ReleaseLabel+"\r\n本机私人助手 · 使用你在设置中选择的模型服务",25,130,930,65);profile.Controls.Add(profileDetails);
        profile.Controls.Add(MakeLabel("在回声中显示的称呼",25,225,900,28));profileDisplayName=MakeText(25,266,610);profileDisplayName.MaxLength=30;profile.Controls.Add(profileDisplayName);
        var saveName=MakeButton("保存称呼",655,263,240,38,true);saveName.Click+=delegate{SaveLocalProfile();};profile.Controls.Add(saveName);
        profile.Controls.Add(MakeLabel("称呼只用于回声首页，不改变你的微信名称。",25,315,930,30));
        profile.Controls.Add(MakeLabel("我的配置",25,385,930,34,true));
        var settings=MakeButton("功能与接口设置",25,435,260,42,true);settings.Click+=delegate{OpenWorkspacePage(0);};profile.Controls.Add(settings);
        var export=MakeButton("导出规则（不含密钥）",305,435,310,42);export.Click+=delegate{ExportRules();};profile.Controls.Add(export);
        var help=MakeButton("阅读使用说明",635,435,260,42);help.Click+=delegate{documentKind.SelectedIndex=7;ShowInternalFile("回声使用说明",Path.Combine(AppPaths.Docs,"秘书版说明.md"));};profile.Controls.Add(help);
        profile.Controls.Add(MakeLabel("反馈与建议",25,535,930,34,true));
        profile.Controls.Add(MakeLabel("收件邮箱："+FeedbackAddress,25,590,930,30));
        feedbackKind=MakeCombo(25,640,400,new[]{"功能建议","界面体验","运行问题","其他意见"});profile.Controls.Add(feedbackKind);
        feedbackText=MakeText(25,700,930,220,true);feedbackText.MaxLength=2000;profile.Controls.Add(feedbackText);
        var mail=MakeButton("打开反馈邮件草稿",25,944,280,42,true);mail.Click+=delegate{OpenFeedbackMail();};profile.Controls.Add(mail);
        var copyEmail=MakeButton("复制邮箱",325,944,220,42);copyEmail.Click+=delegate{if(FeedbackAddress.Length>0)Clipboard.SetText(FeedbackAddress);status.Text="请联系提供本软件的人反馈。";};profile.Controls.Add(copyEmail);
        var copyFeedback=MakeButton("复制反馈内容",565,944,260,42);copyFeedback.Click+=delegate{Clipboard.SetText(FeedbackBody(feedbackKind.Text,feedbackText.Text));status.Text="反馈内容已复制，可以粘贴到邮件中发送。";};profile.Controls.Add(copyFeedback);
        profile.Controls.Add(MakeLabel("草稿会在你的邮件应用打开，检查后由你发送。打不开邮件应用时，可复制邮箱和内容自行发送。",25,1014,930,62));
        profile.Enter+=delegate{LoadLocalProfile();};LoadLocalProfile();
        string iconPath=Path.Combine(AppPaths.Code,"资源","回声.ico");if(File.Exists(iconPath))Icon=new Icon(iconPath);
        Shown+=delegate{RefreshHomeDashboard();};homeRefreshTimer.Interval=15000;homeRefreshTimer.Tick+=delegate{if(mainProductTabs.SelectedIndex==11)RefreshHomeDashboard();};homeRefreshTimer.Start();Disposed+=delegate{homeRefreshTimer.Dispose();};
    }
    void LoadLocalProfile(){try{string file=Path.Combine(settingsDir,"personal-profile.json");var data=File.Exists(file)?json.Deserialize<Dictionary<string,object>>(File.ReadAllText(file,Encoding.UTF8)):new Dictionary<string,object>();localDisplayName=Str(data,"displayName");}catch{localDisplayName="";}profileName.Text=String.IsNullOrWhiteSpace(localDisplayName)?"我的回声":localDisplayName;profileDisplayName.Text=localDisplayName;}
    void SaveLocalProfile(){string name=profileDisplayName.Text.Trim();Directory.CreateDirectory(settingsDir);string file=Path.Combine(settingsDir,"personal-profile.json"),temporary=file+".new";try{File.WriteAllText(temporary,json.Serialize(new Dictionary<string,object>{{"displayName",name}}),Encoding.UTF8);if(File.Exists(file))File.Replace(temporary,file,null);else File.Move(temporary,file);localDisplayName=name;profileName.Text=name.Length==0?"我的回声":name;RefreshHomeDashboard();status.Text="个人称呼已保存。";}catch(Exception error){status.Text="称呼未保存："+error.GetType().Name;}}
    static string FeedbackBody(string kind,string text){return "回声反馈\r\n类型："+kind+"\r\n版本："+ReleaseLabel+"\r\n\r\n"+text.Trim();}
    static string CreateFeedbackUri(string kind,string text){return "mailto:"+FeedbackAddress+"?subject="+Uri.EscapeDataString("回声 V2 反馈 · "+kind)+"&body="+Uri.EscapeDataString(FeedbackBody(kind,text));}
    void OpenFeedbackMail(){if(FeedbackAddress.Length==0){status.Text="未设置反馈邮箱，请联系提供本软件的人。";return;}if(String.IsNullOrWhiteSpace(feedbackText.Text)){status.Text="先写下你的意见，再打开反馈邮件草稿。";feedbackText.Focus();return;}string uri=CreateFeedbackUri(feedbackKind.Text,feedbackText.Text);if(uri.Length>7800){status.Text="反馈内容较长，请复制邮箱和完整内容到邮件应用发送。";return;}try{Process.Start(new ProcessStartInfo(uri){UseShellExecute=true});status.Text="已请求打开邮件草稿，请在邮件应用中检查并发送。";}catch{status.Text="未能打开邮件应用，意见已保留；可以复制邮箱和反馈内容自行发送。";}}
    IList HomePending(){string items=Path.Combine(settingsDir,"important-items.json"),actions=Path.Combine(settingsDir,"important-actions.json");if(!File.Exists(items))return new List<object>();var data=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(items,Encoding.UTF8));if(Int(data,"version",0)!=10)return new List<object>();var states=File.Exists(actions)?json.Deserialize<Dictionary<string,object>>(File.ReadAllText(actions,Encoding.UTF8)):new Dictionary<string,object>();var result=new List<object>();foreach(var obj in data.ContainsKey("items")?data["items"] as IList??new object[0]:new object[0]){var item=obj as Dictionary<string,object>;if(item==null||reminderExcluded.Contains(Str(item,"sourceId"))||Str(item,"lifecycleStatus")=="cancelled"||Str(item,"lifecycleStatus")=="done")continue;string id=Str(item,"id");var state=states.ContainsKey(id)?states[id] as Dictionary<string,object>:null;string statusValue=state==null?"pending":Str(state,"status");if(statusValue=="done"||statusValue=="ignored")continue;if(statusValue=="snoozed"){DateTime until;if(!DateTime.TryParse(Str(state,"until"),out until)||until>DateTime.Now)continue;}result.Add(item);}return result;}
    void RefreshHomeDashboard(){if(homeRunValue==null)return;homeGreeting.Text=String.IsNullOrWhiteSpace(localDisplayName)?"你好，欢迎回到回声":"你好，"+localDisplayName;bool problems=RefreshHealthSummary();homeRunValue.Text=runActive?(localConnectionPhase=="连接中"?"连接中":localConnectionPhase=="连接失败"?"连接失败":problems?"需要处理":"运行中"):(checkingWechatConnection||localConnectionBusy?"连接中":localConnectionPhase=="连接失败"?"连接失败":"未运行");homeRunValue.ForeColor=problems?Color.FromArgb(176,50,62):muted;homePeopleValue.Text=friendList.Items.Count+" / "+groupList.Items.Count;
        int count=new[]{privateEnabled.Checked,groupEnabled.Checked,recordChats.Checked,dailyReport.Checked,weeklyReport.Checked,importantReminders.Checked,autoRefreshMemory.Checked,messageAdviceEnabled.Checked,contactAIEnabled.Checked}.Count(x=>x);homeFeaturesValue.Text=count+" 项";
        secretarySummary.Text=DateTime.Now.ToString("yyyy 年 M 月 d 日 · dddd")+"   ·   "+(runActive?"任务已启动，读取与生成情况见下方状态":localConnectionMessage.Length>0?localConnectionMessage:"点击“保存设置”或底部“开始运行”，立即启用当前功能");
        if(footerRun!=null){footerRun.Text=runActive?"按设置重启":"开始运行";footerRun.BackColor=runActive?Color.FromArgb(22,128,80):teal;}
        try{var pending=HomePending();homePendingValue.Text=pending.Count+" 条";var body=new StringBuilder();foreach(var obj in pending.Cast<object>().Take(3)){var task=(Dictionary<string,object>)obj;body.AppendLine(Str(task,"asker")+" · "+Str(task,"source"));string text=Str(task,"task");if(text.Length==0)text=Str(task,"text");body.AppendLine(text.Length>80?text.Substring(0,80)+"…":text);string due=ReminderDue(task);body.AppendLine("期限："+(due.Length==0?"原话未给出":due)).AppendLine();}SetReading(secretaryTasks,pending.Count==0?"当前没有需要处理的事项。":body.ToString());}catch{homePendingValue.Text="需检查";SetReading(secretaryTasks,"提醒暂时无法读取，请进入待办提醒查看。");}
        homeReportNames.Clear();string root=Path.Combine(AppPaths.Storage,"报告");try{if(Directory.Exists(root)){var hidden=HiddenReports();homeReportNames.AddRange(Directory.GetFiles(root,"信息*.md").Where(x=>!hidden.Contains(Path.GetFileName(x))).Select(Path.GetFileName).GroupBy(x=>x.Replace("-当前","")).Select(x=>x.OrderBy(n=>n.Contains("-当前")?1:0).First()).OrderByDescending(x=>x.Replace("信息日报-","").Replace("信息周报-","")).Take(3));}var body=new StringBuilder();var index=LocalHealth("information-report-index.json");foreach(string name in homeReportNames){string content=File.ReadAllText(Path.Combine(root,name),Encoding.UTF8);var lines=content.Replace("\r\n","\n").Split('\n');string title=lines.FirstOrDefault(x=>x.StartsWith("# "))??name;body.AppendLine(title.TrimStart('#',' '));var spec=index.ContainsKey(name)?index[name] as Dictionary<string,object>:null;if(spec==null||Str(spec,"reportStyle")!="secretary-v2"){body.AppendLine("旧版内容 · 需要重新生成后核验进展").AppendLine();continue;}var points=lines.Where(x=>x.StartsWith("### ")).Take(2).ToArray();if(points.Length>0)foreach(string point in points)body.AppendLine("· "+point.TrimStart('#',' '));else body.AppendLine(content.Contains("无重点")?"本期暂无重点":"已生成，点击下方查看内容");body.AppendLine();}SetReading(secretaryBrief,homeReportNames.Count==0?"还没有简报。\n在设置中开启日报或周报，运行后会定时整理。":body.ToString());}catch{SetReading(secretaryBrief,"简报暂时无法读取，请到日报与周报查看。");}
        RefreshHomeTiles(); RefreshIncomingActivity();
    }
    void AddProfileHeader(){var shell=Controls[0] as TableLayoutPanel;var header=shell.GetControlFromPosition(0,0);string logo=Path.Combine(AppPaths.Code,"资源","回声标志.png");if(File.Exists(logo)){homeLogo=new PictureBox{Image=Image.FromFile(logo),SizeMode=PictureBoxSizeMode.Zoom,Location=new Point(25,8),Size=new Size(30,30)};header.Controls.Add(homeLogo);foreach(Control child in header.Controls){var label=child as Label;if(label!=null)label.Left=72;}Disposed+=delegate{homeLogo.Image.Dispose();};}var personal=MakeButton("个人中心",0,8,140,32);personal.Click+=delegate{OpenWorkspacePage(13);};header.Controls.Add(personal);header.Resize+=delegate{personal.SetBounds(header.ClientSize.Width-UiPixel(166),UiPixel(8),UiPixel(140),UiPixel(32));foreach(Control child in header.Controls)if(child is Button&&child.Text=="保存设置")child.Left=header.ClientSize.Width-UiPixel(320);};}
}
}
