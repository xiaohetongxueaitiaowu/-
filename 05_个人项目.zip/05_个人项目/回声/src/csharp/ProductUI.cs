using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EchoWechatDesktop {
public partial class MainForm {
    TextBox apiBase, memoryEdit, memorySource;
    ComboBox memoryContact, memoryKind, reminderFilter;
    ListView draftList, memoryList;
    TextBox draftEdit, diagnosis;
    CheckBox recordChats, useMemory, importantReminders, analysisCache, budgetEnabled, showCosts, mediaEnabled;
    NumericUpDown contextChars, replyMaxTokens, mergeSeconds, reminderRefreshMinutes, memorySampleChars, dailyRequestLimit, dailyCostLimit, inputPrice, outputPrice, cacheInputPrice;
    bool productBusy;
    System.Windows.Forms.Timer productTimer;
    string selectedMemoryId;
    static string ModeText(string mode) { return mode == "draft" ? "草稿确认" : mode == "record" ? "只记录" : "自动回复"; }
    static string ModeValue(string text) { return text == "草稿确认" ? "draft" : text == "只记录" ? "record" : "auto"; }
    static string LocalEpoch(string value){double seconds;if(!Double.TryParse(value,out seconds))return value;return new DateTime(1970,1,1,0,0,0,DateTimeKind.Utc).AddSeconds(seconds).ToLocalTime().ToString("MM-dd HH:mm:ss");}
    NumericUpDown ProductNumber(TabPage p, string label, int y, decimal min, decimal max, decimal value, int decimals=0) {
        p.Controls.Add(MakeLabel(label,25,y+3,520,25));
        NumericUpDown n=new NumericUpDown(); n.Minimum=min; n.Maximum=max; n.DecimalPlaces=decimals; n.Value=value; n.Location=new Point(550,y); n.Width=150; p.Controls.Add(n);return n;
    }
    void BuildProductTabs(TabControl tabs) {
        TabPage drafts=MakeTab("运行状态"), memories=MakeTab("人物记忆"), features=MakeTab("功能与节省");
        tabs.TabPages.AddRange(new TabPage[]{drafts,memories,features});
        BuildFeatures(features); BuildDrafts(drafts); BuildEditableMemory(memories); BuildDocumentTab(tabs);BuildContactManagement(tabs);
        tabs.Selected += async delegate {
            if(tabs.SelectedTab==drafts)await RefreshProducts();
            if(tabs.SelectedTab==memories){PopulateMemoryContacts();ShowAnalysis();await RefreshMemory(true);}
        };
        productTimer=new System.Windows.Forms.Timer(); productTimer.Interval=8000;
        productTimer.Tick+=async delegate { ReleaseSnoozed();if(mainProductTabs.SelectedTab.Text=="重要提醒")LoadReminders();if(tabs.SelectedTab==drafts) await RefreshProducts(); }; productTimer.Start();
        FormClosing+=delegate { productTimer.Stop(); productTimer.Dispose(); };
    }
    void BuildFeatures(TabPage p) {
        p.Controls.Add(MakeLabel("按需开启 · 关闭后的功能不会调用模型",25,20,900,28,true));
        recordChats=MakeCheck("保存本机最近两个月聊天",25,60,360); recordChats.Checked=false; p.Controls.Add(recordChats);
        useMemory=MakeCheck("回复参考人物记忆",460,60,350); useMemory.Checked=false; p.Controls.Add(useMemory);
        importantReminders=MakeCheck("提取重要提醒与待办",25,100,360); importantReminders.Checked=false; p.Controls.Add(importantReminders);
        analysisCache=MakeCheck("复用已校验的分析结果",460,100,350); analysisCache.Checked=true; p.Controls.Add(analysisCache);
        dailyReport.Location=new Point(25,140); weeklyReport.Location=new Point(460,140); p.Controls.Add(dailyReport); p.Controls.Add(weeklyReport);
        budgetEnabled=MakeCheck("启用每日请求 / 费用上限",25,180,360); budgetEnabled.Checked=true;p.Controls.Add(budgetEnabled);
        showCosts=MakeCheck("显示费用估算（默认不显示）",460,180,400); p.Controls.Add(showCosts);
        mediaEnabled=MakeCheck("启用手动图片识别 / WAV 语音转写",25,220,420);p.Controls.Add(mediaEnabled);
        Button readImage=MakeButton("选择图片或语音",460,218,190,34);readImage.Click+=async delegate { await ReadImage(); };p.Controls.Add(readImage);
        readImage.Enabled=false;mediaEnabled.CheckedChanged+=delegate{readImage.Enabled=mediaEnabled.Checked;};
        p.Controls.Add(MakeLabel("媒体仅在本机识别并预览，不上传，识别结果需核对。语音限中文、16 位 PCM WAV、60 秒内；暂不自动读取微信媒体。",25,263,930,40));
        contextChars=ProductNumber(p,"回复历史字数上限（不包括当前问题）",320,500,12000,4000);
        replyMaxTokens=ProductNumber(p,"单次回复输出上限",365,128,1500,350);
        mergeSeconds=ProductNumber(p,"连续消息合并等待（秒）",410,1,10,2);
        reminderRefreshMinutes=ProductNumber(p,"重要提醒刷新间隔（分钟；没有新消息不重复提取）",455,2,120,10);
        memorySampleChars=ProductNumber(p,"普通联系人摘录字数上限（覆盖早期与近期）",500,3500,18000,6000);
        dailyRequestLimit=ProductNumber(p,"每日模型请求上限（回复、分析、测试连接共用）",545,1,10000,80);
        dailyCostLimit=ProductNumber(p,"每日费用估算上限 / 元（0 表示只限制次数）",590,0,1000,0,2);
        inputPrice=ProductNumber(p,"输入单价 / 每百万单位（按平台当前价格填写）",635,0,1000,0,3);
        outputPrice=ProductNumber(p,"输出单价 / 每百万单位",680,0,1000,0,3);
        cacheInputPrice=ProductNumber(p,"缓存输入单价 / 每百万单位",725,0,1000,0,3);
        p.Controls.Add(MakeLabel("费用为按你填写的单价估算，并非账单。超时保留预算、不自动重试；达到上限暂停模型请求，本机监听仍继续。",25,770,930,55));
        p.Controls.Add(MakeLabel("人物自动更新另在“对话人设”开关控制；资料上传范围另在“回复规则”控制。关闭记录也会暂停报告与提醒。",25,832,930,55));
    }
    Dictionary<string,object> LocalCall(string module,Dictionary<string,object> value,long requestGeneration=-1) {
        string executable=InvokeRequired?(string)Invoke(new Func<string>(()=>pythonPath.Text.Trim())):pythonPath.Text.Trim();
        if(!File.Exists(executable))throw new Exception("未找到内置运行组件");
        ProcessStartInfo info=new ProcessStartInfo(executable,"-X utf8 \""+Path.Combine(AppDomain.CurrentDomain.BaseDirectory,module)+"\"");
        info.UseShellExecute=false;info.CreateNoWindow=true;info.WorkingDirectory=AppDomain.CurrentDomain.BaseDirectory;
        info.RedirectStandardInput=true;info.RedirectStandardOutput=true;info.RedirectStandardError=true;
        info.StandardOutputEncoding=Encoding.UTF8;info.StandardErrorEncoding=Encoding.UTF8;
        long generation=requestGeneration<0?System.Threading.Interlocked.Read(ref stopGeneration):requestGeneration;if(generation!=System.Threading.Interlocked.Read(ref stopGeneration))throw new OperationCanceledException();var outcome=RunCaptured(info,new System.Web.Script.Serialization.JavaScriptSerializer().Serialize(value)+"\n",130000,module=="model_client.py"||module=="feature_dialogue.py"||module=="contact_workspace.py"||module=="feedback_service.py"||module=="wechat_connection.py"||module=="native_windows_check.py"?(Action<Process>)(worker=>TrackJob(worker,generation)):null);
            string text=outcome.Item2;
            if(outcome.Item1!=0){string failure=outcome.Item1==-1?"操作超时，已停止；没有自动重试。":"操作未完成，具体原因未确认；请查看此功能运行记录。";try{var failed=new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<Dictionary<string,object>>(text);if(failed.ContainsKey("errorInfo"))failure=HealthDiagnosis(failed["errorInfo"] as Dictionary<string,object>);else if(failed.ContainsKey("error"))failure=Str(failed,"error");}catch{}throw new Exception(failure);}
            Dictionary<string,object> result=new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<Dictionary<string,object>>(text);
            if(result.ContainsKey("error"))throw new Exception(Str(result,"error"));return result;
    }

    static string Drain(System.IO.StreamReader reader) {
        // Keep draining both pipes but bound the text retained in memory.
        StringBuilder text=new StringBuilder();char[] buffer=new char[4096];int count;
        try{while((count=reader.Read(buffer,0,buffer.Length))>0){int keep=Math.Min(count,2000000-text.Length);if(keep>0)text.Append(buffer,0,keep);}}catch(System.IO.IOException){}catch(ObjectDisposedException){}
        return text.ToString();
    }
    internal static Tuple<int,string> RunCaptured(ProcessStartInfo info,string input,int timeout,Action<Process> started=null) {
        using(Process worker=Process.Start(info)) {
            if(started!=null)started(worker);
            Task<string> output=Task.Run(()=>Drain(worker.StandardOutput));
            Task<string> error=Task.Run(()=>Drain(worker.StandardError));
            Task writer=Task.Run(()=> {if(input==null)return;try{byte[] bytes=Encoding.UTF8.GetBytes(input);worker.StandardInput.BaseStream.Write(bytes,0,bytes.Length);worker.StandardInput.BaseStream.Flush();worker.StandardInput.Close();}catch(System.IO.IOException){}catch(ObjectDisposedException){} });
            if(!worker.WaitForExit(timeout)) {try{worker.Kill();}catch{} return Tuple.Create(-1,"操作超时，已停止子进程。");}
            if(!Task.WaitAll(new Task[]{output,error,writer},5000))return Tuple.Create(-1,"子进程未正常关闭输出管道，已结束本次操作。");
            return Tuple.Create(worker.ExitCode,worker.ExitCode==0?output.Result:error.Result);
        }
    }
    void BuildDrafts(TabPage p) {
        showDraftTools=MakeCheck("显示草稿工具（可选；你也可以直接在微信回复）",25,15,930);p.Controls.Add(showDraftTools);
        draftTools=new Panel();draftTools.Location=new Point(0,55);draftTools.Size=new Size(980,490);p.Controls.Add(draftTools);
        draftTools.Controls.Add(MakeLabel("仅草稿模式生成待确认回复。你在微信手动回复后，该会话的 AI 暂停，旧草稿作废。",25,10,930,50,true));
        Button refresh=MakeButton("刷新",25,80,100,32);refresh.Click+=async delegate{await RefreshProducts();};p.Controls.Add(refresh);
        Button approve=MakeButton("批量确认发送",140,80,200,32,true);approve.Click+=delegate{ApproveDraft();};p.Controls.Add(approve);
        Button reject=MakeButton("丢弃草稿",355,80,140,32);reject.Click+=async delegate{await RejectDraft();};p.Controls.Add(reject);
        draftList=new ListView();draftList.Location=new Point(25,130);draftList.Size=new Size(930,180);draftList.View=View.Details;draftList.FullRowSelect=true;draftList.HideSelection=false;
        BatchList(draftList);
        draftList.Columns.Add("联系人 / 群",180);draftList.Columns.Add("对方消息",570);draftList.Columns.Add("生成时间",150);
        draftList.SelectedIndexChanged+=delegate{if(draftList.SelectedItems.Count>0)draftEdit.Text=Str((Dictionary<string,object>)draftList.SelectedItems[0].Tag,"answer");};p.Controls.Add(draftList);
        p.Controls.Add(MakeLabel("回复草稿（可编辑；仍须通过发前检查）",25,325,900,25,true));draftEdit=MakeText(25,360,930,125,true);p.Controls.Add(draftEdit);
        p.Controls.Add(MakeLabel("运行诊断 · 最近读取、运行状态、发送或跳过原因",25,505,930,25,true));diagnosis=MakeText(25,540,930,180,true);diagnosis.ReadOnly=true;p.Controls.Add(diagnosis);
        var move=new List<Control>();foreach(Control child in p.Controls)if(child!=showDraftTools&&child!=draftTools&&child!=diagnosis&&child.Top<500)move.Add(child);foreach(Control child in move){p.Controls.Remove(child);draftTools.Controls.Add(child);}
        BatchSelectButtons(draftTools,draftList,515,80);
        showDraftTools.CheckedChanged+=delegate{ToggleDraftTools();};ToggleDraftTools();
    }
    async Task RefreshProducts() {
        if(productBusy)return;productBusy=true;
        try {
            var data=await Task.Run(()=>LocalCall("assistant_features.py",new Dictionary<string,object>{{"action","snapshot"}}));
            if(IsDisposed)return;
            string selected=draftList.SelectedItems.Count>0?Str((Dictionary<string,object>)draftList.SelectedItems[0].Tag,"id"):"";
            var checkedDrafts=CheckedIds(draftList);
            string edited=draftEdit.Text;draftList.Items.Clear();
            foreach(object obj in (IList)data["drafts"]) {var row=(Dictionary<string,object>)obj;ListViewItem item=new ListViewItem(Str(row,"label"));item.SubItems.Add(Str(row,"source"));item.SubItems.Add(LocalEpoch(Str(row,"created")));item.Tag=row;draftList.Items.Add(item);item.Checked=checkedDrafts.Contains(Str(row,"id"));if(Str(row,"id")==selected){item.Selected=true;draftEdit.Text=edited;}}
            if(draftList.SelectedItems.Count==0)draftEdit.Clear();
            StringBuilder text=new StringBuilder(); var state=data["bridge"] as Dictionary<string,object>;
            text.AppendLine(bridge!=null&&!bridge.HasExited?"微信监听进程运行中；请以读取与发送记录确认连接。":"微信监听已停止；草稿不能发送。");
            if(state!=null) {text.AppendLine("最近状态时间："+LocalEpoch(Str(state,"updatedAt")));text.AppendLine("状态："+Str(state,"status"));if(!String.IsNullOrEmpty(Str(state,"lastError")))text.AppendLine("最近问题："+Str(state,"lastError"));}
            if(showCosts.Checked){var use=data["usage"] as Dictionary<string,object>;if(use!=null)text.AppendLine("今日请求："+Str(use,"calls")+"；已结算费用估算："+Str(use,"cost")+" 元；预留："+Str(use,"reserved")+" 元");}
            string informationPath=Path.Combine(settingsDir,"information-state.json");
            if(File.Exists(informationPath)){var information=new System.Web.Script.Serialization.JavaScriptSerializer().Deserialize<Dictionary<string,object>>(File.ReadAllText(informationPath,Encoding.UTF8));
                if(information.ContainsKey("lastError"))text.AppendLine("信息整理待重试："+Str(information,"lastError"));
                if(information.ContainsKey("pendingReports"))text.AppendLine("等待补齐的历史报告："+Str(information,"pendingReports"));
                IList issues=information.ContainsKey("extractionDiagnostics")?information["extractionDiagnostics"] as IList:null;
                if(issues!=null&&issues.Count>0)text.AppendLine("上轮提取有 "+issues.Count+" 项需要核对，请查看重要提醒中的“提取待核对”。");}
            foreach(object obj in (IList)data["events"]){var row=(Dictionary<string,object>)obj;text.AppendLine(Str(row,"at")+" · "+Str(row,"kind")+" · "+Str(row,"detail"));}diagnosis.Text=text.ToString();
        }catch(Exception ex){if(!IsDisposed)diagnosis.Text=ex.Message;}finally{productBusy=false;}
    }
    void ApproveDraft() {
        var selected=BatchRows(draftList);if(selected.Count==0)return;
        if(bridge==null||bridge.HasExited){Notice("请先开始微信监听；重启前生成的草稿不能发送。");return;}
        try{foreach(var item in selected){var row=(Dictionary<string,object>)item.Tag;string answer=selected.Count==1&&draftList.SelectedItems.Count>0&&draftList.SelectedItems[0]==item?draftEdit.Text:Str(row,"answer");WriteBridgeCommand(new Dictionary<string,object>{{"command","approve"},{"id",Str(row,"id")},{"answer",answer}});}status.Text="已提交 "+selected.Count+" 条确认；每条仍须通过发前检查，结果请看运行记录。";}catch(Exception ex){status.Text=ex.Message;}
    }
    async Task RejectDraft(){var ids=new List<string>();foreach(var row in BatchRows(draftList))ids.Add(Str((Dictionary<string,object>)row.Tag,"id"));if(ids.Count==0)return;try{await Task.Run(()=>LocalCall("assistant_features.py",new Dictionary<string,object>{{"action","reject_many"},{"ids",ids}}));await RefreshProducts();}catch(Exception ex){status.Text=ex.Message;}}
    void BuildEditableMemory(TabPage p){BuildRelationshipMemory(p);}
    sealed class MemoryContact {public string Id,Label,Kind;public override string ToString(){return Label+"（"+Id+"）";}}
    void PopulateMemoryContacts(){
        MemoryContact previous=memoryContact.SelectedItem as MemoryContact;
        Dictionary<string,object> map=new Dictionary<string,object>();
        try{var result=LocalCall("assistant_features.py",new Dictionary<string,object>{{"action","contact_map"}});map=result["identifiers"] as Dictionary<string,object>??map;}catch(Exception error){Notice(error.Message);}
        string previousId=previous==null?"":previous.Id;
        var pool=contactSearchPools.ContainsKey(memoryContact)?contactSearchPools[memoryContact]:memoryContact.Items.Cast<object>().ToList();
        var reused=pool.OfType<MemoryContact>().GroupBy(x=>x.Id).ToDictionary(x=>x.Key,x=>x.First(),StringComparer.Ordinal);
        var items=new List<MemoryContact>();var seen=new HashSet<string>(StringComparer.Ordinal);
        foreach(ListView list in new ListView[]{friendList,groupList})foreach(ListViewItem row in list.Items){
            string id=map.ContainsKey(row.Text)?Convert.ToString(map[row.Text]):row.Text;if(!seen.Add(id))continue;
            MemoryContact item;if(!reused.TryGetValue(id,out item))item=new MemoryContact{Id=id};
            item.Label=row.SubItems[1].Text;item.Kind=list==groupList?"group":"friend";items.Add(item);
        }
        using(var viewport=new ContactViewport(this)){
            populatingMemoryContacts=true;memoryContact.BeginUpdate();try{
                memoryContact.Items.Clear();memoryContact.Items.AddRange(items.Cast<object>().ToArray());
                var selected=items.FirstOrDefault(x=>x.Id==previousId||(previous!=null&&map.ContainsKey(previousId)&&x.Id==Convert.ToString(map[previousId])));
                if(selected!=null)memoryContact.SelectedItem=selected;else if(items.Count>0)memoryContact.SelectedIndex=0;
                RefreshContactSearch(memoryContact);
            }finally{memoryContact.EndUpdate();populatingMemoryContacts=false;}
        }
        memoryContact.Invalidate();if(PickerContactId(memoryContact.SelectedItem)!=previousId)RefreshSelectedMemoryContact();
    }
    async Task RefreshMemory(bool keepEdits=false){if(memoryList==null)return;MemoryContact contact=memoryContact.SelectedItem as MemoryContact;if(contact==null)return;string id=contact.Id,originalEdit=memoryEdit.Text,originalSource=memorySource.Text;try{var data=await Task.Run(()=>LocalCall("assistant_features.py",new Dictionary<string,object>{{"action","memory_list"},{"identifier",id}}));if(IsDisposed||memoryContact.SelectedItem!=contact)return;ApplyMemoryOptions(data);memoryList.BeginUpdate();try{memoryList.Items.Clear();if(!keepEdits&&memoryEdit.Text==originalEdit&&memorySource.Text==originalSource){selectedMemoryId=null;memoryEdit.Clear();memorySource.Clear();}foreach(object obj in (IList)data["items"]){var row=(Dictionary<string,object>)obj;var item=new ListViewItem(Str(row,"kind"));item.SubItems.Add(Str(row,"text"));item.SubItems.Add(Str(row,"source"));item.Tag=row;memoryList.Items.Add(item);}}finally{memoryList.EndUpdate();}}catch(Exception ex){status.Text=ex.Message;}}
    async Task EditMemory(bool delete){MemoryContact contact=memoryContact.SelectedItem as MemoryContact;if(contact==null)return;var value=new Dictionary<string,object>{{"action",delete?"memory_delete_many":"memory_save"},{"identifier",contact.Id},{"id",selectedMemoryId},{"kind",memoryKind.Text},{"text",memoryEdit.Text},{"source",memorySource.Text}};if(delete){var ids=new List<string>();foreach(var row in BatchRows(memoryList))ids.Add(Str((Dictionary<string,object>)row.Tag,"id"));if(ids.Count==0)return;value["ids"]=ids;}try{await Task.Run(()=>LocalCall("assistant_features.py",value));await RefreshMemory();status.Text="人物记忆已更新，后续回复立即使用最新内容。";}catch(Exception ex){status.Text=ex.Message;}}
    void ShowAnalysis(){LoadRelationshipReading();}
    async Task ReadImage(){
        if(!mediaEnabled.Checked){Notice("请先开启手动媒体识别。");return;}
        using(OpenFileDialog dialog=new OpenFileDialog()){dialog.Filter="图片或语音|*.png;*.jpg;*.jpeg;*.bmp;*.wav";if(dialog.ShowDialog(this)!=DialogResult.OK)return;
            try{var result=await Task.Run(()=>LocalCall("media_reader.py",new Dictionary<string,object>{{"path",dialog.FileName}}));
                ShowInternalDocument("本机媒体识别 · 未上传",String.IsNullOrWhiteSpace(Str(result,"text"))?"没有识别出文字；请检查图片清晰度或语音格式、语言。":Str(result,"text"));
            }catch(Exception error){ShowInternalDocument("媒体识别未完成",error.Message);}
        }
    }
    void AddProductConfig(Dictionary<string,object> c){c["apiBaseUrl"]=apiBase.Text.Trim();c["recordChats"]=recordChats.Checked;c["useMemory"]=useMemory.Checked;c["importantReminders"]=importantReminders.Checked;c["analysisCache"]=analysisCache.Checked;c["budgetEnabled"]=budgetEnabled.Checked;c["showCosts"]=showCosts.Checked;c["showDraftTools"]=showDraftTools.Checked;c["mediaEnabled"]=mediaEnabled.Checked;foreach(var pair in ProductNumbers())c[pair.Key]=pair.Value.Value;}
    Dictionary<string,NumericUpDown> ProductNumbers(){return new Dictionary<string,NumericUpDown>{{"contextChars",contextChars},{"replyMaxTokens",replyMaxTokens},{"mergeSeconds",mergeSeconds},{"reminderRefreshMinutes",reminderRefreshMinutes},{"memorySampleChars",memorySampleChars},{"closeMemorySampleChars",closeMemorySampleChars},{"dailyRequestLimit",dailyRequestLimit},{"dailyCostLimit",dailyCostLimit},{"inputPrice",inputPrice},{"outputPrice",outputPrice},{"cacheInputPrice",cacheInputPrice}};}
    void LoadProductConfig(Dictionary<string,object> c){apiBase.Text=String.IsNullOrEmpty(Str(c,"apiBaseUrl"))?"https://api.deepseek.com":Str(c,"apiBaseUrl");recordChats.Checked=Bool(c,"recordChats",false);useMemory.Checked=Bool(c,"useMemory",false);importantReminders.Checked=Bool(c,"importantReminders",false);analysisCache.Checked=Bool(c,"analysisCache",true);budgetEnabled.Checked=Bool(c,"budgetEnabled",false);showCosts.Checked=Bool(c,"showCosts",false);showDraftTools.Checked=Bool(c,"showDraftTools",false);mediaEnabled.Checked=Bool(c,"mediaEnabled",false);foreach(var pair in ProductNumbers()){decimal value;if(c.ContainsKey(pair.Key)&&Decimal.TryParse(Convert.ToString(c[pair.Key]),out value))pair.Value.Value=Math.Min(pair.Value.Maximum,Math.Max(pair.Value.Minimum,value));}}
    bool NeedsReplyKey(){if(apiBase.Text.StartsWith("http://localhost")||apiBase.Text.StartsWith("http://127.0.0.1"))return false;if(privateEnabled.Checked)foreach(ListViewItem row in friendList.Items)if(ModeValue(row.SubItems[3].Text)!="record")return true;if(groupEnabled.Checked)foreach(ListViewItem row in groupList.Items)if(ModeValue(row.SubItems[2].Text)!="record")return true;return false;}
}
}
