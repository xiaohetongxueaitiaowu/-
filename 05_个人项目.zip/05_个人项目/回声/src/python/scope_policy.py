"""Separate recording, reporting, reminders and replies by canonical conversation ID."""
import json
import assistant_features as features

def mapping():
    path=features.DATA/'contact-map.json'
    try:return json.loads(path.read_text(encoding='utf-8-sig')).get('identifiers') or {}
    except (OSError,ValueError):return {}

def canonical(ids):
    aliases=mapping()
    return {str(aliases.get(x,x)) for x in ids if isinstance(x,str) and x}

def resolve_identifier(identifier, database):
    """Reuse an exact alias binding only for the authenticated account."""
    if not getattr(database,'web_archive',False):return identifier
    try:
        value=json.loads((features.DATA/'contact-map.json').read_text(encoding='utf-8-sig'))
        if value.get('account')!=database.wxid:return identifier
        target=(value.get('identifiers') or {}).get(identifier,identifier)
        prefix='web:'+database.account+':'
        return target if isinstance(target,str) and target.startswith(prefix) else identifier
    except (OSError,ValueError,TypeError,AttributeError):return identifier

def selected(config):
    return canonical([x.get('identifier','') for x in list(config.get('friends') or [])+list(config.get('groupEntries') or [])])

def allowed(identifier,config,feature='report'):
    target=next(iter(canonical([identifier])),identifier)
    scope=config.get('analysisScope','off')
    if not target or scope not in ('all','selected') :return False
    if scope=='selected' and target not in selected(config):return False
    excluded=canonical(config.get('reportExcluded' if feature=='report' else 'reminderExcluded',[]))
    return target not in excluded

def filter_rows(rows,config,purpose):
    excluded=canonical(config.get('reportExcluded' if purpose=='report' else 'reminderExcluded',[]))
    return [r for r in rows if r['chat_id'] not in excluded]

def related_request(row,config):
    if row['sender_role']!='other':return False
    if row['chat_type']!='群聊':return True
    return bool(row['at_self'] or config.get('includePublicGroupTasks',False))

def release_snoozed(actions,now):
    result=dict(actions);changed=0
    for mid,value in actions.items():
        if not isinstance(value,dict) or value.get('status')!='snoozed':continue
        import datetime as dt
        try:until=dt.datetime.fromisoformat(value['until'])
        except (KeyError,ValueError,TypeError):continue
        if until<=now:
            result[mid]={**value,'status':'pending','resumedAt':now.isoformat(timespec='seconds')};changed+=1
    return result,changed
