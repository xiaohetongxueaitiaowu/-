"""Daily and weekly DeepSeek reports over one rolling local WeChat archive."""
import datetime as dt
from contextlib import closing
import json
import msvcrt
import os
import pathlib
import re
import sys
import tempfile
import time

import information_core as core
import scope_policy

from echo_paths import STORAGE as ROOT, DATA, REPORTS
STATE = DATA / "information-state.json"
ITEMS = DATA / "important-items.json"
INDEX = DATA / "information-report-index.json"
RAW_VIEW = DATA / "information-raw-view.txt"
SEARCH_VIEW = DATA / "information-search-view.txt"
LOCK = DATA / "information.lock"
SETTINGS = DATA / "settings.json"
TASK_RULES_VERSION = 6


def read_json(path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except (OSError, ValueError, TypeError):
        return default


def write_text(path, content):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".new")
    temporary.write_text(content, encoding="utf-8")
    os.replace(temporary, path)


def write_json(path, content):
    write_text(path, json.dumps(content, ensure_ascii=False, indent=2))


def started_at(state, now):
    try:
        return dt.datetime.fromisoformat(state["startedAt"])
    except (KeyError, ValueError, TypeError):
        state["startedAt"] = now.isoformat(timespec="seconds")
        return now


def dates_for(kind, now, started, final=False):
    if kind == "日报":
        day = now.date() - dt.timedelta(days=1) if final else now.date()
        start = dt.datetime.combine(day, dt.time.min)
        end = dt.datetime.combine(day + dt.timedelta(days=1), dt.time.min) if final else now
    else:
        day = now.date() - dt.timedelta(days=now.weekday())
        start = dt.datetime.combine(day, dt.time.min)
        end = now
    return start, end, day if kind == "日报" else now.date()


def due_jobs(config, state, now, started):
    jobs = []
    lower=max(started.date(), now.date()-dt.timedelta(days=60))
    if config.get("dailyReport", False):
        done=set(state.get('completedDays') or [])
        if state.get('dailyFinalized'): done.add(state['dailyFinalized'])
        day=lower
        while day < now.date():
            if day.isoformat() not in done:
                jobs.append(('日报', dt.datetime.combine(day,dt.time.min),
                             dt.datetime.combine(day+dt.timedelta(days=1),dt.time.min), day, 'final'))
            day += dt.timedelta(days=1)
        if now.time() >= dt.time(23) and state.get("dailyDone") != now.date().isoformat():
            start = dt.datetime.combine(now.date(), dt.time.min)
            end = now
            jobs.append(("日报", start, end, now.date(), "scheduled"))
    if config.get("weeklyReport", False):
        week=lower-dt.timedelta(days=lower.weekday())
        completed=set(state.get('completedWeeks') or [])
        while dt.datetime.combine(week+dt.timedelta(days=7),dt.time.min)<=now:
            sunday=week+dt.timedelta(days=6)
            if sunday.isoformat() not in completed:
                jobs.append(('周报',dt.datetime.combine(week,dt.time.min),
                             dt.datetime.combine(week+dt.timedelta(days=7),dt.time.min),sunday,'final'))
            week+=dt.timedelta(days=7)
        if now.weekday()==6 and now.time()>=dt.time(23) and state.get('weeklyDone')!=now.date().isoformat():
            jobs.append(('周报',dt.datetime.combine(now.date()-dt.timedelta(days=6),dt.time.min),now,now.date(),'scheduled'))
    return jobs

def queue_legacy_reports(state,index):
    """Rebuild known old reports when running; never treat a legacy file as verified."""
    if state.get('reportEngine')=='secretary-v2':return
    for name,spec in index.items():
        if not isinstance(spec,dict) or spec.get('reportStyle')=='secretary-v2':continue
        match=re.fullmatch(r'信息(日报|周报)-(\d{4}-\d{2}-\d{2})(?:-当前)?\.md',name)
        if not match:continue
        kind,day=match.groups();field='completedDays' if kind=='日报' else 'completedWeeks'
        state[field]=[x for x in state.get(field,[]) if x!=day]
        for key in (('dailyDone','dailyFinalized') if kind=='日报' else ('weeklyDone',)):
            if state.get(key)==day:state.pop(key,None)
    state['reportEngine']='secretary-v2'


def merge_reminders(new_items, replace_ranges=(), followup_rows=(), diagnostics=None, replace_sources=()):
    data = read_json(ITEMS, {})
    actions=read_json(DATA/'important-actions.json',{})
    # Keep legacy items with completed actions as history, but don't apply a
    # source-level legacy action to every new task from that source.
    previous = {x["id"]: x for x in data.get("items", []) if isinstance(x, dict) and x.get("id")} if data.get("version") in (9,10) else {}
    if data.get('version')==9:
        previous={mid:item for mid,item in previous.items() if mid in actions}
        for item in previous.values():
            item['legacyHistory']=True;item['kind']='旧版处理记录 · 日期与任务未经新规则复核'
    new_sources={x.get('sourceMessageId') for x in new_items}
    for mid,item in list(previous.items()):
        if not item.get('sourceMessageId') and mid in new_sources and mid not in actions:
            previous.pop(mid,None)
    for mid, item in list(previous.items()):
        if mid not in actions and item.get('sourceMessageId') in replace_sources:
            previous.pop(mid, None)
            continue
        try:
            when = dt.datetime.fromisoformat(item["when"])
            if mid not in actions and any(start <= when < end for start, end in replace_ranges):
                previous.pop(mid, None)
        except (KeyError, ValueError, TypeError):
            previous.pop(mid, None)
    for item in new_items:
        if item['id'] in actions and item['id'] in previous:
            continue  # Explicit owner decisions and their original evidence remain intact.
        previous[item["id"]] = item
    if followup_rows:
        import task_lifecycle
        previous={x["id"]:x for x in task_lifecycle.update(list(previous.values()),[dict(r) for r in followup_rows],diagnostics)}
    cutoff = dt.datetime.now() - dt.timedelta(days=60)
    ordered = sorted((x for x in previous.values() if dt.datetime.fromisoformat(x["when"]) >= cutoff),
                     key=lambda x: x["when"], reverse=True)
    write_json(ITEMS, {"version": 10, "taskRulesVersion": TASK_RULES_VERSION, "updatedAt": dt.datetime.now().isoformat(timespec="seconds"),
                       "items": ordered})
    return len(ordered)


def rebuild_legacy_reminders(rows, diagnostics=None):
    """Reevaluate archived requests locally, including incorrectly closed tasks.

    The caller supplies only the configured scope and retention period. Owner
    decisions stay attached to their exact task, never to an entire source message.
    """
    rows = [dict(row) for row in rows]
    old = read_json(ITEMS, {})
    actions = read_json(DATA / 'important-actions.json', {})
    available = {row['id'] for row in rows}
    old_rows = [x for x in old.get('items', []) if isinstance(x, dict)]
    sources = {x.get('sourceMessageId') for x in old_rows} & available
    def canonical(text):
        return re.sub(r'[\s，,。；;！!？?]+', '', str(text or ''))
    handled = {(x.get('sourceMessageId'), canonical(x.get('task')))
               for x in old_rows if x.get('id') in actions and
               actions[x['id']].get('status') in ('done', 'ignored')}
    raw = [{'requestQuote': quote, 'evidenceIds': [row['id']], 'pendingReview': True,
            'reviewReason': '升级后按原话重新核对；历史请求是否仍需处理，请你确认'}
           for row in rows if row.get('sender_role') == 'other'
           for quote in core.request_parts(row['content'])
           if core.actionable_request(quote) and core.request_context(row['content'], quote)]
    rebuilt = [x for x in core.normalize_reminders(raw, rows, diagnostics)
               if (x['sourceMessageId'], canonical(x['task'])) not in handled]
    merge_reminders(rebuilt, followup_rows=rows, diagnostics=diagnostics,
                    replace_sources=sources)
    return len(rebuilt)


def make_report(conn, kind, start, end, date, key, model, current=False, request_func=None, scope_ids=None, diagnostics=None):
    rows = scope_policy.filter_rows(scoped_rows(core.rows_between(conn, start, end), scope_ids),core.MODEL_CONFIG or {},"report")
    import secretary_report
    import runtime_health as health
    health.update('report','analysing',phase=kind)
    learning, batches = secretary_report.events(rows,key,model,request_func,conn,kind,diagnostics)
    name = "信息%s-%s%s.md" % (kind, date.isoformat(), "-当前" if current else "")
    path = REPORTS / name
    # Only write the selected evidence-backed learning points, never the raw draft.
    import report_pages
    pages=report_pages.layout(secretary_report.render(kind,start,end,learning,rows,batches),5 if kind=='周报' else 3)
    write_text(REPORTS/'完整事件'/name,pages['full'])
    write_text(REPORTS/'页面预览'/(name+'.html'),pages['html'])
    write_text(path,pages['text'])
    index = read_json(INDEX, {})
    index[name] = {"start": start.isoformat(timespec="seconds"), "end": end.isoformat(timespec="seconds"),
                   "engine": "ConfiguredModel", "messages": len(rows), "evidenceVersion": 10, "reportStyle": "secretary-v2", "events": learning,
                   "coverage":secretary_report.coverage(rows),"sourceIds":sorted({r['chat_id'] for r in secretary_report.eligible_rows(rows)}),
                   "pages":pages['pages'],"omitted":pages['omitted'],"createdAt":time.time()}
    write_json(INDEX, index)
    health.update('report','ok',lastSuccessAt=time.time(),error='',document=name,messages=secretary_report.coverage(rows)['analysed'])
    return name, [], len(rows), len(learning)


def scoped_rows(rows, scope_ids):
    return rows if scope_ids is None else [r for r in rows if r["chat_id"] in scope_ids]

def analysis_scope(config, db):
    scope = config.get("analysisScope", "off")
    if scope == "all":
        return None
    if scope == "off":
        return set()
    if scope != "selected":
        raise ValueError("信息分析范围无效，已停止上传")
    from wechat_bridge import resolve_contacts, resolve_groups, split_names
    friends = config.get("friends") or [{"identifier": x} for x in split_names(config.get("contacts", ""))]
    groups = config.get("groupEntries") or [{"identifier": x} for x in split_names(config.get("groups", ""))]
    return set(resolve_contacts(db, [e.get("identifier", "") for e in friends])) | set(resolve_groups(db, groups))


def revalidate_report(path):
    """Remove newly disallowed AI points without resending the archive to the API."""
    spec=read_json(INDEX,{}).get(path.name,{})
    if spec.get('reportStyle')=='secretary-v1':
        import secretary_report
        start=dt.datetime.fromisoformat(spec['start']);end=dt.datetime.fromisoformat(spec['end'])
        with closing(core.connect()) as conn:
            rows=core.rows_between(conn,start,end)
        by_id={r['id']:r for r in rows if r['identity_state']=='verified'}
        kept=[item for item in spec.get('events',[]) if item.get('evidence') and all(e.get('id') in by_id and isinstance(e.get('quote'),str) and e['quote'] in by_id[e['id']]['content'] for e in item['evidence'])]
        write_text(path,secretary_report.render('周报' if '周报' in path.name else '日报',start,end,kept,rows,0))
        return len(kept)
    source = path.read_text(encoding="utf-8-sig")
    if re.search(r'^## 第 \d+ 页',source,re.M):
        return len(re.findall(r'^### ',source,re.M))
    parts = re.split(r"(?=^## )", source, flags=re.M)
    prefix = parts[0].rstrip()
    prefix = re.sub(r"\n+(?:今日无重点。|本周无重点。)$", "", prefix)
    kept_sections, unique = [], set()
    for section in parts[1:]:
        groups = re.split(r"(?=^### )", section, flags=re.M)
        heading = groups[0].strip()
        accepted = []
        for group in groups[1:]:
            blocks = re.split(r"(?=^- )", group, flags=re.M)
            subheading = blocks[0].strip()
            kept = []
            for block in blocks[1:]:
                point = block.splitlines()[0][2:].strip()
                if core.NOT_LEARNING.search(point):
                    continue
                kept.append(block.strip())
                unique.add(point)
            if kept:
                accepted.append(subheading + "\n\n" + "\n\n".join(kept))
        if accepted:
            kept_sections.append(heading + "\n\n" + "\n\n".join(accepted))
    prefix = re.sub(r"保留 \d+ 条可学习内容", "保留 %d 条可学习内容" % len(unique), prefix)
    if kept_sections:
        result = prefix + "\n\n" + "\n\n".join(kept_sections) + "\n"
    else:
        result = prefix + "\n\n" + ("今日无重点。" if "日报" in path.name else "本周无重点。") + "\n"
    if result != source:
        write_text(path, result)
    return len(unique)


def with_lock(mode):
    DATA.mkdir(parents=True, exist_ok=True)
    handle = LOCK.open("a+b")
    # fstat does not read a byte that another Windows process has locked.
    deadline = time.monotonic() + (30 if mode.startswith("manual") or mode in ("raw", "search") else 0)
    while True:
        try:
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            if os.fstat(handle.fileno()).st_size == 0:
                handle.write(b'0');handle.flush()
            return handle
        except OSError:
            if time.monotonic() >= deadline:
                handle.close()
                return None
            time.sleep(0.25)


def report_block_reason(config,mode):
    if mode=='manual-weekly' and not config.get('weeklyReport',False):
        return '周报已关闭。请在设置 → 功能与 API 开启周报，再点击生成。'
    if mode=='manual-daily' and not config.get('dailyReport',False):
        return '日报已关闭。请在设置 → 功能与 API 开启日报，再点击生成。'
    wants=mode in ('manual','manual-daily','manual-weekly','refresh') or any(config.get(x,False) for x in ('dailyReport','weeklyReport','importantReminders'))
    if wants and not config.get('recordChats',False):
        return '本机聊天记录已关闭，无法整理日报周报。请在设置 → 功能与 API 开启本机记录。'
    if wants and config.get('analysisScope','off')=='off':
        return '聊天信息分析已关闭，未上传聊天。请在设置 → 运行与范围选择允许分析的会话，再生成报告。'
    return ''

def run(mode="tick", now=None, db=None, request_func=None, key=None):
    import runtime_health as health
    now = now or dt.datetime.now()
    failure_origin="local"
    handle = with_lock(mode)
    if handle is None:
        return ["另一项信息整理正在运行；本次跳过。"]
    try:
        state = read_json(STATE, {})
        started = started_at(state, now)
        config = read_json(SETTINGS, None)
        if not isinstance(config, dict) or not config:
            raise ValueError("无法读取已保存设置；已停止信息上传，请在App重新保存设置")
        reason=report_block_reason(config,mode)
        if reason:
            health.update('report','blocked',error=reason,phase='等待启用所需设置')
            return [reason]
        core.MODEL_CONFIG=config
        queue_legacy_reports(state,read_json(INDEX,{}))
        if mode in ('tick','scheduled') and now.timestamp()<float(state.get('apiRetryAfter',0)):
            return []
        reminders_enabled=config.get('importantReminders',False)
        jobs = due_jobs(config, state, now, started) if mode in ("tick", "scheduled") else []
        queued=len(jobs)
        if mode in ('tick','scheduled'):
            # Closed weeks first; otherwise a long daily backlog starves weeks.
            jobs.sort(key=lambda j:(0 if j[0]=='周报' and j[-1]=='final' else 1,j[1]))
            jobs=jobs[:min(14,max(1,int(config.get('reportBackfillPerTick',3))))]
        if mode in ("manual","manual-daily","manual-weekly"):
            jobs = []
            if mode!='manual-weekly' and config.get('dailyReport',False): jobs.append(("日报", *dates_for("日报", now, started), "current"))
            if mode!='manual-daily' and config.get('weeklyReport',False): jobs.append(("周报", *dates_for("周报", now, started), "current"))
            if not jobs:return ['当前选中的报告开关已关闭，本次没有调用模型。']
        archive_lower=max(started,now-dt.timedelta(days=60))
        jobs = [(kind, max(start, archive_lower), end, date, phase) for kind, start, end, date, phase in jobs if end > max(start, archive_lower)]
        try:
            last_refresh = dt.datetime.fromisoformat(state["lastReminderAIAt"])
        except (KeyError, ValueError, TypeError):
            last_refresh = started
        refresh = reminders_enabled and (mode in ("manual", "refresh", "scheduled") or
                   (now - last_refresh).total_seconds() >= 60*int(config.get('reminderRefreshMinutes',10)))
        archive_due=now.timestamp()-float(state.get('lastArchiveScanAt',0))>=300
        if mode == "tick" and not jobs and not refresh and not (config.get('recordChats',False) and archive_due):
            return []
        if mode == "revalidate":
            index = read_json(INDEX, {})
            output = []
            for name, spec in index.items():
                path = REPORTS / pathlib.Path(name).name
                if isinstance(spec, dict) and spec.get("engine") == "DeepSeek" and path.exists():
                    output.append("已核对 %s：%d 条学习重点。" % (path.name, revalidate_report(path)))
            return output
        if mode == "search":
            query = json.load(sys.stdin)
            start = dt.datetime.strptime(query["start"], "%Y-%m-%d")
            end = dt.datetime.strptime(query["end"], "%Y-%m-%d") + dt.timedelta(days=1)
            if end <= start or (end - start).days > 61:
                raise ValueError("日期范围须在近两个月内")
            with closing(core.connect()) as conn:
                content = core.search_view(conn, start, end, query.get("keyword", ""))
            write_text(SEARCH_VIEW, content)
            return ["已从单份聊天库读取结果。"]
        if mode == "raw":
            filename = pathlib.Path(sys.argv[-1]).name
            if filename != sys.argv[-1]:
                raise ValueError("报告文件名无效")
            spec = read_json(INDEX, {}).get(filename)
            if not spec:
                raise ValueError("请先重新生成所选报告")
            with closing(core.connect()) as conn:
                content = core.raw_view(conn, dt.datetime.fromisoformat(spec["start"]), dt.datetime.fromisoformat(spec["end"]))
            write_text(RAW_VIEW, content)
            return ["原文已从单份聊天记录中读取。"]
        if not config.get('recordChats',False):
            return ['聊天记录开关已关闭；本次未读取微信或调用模型。']
        own_db = db is None
        temporary = None
        try:
            failure_origin="wechat"
            if own_db:
                from wechat_identity import make_db as WeChatDB
                # Reuse the bounded, mutex-protected account cache, rather than
                # decode every database into a new temporary directory per report.
                db = WeChatDB()
            with closing(core.connect()) as conn:
                stats = core.scan(db, conn, now, config=config)
                state['lastArchiveScanAt']=now.timestamp()
                if stats["failed_chats"] or stats["failed_messages"]:
                    health.failure('archive',ValueError('部分会话或消息读取失败'),'wechat')
                    raise RuntimeError("有 %d 个会话、%d 条消息读取失败，本次不生成不完整报告" %
                                       (stats["failed_chats"], stats["failed_messages"]))
                health.update('archive','ok',lastReadAt=time.time(),lastSuccessAt=time.time(),error='',messages=stats.get('retained',0))
                failure_origin='local'
                scope_ids = analysis_scope(config, db)
                if scope_ids == set():
                    write_json(STATE, state)
                    return ["信息分析已暂停或范围为空；仅保存本机记录，没有上传聊天。"]
                if not jobs and not refresh:
                    write_json(STATE,state)
                    return []
                key = key or core.read_key()
                model = config.get("model", "deepseek-flash")
                output = []
                diagnostics=[]
                reminders = []
                replace_ranges = []
                old_items=read_json(ITEMS,{})
                if reminders_enabled and (old_items.get('version')!=10 or old_items.get('taskRulesVersion')!=TASK_RULES_VERSION):
                    # One local-only upgrade pass: don't pay to resend two months
                    # of chats, and don't lose unfinished legacy source-level tasks.
                    old_rows=scope_policy.filter_rows(scoped_rows(core.rows_between(conn,archive_lower,now+dt.timedelta(seconds=1)),scope_ids),config,"reminder")
                    migrated_count=rebuild_legacy_reminders(old_rows,diagnostics)
                    output.append('已在本机重新核对旧记录：%d 条历史请求已重算；手动处理记录保留，没有额外调用模型。'%migrated_count)
                for kind, start, end, date, phase in jobs:
                    name, found, count, learned = make_report(
                        conn, kind, start, end, date, key, model, current=phase == "current", request_func=request_func, scope_ids=scope_ids, diagnostics=diagnostics)
                    if reminders_enabled and found:
                        reminders += found
                        replace_ranges.append((start, end))
                        # Persist extracted tasks before advancing completion state;
                        # a later failed batch must not lose earlier reminders.
                        merge_reminders(found,[(start,end)])
                    output.append("已生成 %s：阅读 %d 条消息，保留 %d 条学习重点。" % (name, count, learned))
                    if phase == "scheduled":
                        state["dailyDone" if kind == "日报" else "weeklyDone"] = date.isoformat()
                    elif phase == "final":
                        field='completedDays' if kind=='日报' else 'completedWeeks'
                        state[field]=sorted(set(state.get(field) or [])|{date.isoformat()})[-65:]
                        if kind=='日报': state['dailyFinalized']=date.isoformat()
                    write_json(STATE,state)
                if refresh:
                    begin = max(started, last_refresh - dt.timedelta(minutes=5))
                    daily_covers_refresh = False  # reports and reminders have independent exclusions
                    if not daily_covers_refresh:
                        rows = scope_policy.filter_rows(scoped_rows(core.rows_between(conn, begin, now + dt.timedelta(seconds=1)), scope_ids),config,"reminder")
                        current_ids = {row["id"] for row in rows}
                        scope_stamp=json.dumps([config.get("analysisScope"),config.get("reminderExcluded",[]),config.get("includePublicGroupTasks",False),__import__('feature_preferences').preference('reminders')],sort_keys=True)
                        previous_ids = set(state.get("reminderSeenIds") or []) if state.get("reminderScopeStamp")==scope_stamp else set()
                        state["reminderScopeStamp"]=scope_stamp
                        if current_ids - previous_ids:
                            _, more, _ = core.extract(rows, key, model, request_func, conn,purpose='reminders',diagnostics=diagnostics)
                            reminders += core.normalize_reminders(more, rows,diagnostics)
                            replace_ranges.append((begin, now + dt.timedelta(seconds=1)))
                        state["reminderSeenIds"] = sorted(current_ids)
                    state["lastReminderAIAt"] = now.isoformat(timespec="seconds")
                if reminders_enabled and (refresh or reminders or replace_ranges or read_json(ITEMS, {}).get("version") != 10):
                    followups=scope_policy.filter_rows(scoped_rows(core.rows_between(conn,archive_lower,now+dt.timedelta(seconds=1)),scope_ids),config,"reminder")
                    count = merge_reminders(reminders, replace_ranges,followups,diagnostics)
                    output.append("重要提醒已更新，共 %d 条。" % count)
                state.pop("lastError", None)
                state.pop('apiRetryAfter',None)
                combined=(state.get('extractionDiagnostics') or [])+diagnostics
                unique={json.dumps(x,ensure_ascii=False,sort_keys=True):x for x in combined}
                state['extractionDiagnostics']=list(unique.values())[-500:]
                state['pendingReports']=max(0,queued-len(jobs))
                if diagnostics: output.append('有 %d 项筛选或待核对记录，可在重要提醒的“筛选原因”查看。'%len(diagnostics))
                if state['pendingReports']: output.append('还有 %d 份历史报告等待补齐，每轮最多处理 3 份。'%state['pendingReports'])
                write_json(STATE, state)
                return output
        finally:
            if temporary:
                db = None
                temporary.cleanup()
    except Exception as error:
        error.echo_diagnostic=__import__('error_diagnostics').diagnose(error,failure_origin)
        health.failure('report',error,phase='信息整理失败')
        state = read_json(STATE, {})
        state["lastError"] = __import__('error_diagnostics').message(error)
        state['apiRetryAfter']=now.timestamp()+1800
        write_json(STATE, state)
        raise
    finally:
        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        handle.close()


if __name__ == "__main__":
    mode = "revalidate" if "--revalidate" in sys.argv else "search" if "--search" in sys.argv else "raw" if "--raw" in sys.argv else "manual-daily" if "--manual-daily" in sys.argv else "manual-weekly" if "--manual-weekly" in sys.argv else "manual" if "--manual" in sys.argv else "scheduled" if "--scheduled" in sys.argv else "refresh" if "--refresh" in sys.argv else "tick"
    try:
        for line in run(mode):
            print(line, flush=True)
    except Exception as error:
        print("信息整理失败：" + __import__("error_diagnostics").message(error), file=sys.stderr, flush=True)
        sys.exit(2)
