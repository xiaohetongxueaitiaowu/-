"""Local health signals without prompts, credentials, messages or costs."""
import json
import os
import time
import uuid
import assistant_features as features

def update(component,status,**details):
    allowed={'pid','lastReadAt','lastSuccessAt','lastFailureAt','error','phase','document','pending','endpoint','model','jsonMode','schemaRetries','messages','feature','errorCode','errorCategory','errorTitle','errorAction','httpStatus'}
    path=features.DATA/('health-'+component+'.json')
    try:
        features.DATA.mkdir(parents=True,exist_ok=True)
        try:previous=json.loads(path.read_text(encoding='utf-8-sig'))
        except (OSError,ValueError):previous={}
        value={**previous,'status':status,'updatedAt':time.time(),'pid':os.getpid()}
        if status in ('ok','requesting','analysing'):
            for key in ('error','errorCode','errorCategory','errorTitle','errorAction','httpStatus'):value.pop(key,None)
        value.update({k:v for k,v in details.items() if k in allowed})
        temporary=path.with_name(path.name+'.'+uuid.uuid4().hex+'.new')
        temporary.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8');os.replace(temporary,path)
    except OSError:pass


def failure(component,error,origin='local',**details):
    import error_diagnostics as diagnostics
    info=diagnostics.diagnose(error,origin)
    update(component,'error',lastFailureAt=time.time(),error=diagnostics.message(error,origin),**info,**details)
