"""Version-restricted local HTTP transport, selected explicitly in settings.

The reviewed providers target WeChat 4.1.10.27 only. Queue admission is not a
delivery receipt. This protocol has no exact send ID, so the bridge pauses after
an unverified submission; it is not accepted for continuous unattended replies.
"""
import json,re,urllib.error,urllib.parse,urllib.request
import wechat_transport_validation as validation

SUPPORTED_VERSION='4.1.10.27'
class BackendError(RuntimeError):
 def __init__(self,code,message):self.code=code;super().__init__(message)

def installed_version():
 from wechat_connection_check import discover
 result=discover()
 if result['status']!='detected':raise BackendError(result['code'],result['message'])
 return result['version']

class NoRedirect(urllib.request.HTTPRedirectHandler):
 def redirect_request(self,*args,**kwargs):raise BackendError('redirect','微信本机接口发生重定向，已停止连接。')

class LocalHookClient:
 def __init__(self,url='http://127.0.0.1:30001',version_reader=installed_version,timeout=3):
  try:base,_=validation.endpoint(url,local_hook=True)
  except ValueError as error:raise BackendError('address',str(error)) from None
  try:seconds=validation.timeout(timeout,5)
  except ValueError as error:raise BackendError('timeout_setting',str(error)) from None
  self.url=base;self.version_reader=version_reader;self.timeout=seconds
  self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
 def _request(self,path,payload=None):
  data=None if payload is None else json.dumps(payload,ensure_ascii=False).encode('utf-8')
  req=urllib.request.Request(self.url+path,data=data,headers={'Content-Type':'application/json; charset=utf-8'},method='GET' if payload is None else 'POST')
  try:
   with self.opener.open(req,timeout=self.timeout) as response:blob=response.read(65537)
  except BackendError:raise
  except urllib.error.HTTPError as error:
   status=error.code;error.close()
   raise BackendError('http','微信本机接口返回HTTP '+str(status)+'。') from None
  except (OSError,urllib.error.URLError):raise BackendError('connection','微信后台接口未启动、连接失败或超时；未重试发送。') from None
  if len(blob)>65536:raise BackendError('response','微信本机接口返回内容过大。')
  try:result=validation.json_object(blob)
  except (ValueError,UnicodeError):raise BackendError('response','微信本机接口返回了无效JSON或编码。') from None
  if not isinstance(result,dict):raise BackendError('response','微信本机接口响应必须为对象。')
  return result
 def inspect(self):
  actual=self.version_reader()
  if actual!=SUPPORTED_VERSION:raise BackendError('version','微信版本不兼容：当前'+actual+'，此候选接口仅适配'+SUPPORTED_VERSION+'；未发送任何请求。')
  root=self._request('/')
  if root.get('service')!='WeChat-Hook':raise BackendError('service','此端口不是已识别的微信后台接口。')
  status=self._request('/QueryDB/status')
  if type(status.get('IsLogin')) is not int or status['IsLogin']!=1:raise BackendError('login','后台接口可连接，但微信未确认登录。')
  return {'service':'WeChat-Hook','version':actual,'connected':True,'loggedIn':True,'desktopActions':0}
 def verify_owner(self,expected_owner):
  profile=self._request('/GetSelfProfile',{})
  if not isinstance(expected_owner,str) or not expected_owner or profile.get('wxid')!=expected_owner:raise BackendError('identity','后台接口登录账号与回声读取的本人身份不一致。')
  return True
 def queue_text(self,user,text,expected_owner,authorize):
  if not callable(authorize):raise BackendError('authorization','缺少回声的发送前单次授权核验。')
  if not validation.possible_recipient(user):raise BackendError('recipient','必须使用已确认的微信唯一ID。')
  if not isinstance(text,str) or not text.strip() or len(text)>4000 or '\x00' in text:raise BackendError('text','正文为空、过长或含无效字符。')
  self.inspect()
  self.verify_owner(expected_owner)
  # Callback consumes the existing single-use send grant after checking the
  # current settings, target, manual takeover, quiet hours and latest message.
  authorize()
  response=self._request('/SendTextMsg',{'wxidorgid':user,'msg':text})
  if type(response.get('ret')) is not int or response['ret']!=0 or response.get('queued') is False:raise BackendError('rejected','微信后台接口未接受发送请求。')
  return {'queued':True,'sentConfirmed':False,'desktopActions':0,'retryAllowed':False}
