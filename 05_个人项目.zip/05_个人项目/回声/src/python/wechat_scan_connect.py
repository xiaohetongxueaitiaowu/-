"""One personal-WeChat QR flow; protected session, no transport picker.

Experimental login + identity/contact/sync initialization acceptance. No desktop
actions, no model requests, no automatic messages. Connected is not send-tested.
The installed 31 app remains untouched until full runtime acceptance.
"""
import datetime
import base64
import hashlib
import http.cookiejar
import json
import math
import os
from pathlib import Path
import re
import sys
import urllib.parse
import uuid

import wechat_direct_probe as probe
from echo_paths import DATA
from personal_wechat_web import PersonalWeb,contact_kind
MAX_SESSION_BYTES=16*1024*1024


def cookie_records(jar):
    return [{k:getattr(item,k) for k in ('version','name','value','port','port_specified','domain',
             'domain_specified','domain_initial_dot','path','path_specified','secure','expires','discard',
             'comment','comment_url','rfc2109')} | {'rest':dict(item._rest)} for item in jar]


class ScanConnection(probe.Probe):
    def __init__(self,folder=None,*,session_factory=None,**kwargs):
        super().__init__(folder=folder or DATA/'微信扫码连接',**kwargs)
        self.session_path=self.folder/'session.bin'
        self.factory=session_factory or self.make_session

    def make_session(self,redirect,tickets):
        jar=next((handler.cookiejar for handler in self.http.opener.handlers
                  if isinstance(handler,probe.urllib.request.HTTPCookieProcessor)),None)
        return PersonalWeb(redirect,tickets,opener=self.http.opener,cookie_jar=jar,clock=self.clock)

    def login_jar(self):
        opener=getattr(self.http,'opener',None)
        return next((handler.cookiejar for handler in getattr(opener,'handlers',[])
                     if isinstance(handler,probe.urllib.request.HTTPCookieProcessor)),None)

    def restore_login_cookies(self,state):
        jar=self.login_jar()
        if jar is None:return
        from personal_wechat_session import cookies_from_records
        saved=cookies_from_records(state.get('loginCookies',[]))
        for cookie in saved:jar.set_cookie(cookie)

    def login_cookie_changes(self):
        jar=self.login_jar()
        if jar is None:return {}
        rows=cookie_records(jar)
        from personal_wechat_session import cookies_from_records
        cookies_from_records(rows)
        if len(json.dumps(rows).encode('utf-8'))>6500:
            raise probe.ProbeError('credentials','扫码会话 Cookie 超过保存范围，请重新连接。')
        return {'loginCookies':rows}

    def credential_response(self,redirect,identity=None):
        url=probe.credential_url(redirect);body=self.http(url)
        response=getattr(self.http,'last_response',{})
        try:return probe.parse_login(body,response.get('contentType',''))
        except probe.ProbeError as error:
            if error.code in ('login_html','web_login_unavailable'):
                # Keep response data encrypted locally; never print ticket URLs
                # or page contents. This makes the next live failure diagnosable.
                parsed=urllib.parse.urlsplit(url)
                safe={'host':parsed.hostname,'path':parsed.path,'queryKeys':sorted(urllib.parse.parse_qs(parsed.query)),
                      'response':response,'checkedAt':self.clock(),'errorCode':error.code}
                if identity:safe['challengeDigest']=hashlib.sha256(identity.encode()).hexdigest()
                decoded,encoding=probe.decode_login_page(body,response.get('contentType',''))
                try:
                    (self.folder/'登录响应诊断.bin').write_bytes(self.encrypt({'body':decoded,'rawBodyBase64':base64.b64encode(body).decode('ascii'),'encoding':encoding,'metadata':safe}))
                    (self.folder/'登录响应类型.json').write_text(json.dumps(safe,ensure_ascii=False),encoding='utf-8')
                except OSError:pass
            raise

    def _any(self,identity):
        if not isinstance(identity,str) or not re.fullmatch(r'[0-9a-f]{32}',identity):
            raise probe.ProbeError('challenge','请使用当前二维码，旧二维码不能继续连接。')
        try:
            if self.path.stat().st_size>8192:raise ValueError()
            value=self.decrypt(self.path.read_bytes())
            if not isinstance(value,dict) or value.get('id')!=identity:raise ValueError()
            return value
        except Exception:raise probe.ProbeError('challenge','二维码状态已改变或无法解密，请重新扫码。') from None

    def _session_write(self,value):
        temp=self.session_path.with_name('session.'+uuid.uuid4().hex+'.tmp')
        try:
            blob=self.encrypt(value)
            if not isinstance(blob,bytes) or len(blob)>MAX_SESSION_BYTES:
                raise probe.ProbeError('credentials','扫码连接凭据超过本机存储范围，未启用代管。')
            temp.write_bytes(blob);os.replace(temp,self.session_path)
        except OSError:
            raise probe.ProbeError('storage','无法保存扫码连接，请检查磁盘空间与文件权限；未启用代管。') from None
        finally:
            if temp.exists():temp.unlink()

    def session_read(self):
        if self.session_path.stat().st_size>MAX_SESSION_BYTES:
            raise probe.ProbeError('credentials','本机扫码连接文件过大，已停止读取。')
        return self.decrypt(self.session_path.read_bytes())

    def create(self):
        # Keep the preceding server session accessible until its explicit Stop;
        # do not replace encrypted tickets with an anonymous fresh challenge.
        if self.session_path.exists():
            try:
                saved=self.session_read()
                if isinstance(saved,dict) and saved.get('active') is True:
                    raise probe.ProbeError('already_connected','已有扫码连接，请先停止连接，再重新扫码。')
            except probe.ProbeError:raise
            except Exception:raise probe.ProbeError('credentials','旧连接状态无法解密，请检查本机用户和文件权限。') from None
        jar=self.login_jar()
        if jar is not None:jar.clear()
        result=super().create()
        changes=self.login_cookie_changes()
        if changes:self.update(result['challengeId'],**changes)
        result['message']='请用要代管的个人微信扫码，并在手机确认。程序将自动核验本人身份和后台消息接口。'
        result['purpose']='personal_account';result['runtimeEnabled']=False
        return result

    def _expire(self,identity):
        with probe.challenge_lock(self.folder):
            state=self._any(identity);created=state.get('created')
            if (state.get('state')=='waiting' and type(created) in (int,float) and
                    math.isfinite(created) and self.clock()-created>=probe.EXPIRY):
                state['state']='expired';self._write(state)
                return True
            return state.get('state')=='expired'

    def poll(self,identity,expected_owner_name=''):
        self.check_expected_name(expected_owner_name)
        if self._expire(identity):return {'status':'expired','errorCode':'qr_expired','message':'二维码已过期，请点击扫码连接获取新二维码。'}
        value=self.read(identity)
        self.restore_login_cookies(value)
        millis=int(self.clock()*1000);bits=(~millis)&0xffffffff;signed=bits if bits<0x80000000 else bits-0x100000000
        query=urllib.parse.urlencode({'uuid':value['uuid'],'tip':'0','loginicon':'true','r':str(signed)})
        try:body=self.http('https://login.wx.qq.com/cgi-bin/mmwebwx-bin/login?'+query)
        except probe.ProbeError as error:
            if error.code in ('timeout','dns','network'):return self.retry(identity,error)
            raise
        code,redirect=probe.parse_status(body)
        if self._expire(identity):return {'status':'expired','errorCode':'qr_expired','message':'二维码已过期，本次返回不会继续登录，请重新扫码。'}
        self.update(identity,pollFailures=0,**self.login_cookie_changes())
        if code=='408':return {'status':'waiting','message':'等待扫码。二维码生成成功还不代表账号已连接。'}
        if code=='201':return {'status':'scanned','message':'已扫码，请在手机确认登录。'}
        if code=='202':self.update(identity,state='cancelled');return {'status':'phone_cancelled','message':'手机取消了本次微信登录，请重新获取二维码。'}
        if code in ('0','500'):self.update(identity,state='finished');return {'status':'login_server_error','errorCode':'login_server','message':'微信登录服务未完成本次请求，请重新获取二维码；本机未开启代管。'}
        if code=='400':self.update(identity,state='expired');return {'status':'expired','message':'二维码已过期，请重新获取。'}
        try:ret,tickets=self.credential_response(redirect,identity)
        except probe.ProbeError as error:
            if error.code=='web_login_unavailable':
                self.update(identity,state='failed',loginFailure=error.code)
            raise
        try:
            self.read(identity)
        except Exception:
            if tickets is not None:self.logout(redirect,tickets)
            raise
        if tickets is None:
            self.update(identity,state='finished')
            return {'status':'account_rejected','errorCode':'account_restricted','loginCode':ret,
                    'message':'微信服务器拒绝该账号登录（状态 '+ret+'）。无法通过这个二维码代管此账号，未改用桌面操作。'}
        session=None
        try:
            with probe.challenge_lock(self.folder):
                state=self._read(identity);state['state']='connecting';self._write(state)
                # Save issued tickets before an initialization request. Stop can
                # still revoke and request logout during a slow request.
                self._session_write({'challenge':identity,'active':True,'phase':'initializing',
                                     'redirect':redirect,'tickets':tickets})
            session=self.factory(redirect,tickets)
            session.initialize()
            if expected_owner_name and getattr(session,'owner_name','')!=expected_owner_name:
                raise probe.ProbeError('account_mismatch','扫码登录的账号昵称与指定代管账号不符，已停止，未开始读取联系人或自动回复。请用指定账号重新扫码。')
            with probe.challenge_lock(self.folder):
                if self._any(identity).get('state')!='connecting':raise probe.ProbeError('cancelled','连接已停止，未恢复旧二维码。')
            catalog=session.load_contacts()
            saved={'challenge':identity,'active':True,'phase':'connected_unverified','redirect':redirect,
                   'tickets':tickets,'owner':session.owner,'ownerName':getattr(session,'owner_name',''),'account':session.account,'device':session.device,
                   'key':session.key,'checkKey':session.check_key,'contacts':session.contacts,
                   'cookies':cookie_records(session.cookies),'createdAt':self.clock()}
            with probe.challenge_lock(self.folder):
                state=self._any(identity)
                if state.get('state')!='connecting':raise probe.ProbeError('cancelled','连接已停止，未启用代管。')
                self._session_write(saved);state['state']='connected_unverified';self._write(state)
            contacts=catalog['contacts']
            return {'status':'connected_unverified','accountLoginConfirmed':True,'accountIdentityVerified':True,
                    'accountDisplayName':getattr(session,'owner_name',''),
                    'privateContacts':sum(contact_kind(row,session.owner)=='private' for row in contacts),
                    'groups':sum(contact_kind(row,session.owner)=='group' for row in contacts),
                    'publicAccounts':sum(contact_kind(row,session.owner)=='public' for row in contacts),
                    'backgroundProtocolInitialized':True,'runtimeEnabled':False,'sendTestPassed':False,
                    'message':'扫码登录与后台初始化通过。真实收发尚待核验；当前未自动回复，也未操作电脑桌面。'}
        except Exception as error:
            cleanup='not_confirmed'
            try:
                if session is not None:session.logout()
                else:
                    result=self.logout(redirect,tickets)
                    if not result.startswith('已请求'):raise probe.ProbeError('logout','服务器退出尚未确认。')
                cleanup='requested'
            except Exception:pass
            with probe.challenge_lock(self.folder):
                state=self._any(identity)
                if state.get('state')=='connecting':state['state']='failed';self._write(state)
                # Never overwrite the tickets of a newer login session.
                if self.session_path.exists():
                    saved=self.session_read()
                    if isinstance(saved,dict) and saved.get('challenge')==identity:
                        self._session_write({'challenge':identity,'active':False,'phase':'failed','logout':cleanup})
            if isinstance(error,probe.ProbeError):raise
            raise probe.ProbeError('initialization','扫码后后台初始化未完成，请查看网络或账号状态；未开启回复。') from None

    def cancel(self,identity):
        logout_data=None
        with probe.challenge_lock(self.folder):
            state=self._any(identity);state['state']='cancelled';self._write(state)
            if self.session_path.exists():
                saved=self.session_read()
                if isinstance(saved,dict) and saved.get('challenge')==identity:
                    if saved.get('active'):logout_data=saved
                    self._session_write({'challenge':identity,'active':False,'phase':'cancelled'})
        cleanup='not_needed'
        if logout_data is not None:
            try:
                result=self.logout(logout_data['redirect'],logout_data['tickets'])
                cleanup='requested' if result.startswith('已请求') else 'not_confirmed'
            except Exception:cleanup='not_confirmed'
        return {'status':'cancelled','logout':cleanup,'runtimeEnabled':False,
                'message':'扫码连接已停止。'+('尚未登录，不会开始代管。' if cleanup=='not_needed' else
                         '已撤销本机凭据；服务器退出'+('已请求，请在手机核对。' if cleanup=='requested' else '尚未确认，请在手机核对已登录设备。'))}

    def current(self,identity):
        with probe.challenge_lock(self.folder):
            state=self._any(identity)
            return {'status':state.get('state'),'runtimeEnabled':False}
    def check_expected_name(self,name):
        if not isinstance(name,str) or len(name)>256 or any(ord(c)<32 for c in name):
            raise probe.ProbeError('configuration','代管账号核对昵称格式无效。')

    def ready(self,expected_owner_name=''):
        self.check_expected_name(expected_owner_name)
        try:
            if self.path.stat().st_size>8192:raise ValueError()
            current=self.decrypt(self.path.read_bytes());identity=current.get('id')
            from personal_wechat_session import PersonalSessionStore
            store=PersonalSessionStore(self);client=store.restore(identity)
            if expected_owner_name and client.owner_name!=expected_owner_name:
                return {'status':'error','errorCode':'account_mismatch','ready':False,'runtimeEnabled':False,
                        'message':'当前扫码凭据的账号昵称与指定代管账号不符，未启动。请用指定账号重新扫码。'}
            return {'status':'connected_unverified','accountIdentityVerified':True,'challengeId':identity,
                    'accountDisplayName':client.owner_name,
                    'ready':store.active(identity,client.account),'runtimeEnabled':False}
        except (OSError,ValueError,probe.ProbeError):
            failure=self.terminal_login_failure()
            if failure:return failure
            return {'status':'login_required','ready':False,'runtimeEnabled':False,'message':'请先用手机扫码连接个人微信。'}

    def terminal_login_failure(self):
        """Restore a typed rejection, without retrying an already rejected QR.

        Legacy HTML must be bound to the same challenge and response time.
        A cancelled/replaced challenge never inherits an older rejection.
        """
        try:
            with probe.challenge_lock(self.folder):
                if self.path.stat().st_size>8192:return None
                state=self.decrypt(self.path.read_bytes())
                if not isinstance(state,dict) or state.get('state') not in ('waiting','failed','finished','cancelled'):return None
                identity=state.get('id','')
                if not isinstance(identity,str) or not re.fullmatch(r'[0-9a-f]{32}',identity):return None
                confirmed=state.get('loginFailure')=='web_login_unavailable'
                if not confirmed:
                    result_path=self.folder/'结果.json';blob=self.folder/'登录响应诊断.bin'
                    if result_path.stat().st_size>8192 or blob.stat().st_size>1500000:return None
                    result=json.loads(result_path.read_text('utf-8'))
                    if result.get('challengeDigest')!=hashlib.sha256(identity.encode()).hexdigest() or result.get('errorCode')!='login_html':return None
                    saved=self.decrypt(blob.read_bytes());meta=saved.get('metadata',{})
                    created=state.get('created');checked=meta.get('checkedAt')
                    if type(created) not in (int,float) or type(checked) not in (int,float) or not 0<=checked-created<probe.EXPIRY:return None
                    if meta.get('challengeDigest') not in (None,hashlib.sha256(identity.encode()).hexdigest()):return None
                    confirmed=probe.login_page_restriction(saved.get('body'),legacy_utf8_replacement='rawBodyBase64' not in saved)
                    if confirmed:
                        state['loginFailure']='web_login_unavailable'
                        if state.get('state')=='waiting':state['state']='failed'
                        self._write(state)
                if confirmed:return {'status':'error','errorCode':'web_login_unavailable','message':probe.WEB_LOGIN_MESSAGE,'ready':False,'runtimeEnabled':False,'previousAttempt':True}
        except (OSError,ValueError,TypeError,AttributeError,probe.ProbeError):pass
        return None

    def publish(self,result,identity):
        """Only matching current flow metadata, never QR, tickets or contacts."""
        allowed={'waiting':{'waiting','scanned','retrying','error'},'connecting':{'error'},
                 'finished':{'account_rejected','login_server_error'},'failed':{'error'},'cancelled':{'cancelled','phone_cancelled'},
                 'expired':{'expired'},'connected_unverified':{'connected_unverified'}}
        with probe.challenge_lock(self.folder):
            try:state=self._any(identity)
            except probe.ProbeError:return False
            if result.get('status') not in allowed.get(state.get('state'),set()):return False
            fields=('status','errorCode','message','loginCode','accountLoginConfirmed','accountIdentityVerified',
                    'privateContacts','groups','publicAccounts','backgroundProtocolInitialized','runtimeEnabled',
                    'sendTestPassed','modelRequests','messageReads','messageSends','desktopActions','checkedAt','logout')
            safe={key:result[key] for key in fields if key in result}
            safe['challengeDigest']=hashlib.sha256(identity.encode()).hexdigest()
            path=self.folder/'结果.json';temp=path.with_suffix('.'+uuid.uuid4().hex+'.tmp')
            try:temp.write_text(json.dumps(safe,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temp,path)
            finally:
                if temp.exists():temp.unlink()
            return True


def main():
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    value={};connection=ScanConnection()
    try:
        value=json.loads(sys.stdin.readline(16385));action=value.get('action')
        if action=='create':result=connection.create()
        elif action=='poll':result=connection.poll(value.get('challengeId'),value.get('expectedOwnerName',''))
        elif action=='cancel':result=connection.cancel(value.get('challengeId'))
        elif action=='status':result=connection.current(value.get('challengeId'))
        elif action=='ready':result=connection.ready(value.get('expectedOwnerName',''))
        else:raise probe.ProbeError('configuration','未识别的微信扫码操作。')
    except probe.ProbeError as error:result={'status':'error','errorCode':error.code,'message':str(error)}
    except Exception:result={'status':'error','errorCode':'local','message':'本机扫码连接状态无法读取，未开启后台回复。'}
    result.update(modelRequests=0,messageReads=0,messageSends=0,desktopActions=0,
                  checkedAt=datetime.datetime.now().astimezone().isoformat())
    try:connection.publish(result,result.get('challengeId',value.get('challengeId')))
    except Exception:pass  # Metadata failure never claims a successful login or enables sending.
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
