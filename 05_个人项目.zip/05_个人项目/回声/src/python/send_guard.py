"""Single-use local send grants. No credentials, network or UI operations here."""
import hashlib
import json
import os
import pathlib
import sqlite3
import time
import uuid

from echo_paths import DATA

class LocalConnection(sqlite3.Connection):
    def __exit__(self, *args):
        try:
            return super().__exit__(*args)
        finally:
            self.close()

def fingerprint(config):
    return hashlib.sha256(json.dumps({k: v for k, v in config.items() if k not in ("apiKey", "livePrivateOnly")}, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()

def read_settings():
    return json.loads((DATA / "settings.json").read_text(encoding="utf-8-sig"))

def connect():
    DATA.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DATA / "send-authorizations.sqlite"), timeout=5, factory=LocalConnection)
    conn.row_factory = sqlite3.Row
    conn.execute("CREATE TABLE IF NOT EXISTS sessions (id TEXT PRIMARY KEY,pid INTEGER,heartbeat REAL,active INTEGER)")
    conn.execute("CREATE TABLE IF NOT EXISTS grants (id TEXT PRIMARY KEY,session TEXT,user TEXT,seq INTEGER,local_id INTEGER,config TEXT,answer TEXT,created REAL,status TEXT,receipt TEXT)")
    conn.execute("CREATE TABLE IF NOT EXISTS api_receipts (token TEXT PRIMARY KEY,user TEXT NOT NULL,server_id TEXT NOT NULL,UNIQUE(user,server_id))")
    return conn

def start_session():
    sid = uuid.uuid4().hex
    with connect() as conn:
        conn.execute("UPDATE sessions SET active=0")
        conn.execute("DELETE FROM grants WHERE created<?", (time.time() - 86400 * 7,))
        conn.execute("DELETE FROM sessions WHERE heartbeat<?", (time.time() - 86400 * 7,))
        conn.execute("DELETE FROM api_receipts WHERE token NOT IN (SELECT id FROM grants)")
        conn.execute("INSERT INTO sessions VALUES (?,?,?,1)", (sid, os.getpid(), time.time()))
    return sid

def heartbeat(sid):
    with connect() as conn:
        conn.execute("UPDATE sessions SET heartbeat=? WHERE id=? AND active=1", (time.time(), sid))

def stop_session(sid):
    with connect() as conn:
        conn.execute("UPDATE sessions SET active=0 WHERE id=?", (sid,))
        conn.execute("UPDATE grants SET status='revoked' WHERE session=? AND status='pending'", (sid,))

def revoke(sid, user):
    with connect() as conn:
        conn.execute("UPDATE grants SET status='revoked' WHERE session=? AND user=? AND status='pending'", (sid, user))

def issue(sid, task, config, answer):
    if not config.get("enabled") or fingerprint(read_settings()) != fingerprint(config):
        raise ValueError("设置未保存、已更改或自动回复关闭")
    token = uuid.uuid4().hex
    with connect() as conn:
        conn.execute("INSERT INTO grants VALUES (?,?,?,?,?,?,?,?,?,?)", (token, sid, task[0], int(task[3]), int(task[4]), fingerprint(config), hashlib.sha256(answer.encode()).hexdigest(), time.time(), "pending", None))
    return token

def claim(token, user, answer, checks, now=None, consume=True):
    """Consume just once, immediately before the caller's one send-key operation."""
    def validate(conn):
        current=time.time() if now is None else now
        row=conn.execute("SELECT g.*,s.active,s.heartbeat FROM grants g JOIN sessions s ON g.session=s.id WHERE g.id=?",(token,)).fetchone()
        if not row or row['status']!='pending' or row['user']!=user or row['answer']!=hashlib.sha256(answer.encode()).hexdigest():
            raise ValueError('发送授权不存在、已使用或不匹配')
        if not row['active'] or not 0<=current-row['created']<=90 or not 0<=current-row['heartbeat']<=25:
            raise ValueError('发送授权已过期或监听已停止')
        config=read_settings()
        if not config.get('enabled') or fingerprint(config)!=row['config']:
            raise ValueError('发前设置已改变')
        return dict(row),config
    # Database/UI checks can take seconds. Hold no authorization lock while
    # they run, so the listener can heartbeat, stop, or revoke a manual takeover.
    with connect() as conn:
        row,config=validate(conn)
    checks(config,row)
    conn = connect()
    try:
        conn.execute("BEGIN IMMEDIATE")
        row,config=validate(conn)
        if consume:
            conn.execute("UPDATE grants SET status='claimed' WHERE id=?", (token,))
        conn.commit()
        return row
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()

def receipt(token, user, identity):
    with connect() as conn:
        conn.execute("UPDATE grants SET receipt=? WHERE id=? AND user=? AND status='claimed'", (json.dumps(list(identity)), token, user))

def confirmed_bot_message(user, identity):
    with connect() as conn:
        return conn.execute("SELECT 1 FROM grants WHERE user=? AND status='claimed' AND receipt=?", (user, json.dumps(list(identity)))).fetchone() is not None

def confirmed_grant_receipt(token,user):
    with connect() as conn:
        row=conn.execute("SELECT receipt FROM grants WHERE id=? AND user=? AND status='claimed'",(token,user)).fetchone()
    if row is None or not row[0]:return None
    try:identity=json.loads(row[0])
    except (ValueError,TypeError):return None
    if not isinstance(identity,list) or len(identity)!=2 or any(type(x) is not int or x<=0 for x in identity):return None
    return tuple(identity)

def register_api_receipt(token,user,server_id):
    import re
    if not isinstance(server_id,str) or not re.fullmatch(r'[1-9][0-9]*',server_id):raise ValueError('接口消息ID无效')
    with connect() as conn:
        row=conn.execute("SELECT id FROM grants WHERE id=? AND user=? AND status='claimed'",(token,user)).fetchone()
        if not row:raise ValueError('接口回执不属于已使用的单次发送授权')
        conn.execute('INSERT INTO api_receipts VALUES(?,?,?)',(token,user,server_id))

def confirm_api_message(user,server_id,identity):
    if not server_id:return False
    with connect() as conn:
        row=conn.execute("SELECT g.id FROM grants g JOIN api_receipts a ON a.token=g.id WHERE a.user=? AND a.server_id=? AND g.user=? AND g.status='claimed'",(user,str(server_id),user)).fetchone()
        if not row:return False
        conn.execute('UPDATE grants SET receipt=? WHERE id=?',(json.dumps(list(identity)),row[0]))
        return True

def status(token):
    with connect() as conn:
        row = conn.execute("SELECT status FROM grants WHERE id=?", (token,)).fetchone()
        return row[0] if row else "unknown"
