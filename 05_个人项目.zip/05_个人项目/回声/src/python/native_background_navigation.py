"""Owned WeChat controls only; independent background-navigation experiment."""
from collections import deque
import time
from native_background_sender import Blocked,chat_name,session_name

def owned_tree(root,pid,*,max_nodes=800,max_depth=40,seconds=8):
    if type(pid) is not int or pid<=0:raise Blocked('account_binding')
    if root.ProcessId!=pid:raise Blocked('provider_mismatch')
    queue=deque([(root,0,())]);count=0;deadline=time.monotonic()+seconds
    while queue and count<max_nodes and time.monotonic()<deadline:
        control,depth,parents=queue.popleft();count+=1
        # Embedded browsers have their own provider process, even when hosted
        # inside the WeChat main HWND. Do not enter or act on those subtrees.
        if control.ProcessId!=pid:continue
        yield control,parents
        children=control.GetChildren()
        if depth<max_depth:queue.extend((c,depth+1,parents+(control,)) for c in children)
        elif children:raise Blocked('scan_incomplete')
    if queue:raise Blocked('scan_incomplete')

def find_chat_controls(root,pid,recipient,**bounds):
    import re
    groups={}
    for control,parents in owned_tree(root,pid,**bounds):
        view=next((p for p in reversed(parents) if p.ClassName=='mmui::ChatInputView'),None)
        if view is None or not control.ClassName.startswith('mmui::'):continue
        group=groups.setdefault(id(view),[[],[]])
        kind=control.ControlTypeName
        if (kind=='EditControl' and control.ClassName=='mmui::ChatInputField' and
                'chat_input' in (control.AutomationId or '').lower() and chat_name(control.Name)==recipient):group[0].append(control)
        if kind in ('ButtonControl','CustomControl') and re.fullmatch(r'(?:Send|发送)(?:\s*[（(][A-Za-z+ ]{1,20}[)）])?',control.Name or ''):group[1].append(control)
    pairs=[]
    for inputs,buttons in groups.values():
        if not inputs:continue
        if len(inputs)!=1 or len(buttons)!=1:raise Blocked('ambiguous_controls')
        pairs.append((inputs[0],buttons[0]))
    if len(pairs)!=1:raise Blocked('chat_not_open' if not pairs else 'ambiguous_controls')
    return pairs[0]

def return_to_sessions(*,root,pid,binding,snapshot,foreground_is_wechat,invoke_pattern,value_pattern,wait=time.sleep):
    """At most one exact native Back invocation, never mouse/key/focus fallback."""
    before=snapshot();candidates=[];inputs=[];groups=0
    if foreground_is_wechat():raise Blocked('owner_active')
    if not binding():raise Blocked('binding_changed')
    for control,parents in owned_tree(root,pid):
        if control.ClassName=='mmui::ChatSessionList':groups+=1
        if control.ClassName=='mmui::ChatInputField':inputs.append(control)
        if (control.ControlTypeName in ('ButtonControl','CustomControl') and control.ClassName=='mmui::XButton' and control.Name=='返回' and
                any(p.ClassName=='mmui::ChatTitleBarMasterView' for p in parents) and not control.IsOffscreen):candidates.append(control)
    if groups:return {'status':'already_visible','actions':0,'unchanged':snapshot()==before}
    if len(candidates)!=1 or len(inputs)!=1:raise Blocked('navigation_ambiguous')
    box=inputs[0];value=value_pattern(box);button=candidates[0];invoke=invoke_pattern(button)
    if value is None or invoke is None or box.IsOffscreen or not button.IsEnabled:raise Blocked('controls_unavailable')
    if value.Value!='':raise Blocked('owner_draft')
    if not binding() or snapshot()!=before or foreground_is_wechat():raise Blocked('desktop_changed')
    if value.Value!='':raise Blocked('owner_draft')
    try:invoke.Invoke()
    except Exception:pass  # Provider may have invoked already; never repeat.
    wait(.2)
    unchanged=snapshot()==before
    if not unchanged:return {'status':'desktop_changed','actions':1,'unchanged':False}
    if not binding():return {'status':'binding_changed','actions':1,'unchanged':True}
    groups=sum(c.ClassName=='mmui::ChatSessionList' for c,_ in owned_tree(root,pid))
    return {'status':'sessions_visible' if groups else 'not_confirmed','actions':1,'unchanged':True}


def select_recent_chat(*,root,pid,recipient,binding,snapshot,foreground_is_wechat,
                       selection_pattern,value_pattern,wait=time.sleep):
    """One exact owned recent row; no Invoke, search, keyboard or focus fallback."""
    before=snapshot()
    if foreground_is_wechat():raise Blocked('owner_active')
    if binding() is not True:raise Blocked('binding_changed')
    candidates=[];inputs=[]
    for control,parents in owned_tree(root,pid):
        if control.ClassName=='mmui::ChatInputField':inputs.append(control)
        if (control.ControlTypeName=='ListItemControl' and control.ClassName=='mmui::ChatSessionCell' and
            any(p.ClassName=='mmui::ChatSessionList' for p in parents) and session_name(control.Name)==recipient):
            candidates.append(control)
    if len(candidates)!=1:raise Blocked('navigation_ambiguous')
    row=candidates[0]
    if row.IsOffscreen or not row.IsEnabled:raise Blocked('controls_unavailable')
    selection=selection_pattern(row)
    if selection is None:raise Blocked('controls_unavailable')
    for box in inputs:
        value=value_pattern(box)
        if value is None:raise Blocked('controls_unavailable')
        if value.Value!='':raise Blocked('owner_draft')
    if binding() is not True or foreground_is_wechat() or snapshot()!=before:raise Blocked('desktop_changed')
    for box in inputs:
        if value_pattern(box).Value!='':raise Blocked('owner_draft')
    try:selection.Select()
    except Exception:pass  # May have taken effect; never repeat.
    wait(.2)
    if snapshot()!=before:return {'status':'desktop_changed','actions':1,'unchanged':False}
    if binding() is not True:return {'status':'binding_changed','actions':1,'unchanged':True}
    return {'status':'selected_unverified','actions':1,'unchanged':True}
