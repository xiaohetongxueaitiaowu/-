"""Owner-confirmed preferences and separate, bounded conversations in one DB."""
import json
import time
import sqlite3
import assistant_features as features

FEATURES = {'daily': '秘书日报', 'weekly': '秘书周报', 'reminders': '待办提醒',
            'memory': '人物与关系', 'adviser': '消息建议', 'reply': '自动回复', 'contact': '联系人专属问答'}

def tables(conn):
    conn.execute('CREATE TABLE IF NOT EXISTS feature_preferences(feature TEXT,target TEXT,text TEXT,PRIMARY KEY(feature,target))')
    conn.execute('CREATE TABLE IF NOT EXISTS feature_dialogues(id INTEGER PRIMARY KEY,feature TEXT,target TEXT,role TEXT,text TEXT,at REAL)')
    if 'permission_stamp' not in {x[1] for x in conn.execute('PRAGMA table_info(feature_dialogues)')}:
        try:conn.execute("ALTER TABLE feature_dialogues ADD COLUMN permission_stamp TEXT NOT NULL DEFAULT ''")
        except sqlite3.OperationalError as error:
            if 'duplicate column' not in str(error):raise

def validate(feature, target):
    if feature not in FEATURES or not isinstance(target,str) or len(target)>300:
        raise ValueError('功能或对象无效')

def canonical_target(target):
    import scope_policy
    return next(iter(scope_policy.canonical([target])),target)

def preference(feature, target=''):
    validate(feature,target)
    target=canonical_target(target)
    with features.database() as conn:
        tables(conn)
        rows=conn.execute('SELECT target,text FROM feature_preferences WHERE feature=? AND target IN (?,?) ORDER BY target', (feature,'',target)).fetchall()
        return '\n'.join(dict.fromkeys(row['text'] for row in rows))[:3000]

def read(feature, target=''):
    validate(feature,target)
    target=canonical_target(target)
    with features.database() as conn:
        tables(conn)
        rows=conn.execute('SELECT role,text FROM feature_dialogues WHERE feature=? AND target=? ORDER BY id DESC LIMIT 12',(feature,target)).fetchall()
        own=conn.execute('SELECT text FROM feature_preferences WHERE feature=? AND target=?',(feature,target)).fetchone()
    return {'preference':own[0] if own else '', 'inheritedPreference':preference(feature) if target else '', 'history':[dict(row) for row in reversed(rows)]}

def save(feature, target, text):
    validate(feature,target)
    target=canonical_target(target)
    if not isinstance(text,str) or len(text)>1500:raise ValueError('长期要求最多1500字')
    with features.database() as conn:
        tables(conn)
        conn.execute('INSERT OR REPLACE INTO feature_preferences VALUES(?,?,?)',(feature,target,text.strip()))
    return read(feature,target)

def clear(feature,target):
    validate(feature,target)
    target=canonical_target(target)
    with features.database() as conn:
        tables(conn)
        conn.execute('DELETE FROM feature_dialogues WHERE feature=? AND target=?',(feature,target))
    return read(feature,target)

def history_for_scope(feature,target,permission_stamp):
    target=canonical_target(target)
    with features.database() as conn:
        tables(conn);rows=conn.execute('SELECT role,text FROM feature_dialogues WHERE feature=? AND target=? AND permission_stamp=? ORDER BY id DESC LIMIT 12',(feature,target,permission_stamp)).fetchall()
    return [dict(row) for row in reversed(rows)]

def append(feature,target,question,answer,permission_stamp=''):
    validate(feature,target)
    target=canonical_target(target)
    with features.database() as conn:
        tables(conn)
        for role,text in [('user',question),('assistant',answer)]:
            conn.execute('INSERT INTO feature_dialogues(feature,target,role,text,at,permission_stamp) VALUES(?,?,?,?,?,?)',(feature,target,role,text,time.time(),permission_stamp))
        conn.execute('DELETE FROM feature_dialogues WHERE feature=? AND target=? AND id NOT IN (SELECT id FROM feature_dialogues WHERE feature=? AND target=? ORDER BY id DESC LIMIT 12)',(feature,target,feature,target))
