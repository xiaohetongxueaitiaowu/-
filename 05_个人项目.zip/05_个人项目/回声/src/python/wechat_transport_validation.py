"""Format validation only; canonical identity still requires the DB send grant.

No secrets are included in validation errors. A syntactically possible ID is
not proof of a contact, membership, account owner or permission to send.
"""
import json,math,re,urllib.parse

def endpoint(value,local_hook=False):
 if not isinstance(value,str) or not value or any(not 33<=ord(c)<=126 for c in value):
  raise ValueError('微信接口地址须为完整的ASCII域名或IP地址，不包含空白或控制字符。')
 try:parts=urllib.parse.urlsplit(value);port=parts.port
 except (TypeError,ValueError):raise ValueError('微信接口地址或端口无效。') from None
 local=parts.hostname in ('127.0.0.1','::1')
 if not parts.hostname or parts.username is not None or parts.password is not None or parts.query or parts.fragment or parts.path not in ('','/') or port==0:
  raise ValueError('微信接口地址不允许附带密钥、路径、参数或无效端口。')
 if local_hook:
  if parts.scheme!='http' or parts.hostname!='127.0.0.1' or port is None:
   raise ValueError('本机Hook仅接受 http://127.0.0.1:端口。')
 elif parts.scheme not in ('http','https') or parts.scheme=='http' and not local:
  raise ValueError('微信服务使用HTTPS；HTTP仅允许本机回环地址。')
 return value.rstrip('/'),local

def timeout(value,maximum):
 if isinstance(value,bool):raise ValueError('微信连接超时值无效。')
 try:number=float(value)
 except (ValueError,TypeError,OverflowError):raise ValueError('微信连接超时须为有效秒数。') from None
 if not math.isfinite(number) or not 0<number<=maximum:raise ValueError('微信连接超时超出允许范围。')
 return number

def header_token(value):
 if not isinstance(value,str) or '\r' in value or '\n' in value:raise ValueError('微信Token格式无效。')
 token=value.strip()
 if not token or any(not 33<=ord(c)<=126 for c in token):raise ValueError('微信Token包含无效字符，请只填写服务提供的Token。')
 return token

def possible_recipient(value):
 if not isinstance(value,str) or len(value)>128 or value in ('filehelper','weixin','newsapp','notifymessage','wxid_'):return False
 # Older canonical WeChat usernames need not start with wxid_. The bridge
 # requires the exact username returned by its verified allowlist resolution.
 return bool(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_-]*|[0-9]+@chatroom',value))

def json_object(blob):
 if not isinstance(blob,bytes) or len(blob)>65536:raise ValueError('微信响应格式或大小无效。')
 text=blob.decode('utf-8');depth=0;quoted=False;escaped=False
 for character in text:
  if quoted:
   if escaped:escaped=False
   elif character=='\\':escaped=True
   elif character=='"':quoted=False
  elif character=='"':quoted=True
  elif character in '[{':
   depth+=1
   if depth>64:raise ValueError('微信响应结构嵌套过深，无法核验。')
  elif character in ']}':depth-=1
 def pairs(values):
  result={}
  for key,value in values:
   if key in result:raise ValueError('微信响应有重复字段，无法唯一核验。')
   result[key]=value
  return result
 def invalid_constant(_):raise ValueError('微信响应包含非JSON数值。')
 def finite_float(value):
  number=float(value)
  if not math.isfinite(number):raise ValueError('微信响应数值超出有效范围。')
  return number
 try:result=json.loads(text,object_pairs_hook=pairs,parse_constant=invalid_constant,parse_float=finite_float)
 except RecursionError:raise ValueError('微信响应结构嵌套过深，无法核验。') from None
 if not isinstance(result,dict):raise ValueError('微信响应必须为JSON对象。')
 return result

def server_message_id(value):
 if type(value) is int:
  number=value
 elif isinstance(value,str) and re.fullmatch(r'[1-9][0-9]{0,19}',value):
  number=int(value)
 else:raise ValueError('微信接口没有提供精确的64位消息ID。')
 if not 0<number<=18446744073709551615:raise ValueError('微信接口消息ID超出64位范围。')
 return str(number)
