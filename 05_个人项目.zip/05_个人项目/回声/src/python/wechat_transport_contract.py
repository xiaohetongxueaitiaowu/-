"""Provider-independent contracts for the distributable Echo project.

Research metadata is not runtime compatibility. External providers are not
activated by registering them here, and no network/model/UI calls occur here.
"""
from dataclasses import dataclass
from hashlib import sha256
from contextlib import contextmanager
import json,sqlite3

@dataclass(frozen=True)
class Provider:
 id:str
 title:str
 personal:bool|None
 groups:bool|None
 background:bool|None
 versions:tuple[str,...]=()
 stage:str='researched'
 credentials:tuple[str,...]=()
 external_messages:bool=False
 source:str=''

PROVIDERS={p.id:p for p in (
 Provider('desktop','本机桌面微信',True,True,False,('4.1.15.13',),'existing',source='https://github.com/fanyuantaier/wechatauto-replica'),
 Provider('hook_http','本机Hook后台接口',True,True,True,('4.1.10.27',),'prototype',source='https://github.com/mosheng20205/WechatHook4.1.10.27'),
 Provider('wechatferry','WeChatFerry',True,True,True,('3.9.12.51',),'archived',source='https://github.com/lich0821/WeChatFerry/releases'),
 Provider('official_bot','腾讯官方Bot',False,None,True,(),credentials=('botToken',),source='https://github.com/Tencent/openclaw-weixin'),
 Provider('gewe','GeWeAPI',True,True,True,(),stage='prototype',credentials=('token','appId'),external_messages=True,source='https://doc.geweapi.com/'),
 Provider('weke','WekeAPI',True,True,True,(),credentials=('accessToken','appId'),external_messages=True,source='https://doc.wekeapi.com/'),
 Provider('wechaty','Wechaty',None,None,None,(),stage='backend_dependent',credentials=('puppet',),source='https://github.com/wechaty/wechaty'),
 Provider('webhook_web','wechatbot-webhook网页版',True,True,True,(),credentials=('serviceToken',),source='https://github.com/danni-cool/wechatbot-webhook'),
 Provider('gewechat_archive','Gewechat历史仓库',True,True,None,(),stage='retired',source='https://github.com/Devo919/Gewechat'),
)}

def readiness(provider_id,*,wechat_version='',personal=True,groups=False,background=True,credentials=None,external_consent=False,live_verified=False):
 """Classify blockers without contacting vendors or silently selecting another."""
 provider=PROVIDERS.get(provider_id)
 if provider is None:return {'status':'unsupported','code':'unknown_provider','message':'未识别的微信接口；未切换到其他接入方式。'}
 result={'provider':provider.id,'status':'blocked','source':provider.source,'implementationStage':provider.stage}
 def fail(code,text):return dict(result,code=code,message=text)
 if provider.stage in ('retired','archived'):return fail('maintenance','此项目已停止维护或归档，未作为当前商用连接启用。')
 for wanted,cap,label in ((personal,provider.personal,'代管个人好友'),(groups,provider.groups,'群聊'),(background,provider.background,'不操作桌面的后台发送')):
  if wanted and cap is not True:return fail('capability','此接口未确认支持：'+label+'。')
 if provider.versions and wechat_version not in provider.versions:return fail('version','当前微信版本不在此接口已确认的版本范围内。')
 credentials=credentials or {}
 missing=[field for field in provider.credentials if not isinstance(credentials.get(field),str) or not credentials[field].strip()]
 if missing:return dict(fail('credentials','微信接口凭据尚未配置；它与模型API Key分开。'),requiredFields=missing)
 if provider.external_messages and external_consent is not True:return fail('data_route','此接口会把微信消息交给独立服务，尚未确认此数据接入方式。')
 # `live_verified` is supplied by the acceptance runner, never copied from a
 # saved user's checkbox. Existing/prototype SDKs must still be registered.
 if provider.stage not in ('existing','prototype'):return dict(result,status='needs_adapter',code='adapter',message='已查阅文档；此服务尚未接入运行程序。')
 if live_verified is not True:return dict(result,status='needs_live_test',code='acceptance',message='接入原型已准备，真实账号收发尚未验收。')
 return dict(result,status='ready',code='ok',message='所需能力和本连接的真实验收已确认。')

def opaque_key(*parts):return sha256(json.dumps(parts,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()

def identity_valid(value):
 return isinstance(value,str) and bool(value) and len(value)<=2048 and value==value.strip() and not any(ord(c)<33 or ord(c)==127 for c in value)

@dataclass(frozen=True)
class AccountBinding:
 provider:str
 instance:str
 account_id:str
 owner_id:str
 def __post_init__(self):
  if not isinstance(self.provider,str) or self.provider not in PROVIDERS or any(not identity_valid(v) for v in (self.instance,self.account_id,self.owner_id)):raise ValueError('接口、设备和本人身份必须明确绑定')
 @property
 def key(self):return opaque_key(self.provider,self.instance,self.account_id,self.owner_id)

@dataclass(frozen=True)
class Message:
 account:AccountBinding
 conversation_id:str
 message_id:str
 kind:str
 sender_id:str
 text:str
 created_at_ms:int
 def __post_init__(self):
  if not isinstance(self.account,AccountBinding):raise ValueError('消息必须绑定明确的微信账号')
  if any(not identity_valid(v) for v in (self.conversation_id,self.message_id)):raise ValueError('会话和消息唯一ID必须有效，不能用文本代替消息ID')
  if self.kind not in ('private','group'):raise ValueError('会话类型必须明确')
  if not isinstance(self.sender_id,str) or not isinstance(self.text,str):raise ValueError('发言者及正文格式错误')
  if type(self.created_at_ms) is not int or self.created_at_ms<=0:raise ValueError('消息时间必须由适配器明确转换为毫秒')
 @property
 def key(self):return opaque_key(self.account.key,self.conversation_id,self.message_id)
 @property
 def role(self):
  if not identity_valid(self.sender_id) or self.sender_id.endswith('@chatroom') or self.sender_id.startswith('@@') or (self.kind=='group' and self.sender_id==self.conversation_id):return 'UNKNOWN'
  if self.sender_id==self.account.owner_id:return 'SELF'
  if self.kind=='private' and self.sender_id!=self.conversation_id:return 'UNKNOWN'
  return 'OTHER'

class EventStore:
 """Account-scoped deduplication; only hashes, no message bodies or secrets."""
 def __init__(self,path):
  self.path=str(path)
  with self._connection() as conn:
   conn.execute('CREATE TABLE IF NOT EXISTS events(key TEXT PRIMARY KEY,account TEXT NOT NULL,created INTEGER NOT NULL)')
 @contextmanager
 def _connection(self):
  conn=sqlite3.connect(self.path)
  try:
   with conn:yield conn
  finally:conn.close()
 def accept(self,message):
  with self._connection() as conn:
   result=conn.execute('INSERT OR IGNORE INTO events VALUES(?,?,?)',(message.key,message.account.key,message.created_at_ms))
   return result.rowcount==1
 def prune(self,before_ms):
  if type(before_ms) is not int:raise ValueError('清理时间必须为毫秒')
  with self._connection() as conn:return conn.execute('DELETE FROM events WHERE created<?',(before_ms,)).rowcount

SEND_TRANSITIONS={'created':{'authorized','cancelled'},'authorized':{'submitted','cancelled','failed','uncertain'},'submitted':{'confirmed','uncertain','failed'},'confirmed':set(),'cancelled':set(),'failed':set(),'uncertain':{'confirmed','failed'}}
def transition(current,new):
 if new not in SEND_TRANSITIONS.get(current,set()):raise ValueError('不允许的发送状态变化；入队不等于发送确认，失败后不自动重发')
 return new

def can_automatically_reply(message,allowed_ids):
 # Only normalized, confirmed OTHER messages from an explicit allowlist.
 return message.role=='OTHER' and message.conversation_id in set(allowed_ids)
