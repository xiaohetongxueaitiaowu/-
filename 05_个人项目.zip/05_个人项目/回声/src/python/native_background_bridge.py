"""Experimental binding to existing production send grants; not auto-selected.

This module deliberately requires a current account/window binding assertion.
An old readable database or an exact displayed chat name alone cannot prove
which account owns the live WeChat window. No installed route enables this yet.
"""
from native_background_sender import Blocked,Outcome,locate_current_chat,send_current_chat


def send_authorized(payload,db,*,assert_binding,bound_handle,snapshot,foreground_is_wechat,
                    locate=None,guard=None,bridge=None,send_impl=None,**timing):
    if guard is None:
        import send_guard as guard
    if bridge is None:
        import wechat_bridge as bridge
    if (not isinstance(payload,dict) or not callable(assert_binding) or
            type(bound_handle) is not int or bound_handle<=0):
        return Outcome('blocked','binding_required')
    if locate is None:
        locate=lambda name:locate_current_chat(name,allowed_handles=[bound_handle])
    user,answer,token=payload.get('user'),payload.get('answer'),payload.get('authorization')
    own_id=payload.get('selfSenderId')
    if (not all(isinstance(v,str) and v.strip() for v in (user,answer,token)) or
            type(own_id) is not int or own_id<=0):
        return Outcome('blocked','authorization')
    grant={};claimed=False

    def binding():
        if assert_binding() is not True:raise Blocked('binding_changed')

    def checks(config,row):
        binding()
        bridge.send_checks(db,config,row,answer,own_id)

    try:
        grant=guard.claim(token,user,answer,checks,consume=False)
        name=bridge.exact_display_name(db,user)
    except Exception as error:
        return Outcome('blocked',error.code if isinstance(error,Blocked) else 'authorization')

    def validate():
        if not claimed:
            guard.claim(token,user,answer,checks,consume=False)
        else:
            # Stop/revoke/settings may change after consuming a grant. Do not
            # call claim again: it must stay single-use. Read its active session.
            with guard.connect() as conn:
                row=conn.execute('SELECT g.*,s.active,s.heartbeat FROM grants g JOIN sessions s ON g.session=s.id WHERE g.id=?',(token,)).fetchone()
            now=guard.time.time()
            config=guard.read_settings()
            if (row is None or row['status']!='claimed' or not row['active'] or
                    row['user']!=user or row['config']!=grant['config'] or
                    not 0<=now-row['created']<=90 or not 0<=now-row['heartbeat']<=25 or
                    not config.get('enabled') or guard.fingerprint(config)!=grant['config']):
                raise Blocked('authorization_changed')
            checks(config,grant)
        if bridge.exact_display_name(db,user)!=name:raise Blocked('binding_changed')

    def claim(verifier):
        nonlocal grant,claimed
        def final_checks(config,row):
            checks(config,row)
            verifier()
        grant=guard.claim(token,user,answer,final_checks)
        claimed=True

    def receipt():
        # Native UIA has no server send identifier. Receipt is a scoped newer
        # local SELF record, as in the desktop sender, not server API provenance.
        for row in db.get_messages(user,limit=8) or []:
            seq,local_id=int(row.get('sort_seq') or 0),int(row.get('local_id') or 0)
            if (seq>grant['seq'] and local_id>0 and
                    bridge.sender_type(row,own_id,None)=='SELF' and row.get('content')==answer):
                identity=(seq,local_id)
                # Commit before touching UI controls again: Qt can destroy and
                # recreate the input provider immediately after a send.
                try:guard.receipt(token,user,identity)
                except Exception:pass  # Return the verified identity; outer store reports failure explicitly.
                return identity

    result=(send_impl or send_current_chat)(recipient=name,text=answer,locate=locate,snapshot=snapshot,
                            foreground_is_wechat=foreground_is_wechat,validate=validate,
                            claim=claim,find_receipt=receipt,**timing)
    if result.receipt is not None:
        try:
            if not guard.confirmed_bot_message(user,result.receipt):guard.receipt(token,user,result.receipt)
        except Exception:
            return Outcome('confirmed_receipt_store_failed','receipt_store',True,
                           result.receipt,result.invariants_unchanged,result.draft_remaining)
    return result
