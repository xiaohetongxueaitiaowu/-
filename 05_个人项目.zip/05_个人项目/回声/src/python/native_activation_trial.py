"""Experimental reversible window flag. Never enabled by the production app.

WS_EX_NOACTIVATE is not a guarantee against programmatic activation. A real
provider test must verify foreground behaviour, and the flag is always restored.
"""
from contextlib import contextmanager
NOACTIVATE=0x08000000


class WindowsStyle:
    def __init__(self):
        import ctypes
        self.ctypes=ctypes;self.api=ctypes.WinDLL('user32',use_last_error=True)
        self.api.GetWindowLongW.argtypes=[ctypes.c_void_p,ctypes.c_int]
        self.api.GetWindowLongW.restype=ctypes.c_long
        self.api.SetWindowLongW.argtypes=[ctypes.c_void_p,ctypes.c_int,ctypes.c_long]
        self.api.SetWindowLongW.restype=ctypes.c_long
    def read(self,handle):
        self.ctypes.set_last_error(0);value=self.api.GetWindowLongW(handle,-20)
        if not value and self.ctypes.get_last_error():raise OSError('style_read_failed')
        return value & 0xffffffff
    def write(self,handle,value):
        self.ctypes.set_last_error(0);previous=self.api.SetWindowLongW(handle,-20,value)
        if not previous and self.ctypes.get_last_error():raise OSError('style_write_failed')


@contextmanager
def temporary_noactivate(binding,*,authorized=False,styles=None):
    if authorized is not True:raise PermissionError('explicit_trial_authorization_required')
    if not binding.confirmed():raise ValueError('account_binding_changed')
    styles=styles or WindowsStyle();handle=binding.handle
    original=styles.read(handle);added=not bool(original & NOACTIVATE)
    state={'changed':False,'restored':not added,'restorationError':False}
    try:
        if added:
            state['changed']=True
            styles.write(handle,original|NOACTIVATE)
        if not binding.confirmed() or styles.read(handle)&NOACTIVATE==0:
            raise ValueError('flag_not_confirmed')
        yield state
    finally:
        if added:
            try:
                # Never modify a reused HWND or clobber concurrent unrelated flags.
                if not binding.confirmed():raise ValueError('account_binding_changed')
                current=styles.read(handle);styles.write(handle,current&~NOACTIVATE)
                state['restored']=not bool(styles.read(handle)&NOACTIVATE)
            except Exception:state['restorationError']=True
