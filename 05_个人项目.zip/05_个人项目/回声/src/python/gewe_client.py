"""GeWe documented HTTP client; no account login or service registration.

Not activated without separately entered WeChat credentials and data-route
choice. HTTPS required for remote hosts. API acceptance is not recipient receipt.
"""
import json,re,urllib.error,urllib.parse,urllib.request
from local_hook_client import BackendError,NoRedirect
import wechat_transport_validation as validation

class GeweClient:
 def __init__(self,url,token,app_id,external_approved=False,timeout=8):
  try:base,local=validation.endpoint(url)
  except ValueError as error:raise BackendError('address',str(error)) from None
  if not local and external_approved is not True:raise BackendError('data_route','尚未选择允许微信消息经过此独立服务。')
  try:secret=validation.header_token(token)
  except ValueError as error:raise BackendError('credentials',str(error)) from None
  if not isinstance(app_id,str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,128}',app_id):raise BackendError('credentials','请填写已登录微信节点的 appId。')
  try:seconds=validation.timeout(timeout,15)
  except ValueError as error:raise BackendError('timeout_setting',str(error)) from None
  self.url=base;self.token=secret;self.app_id=app_id;self.timeout=seconds
  self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
 def _request(self,path,payload):
  body=json.dumps({'appId':self.app_id,**payload},ensure_ascii=False).encode('utf-8')
  request=urllib.request.Request(self.url+path,data=body,headers={'Content-Type':'application/json; charset=utf-8','X-GEWE-TOKEN':self.token},method='POST')
  try:
   with self.opener.open(request,timeout=self.timeout) as response:blob=response.read(65537)
  except BackendError:raise
  except urllib.error.HTTPError as error:
   code='wechat_auth' if error.code in (401,403) else 'wechat_rate' if error.code==429 else 'wechat_http'
   status=error.code;error.close()
   raise BackendError(code,'微信服务返回 HTTP '+str(status)+'；未重复发送。') from None
  except (OSError,urllib.error.URLError):raise BackendError('connection','微信服务连接失败或超时；发送结果未确认，未自动重发。') from None
  if len(blob)>65536:raise BackendError('response','微信接口返回内容过大。')
  try:result=validation.json_object(blob)
  except (UnicodeError,ValueError):raise BackendError('response','微信接口返回无效JSON或编码。') from None
  if not isinstance(result,dict) or type(result.get('ret')) is not int:raise BackendError('response','微信接口响应缺少明确状态。')
  if result['ret']!=200:raise BackendError('wechat_rejected','微信接口未接受操作，业务状态码 '+str(result['ret'])+'；未显示未经核验的服务响应。')
  return result.get('data')
 def inspect(self):
  result=self._request('/gewe/v2/api/login/checkOnline',{})
  if result is not True:raise BackendError('login','微信服务节点未确认在线，请检查该服务的扫码登录。')
  return {'service':'GeWe','connected':True,'loggedIn':True,'desktopActions':0}
 def verify_owner(self,expected_owner):
  profile=self._request('/gewe/v2/api/personal/getProfile',{})
  if not isinstance(profile,dict) or not isinstance(expected_owner,str) or not expected_owner or profile.get('wxid')!=expected_owner:raise BackendError('identity','微信服务账号与回声读取的本人身份不一致。')
  return True
 def queue_text(self,user,text,expected_owner,authorize):
  if not callable(authorize):raise BackendError('authorization','缺少发送前单次授权。')
  if not validation.possible_recipient(user):raise BackendError('recipient','必须使用已核验的好友或群唯一ID。')
  if not isinstance(text,str) or not text.strip() or len(text)>4000 or '\x00' in text:raise BackendError('text','微信正文为空、过长或无效。')
  self.inspect();self.verify_owner(expected_owner);authorize()
  result=self._request('/gewe/v2/api/message/postText',{'toWxid':user,'content':text})
  if not isinstance(result,dict) or result.get('toWxid')!=user:raise BackendError('receipt','微信服务响应的目标身份未核实；未重发。')
  try:identity=validation.server_message_id(result.get('newMsgId'))
  except ValueError:raise BackendError('receipt','微信服务未返回精确、有效的64位消息ID；发送结果未确认，未重发。') from None
  return {'queued':True,'sentConfirmed':False,'serverMessageId':identity,'desktopActions':0,'retryAllowed':False}
