"""Independent text-only iLink protocol prototype, NOT an installed route.

Reference: Tencent/openclaw-weixin docs/protocol_zh_CN.md (2026-10-04).
No desktop automation, contact import, account registration or model requests.
Bot conversations do not prove access to existing personal WeChat friends/groups.
"""
from dataclasses import dataclass, field
from contextlib import closing
import base64
import hashlib
import json
import secrets
import socket
import sqlite3
import ssl
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

from local_hook_client import BackendError
import wechat_transport_validation as valid

ORIGIN = 'https://ilinkai.weixin.qq.com'
STATES = {'wait', 'scaned', 'confirmed', 'expired', 'need_verifycode',
          'verify_code_blocked', 'scaned_but_redirect', 'binded_redirect'}


def atom(value, maximum=4096):
    return (isinstance(value, str) and 0 < len(value) <= maximum and
            all(33 <= ord(c) <= 126 for c in value))


def peer_set(values):
    if not isinstance(values, (list, tuple, set, frozenset)) or any(not atom(value, 512) for value in values):
        raise BackendError('recipient', 'Bot 允许名单须由已确认的唯一身份组成。')
    return set(values)


class RejectRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        raise BackendError('redirect', '微信协议返回跳转，未将凭据发送到其他地址。')


@dataclass(frozen=True)
class Challenge:
    code: str = field(repr=False)
    display: str = field(repr=False)
    issued: float


@dataclass(frozen=True)
class Credentials:
    token: str = field(repr=False)
    bot: str = field(repr=False)
    scanner: str = field(repr=False)


@dataclass(frozen=True)
class Incoming:
    peer: str = field(repr=False)
    message_id: str
    text: str = field(repr=False)
    created_ms: int
    context: str = field(repr=False)
    binding: str = field(repr=False)
    received: float


class ReplyLedger:
    """Durable attempt IDs only; uncertain requests stay claimed after restart."""
    def __init__(self, path):
        self.path = str(path)
        with closing(sqlite3.connect(self.path)) as conn:
            with conn:
                conn.execute('CREATE TABLE IF NOT EXISTS attempts (key TEXT PRIMARY KEY)')

    def claim(self, account, peer, mid):
        key = hashlib.sha256(json.dumps([account, peer, mid], separators=(',', ':')).encode()).hexdigest()
        try:
            with closing(sqlite3.connect(self.path)) as conn:
                with conn:
                    return conn.execute('INSERT OR IGNORE INTO attempts VALUES (?)', (key,)).rowcount == 1
        except sqlite3.Error:
            raise BackendError('storage', '发送去重记录无法保存，已停止发送；请检查磁盘和文件权限。') from None


class ILinkClient:
    """Bound to one Bot account; sends require an accepted inbound context."""
    def __init__(self, credentials=None, *, timeout=10, opener=None, clock=time.monotonic, ledger=None):
        if credentials is not None and (not isinstance(credentials, Credentials) or
                not atom(credentials.token) or not atom(credentials.bot, 512) or
                not atom(credentials.scanner, 512)):
            raise BackendError('credentials', '微信 Bot 凭据不完整。')
        self.credentials = credentials
        self.timeout = valid.timeout(timeout, 35)
        self.opener = opener or urllib.request.build_opener(urllib.request.ProxyHandler({}), RejectRedirect())
        self.clock = clock
        self.ledger = ledger
        self.binding = (hashlib.sha256((credentials.bot + '\0' + credentials.token).encode()).hexdigest()
                        if credentials else '')
        self._contexts = {}
        self._attempted = set()

    def _request(self, path, payload=None, *, authenticated=False):
        if authenticated and self.credentials is None:
            raise BackendError('credentials', '尚未完成微信 Bot 扫码登录。')
        headers = {'iLink-App-Id': 'bot', 'iLink-App-ClientVersion': str(0x020409)}
        data = None
        if payload is not None:
            headers.update({'Content-Type': 'application/json', 'AuthorizationType': 'ilink_bot_token',
                            'X-WECHAT-UIN': base64.b64encode(str(secrets.randbits(32)).encode()).decode()})
            body = dict(payload)
            if authenticated:
                headers['Authorization'] = 'Bearer ' + self.credentials.token
                body['base_info'] = {'channel_version': '2.4.9', 'bot_agent': 'Echo/0.1.0'}
            data = json.dumps(body, ensure_ascii=False, allow_nan=False).encode('utf-8')
        request = urllib.request.Request(ORIGIN + path, data=data, headers=headers,
                                         method='GET' if data is None else 'POST')
        try:
            with self.opener.open(request, timeout=self.timeout) as response:
                blob = response.read(65537)
        except BackendError:
            raise
        except urllib.error.HTTPError as error:
            status = error.code
            error.close()
            code = 'wechat_auth' if status in (401, 403) else 'wechat_rate' if status == 429 else 'wechat_http'
            raise BackendError(code, '微信协议服务返回 HTTP ' + str(status) + '；未自动重复请求。') from None
        except (OSError, urllib.error.URLError) as error:
            reason = getattr(error, 'reason', error)
            if isinstance(reason, ssl.SSLError):
                code, message = 'tls', '微信连接证书或 TLS 校验失败。'
            elif isinstance(reason, socket.gaierror):
                code, message = 'dns', '微信接口域名解析失败，请检查网络和 DNS。'
            elif isinstance(reason, (TimeoutError, socket.timeout)):
                code, message = 'timeout', '微信接口超时；发送结果未知时不能重复发送。'
            else:
                code, message = 'connection', '微信接口连接失败，请检查网络。'
            raise BackendError(code, message) from None
        try:
            result = valid.json_object(blob)
        except (ValueError, UnicodeError):
            raise BackendError('response', '微信接口返回格式、编码或大小不符合协议。') from None
        for name in ('ret', 'errcode'):
            if name in result:
                code = result[name]
                if type(code) is not int:
                    raise BackendError('response', '微信业务状态类型无效。')
                if code:
                    if code == -14:
                        raise BackendError('wechat_session', '微信 Bot 会话已失效，请重新扫码；未循环重试。')
                    raise BackendError('wechat_rejected', '微信接口拒绝操作，状态码 ' + str(code) + '。')
        return result

    def create_challenge(self):
        result = self._request('/ilink/bot/get_bot_qrcode?bot_type=3', {'local_token_list': []})
        code, display = result.get('qrcode'), result.get('qrcode_img_content')
        if not atom(code) or not isinstance(display, str) or not display.strip() or len(display) > 16384:
            raise BackendError('response', '微信接口未提供有效二维码。')
        return Challenge(code, display, self.clock())

    def poll_challenge(self, challenge, verify_code=None):
        if (not isinstance(challenge, Challenge) or not atom(challenge.code) or
                not 0 <= self.clock() - challenge.issued < 300):
            raise BackendError('qr_expired', '二维码已过期，请重新获取。')
        query = {'qrcode': challenge.code}
        if verify_code is not None:
            if not isinstance(verify_code, str) or not verify_code.isascii() or not verify_code.isdecimal() or not 4 <= len(verify_code) <= 12:
                raise BackendError('verification', '请填写手机显示的数字配对码。')
            query['verify_code'] = verify_code
        result = self._request('/ilink/bot/get_qrcode_status?' + urllib.parse.urlencode(query))
        status = result.get('status')
        if not isinstance(status, str) or status not in STATES:
            raise BackendError('response', '微信返回未知二维码状态。')
        if status == 'scaned_but_redirect':
            raise BackendError('qr_region', '微信要求切换地区节点；该节点尚未核验，未继续连接。')
        if status == 'confirmed':
            # Never trust a credential-bearing alternate URL implicitly.
            base = result.get('baseurl', ORIGIN)
            if not isinstance(base, str) or base.rstrip('/') != ORIGIN:
                raise BackendError('qr_region', '微信登录返回其他节点，尚未核验该节点。')
            token, bot, scanner = result.get('bot_token'), result.get('ilink_bot_id'), result.get('ilink_user_id')
            if not atom(token) or not atom(bot, 512) or not atom(scanner, 512):
                raise BackendError('response', '微信确认状态缺少账号和凭据，不能视为登录成功。')
            return status, Credentials(token, bot, scanner)
        return status, None

    def get_updates(self, cursor='', allowed_peers=()):
        if not isinstance(cursor, str) or len(cursor) > 32768:
            raise BackendError('cursor', '微信消息游标无效。')
        peers = peer_set(allowed_peers)
        result = self._request('/ilink/bot/getupdates', {'get_updates_buf': cursor}, authenticated=True)
        if type(result.get('ret')) is not int or result['ret'] != 0 or not isinstance(result.get('msgs'), list):
            raise BackendError('response', '微信消息响应缺少明确成功状态或列表。')
        new_cursor = result.get('get_updates_buf', '')
        if not isinstance(new_cursor, str) or len(new_cursor) > 32768:
            raise BackendError('response', '微信接口返回无效消息游标。')
        now = self.clock()
        self._contexts = {key: value for key, value in self._contexts.items() if 0 <= now - value.received < 300}
        accepted, skipped, staged = [], {}, dict(self._contexts)
        for raw in result['msgs']:
            reason = 'invalid_message'
            incoming = None
            if isinstance(raw, dict):
                if raw.get('group_id'):
                    reason = 'group_unverified'
                elif type(raw.get('message_type')) is not int or raw.get('message_type') != 1:
                    reason = 'not_user_message'
                elif type(raw.get('message_state')) is not int or raw.get('message_state') != 2 or raw.get('delete_time_ms'):
                    reason = 'not_final_message'
                elif raw.get('to_user_id') != self.credentials.bot:
                    reason = 'account_mismatch'
                elif not atom(raw.get('from_user_id'), 512) or raw.get('from_user_id') not in peers:
                    reason = 'not_allowed'
                else:
                    try:
                        mid = valid.server_message_id(raw.get('message_id'))
                        stamp, context, items = raw.get('create_time_ms'), raw.get('context_token'), raw.get('item_list')
                        if type(stamp) is not int or not 0 < stamp < 2**63 or not atom(context) or not isinstance(items, list) or not items:
                            raise ValueError()
                        parts = []
                        for item in items:
                            if not isinstance(item, dict) or type(item.get('type')) is not int or item['type'] != 1:
                                raise ValueError()
                            part = item.get('text_item')
                            if not isinstance(part, dict) or not isinstance(part.get('text'), str) or not part['text'].strip():
                                raise ValueError()
                            parts.append(part['text'])
                        text = '\n'.join(parts)
                        if len(text) > 12000 or '\x00' in text:
                            raise ValueError()
                        incoming = Incoming(raw['from_user_id'], mid, text, stamp, context, self.binding, now)
                    except (ValueError, TypeError):
                        pass
            if incoming is None:
                skipped[reason] = skipped.get(reason, 0) + 1
                continue
            key = (incoming.peer, incoming.message_id)
            if key in staged:
                skipped['duplicate'] = skipped.get('duplicate', 0) + 1
                continue
            # Bound in-memory contexts. Refuse the batch instead of dropping an
            # old send credential to admit arbitrary new records.
            if len(staged) >= 1000:
                raise BackendError('capacity', '待处理消息过多，请处理或等待上下文到期。')
            staged[key] = incoming
            accepted.append(incoming)
        self._contexts = staged
        self._attempted.intersection_update(self._contexts)
        return {'messages': accepted, 'cursor': new_cursor or cursor, 'skipped': skipped}

    def queue_reply(self, incoming, text, *, allowed_peers, authorize):
        if not isinstance(incoming, Incoming) or self.credentials is None:
            raise BackendError('context', '缺少该账号收到的有效消息上下文。')
        key = (incoming.peer, incoming.message_id)
        if incoming.binding != self.binding or self._contexts.get(key) != incoming:
            raise BackendError('context', '消息不属于当前 Bot 账号或尚未通过入站校验。')
        if not 0 <= self.clock() - incoming.received < 300:
            raise BackendError('context_expired', '消息上下文已超过本机五分钟回复期限，请等待新消息。')
        if incoming.peer not in peer_set(allowed_peers):
            raise BackendError('recipient', '该联系人已不在允许名单中。')
        if not isinstance(text, str) or not text.strip() or len(text) > 4000 or '\x00' in text:
            raise BackendError('text', '回复正文为空、过长或格式无效。')
        if key in self._attempted:
            raise BackendError('already_attempted', '该消息已提交过发送，结果未知时也不自动重发。')
        if not isinstance(self.ledger, ReplyLedger):
            raise BackendError('ledger_required', '发送需要持久化去重记录，防止重启后重复发送。')
        if not callable(authorize) or authorize() is not True:
            raise BackendError('authorization', '当前设置、人工接管或单次授权不允许发送。')
        if not self.ledger.claim(self.credentials.bot, incoming.peer, incoming.message_id):
            raise BackendError('already_attempted', '该消息已有持久化发送记录，未重复发送。')
        self._attempted.add(key)
        client_id = 'echo-' + uuid.uuid4().hex
        result = self._request('/ilink/bot/sendmessage', {'msg': {
            'from_user_id': '', 'to_user_id': incoming.peer, 'client_id': client_id,
            'message_type': 2, 'message_state': 2, 'context_token': incoming.context,
            'item_list': [{'type': 1, 'text_item': {'text': text}}]}}, authenticated=True)
        if type(result.get('ret')) is not int or result['ret'] != 0:
            raise BackendError('receipt', '微信接口未返回明确接受状态；未重发。')
        return {'queued': True, 'sentConfirmed': False, 'clientId': client_id,
                'desktopActions': 0, 'retryAllowed': False}
