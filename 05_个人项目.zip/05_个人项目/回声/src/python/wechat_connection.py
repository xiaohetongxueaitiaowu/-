"""Explicit connection routing. Background routes never import desktop drivers."""
from local_hook_client import BackendError,LocalHookClient
from wechat_connection_check import discover

def settings(config):
 if not isinstance(config,dict):raise BackendError('connection_settings','微信连接设置必须为配置对象。')
 if 'wechatConnection' not in config:return {'provider':'native_windows'}
 raw=config['wechatConnection']
 if not isinstance(raw,dict):raise BackendError('connection_settings','微信连接设置格式无效，请重新选择接入方式。')
 provider=raw.get('provider')
 if provider not in ('hook_http','native_windows'):raise BackendError('adapter_missing','旧扫码、付费服务与桌面操纵路线已停用，请使用 Windows 后台连接检查；未自动切换发送方式。')
 result={'provider':provider}
 if provider=='hook_http':
  url=raw.get('endpoint','http://127.0.0.1:30001')
  # Validate address before version discovery or any connection activity.
  LocalHookClient(url,version_reader=lambda:'')
  path=raw.get('wechatExe','')
  if not isinstance(path,str):raise BackendError('connection_settings','微信程序位置必须为路径文字。')
  result.update(endpoint=url,wechatExe=path)
 elif provider=='gewe':
  from wechat_transport_validation import endpoint
  try:endpoint(raw.get('endpoint',''))
  except ValueError as error:raise BackendError('address',str(error)) from None
  result.update(endpoint=raw.get('endpoint',''),appId=raw.get('appId',''),externalApproved=raw.get('externalApproved') is True)
 return result

def hook_client(config):
 value=settings(config)
 if value['provider']!='hook_http':raise BackendError('connection_mode','当前未选择微信后台接口。')
 def version():
  result=discover(value['wechatExe'] or None)
  if result['status']!='detected':raise BackendError(result['code'],result['message'])
  return result['version']
 return LocalHookClient(value['endpoint'],version_reader=version)

def background_client(config):
 value=settings(config)
 if value['provider']=='hook_http':return hook_client(config)
 if value['provider']=='gewe':
  from gewe_client import GeweClient
  from wechat_credentials import get_token
  return GeweClient(value['endpoint'],get_token('gewe'),value['appId'],value['externalApproved'])
 raise BackendError('connection_mode','当前未选择可用的微信后台接口。')

def inspect(config,owner=None):
 value=settings(config)
 if value['provider']=='native_windows':
  from native_window_transport import inspect as native_inspect
  state=native_inspect(config)
  if not state.get('ready'):raise BackendError(state['errorCode'],state['message'])
  return state
 if value['provider']=='isolated_local':
  from local_isolation import inspect as local_inspect
  state=local_inspect()
  raise BackendError(state['errorCode'],state['message'])
 if value['provider']=='personal_web':
  from wechat_scan_connect import ScanConnection
  result=ScanConnection().ready()
  return {**result,'provider':'personal_web','background':True,'requiresDesktop':False,
          'message':'扫码账号已连接；后台运行与实际收发显示在首页。' if result.get('ready') else result.get('message','请先扫码连接微信。')}
 if value['provider']=='desktop':return {'provider':'desktop','status':'configured','background':False,'requiresDesktop':True,'message':'已选择桌面模式；发送时会操作微信窗口。'}
 client=background_client(config);result=client.inspect()
 if owner is not None:client.verify_owner(owner)
 return {**result,'provider':value['provider'],'status':'connected_unverified','background':True,'requiresDesktop':False,'message':'微信后台接口可连接；真实收发仍需验收。'}

def diagnose(config):
 try:return inspect(config)
 except BackendError as error:return {'status':'blocked','errorCode':error.code,'message':str(error),'requiresDesktop':False,'desktopActions':0}

if __name__=='__main__':
 import json,sys
 if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
 try:result=diagnose(json.loads(sys.stdin.readline()))
 except (ValueError,TypeError):result={'status':'blocked','errorCode':'configuration','message':'微信连接设置无法读取。'}
 if result.get('status')=='blocked':
  import error_diagnostics
  result.update(error_diagnostics.payload(BackendError(result.get('errorCode','configuration'),result['message']),'wechat'))
 print(json.dumps(result,ensure_ascii=False))
 raise SystemExit(2 if result.get('status')=='blocked' else 0)
