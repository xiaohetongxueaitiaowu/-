﻿"""Owner-submitted feedback; no chat, model requests, logs or background sending."""
import datetime as dt
import json
import os
import re
import smtplib
import sqlite3
import ssl
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid
from email.message import EmailMessage
import assistant_features as features

RECIPIENT=''
KINDS=('功能建议','界面体验','运行问题','其他意见')
EMAIL=re.compile(r'^[^\s@<>\r\n]+@[^\s@<>\r\n]+\.[^\s@<>\r\n]+$')

def tables(conn):
    conn.execute('CREATE TABLE IF NOT EXISTS feedback(id TEXT PRIMARY KEY,kind TEXT,text TEXT,reply_to TEXT,version TEXT,status TEXT,created TEXT,updated TEXT,error TEXT)')
    if 'sender_pid' not in {row[1] for row in conn.execute('PRAGMA table_info(feedback)')}:
        try:conn.execute('ALTER TABLE feedback ADD COLUMN sender_pid INTEGER')
        except sqlite3.OperationalError:
            if 'sender_pid' not in {row[1] for row in conn.execute('PRAGMA table_info(feedback)')}:raise

class RejectRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        raise urllib.error.HTTPError(req.full_url,code,'反馈接口不允许跳转',headers,fp)

def settings():
    try:return json.loads((features.DATA/'feedback-settings.json').read_text(encoding='utf-8-sig'))
    except (OSError,ValueError):return {'mode':'local'}

def secret(value=None):
    import win32crypt
    path=features.DATA/'feedback-secret.bin'
    if value is not None:
        features.DATA.mkdir(parents=True,exist_ok=True)
        if value:
            temporary=path.with_suffix('.new');temporary.write_bytes(win32crypt.CryptProtectData(value.encode('utf-8'),'Echo feedback',None,None,None,0));temporary.replace(path)
        elif path.exists():path.unlink()
    return win32crypt.CryptUnprotectData(path.read_bytes(),None,None,None,0)[1].decode('utf-8') if path.exists() else ''

def configuration():
    config=settings();return {**config,'recipient':RECIPIENT,'hasSecret':(features.DATA/'feedback-secret.bin').exists(),'configured':config.get('mode') in ('smtp','https')}

def configure(value):
    mode=value.get('mode','local');config={'mode':mode}
    if mode=='smtp':
        host=str(value.get('host') or '').strip();sender=str(value.get('sender') or '').strip();username=str(value.get('username') or sender).strip()
        port=int(value.get('port') or 465);tls=value.get('tls','ssl')
        if not host or len(host)>253 or any(x in host for x in ('/','\r','\n',' ')) or not EMAIL.fullmatch(sender) or not username or len(username)>300 or not 1<=port<=65535 or tls not in ('ssl','starttls'):raise ValueError('请填写有效的发信服务器、端口、邮箱与加密方式')
        config.update(host=host,port=port,tls=tls,sender=sender,username=username)
    elif mode=='https':
        endpoint=str(value.get('endpoint') or '').strip();url=urllib.parse.urlsplit(endpoint)
        if url.scheme!='https' or not url.hostname or url.username or url.password or url.fragment or len(endpoint)>2000:raise ValueError('反馈接口必须是 HTTPS 地址，不含账号密码或片段')
        config['endpoint']=endpoint
    elif mode!='local':raise ValueError('发送方式无效')
    supplied=value.get('secret','')
    identity=('mode','host','port','sender','username','endpoint')
    changed=any(config.get(k)!=settings().get(k) for k in identity)
    if 'secret' in value or changed:
        if not isinstance(supplied,str) or len(supplied)>3000:raise ValueError('发送凭据无效')
        if supplied or value.get('clearSecret') or changed:secret(supplied)
    features.DATA.mkdir(parents=True,exist_ok=True)
    path=features.DATA/'feedback-settings.json';temporary=path.with_suffix('.new');temporary.write_text(json.dumps(config,ensure_ascii=False),encoding='utf-8');temporary.replace(path)
    return configuration()

def list_items():
    with features.database() as conn:
        tables(conn)
        import psutil
        for row in conn.execute("SELECT id,sender_pid FROM feedback WHERE status='sending'").fetchall():
            if not row['sender_pid'] or not psutil.pid_exists(row['sender_pid']):
                conn.execute("UPDATE feedback SET status='unknown',error='发送已中断，结果待核对；不会自动重发' WHERE id=?",(row['id'],))
        rows=[dict(x) for x in conn.execute('SELECT * FROM feedback ORDER BY created DESC LIMIT 100')]
    return {'items':rows,'configuration':configuration()}

def save(value):
    kind=value.get('kind');text=value.get('text');reply=value.get('replyTo','');version=str(value.get('version') or '回声 V2')[:100]
    if kind not in KINDS or not isinstance(text,str) or not text.strip() or len(text)>4000 or not isinstance(reply,str) or (reply and not EMAIL.fullmatch(reply)):raise ValueError('请填写反馈内容（最多4000字），联系邮箱可不填')
    identifier=str(value.get('id') or uuid.uuid4().hex);now=dt.datetime.now().isoformat(timespec='seconds')
    if not re.fullmatch(r'[a-f0-9]{32}',identifier):raise ValueError('反馈编号无效')
    with features.database() as conn:
        tables(conn);row=conn.execute('SELECT * FROM feedback WHERE id=?',(identifier,)).fetchone()
        if row and row['status'] not in ('saved','failed'):raise ValueError('已发送或处理中反馈不能覆盖，请另存一条新反馈')
        conn.execute('INSERT OR REPLACE INTO feedback(id,kind,text,reply_to,version,status,created,updated,error) VALUES(?,?,?,?,?,?,?,?,?)',(identifier,kind,text.strip(),reply,version,'saved',row['created'] if row else now,now,''))
    return {'id':identifier,'status':'saved'}

def send(identifier):
    if not RECIPIENT:raise ValueError('纯净版未预置反馈收件地址，请联系软件提供方。')
    config=settings();mode=config.get('mode','local')
    if mode not in ('smtp','https'):raise ValueError('尚未配置反馈发送服务。请在“发送设置”配置发信邮箱或反馈接口；内容可先保存到本机。')
    with features.database() as conn:
        tables(conn);row=conn.execute('SELECT * FROM feedback WHERE id=?',(identifier,)).fetchone()
        if not row:raise ValueError('请先保存反馈')
        if row['status'] not in ('saved','failed'):raise ValueError('反馈已发送、正在处理或发送状态待核对；不会重复发送')
        claimed=conn.execute("UPDATE feedback SET status='sending',error='',sender_pid=? WHERE id=? AND status IN ('saved','failed')",(os.getpid(),identifier)).rowcount
        if claimed!=1:raise ValueError('另一项发送正在处理此反馈')
        item=dict(row)
    submitted=False;acknowledged=False;status='sent';error=''
    try:
        key=secret()
        if mode=='smtp':
            message=EmailMessage();message['From']=config['sender'];message['To']=RECIPIENT;message['Subject']='回声 V2 反馈 · '+item['kind'];message['Message-ID']='<echo-'+identifier+'@feedback.local>'
            if item['reply_to']:message['Reply-To']=item['reply_to']
            message.set_content('回声反馈\n类型：'+item['kind']+'\n版本：'+item['version']+'\n编号：'+identifier+'\n\n'+item['text'])
            context=ssl.create_default_context()
            smtp=smtplib.SMTP_SSL(config['host'],config['port'],timeout=25,context=context) if config['tls']=='ssl' else smtplib.SMTP(config['host'],config['port'],timeout=25)
            with smtp:
                if config['tls']=='starttls':smtp.ehlo();smtp.starttls(context=context);smtp.ehlo()
                smtp.login(config['username'],key)
                submitted=True
                refused=smtp.send_message(message)
                if refused:raise smtplib.SMTPRecipientsRefused(refused)
                acknowledged=True
        else:
            body=json.dumps({'id':identifier,'recipient':RECIPIENT,'kind':item['kind'],'text':item['text'],'replyTo':item['reply_to'],'version':item['version']},ensure_ascii=False).encode()
            headers={'Content-Type':'application/json','Idempotency-Key':identifier}
            if key:headers['Authorization']='Bearer '+key
            request=urllib.request.Request(config['endpoint'],body,headers,method='POST')
            submitted=True
            opener=urllib.request.build_opener(RejectRedirect(),urllib.request.HTTPSHandler(context=ssl.create_default_context()))
            with opener.open(request,timeout=25) as response:
                reply=json.loads(response.read(65536).decode('utf-8'))
            if reply.get('accepted') is not True:status='failed';error='收件服务没有确认接收，反馈仍保存在本机'
            else:acknowledged=True
    except (smtplib.SMTPAuthenticationError,smtplib.SMTPRecipientsRefused,smtplib.SMTPSenderRefused,smtplib.SMTPDataError,urllib.error.HTTPError):
        status='failed';error='服务拒绝发送，请检查账号授权或收件接口配置；内容已保留'
    except Exception:
        if not acknowledged:
            status='unknown' if submitted else 'failed';error='发送状态待核对，请确认是否收到后再处理；不会自动重发' if submitted else '连接或发送配置不可用，内容已保留'
    with features.database() as conn:
        tables(conn);conn.execute('UPDATE feedback SET status=?,error=?,updated=? WHERE id=?',(status,error,dt.datetime.now().isoformat(timespec='seconds'),identifier))
    return {'id':identifier,'status':status,'error':error,'recipient':RECIPIENT}

def execute(value):
    action=value.get('action','list')
    if action=='configuration':return configuration()
    if action=='configure':return configure(value)
    if action=='save':return save(value)
    if action=='list':return list_items()
    if action=='send':return send(str(value.get('id') or ''))
    if action=='delete':
        ids=value.get('ids',[])
        if not isinstance(ids,list) or not ids or any(not isinstance(x,str) for x in ids):raise ValueError('请选择要删除的反馈记录')
        with features.database() as conn:
            tables(conn);conn.executemany("DELETE FROM feedback WHERE id=? AND status!='sending'",[(x,) for x in ids])
        return list_items()
    raise ValueError('未知反馈操作')

if __name__=='__main__':
    try:print(json.dumps(execute(json.load(sys.stdin)),ensure_ascii=False))
    except Exception as error:print(json.dumps({'error':str(error)},ensure_ascii=False));sys.exit(2)
