"""Read-only connection diagnostics for different customers' Windows installs.

No sends, injection, login, contact/history reads or model requests. Network
inspection is explicit and restricted to the reviewed local Hook health API.
"""
import argparse,json,os,pathlib,re,sys
from wechat_transport_contract import PROVIDERS,readiness

EXECUTABLES=('Weixin.exe','WeChat.exe')

def registry_executable(value):
 if not isinstance(value,str):return None
 value=os.path.expandvars(value.strip())
 match=re.fullmatch(r'"([^"\r\n]+\.exe)"(?:,\s*-?\d+)?',value,re.I)
 if match:value=match.group(1)
 elif re.fullmatch(r'[^"\r\n]+\.exe(?:,\s*-?\d+)?',value,re.I):value=re.sub(r',\s*-?\d+$','',value)
 else:return None
 if pathlib.PureWindowsPath(value).name.casefold() not in {name.casefold() for name in EXECUTABLES}:return None
 return value

def registry_paths():
 if os.name!='nt':return []
 import winreg
 found=[]
 for hive in (winreg.HKEY_CURRENT_USER,winreg.HKEY_LOCAL_MACHINE):
  for view in (winreg.KEY_WOW64_64KEY,winreg.KEY_WOW64_32KEY):
   for key_name in (r'Software\Tencent\Weixin',r'Software\Tencent\WeChat'):
    try:
     with winreg.OpenKey(hive,key_name,0,winreg.KEY_READ|view) as key:
      for name in ('InstallPath','InstallLocation','ExePath'):
       try:value=winreg.QueryValueEx(key,name)[0]
       except OSError:continue
       if not isinstance(value,str):continue
       exe=registry_executable(value)
       if exe:found.append(exe)
       else:found.extend(str(pathlib.Path(os.path.expandvars(value))/exe_name) for exe_name in EXECUTABLES)
    except OSError:continue
 return found

def running_paths():
 if os.name!='nt':return []
 import ctypes
 from ctypes import wintypes
 class ProcessEntry(ctypes.Structure):
  _fields_=[('dwSize',wintypes.DWORD),('cntUsage',wintypes.DWORD),('th32ProcessID',wintypes.DWORD),('th32DefaultHeapID',ctypes.c_size_t),('th32ModuleID',wintypes.DWORD),('cntThreads',wintypes.DWORD),('th32ParentProcessID',wintypes.DWORD),('pcPriClassBase',wintypes.LONG),('dwFlags',wintypes.DWORD),('szExeFile',wintypes.WCHAR*260)]
 kernel=ctypes.WinDLL('kernel32',use_last_error=True)
 kernel.CreateToolhelp32Snapshot.argtypes=[wintypes.DWORD,wintypes.DWORD];kernel.CreateToolhelp32Snapshot.restype=wintypes.HANDLE
 kernel.Process32FirstW.argtypes=[wintypes.HANDLE,ctypes.POINTER(ProcessEntry)]
 kernel.Process32NextW.argtypes=[wintypes.HANDLE,ctypes.POINTER(ProcessEntry)]
 kernel.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];kernel.OpenProcess.restype=wintypes.HANDLE
 kernel.QueryFullProcessImageNameW.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.LPWSTR,ctypes.POINTER(wintypes.DWORD)]
 kernel.CloseHandle.argtypes=[wintypes.HANDLE]
 snapshot=kernel.CreateToolhelp32Snapshot(2,0)
 if snapshot in (None,ctypes.c_void_p(-1).value):return []
 found=[];entry=ProcessEntry();entry.dwSize=ctypes.sizeof(entry)
 try:
  present=kernel.Process32FirstW(snapshot,ctypes.byref(entry))
  while present:
   if entry.szExeFile.casefold() in {name.casefold() for name in EXECUTABLES}:
    handle=kernel.OpenProcess(0x1000,False,entry.th32ProcessID)
    if handle:
     try:
      buffer=ctypes.create_unicode_buffer(32768);size=wintypes.DWORD(len(buffer))
      if kernel.QueryFullProcessImageNameW(handle,0,buffer,ctypes.byref(size)):found.append(buffer.value)
     finally:kernel.CloseHandle(handle)
   present=kernel.Process32NextW(snapshot,ctypes.byref(entry))
 finally:kernel.CloseHandle(snapshot)
 return found

def default_paths():
 paths=[]
 for name in ('ProgramFiles','ProgramFiles(x86)','LOCALAPPDATA'):
  root=os.environ.get(name)
  if root:
   for folder,exe in (('Weixin','Weixin.exe'),('WeChat','WeChat.exe')):paths.append(str(pathlib.Path(root)/'Tencent'/folder/exe))
 return paths

def file_version(path):
 if os.name!='nt':raise OSError('本机微信安装检测仅支持Windows')
 import ctypes
 from ctypes import wintypes
 class FixedInfo(ctypes.Structure):
  _fields_=[(field,wintypes.DWORD) for field in ('signature','structure','fileMS','fileLS','productMS','productLS','flagsMask','flags','os','type','subtype','dateMS','dateLS')]
 api=ctypes.WinDLL('version',use_last_error=True)
 api.GetFileVersionInfoSizeW.argtypes=[wintypes.LPCWSTR,ctypes.POINTER(wintypes.DWORD)];api.GetFileVersionInfoSizeW.restype=wintypes.DWORD
 api.GetFileVersionInfoW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,ctypes.c_void_p]
 api.VerQueryValueW.argtypes=[ctypes.c_void_p,wintypes.LPCWSTR,ctypes.POINTER(ctypes.c_void_p),ctypes.POINTER(wintypes.UINT)]
 unused=wintypes.DWORD();size=api.GetFileVersionInfoSizeW(str(path),ctypes.byref(unused))
 if not size or size>4_000_000:raise OSError('无法读取微信版本信息')
 buffer=ctypes.create_string_buffer(size)
 if not api.GetFileVersionInfoW(str(path),0,size,buffer):raise OSError('无法读取微信版本信息')
 pointer=ctypes.c_void_p();length=wintypes.UINT()
 if not api.VerQueryValueW(buffer,'\\',ctypes.byref(pointer),ctypes.byref(length)) or length.value<ctypes.sizeof(FixedInfo):raise OSError('微信版本信息无效')
 value=ctypes.cast(pointer,ctypes.POINTER(FixedInfo)).contents
 if value.signature!=0xFEEF04BD:raise OSError('微信版本信息无效')
 return '.'.join(str(n) for n in (value.fileMS>>16,value.fileMS&65535,value.fileLS>>16,value.fileLS&65535))

def discover(explicit=None,*,running=None,candidates=None,exists=None,version_reader=file_version):
 if explicit and pathlib.PureWindowsPath(str(explicit)).name.casefold() not in {name.casefold() for name in EXECUTABLES}:return {'status':'blocked','code':'wechat_path','message':'请选择 Weixin.exe 或 WeChat.exe。','installations':[]}
 exists=exists or (lambda p:pathlib.Path(p).is_file())
 running=running_paths() if running is None else running
 candidates=registry_paths()+default_paths() if candidates is None else candidates
 def unique(paths):
  result=[];seen=set()
  for path in paths:
   key=str(path).casefold()
   if key not in seen and exists(path):seen.add(key);result.append(str(path))
  return result
 paths=unique([explicit]) if explicit else unique(running) or unique(candidates)
 if not paths:return {'status':'blocked','code':'wechat_missing','message':'未找到微信程序，请在连接设置中选择微信安装位置。','installations':[]}
 installs=[]
 for path in paths:
  try:version=version_reader(path)
  except (OSError,ValueError,ImportError):version=''
  installs.append({'path':path,'version':version,'running':str(path).casefold() in {str(p).casefold() for p in running}})
 if len(installs)!=1:return {'status':'blocked','code':'wechat_ambiguous','message':'发现多个微信安装，请明确选择要接入的程序和账号。','installations':installs}
 if not installs[0]['version']:return {'status':'blocked','code':'version_unknown','message':'无法读取所选微信的版本，未猜测兼容性。','installations':installs}
 return {'status':'detected','code':'ok','message':'已识别微信程序；这不表示微信接口已经连接。','installations':installs,'version':installs[0]['version']}

def report(provider='hook_http',*,discovery=None,background=True,groups=True):
 discovery=discover() if discovery is None else discovery
 version=discovery.get('version','') if discovery.get('status')=='detected' else ''
 matrix=[]
 for key,entry in PROVIDERS.items():
  state=readiness(key,wechat_version=version,groups=groups,background=background)
  matrix.append({'id':key,'name':entry.title,'requiresDesktop':None if entry.background is None else not entry.background,'personalDelegation':entry.personal,'groupSupport':entry.groups,'stage':entry.stage,'source':entry.source,'check':state})
 selected=next((row['check'] for row in matrix if row['id']==provider),readiness(provider))
 if provider in ('desktop','hook_http') and discovery.get('status')!='detected':selected={key:value for key,value in discovery.items() if key!='installations'}
 return {'schemaVersion':1,'wechat':discovery,'selectedProvider':provider,'connection':selected,'providers':matrix,'desktopActions':0,'modelRequests':0,'messageReads':0,'messageSends':0,'notes':['文档支持、原型通过与真实收发验收是不同状态。','微信接口Token与模型API Key分别配置。','后台接口失败时不会自动改成操纵桌面。']}

def main():
 parser=argparse.ArgumentParser(description='回声通用微信连接检查（不发送消息）')
 parser.add_argument('--provider',choices=list(PROVIDERS),default='hook_http')
 parser.add_argument('--wechat-exe',help='显式选择微信程序，支持不同安装盘和目录')
 parser.add_argument('--probe-local',action='store_true',help='仅检查兼容Hook的本机健康接口')
 parser.add_argument('--local-url',default='http://127.0.0.1:30001')
 parser.add_argument('--output',help='保存不含聊天与密钥的诊断JSON')
 args=parser.parse_args();result=report(args.provider,discovery=discover(args.wechat_exe))
 if args.probe_local:
  from local_hook_client import LocalHookClient,BackendError
  if args.provider!='hook_http':result['localProbe']={'status':'blocked','code':'probe_scope','message':'本机探测仅适用于Hook候选接口。'}
  elif result['wechat'].get('status')!='detected':result['localProbe']={'status':'blocked','code':'wechat_detection','message':'尚未明确微信安装和版本，未连接接口。'}
  else:
   try:result['localProbe']=LocalHookClient(args.local_url,version_reader=lambda:result['wechat']['version']).inspect()
   except BackendError as error:result['localProbe']={'status':'blocked','code':error.code,'message':str(error)}
 blob=json.dumps(result,ensure_ascii=False,indent=2)
 if args.output:pathlib.Path(args.output).write_text(blob+'\n',encoding='utf-8')
 if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
 print(blob)
 return 0 if result['connection']['status']=='ready' else 2

if __name__=='__main__':raise SystemExit(main())
