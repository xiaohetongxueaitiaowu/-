"""Optional Windows OCR; uses the already installed SDK, no model upload."""
import asyncio
import json
import pathlib
import sys
import subprocess
import os
import wave
import re

SPEECH_SCRIPT=r'''
[Console]::InputEncoding = [System.Text.Encoding]::UTF8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference='Stop'
try {
    Add-Type -AssemblyName System.Speech
    $echoInput=[Console]::In.ReadToEnd() | ConvertFrom-Json
    $echoInfo=[System.Speech.Recognition.SpeechRecognitionEngine]::InstalledRecognizers() | Where-Object {$_.Culture.Name -eq $echoInput.language} | Select-Object -First 1
    if ($null -eq $echoInfo) {throw 'Windows 未安装所选语言的本机语音识别引擎'}
    $echoEngine=New-Object -TypeName System.Speech.Recognition.SpeechRecognitionEngine -ArgumentList $echoInfo.Id
    try {
        $echoEngine.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar))
        $echoEngine.SetInputToWaveFile($echoInput.path)
        $echoLines=New-Object System.Collections.Generic.List[string]
        while ($true) {
            try {$echoResult=$echoEngine.Recognize()}
            catch {if ($echoLines.Count -gt 0 -and $echoEngine.AudioState -eq [System.Speech.Recognition.AudioState]::Stopped) {break};throw}
            if ($null -eq $echoResult) {break}
            $echoLines.Add($echoResult.Text)
        }
        @{text=($echoLines -join ' ');language=$echoInfo.Culture.Name} | ConvertTo-Json -Compress
    } finally {$echoEngine.Dispose()}
} catch {@{error=$_.Exception.Message} | ConvertTo-Json -Compress;exit 2}
'''

def transcribe(path,language='zh-CN'):
    if language not in ('zh-CN','en-US'): raise ValueError('请选择中文或英文')
    with wave.open(str(path),'rb') as audio:
        if audio.getnframes()/audio.getframerate()>60: raise ValueError('语音超过 60 秒，请先拆分')
        if audio.getnchannels()>2 or audio.getsampwidth()!=2: raise ValueError('请使用 16 位 PCM WAV 文件')
    executable=pathlib.Path(os.environ.get('SystemRoot',r'C:\Windows'))/'System32/WindowsPowerShell/v1.0/powershell.exe'
    result=subprocess.run([str(executable),'-NoProfile','-NonInteractive','-Command',SPEECH_SCRIPT],
        input=json.dumps({'path':str(path),'language':language},ensure_ascii=False),capture_output=True,
        text=True,encoding='utf-8',timeout=90,creationflags=subprocess.CREATE_NO_WINDOW)
    output=json.loads(result.stdout.lstrip('\ufeff'))
    if result.returncode or output.get('error'): raise ValueError(output.get('error','本机语音识别未完成'))
    return output

async def recognize(path):
    from winsdk.windows.storage import StorageFile, FileAccessMode
    from winsdk.windows.graphics.imaging import BitmapDecoder, BitmapPixelFormat, BitmapAlphaMode
    from winsdk.windows.media.ocr import OcrEngine
    file=await StorageFile.get_file_from_path_async(str(path))
    stream=await file.open_async(FileAccessMode.READ)
    decoder=await BitmapDecoder.create_async(stream)
    if decoder.pixel_width>4000 or decoder.pixel_height>4000: raise ValueError('图片边长超过 4000，请先缩小')
    bitmap=await decoder.get_software_bitmap_async(BitmapPixelFormat.BGRA8, BitmapAlphaMode.PREMULTIPLIED)
    engine=OcrEngine.try_create_from_user_profile_languages()
    if engine is None: raise ValueError('Windows 未安装可用的文字识别语言')
    result=await engine.recognize_async(bitmap)
    text=re.sub(r'(?<=[\u4e00-\u9fff])[ \t]+(?=[\u4e00-\u9fff])','',result.text)
    # OCR sometimes separates the individual digits in "17" into "1 7".
    # Restrict joining to runs of single digits; do not join "2026 10".
    return re.sub(r'(?<!\d)(?:\d[ \t]+)+\d(?!\d)',lambda m:re.sub(r'[ \t]+','',m.group()),text)

def main(value):
    path=pathlib.Path(value['path']).resolve()
    if not path.is_file() or path.suffix.lower() not in ('.png','.jpg','.jpeg','.bmp','.wav'):
        raise ValueError('请选择 PNG/JPG/BMP 图片或 WAV 语音')
    if path.stat().st_size>10*1024*1024: raise ValueError('图片超过 10MB，请先缩小')
    if path.suffix.lower()=='.wav':return transcribe(path,value.get('language','zh-CN'))
    return {'text':asyncio.run(recognize(path))}

if __name__=='__main__':
    try: print(json.dumps(main(json.load(sys.stdin)),ensure_ascii=False))
    except Exception as error:
        print(json.dumps({'error':str(error)},ensure_ascii=False));sys.exit(2)
