"""Native batch picker metadata only; no messages, model or sending APIs."""
import contextlib
import gc
import io
import json
import pathlib
import tempfile
import sys
from wechat_identity import make_db
import assistant_features as features

def catalog(db,kind='all'):
    if kind not in ('all','friend','group'):raise ValueError('请选择好友或群')
    conn=db._contact_conn()
    if conn is None:raise ValueError('无法读取联系人，请确认电脑微信已登录')
    try:
        columns={r[1] for r in conn.execute('PRAGMA table_info(contact)')}
        if 'local_type' not in columns:raise ValueError('当前版本无法确认好友分类；请手动批量填写')
        predicate='local_type IN (1,2)' if kind=='all' else 'local_type=?'
        args=() if kind=='all' else (1 if kind=='friend' else 2,)
        rows=conn.execute('SELECT username,nick_name,remark,alias,local_type FROM contact WHERE '+predicate+(' AND delete_flag=0' if 'delete_flag' in columns else '')+' ORDER BY remark,nick_name,username',args).fetchall()
    finally:conn.close()
    items=[];seen=set()
    for source in rows:
        row=dict(source);user=str(row.get('username') or '')
        if not user or user in (db.wxid,'filehelper') or user.startswith(('gh_','@')) or user in seen:continue
        category='group' if user.endswith('@chatroom') else 'friend'
        if kind!='all' and category!=kind:continue
        if category=='friend' and int(row['local_type'])!=1:continue
        if category=='friend' and not (row.get('nick_name') or row.get('remark') or row.get('alias')):continue
        seen.add(user)
        items.append({'identifier':user,'label':row.get('remark') or row.get('nick_name') or user,
                      'nickname':row.get('nick_name') or '', 'alias':row.get('alias') or '', 'kind':category})
    return {'items':items,'account':db.wxid,'requestedKind':kind,'chatContentRead':False,'modelRequests':0}

def main():
    import argparse
    parser=argparse.ArgumentParser();parser.add_argument('--kind',choices=('friend','group'),default='friend')
    kind=parser.parse_args().kind
    db=None
    try:
        with tempfile.TemporaryDirectory(prefix='echo_contact_picker_') as folder:
            try:
                with contextlib.redirect_stdout(io.StringIO()),contextlib.redirect_stderr(io.StringIO()):
                    db=make_db(workdir=folder)
                    result=catalog(db,kind)
                    config=features.settings();mapping={}
                    for entry in list(config.get('friends') or [])+list(config.get('groupEntries') or []):
                        identifier=entry.get('identifier','')
                        matches=[x['identifier'] for x in result['items'] if identifier in (x['identifier'],x['label'],x['nickname'],x['alias'])]
                        if len(set(matches))==1:mapping[identifier]=matches[0]
                    if mapping:features.bind_contacts(mapping,result['account'])
            finally:db=None;gc.collect()
        print(json.dumps(result,ensure_ascii=False))
        return 0
    except Exception as error:
        print(json.dumps(__import__('error_diagnostics').payload(error,'wechat'),ensure_ascii=False),file=sys.stderr)
        return 1

if __name__=='__main__':sys.exit(main())
