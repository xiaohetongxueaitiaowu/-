"""QR personal WeChat runtime. Protocol IO only; no native UI imports/actions."""
import concurrent.futures,hashlib,json,queue,sys,threading,time
from wechat_scan_connect import ScanConnection
from personal_wechat_session import PersonalSessionStore
from personal_wechat_web import contact_kind
from personal_web_database import WebDatabase,canonical,number
from ilink_background_client import ReplyLedger
from wechat_direct_probe import ProbeError
from wechat_bridge import ask_deepseek,in_quiet_hours,allowed_text,INTRO,write_state
from reply_policy import needs_owner,safe_output
import assistant_features as features
import activity_feed,runtime_health as health

def resolve(client,config):
    targets={};mapping={};blocked={x.strip() for x in str(config.get('blocked','')).replace('，',',').replace('\n',',').split(',')}
    for entry in config.get('friends') or []:
        if not isinstance(entry,dict) or not config.get('privateEnabled'):continue
        if config.get('contactMode')==1 and entry.get('starred') is not True:continue
        identifier=entry.get('identifier');label=entry.get('label') or identifier
        if not isinstance(identifier,str) or not identifier or identifier in blocked or label in blocked:continue
        # Both fields were explicitly supplied by the owner. No substring search.
        matches=[u for u,row in client.contacts.items() if contact_kind(row,client.owner)=='private' and
                 (identifier in (u,canonical(client.account,u),row.get('Alias'),row.get('RemarkName'),row.get('NickName')) or
                  label in (row.get('RemarkName'),row.get('NickName')))]
        if len(matches)!=1:continue
        u=matches[0]
        if u in blocked or canonical(client.account,u) in blocked:continue
        mode=entry.get('replyMode','record')
        if mode not in ('auto','draft','record'):mode='record'
        if u in targets:
            old=targets[u]['replyMode'];mode=max((old,mode),key={'auto':0,'draft':1,'record':2}.get)
        targets[u]={**entry,'label':label,'replyMode':mode};mapping[identifier]=canonical(client.account,u)
    return targets,mapping

def record_selection(client,config):
    selected=set()
    for entry in (config.get('friends') or [])+(config.get('groupEntries') or []):
        if not isinstance(entry,dict):continue
        identifier=entry.get('identifier');label=entry.get('label') or identifier
        if not isinstance(identifier,str) or not identifier:continue
        matches=[u for u,row in client.contacts.items() if contact_kind(row,client.owner) in ('private','group') and
                 (identifier in (u,canonical(client.account,u),row.get('Alias'),row.get('RemarkName'),row.get('NickName')) or
                  label in (row.get('RemarkName'),row.get('NickName')))]
        if len(matches)==1:selected.add(matches[0])
    return selected

def managed_mapping(client,config):
    bindings={}
    for entry in (config.get('friends') or [])+(config.get('groupEntries') or []):
        if not isinstance(entry,dict) or not entry.get('identifier'):continue
        matches=record_selection(client,{'friends':[entry]})
        if len(matches)==1:bindings[entry['identifier']]=canonical(client.account,next(iter(matches)))
    return bindings

class Replies:
    def __init__(self,client,store,identity,config,ledger,*,model=ask_deepseek,feed=activity_feed,clock=time.time):
        self.client=client;self.store=store;self.identity=identity;self.config=config;self.ledger=ledger
        self.model=model;self.feed=feed;self.clock=clock;self.targets,self.mapping=resolve(client,config)
        self.paused=set();self.history={};self.introduced=set();self.pending={};self.completed=queue.Queue();self.stop=threading.Event();self.processed=set();self.receipts={};self.approvals=queue.Queue()
        self.guard=threading.RLock();self.pool=concurrent.futures.ThreadPoolExecutor(max_workers=2)
        self.record=lambda rows:None
        self.session='personal-web:'+client.account+':'+identity
        self.fingerprint=hashlib.sha256(json.dumps(config,sort_keys=True,ensure_ascii=False).encode()).hexdigest()
        self.takeover_path=store.connection.folder/'账号'/client.account/'人工接管.bin'
        try:
            saved=store.connection.decrypt(self.takeover_path.read_bytes());self.paused=set(saved.get('paused',[]));self.introduced=set(saved.get('introduced',[]))
        except FileNotFoundError:pass
        except Exception:raise ProbeError('credentials','无法恢复人工接管状态，已拒绝自动回复。') from None
    def save_pause(self):
        self.takeover_path.parent.mkdir(parents=True,exist_ok=True);temp=self.takeover_path.with_suffix('.new')
        temp.write_bytes(self.store.connection.encrypt({'paused':sorted(self.paused),'introduced':sorted(self.introduced)}));temp.replace(self.takeover_path)
    def key(self,item):return canonical(self.client.account,item.conversation),item.created_ms,number(item.message_id)
    def pause(self,user):
        self.paused.add(user);self.pending.pop(user,None);features.cancel_drafts(user=canonical(self.client.account,user));self.save_pause()
    def permitted(self,item):
        target=self.targets.get(item.conversation)
        return bool(target and target['replyMode'] in ('auto','draft') and self.config.get('enabled') is True and
             not self.stop.is_set() and item.conversation not in self.paused and
             self.store.active(self.identity,self.client.account) and not in_quiet_hours(self.config) and
             item.role=='OTHER' and item.message_type==1 and self.client.latest.get(item.conversation)==item and
             item.conversation in resolve(self.client,self.config)[0] and not needs_owner(item.text))
    def receive(self,items,baseline):
        for item in items:
            if item.account!=self.client.account or item.created_ms<=baseline*1000:continue
            identity=(item.conversation,item.message_id)
            if identity in self.processed:continue
            if len(self.processed)>10000:raise ProbeError('capacity','本次处理索引已满，请重新运行；未重复回复。')
            self.processed.add(identity)
            target=self.targets.get(item.conversation)
            if not target:continue
            user=item.conversation;label=target['label'];key=self.key(item)
            if item.role=='SELF':
                if not item.bot_echo:self.pause(user)
                else:
                    known=self.receipts.get((user,item.message_id))
                    if known:self.feed.status(*known,'AUTO_SENT');continue
                self.history.setdefault(user,[]).append({'role':'assistant','content':item.text});continue
            if item.role!='OTHER':continue
            self.feed.received(*key,label,label,item.text,item.created_ms/1000)
            self.history.setdefault(user,[]).append({'role':'user','content':item.text})
            self.history[user]=self.history[user][-30:]
            if item.message_type!=1:self.feed.status(*key,'MEDIA_UNSUPPORTED');continue
            if target['replyMode']=='record':self.feed.status(*key,'RECORDED');continue
            if user in self.paused:self.feed.status(*key,'PAUSED');continue
            if in_quiet_hours(self.config):self.feed.status(*key,'QUIET');continue
            if needs_owner(item.text):self.pause(user);self.feed.status(*key,'NEED_OWNER');continue
            if not allowed_text(self.config,item.text) or len(item.text)>6000:self.feed.status(*key,'SKIPPED');continue
            if not self.permitted(item):continue
            self.pending[user]=item;self.feed.status(*key,'QUEUED')
            local=dict(self.config);mapped=canonical(self.client.account,user)
            local['prompt']=str(local.get('prompt',''))+'\n只回答最后一条来信，不重新回答历史问题，不重复自我介绍。程序会在首次回复中补齐身份说明。'
            local['_resolvedLabels']={mapped:label}
            local['contactPersonas']={mapped:(self.config.get('contactPersonas') or {}).get(target['identifier'],'')}
            prior=self.history[user][:-1]
            def generate(message=item,cfg=local,history=list(prior),public=mapped):
                try:
                    memory=''
                    if cfg.get('useMemory') is True and __import__('scope_policy').allowed(public,cfg,'report'):
                        from memory_manager import memory_excerpt
                        # Canonical IDs bind references to the authenticated
                        # account. Old label-only analyses cannot cross logins.
                        memory=memory_excerpt(self.targets[message.conversation]['label'],public)
                        manual=features.memory_data([public],int(cfg.get('memoryContextChars',1200)))
                        if manual:memory+='\n主人编辑的记忆（推测不是事实）：'+json.dumps(manual,ensure_ascii=False)
                    self.completed.put((message,self.model(cfg,message.text,history,memory=memory,user=public),None))
                except Exception as error:self.completed.put((message,None,error))
            self.pool.submit(generate)
    def finish(self):
        while not self.completed.empty():
            item,answer,error=self.completed.get_nowait();user=item.conversation;key=self.key(item)
            if self.pending.get(user)!=item or not self.permitted(item):self.feed.status(*key,'CANCELLED');continue
            self.pending.pop(user,None)
            if error is not None:health.failure('model',error,'model');self.feed.status(*key,'SKIPPED');continue
            if user not in self.introduced:answer=INTRO+'\n'+str(answer).removeprefix(INTRO).strip()
            if not safe_output(answer):self.pause(user);self.feed.status(*key,'NEED_OWNER');continue
            if self.targets[user]['replyMode']=='draft':
                task=(key[0],self.targets[user]['label'],item.text,key[1],key[2])
                features.create_draft(task,answer,self.session,self.fingerprint)
                self.feed.status(*key,'DRAFT_PENDING');continue
            # Final protocol sync observes owner messages that arrived during
            # model work. Read/sync is serialized, never desktop automation.
            with self.guard:
                rows=self.client.get_updates()['messages'];self.record(rows);self.store.persist(self.identity,self.client)
                self.receive(rows,0)
                if not self.permitted(item):self.feed.status(*key,'CANCELLED');continue
                try:
                    receipt=self.client.queue_text(user,answer,event_id=item.message_id,ledger=self.ledger,authorize=lambda:self.permitted(item))
                    self.receipts[(user,receipt['serverMessageId'])]=key
                    self.introduced.add(user);self.save_pause();self.store.persist(self.identity,self.client)
                    self.history.setdefault(user,[]).append({'role':'assistant','content':answer})
                    self.history[user]=self.history[user][-30:]
                    self.feed.status(*key,'SERVER_ACCEPTED')
                except Exception as error:
                    self.pause(user);health.failure('wechat',error,'wechat');self.feed.status(*key,'SEND_FAILED')
    def approve(self,command):
        identifier=str(command.get('id') or '')
        try:
            task,answer=features.take_draft(identifier,self.session,self.fingerprint,command.get('answer'))
            with self.guard:
                rows=self.client.get_updates()['messages'];self.record(rows);self.store.persist(self.identity,self.client);self.receive(rows,0)
                item=next((x for x in self.client.events.values() if self.key(x)==(task[0],task[3],task[4])),None)
                if item is None or not self.permitted(item) or not safe_output(answer):raise ProbeError('authorization','草稿对应的消息或当前发送条件已改变。')
                receipt=self.client.queue_text(item.conversation,answer,event_id=item.message_id,ledger=self.ledger,authorize=lambda:self.permitted(item))
                self.receipts[(item.conversation,receipt['serverMessageId'])]=self.key(item);self.store.persist(self.identity,self.client)
                self.introduced.add(item.conversation);self.save_pause()
                self.history.setdefault(item.conversation,[]).append({'role':'assistant','content':answer})
                features.finish_draft(identifier,'sent');self.feed.status(*self.key(item),'SERVER_ACCEPTED')
        except Exception:
            features.finish_draft(identifier,'cancelled');print('此条草稿未发送：消息或发送授权已改变，请重新生成。',flush=True)
    def close(self):self.stop.set();self.pending.clear();features.cancel_drafts(session=self.session);self.pool.shutdown(wait=False,cancel_futures=True)

def run(config):
    if config.get('enabled') is not True:raise ProbeError('configuration','当前设置未启用运行。')
    controller=ScanConnection();identity=controller.decrypt(controller.path.read_bytes()).get('id')
    store=PersonalSessionStore(controller);client=store.restore(identity)
    engine=Replies(client,store,identity,config,ReplyLedger(controller.folder/'单次发送.sqlite'))
    database=WebDatabase(client)
    selected_records=record_selection(client,config)
    def record(rows):
        database.update_contacts(client)
        database.record(rows,config,record_selection(client,config))
        bindings=managed_mapping(client,config)
        temporary=(features.DATA/'contact-map.json').with_suffix('.new')
        temporary.write_text(json.dumps({'account':database.wxid,'identifiers':bindings},ensure_ascii=False),encoding='utf-8');temporary.replace(features.DATA/'contact-map.json')
    engine.record=record
    # Bind scope without migrating memories from a different login account.
    path=features.DATA/'contact-map.json';path.write_text(json.dumps({'account':database.wxid,'identifiers':managed_mapping(client,config)},ensure_ascii=False),encoding='utf-8')
    initial=client.get_updates()['messages'];database.record(initial,config,selected_records);store.persist(identity,client)
    baseline=time.time();write_state('starting',len(engine.targets),read_success=True)
    def commands():
        for line in sys.stdin:
            if line.strip()=='stop':engine.stop.set();break
            try:
                command=json.loads(line)
                if command.get('command')=='resume':
                    target=next((u for u,e in engine.targets.items() if command.get('identifier')==e['identifier']),None)
                    if target:engine.paused.discard(target);engine.save_pause()
                elif command.get('command')=='approve':
                    engine.approvals.put(command)
            except (ValueError,AttributeError):pass
        engine.stop.set()
    threading.Thread(target=commands,daemon=True).start()
    print('已连接微信后台。按当前设置监听 '+str(len(engine.targets))+' 位已核验好友；不操作微信窗口，旧消息不补发。',flush=True)
    if config.get('groupEnabled'):print('当前扫码路线的群自动回复尚未验收，群只记录；没有改用桌面发送。',flush=True)
    incoming=queue.Queue();failures=queue.Queue();last_state=0
    def receiver():
        try:
            while not engine.stop.is_set() and store.active(identity,client.account):
                changed=client.check_updates()
                if engine.stop.is_set() or not store.active(identity,client.account):break
                if changed:
                    with engine.guard:
                        rows=client.get_updates()['messages'];record(rows);store.persist(identity,client);incoming.put(rows)
                import wechat_bridge as legacy
                legacy.LAST_READ_AT=int(time.time())
                health.update('wechat','ok',lastReadAt=legacy.LAST_READ_AT,phase='个人微信扫码后台')
        except Exception as error:failures.put(error)
    threading.Thread(target=receiver,daemon=True).start()
    try:
        while not engine.stop.is_set() and store.active(identity,client.account):
            if not failures.empty():raise failures.get_nowait()
            with engine.guard:
                while not incoming.empty():engine.receive(incoming.get_nowait(),baseline)
            while not engine.approvals.empty():engine.approve(engine.approvals.get_nowait())
            import wechat_bridge as legacy
            legacy.REPLY_OVERVIEW={'autoReplyConversations':sum(x['replyMode']=='auto' and u not in engine.paused for u,x in engine.targets.items()),
                'pausedConversations':len(engine.paused),'privateConversations':len(engine.targets),'groupConversations':0,'background':True,'oldMessagesReplied':False}
            legacy.REPLY_OVERVIEW['pausedLabels']=[engine.targets[u]['label'] for u in engine.paused if u in engine.targets]
            legacy.REPLY_OVERVIEW['groupReplySupported']=False
            if time.monotonic()-last_state>=1:
                write_state('listening',len(engine.targets));last_state=time.monotonic()
            engine.finish();engine.stop.wait(.1)
    finally:engine.close();health.update('wechat','stopped');write_state('stopped')

if __name__=='__main__':
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    try:run(json.loads(sys.stdin.readline(2000001)))
    except Exception as error:
        health.failure('wechat',error,'wechat');print('微信后台启动未完成：'+str(error)[:160] if isinstance(error,ProbeError) else '微信后台启动未完成，请查看首页连接原因。',flush=True)
        write_state('error');raise SystemExit(2)
