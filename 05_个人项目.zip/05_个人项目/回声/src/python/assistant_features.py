"""Small local state store: drafts, editable memories and bounded diagnostics."""
from contextlib import contextmanager
import datetime as dt
import json
import pathlib
import sqlite3
import time
import uuid
import threading
import os

from echo_paths import DATA
_INIT_LOCK=threading.Lock()
_READY=set()

@contextmanager
def database():
    DATA.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DATA / 'assistant-state.sqlite'), timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute('PRAGMA busy_timeout=10000')
        path=str((DATA/'assistant-state.sqlite').resolve())
        with _INIT_LOCK:
            if path not in _READY or conn.execute('PRAGMA schema_version').fetchone()[0]==0:
                for attempt in range(10):
                    try:
                        if conn.execute('PRAGMA journal_mode').fetchone()[0]!='wal':conn.execute('PRAGMA journal_mode=WAL')
                        break
                    except sqlite3.OperationalError as error:
                        if 'locked' not in str(error) or attempt==9:raise
                        time.sleep(.05*(attempt+1))
                conn.executescript('''
          CREATE TABLE IF NOT EXISTS drafts(id TEXT PRIMARY KEY,user TEXT,label TEXT,source TEXT,answer TEXT,
             seq INTEGER,local_id INTEGER,session TEXT,config TEXT,created REAL,status TEXT);
          CREATE TABLE IF NOT EXISTS memories(id TEXT PRIMARY KEY,identifier TEXT,kind TEXT,text TEXT,
             source TEXT,updated TEXT);
          CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,at TEXT,kind TEXT,detail TEXT);
          CREATE TABLE IF NOT EXISTS usage(day TEXT PRIMARY KEY,calls INTEGER,cost REAL,reserved REAL,cache INTEGER);
          CREATE TABLE IF NOT EXISTS memory_options(identifier TEXT PRIMARY KEY,relation TEXT,depth TEXT);
                ''')
                _READY.add(path)
        yield conn
        conn.commit()
    finally:
        conn.close()

def event(kind, detail):
    with database() as conn:
        conn.execute('INSERT INTO events(at,kind,detail) VALUES(?,?,?)',
                     (dt.datetime.now().isoformat(timespec='seconds'),kind,str(detail)[:240]))
        conn.execute('DELETE FROM events WHERE id NOT IN (SELECT id FROM events ORDER BY id DESC LIMIT 200)')

def expire_drafts(conn):
    conn.execute("UPDATE drafts SET status='expired' WHERE status='pending' AND created<?",(time.time()-900,))
    conn.execute('DELETE FROM drafts WHERE created<?',(time.time()-7*86400,))

def create_draft(task, answer, session, fingerprint):
    with database() as conn:
        expire_drafts(conn)
        conn.execute("UPDATE drafts SET status='superseded' WHERE user=? AND status='pending'",(task[0],))
        identifier = uuid.uuid4().hex
        conn.execute('INSERT INTO drafts VALUES(?,?,?,?,?,?,?,?,?,?,?)',
                     (identifier,*task[:3],answer,task[3],task[4],session,fingerprint,time.time(),'pending'))
    return identifier

def cancel_drafts(user=None, session=None):
    with database() as conn:
        sql = "UPDATE drafts SET status='cancelled' WHERE status IN ('pending','approving')"
        if user is not None:
            sql += ' AND user=?'; value=user
        elif session is not None:
            sql += ' AND session=?'; value=session
        else:
            conn.execute(sql); return
        conn.execute(sql,(value,))

def take_draft(identifier, session, fingerprint, answer=None):
    with database() as conn:
        conn.execute('BEGIN IMMEDIATE')
        expire_drafts(conn)
        row = conn.execute("SELECT * FROM drafts WHERE id=? AND status='pending'",(identifier,)).fetchone()
        if not row or row['session']!=session or row['config']!=fingerprint:
            raise ValueError('草稿已过期、已处理或设置已改变，请重新生成')
        text = row['answer'] if answer is None else str(answer).strip()
        if not text or len(text)>2000:
            raise ValueError('草稿为空或超过 2000 字')
        conn.execute("UPDATE drafts SET status='approving',answer=? WHERE id=?",(text,identifier))
        return (row['user'],row['label'],row['source'],row['seq'],row['local_id']),text

def finish_draft(identifier,status):
    with database() as conn:
        conn.execute('UPDATE drafts SET status=? WHERE id=?',(status,identifier))

def memory_data(identifiers, limit=1200):
    with database() as conn:
        rows=[]
        for identifier in dict.fromkeys(identifiers):
            rows += list(conn.execute('SELECT kind,text,source,updated FROM memories WHERE identifier=? ORDER BY updated DESC',(identifier,)))
        result=[];used=0
        for row in rows:
            if used+len(row['text'])>limit: continue
            result.append(dict(row));used+=len(row['text'])
        return result

def settings():
    path=DATA/'settings.json'
    try:
        config=json.loads(path.read_text(encoding='utf-8-sig')) if path.exists() else {}
        return config if isinstance(config,dict) else {}
    except (OSError,ValueError):return {}

def bridge_snapshot():
    path=DATA/'bridge-state.json'
    try:
        state=json.loads(path.read_text(encoding='utf-8-sig')) if path.exists() else {}
        return state if isinstance(state,dict) else {'status':'unknown','lastError':'状态格式无效'}
    except (OSError,ValueError):return {'status':'unknown','lastError':'运行状态暂不可读'}

def reply_mode(config,identifier):
    for entry in list(config.get('friends') or [])+list(config.get('groupEntries') or []):
        if entry.get('identifier')==identifier:
            mode=entry.get('replyMode','auto')
            return mode if mode in ('auto','draft','record') else 'record'
    import re
    legacy = re.split(r'[,，\r\n]+', str(config.get('contacts',''))+'\n'+str(config.get('groups','')))
    return 'auto' if identifier in [x.strip() for x in legacy] else 'record'

def resolved_mode(config, identifiers, user):
    modes = [reply_mode(config, identifier) for identifier, target in identifiers.items() if target == user]
    return max(modes, key={'auto':0, 'draft':1, 'record':2}.get) if modes else 'record'

def bind_contacts(identifiers, account):
    with database() as conn:
        for alias,user in identifiers.items():
            if alias!=user:conn.execute('UPDATE memories SET identifier=? WHERE identifier=?',(user,alias))
            if alias!=user:
                conn.execute('INSERT OR IGNORE INTO memory_options SELECT ?,relation,depth FROM memory_options WHERE identifier=?',(user,alias))
                conn.execute('DELETE FROM memory_options WHERE identifier=?',(alias,))
    path=DATA/'contact-map.json';temporary=path.with_suffix('.tmp')
    try:
        previous=json.loads(path.read_text(encoding='utf-8-sig'))
        merged=dict(previous.get('identifiers') or {}) if previous.get('account')==account else {}
    except (OSError,ValueError,TypeError):merged={}
    merged.update(identifiers)
    temporary.write_text(json.dumps({'account':account,'identifiers':merged},ensure_ascii=False),encoding='utf-8')
    os.replace(temporary,path)

def contact_overview(conn):
    from echo_paths import STORAGE
    values={r['identifier']:dict(r) for r in conn.execute('SELECT identifier,relation,depth FROM memory_options')}
    for category in ('用户','群'):
        for file in (STORAGE/category).glob('*/联系人.json'):
            try:
                metadata=json.loads(file.read_text(encoding='utf-8-sig'));user=metadata['username']
                entry=values.setdefault(user,{'relation':'unspecified','depth':'auto'})
                folder=file.parent
                state=json.loads((folder/'分析状态.json').read_text(encoding='utf-8-sig')) if (folder/'分析状态.json').exists() else {}
                text=(folder/'整理状态.md').read_text(encoding='utf-8-sig') if (folder/'整理状态.md').exists() else ''
                entry.update(history=metadata.get('messageCount',state.get('messageCount',0)),status=text.replace('#','').strip().replace('\n',' ')[:140],
                    digest=(folder/'对话精炼.md').exists(),profile=(folder/'人物分析.md').exists(),updated=state.get('lastAnalyzedAt',''))
            except (OSError,ValueError,KeyError,TypeError):continue
    return values

def command(value):
    action=value.get('action','snapshot')
    with database() as conn:
        expire_drafts(conn)
        if action=='memory_save_many':
            identifier=str(value.get('identifier') or '').strip();texts=value.get('texts');kind=value.get('kind')
            if not identifier or kind not in ('事实','偏好','推测') or not isinstance(texts,list) or not texts or len(texts)>1000 or any(not isinstance(x,str) or not x.strip() or len(x.strip())>1200 for x in texts):raise ValueError('每行一条记忆，最多1000条，每条最多1200字')
            texts=list(dict.fromkeys(x.strip() for x in texts));now=dt.datetime.now().isoformat(timespec='seconds')
            conn.executemany('INSERT INTO memories VALUES(?,?,?,?,?,?)',[(uuid.uuid4().hex,identifier,kind,text,str(value.get('source') or '主人手动填写；非聊天原话')[:500],now) for text in texts])
            return {'ok':True,'changed':len(texts)}
        if action in ('reject_many','memory_delete_many','memory_kind_many','memory_options_many'):
            ids=value.get('ids')
            if not isinstance(ids,list) or not ids or len(ids)>20000 or any(not isinstance(x,str) or not x.strip() for x in ids):
                raise ValueError('请选择有效的批量对象（最多20000项）')
            ids=list(dict.fromkeys(ids))
            if action=='reject_many':
                before=conn.total_changes
                conn.executemany("UPDATE drafts SET status='rejected' WHERE id=? AND status='pending'",[(x,) for x in ids])
            elif action in ('memory_delete_many','memory_kind_many'):
                identifier=str(value.get('identifier') or '').strip()
                if not identifier:raise ValueError('缺少记忆所属联系人')
                kind=value.get('kind')
                if action=='memory_kind_many' and kind not in ('事实','偏好','推测'):raise ValueError('记忆分类无效')
                before=conn.total_changes
                if action=='memory_delete_many':conn.executemany('DELETE FROM memories WHERE id=? AND identifier=?',[(x,identifier) for x in ids])
                else:conn.executemany('UPDATE memories SET kind=?,updated=? WHERE id=? AND identifier=?',[(kind,dt.datetime.now().isoformat(timespec='seconds'),x,identifier) for x in ids])
            else:
                relation=value.get('relation');depth=value.get('depth')
                if relation not in ('unspecified','general','close','very_close') or depth not in ('auto','brief','detailed','deep'):raise ValueError('关系或分析深度无效')
                before=conn.total_changes
                conn.executemany('INSERT OR REPLACE INTO memory_options VALUES(?,?,?)',[(x,relation,depth) for x in ids])
            return {'ok':True,'changed':conn.total_changes-before}
        if action=='snapshot':
            day=dt.date.today().isoformat()
            return {'drafts':[dict(r) for r in conn.execute("SELECT * FROM drafts WHERE status='pending' ORDER BY created DESC")],
                    'events':[dict(r) for r in conn.execute('SELECT at,kind,detail FROM events ORDER BY id DESC LIMIT 30')],
                    'usage':dict(conn.execute('SELECT * FROM usage WHERE day=?',(day,)).fetchone() or {}),
                    'bridge':bridge_snapshot()}
        if action=='contact_map':
            path=DATA/'contact-map.json'
            result=json.loads(path.read_text(encoding='utf-8-sig')) if path.exists() else {'identifiers':{}}
            result['overview']=contact_overview(conn)
            return result
        if action=='reject':
            conn.execute("UPDATE drafts SET status='rejected' WHERE id=? AND status='pending'",(value['id'],));return {'ok':True}
        if action=='memory_list':
            return {'items':[dict(r) for r in conn.execute('SELECT * FROM memories WHERE identifier=? ORDER BY updated DESC',(value['identifier'],))],
                    'options':dict(conn.execute('SELECT relation,depth FROM memory_options WHERE identifier=?',(value['identifier'],)).fetchone() or {'relation':'unspecified','depth':'auto'})}
        if action=='memory_options':
            identifier=str(value.get('identifier') or '').strip()
            relation=value.get('relation');depth=value.get('depth')
            if not identifier or relation not in ('unspecified','general','close','very_close') or depth not in ('auto','brief','detailed','deep'):
                raise ValueError('请选择有效的联系人关系和分析深度')
            conn.execute('INSERT OR REPLACE INTO memory_options VALUES(?,?,?)',(identifier,relation,depth))
            return {'ok':True}
        if action=='memory_save':
            identifier=str(value['identifier']).strip();text=str(value['text']).strip()
            kind=value.get('kind')
            if not identifier or not text or len(text)>1200 or kind not in ('事实','偏好','推测'):
                raise ValueError('请填写联系人、分类及不超过 1200 字的记忆')
            mid=value.get('id') or uuid.uuid4().hex
            previous=conn.execute('SELECT identifier FROM memories WHERE id=?',(mid,)).fetchone()
            if previous and previous['identifier']!=identifier: raise ValueError('记忆所属联系人不匹配')
            conn.execute('INSERT OR REPLACE INTO memories VALUES(?,?,?,?,?,?)',(mid,identifier,kind,text,
                         str(value.get('source') or '主人手动填写；非聊天原话')[:500],dt.datetime.now().isoformat(timespec='seconds')))
            return {'ok':True}
        if action=='memory_delete':
            conn.execute('DELETE FROM memories WHERE id=? AND identifier=?',(value['id'],value['identifier']));return {'ok':True}
    raise ValueError('未知本机操作')


def memory_options(identifier):
    with database() as conn:
        return dict(conn.execute('SELECT relation,depth FROM memory_options WHERE identifier=?',(identifier,)).fetchone() or {'relation':'unspecified','depth':'auto'})

if __name__=='__main__':
    import sys
    try:
        print(json.dumps(command(json.load(sys.stdin)),ensure_ascii=False))
    except Exception as error:
        print(json.dumps(__import__('error_diagnostics').payload(error),ensure_ascii=False),file=sys.stderr);sys.exit(2)
