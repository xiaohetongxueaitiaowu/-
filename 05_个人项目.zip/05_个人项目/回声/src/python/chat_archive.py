"""Resolve the single archive for the explicitly selected WeChat connection."""
import assistant_features as features
from personal_web_database import configured,archive_path
from wechat_direct_probe import ProbeError

def current_path(required=False):
    if not configured():return features.DATA/'近两个月聊天.sqlite'
    try:return archive_path()
    except (OSError,ValueError,ProbeError):
        if required:raise ProbeError('login','请先扫码完成微信连接，再读取当前账号的聊天。') from None
        return None
