"""Account-scoped, sixty-day QR records. Compatible local analysis reader."""
from contextlib import closing
import hashlib,json,re,sqlite3,time
from pathlib import Path
from echo_paths import DATA
from personal_wechat_web import contact_kind
from wechat_direct_probe import ProbeError

def canonical(account,user):return 'web:'+account+':'+user+('@chatroom' if user.startswith('@@') else '')
def number(user):return int.from_bytes(hashlib.sha256(user.encode()).digest()[:8],'big')%(2**63-2)+1
def archive_path():
    pointer=json.loads((DATA/'微信扫码连接'/'当前账号.json').read_text('utf-8'))
    account=pointer.get('account')
    import re
    if not isinstance(account,str) or not re.fullmatch('[0-9a-f]{64}',account):raise ProbeError('identity','扫码账号记录缺少明确身份。')
    return DATA/'微信扫码连接'/'账号'/account/'聊天.sqlite'
def configured():
    try:return json.loads((DATA/'settings.json').read_text('utf-8-sig')).get('wechatConnection',{}).get('provider')=='personal_web'
    except (ValueError,OSError,AttributeError):return False

class WebDatabase:
    echo_identity_supported=True;web_archive=True;_MSG_ORDER_ASC='ASC'
    def __init__(self,client=None,**kwargs):
        if client is not None:
            if not re.fullmatch('[0-9a-f]{64}',str(client.account)) or not client.owner or not isinstance(client.contacts,dict):raise ProbeError('identity','后台存储需要已核验的本人身份。')
            folder=DATA/'微信扫码连接';folder.mkdir(parents=True,exist_ok=True)
            path=folder/'当前账号.json';temp=path.with_suffix('.new')
            temp.write_text(json.dumps({'account':client.account}),encoding='utf-8');temp.replace(path)
        self.path=archive_path();self.path.parent.mkdir(parents=True,exist_ok=True)
        with closing(sqlite3.connect(self.path)) as conn:
            conn.executescript('CREATE TABLE IF NOT EXISTS web_meta(key TEXT PRIMARY KEY,value TEXT);'
                'CREATE TABLE IF NOT EXISTS messages(id TEXT PRIMARY KEY,ts INTEGER,chat_id TEXT,chat_name TEXT,chat_type TEXT,sender_id TEXT,sender_name TEXT,sender_role TEXT,identity_state TEXT,msg_type TEXT,content TEXT,at_self INTEGER,raw_sender_num INTEGER DEFAULT 0,raw_blob BLOB,server_id TEXT,bot INTEGER DEFAULT 0);'
                'CREATE TABLE IF NOT EXISTS conversations(chat_id TEXT PRIMARY KEY,name TEXT,kind TEXT);'
                'CREATE INDEX IF NOT EXISTS web_time ON messages(ts);')
            if client is not None:
                saved={'account':client.account,'owner':client.owner,'contacts':client.contacts}
                conn.execute('INSERT OR REPLACE INTO web_meta VALUES(?,?)',('identity',json.dumps(saved,ensure_ascii=False)));conn.commit()
            row=conn.execute('SELECT value FROM web_meta WHERE key=?',('identity',)).fetchone()
            if not row:raise ProbeError('login','请先在回声扫码连接微信。')
            saved=json.loads(row[0])
        self.account=saved['account'];self.owner=saved['owner'];self.contacts=saved['contacts'];self.wxid=canonical(self.account,self.owner)
        if self.path.parent.name!=self.account or not re.fullmatch('[0-9a-f]{64}',self.account):raise ProbeError('identity','存储账号与当前账号不一致。')
        self.revision=getattr(client,'contact_revision',0) if client is not None else None
    def update_contacts(self,client):
        if client.account!=self.account or client.owner!=self.owner:raise ProbeError('identity','后台读取账号已改变。')
        revision=getattr(client,'contact_revision',0)
        if revision==self.revision:return
        saved={'account':client.account,'owner':client.owner,'contacts':client.contacts}
        with closing(sqlite3.connect(self.path)) as conn:
            conn.execute('INSERT OR REPLACE INTO web_meta VALUES(?,?)',('identity',json.dumps(saved,ensure_ascii=False)));conn.commit()
        self.contacts=dict(client.contacts);self.revision=revision
    def record(self,items,config,selected):
        if config.get('recordChats') is not True:return
        with closing(sqlite3.connect(self.path,timeout=15)) as conn:
            for item in items:
                if item.account!=self.account:raise ProbeError('identity','收到不同账号的聊天，未保存。')
                if config.get('recordScope')=='selected' and item.conversation not in selected:continue
                chat=canonical(self.account,item.conversation);sender=canonical(self.account,item.sender)
                names=self._nickname_index();kind='群聊' if item.kind=='group' else '私聊'
                mid=hashlib.sha256((chat+'|'+item.message_id).encode()).hexdigest()[:24]
                conn.execute('INSERT OR IGNORE INTO messages VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',
                    (mid,item.created_ms//1000,chat,names.get(chat,chat),kind,sender,names.get(sender,sender),
                     item.role.lower(),'verified' if item.role in ('SELF','OTHER') else 'unverified','文本' if item.message_type==1 else '媒体未解析',item.text,0,number(sender),None,item.message_id,int(item.bot_echo)))
                conn.execute('INSERT OR REPLACE INTO conversations VALUES(?,?,?)',(chat,names.get(chat,chat),kind))
            conn.execute('DELETE FROM messages WHERE ts<?',(int(time.time())-60*86400,));conn.commit()
    def _nickname_index(self):
        result={self.wxid:'我'}
        for user,row in self.contacts.items():
            result[canonical(self.account,user)]=row.get('RemarkName') or row.get('NickName') or user
            for member in row.get('MemberList',[]) or []:
                if isinstance(member,dict) and member.get('UserName'):result[canonical(self.account,member['UserName'])]=member.get('DisplayName') or member.get('NickName') or member['UserName']
        return result
    def _sender_id_index(self):
        names=self._nickname_index();return {number(user):user for user in names}
    def _contact_conn(self):
        # Metadata only, not a second copy of chat bodies. This keeps the
        # existing separate friend/group batch pickers usable after QR login.
        conn=sqlite3.connect(':memory:');conn.row_factory=sqlite3.Row
        conn.execute('CREATE TABLE contact(username TEXT,nick_name TEXT,remark TEXT,alias TEXT,local_type INTEGER,delete_flag INTEGER)')
        for user,row in self.contacts.items():
            kind=contact_kind(row,self.owner)
            if kind not in ('private','group'):continue
            conn.execute('INSERT INTO contact VALUES(?,?,?,?,?,0)',(canonical(self.account,user),row.get('NickName',''),row.get('RemarkName',''),row.get('Alias',''),1 if kind=='private' else 2))
        return conn
    def search_contact(self,text):
        rows=[]
        for user,row in self.contacts.items():
            public=canonical(self.account,user)
            if text not in (public,user,row.get('Alias'),row.get('RemarkName'),row.get('NickName')):continue
            rows.append({'username':public,'alias':row.get('Alias',''),'remark':row.get('RemarkName',''),'nick_name':row.get('NickName','')})
        return rows
    def get_groups(self):
        return [{'username':canonical(self.account,u),'name':r.get('NickName') or u,
                 'members':[{'username':canonical(self.account,m['UserName']),'nickname':m.get('NickName','')} for m in r.get('MemberList',[]) if isinstance(m,dict) and m.get('UserName')]}
                for u,r in self.contacts.items() if contact_kind(r,self.owner)=='group']
    def list_message_chats(self):
        with closing(sqlite3.connect(self.path)) as conn:chats=[x[0] for x in conn.execute('SELECT DISTINCT chat_id FROM messages')]
        names=self._nickname_index();return [{'username':u,'name':names.get(u,u)} for u in chats]
    def _rows(self,user,cutoff=0,upper=2**63-1,limit=None,descending=False):
        target=next((u for u in self.contacts if canonical(self.account,u)==user),None)
        if target is None:return []
        with closing(sqlite3.connect(self.path)) as conn:
            conn.row_factory=sqlite3.Row
            sql='SELECT rowid AS seq,* FROM messages WHERE chat_id=? AND ts>=? AND ts<? ORDER BY rowid '+('DESC' if descending else 'ASC')
            args=[user,cutoff,upper]
            if limit is not None:sql+=' LIMIT ?';args.append(int(limit))
            rows=[dict(x) for x in conn.execute(sql,args)]
        return [{'content':r['content'],'create_time':r['ts'],'sender_id':r['raw_sender_num'],
                 'sort_seq':r['seq'],'local_id':r['seq'],'server_id':r['server_id'],'type':r['msg_type'],'type_code':1 if r['msg_type']=='文本' else 0,'echo_sender_username':r['sender_id'],
                 'echo_sender_role':r['sender_role'].upper(),'echo_identity_version':'shard-v1','source':'','bot_echo':bool(r['bot'])} for r in rows]
    def get_messages(self,user,limit=100,**kwargs):return self._rows(user,limit=limit,descending=True)
    def verified_history(self,user):return self._rows(user)
    def _run_msg_query(self,user,build):return build([user])
    def _shard_rows(self,tables,where,params,**kwargs):return self._rows(tables[0],params[0],params[1])
    def _msg_row_to_dict(self,row):return row

