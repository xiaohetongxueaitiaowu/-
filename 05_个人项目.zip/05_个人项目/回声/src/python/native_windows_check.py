"""Minimal native Windows connection diagnosis. No input, injection or WSL."""
import json,sys
from local_hook_client import BackendError,LocalHookClient,SUPPORTED_VERSION
from wechat_connection_check import discover

def blocked(code,message,**extra):
    return {'status':'blocked','ready':False,'provider':'native_windows',
            'errorCode':code,'message':message,'desktopActions':0,'wechatSends':0,
            'modelRequests':0,'requiresDesktop':False,**extra}

def read_local_evidence():
    from echo_paths import DATA
    path=DATA/'native-background-acceptance.json'
    try:
        if path.stat().st_size>8192:return {}
        result=json.loads(path.read_text('utf-8-sig'))
        return result if isinstance(result,dict) else {}
    except (OSError,ValueError):return {}

def inspect(*,discovery=discover,client_factory=LocalHookClient,capability_reader=None,evidence_reader=read_local_evidence):
    try:
        detected=discovery()
        if detected.get('status')!='detected':
            return blocked('wechat_missing','尚未识别 Windows 微信，请安装并登录微信。')
        version=detected.get('version','')
        if version!=SUPPORTED_VERSION:
            evidence=evidence_reader()
            if (evidence.get('version')==version and evidence.get('method')=='uia_value_v1'
                and evidence.get('foregroundChanged') is True):
                return blocked('wechat_focus','当前微信 '+version+' 的后台控件写入曾在本机实测改变前台焦点，已停用这条发送路线。后台代管尚未通过；不会退回鼠标或按键发送。',
                    currentVersion=version,interfaceExposed=True,sendCapabilityExposed=True,
                    focusInvariantPassed=False,endToEndVerified=False)
            if capability_reader is None:
                from native_ui_capabilities import inspect as capability_reader
            capabilities=capability_reader()
            exposed=(capabilities.get('windows')==1 and capabilities.get('complete') is True
                     and capabilities.get('nativeNodes',0)>0)
            writable=(exposed and capabilities.get('inputValuePatterns',0)==1
                      and capabilities.get('sendInvokePatterns',0)>0)
            if writable:
                return blocked('wechat_send_unverified','当前微信 '+version+' 的后台控件可读取，尚未通过不抢焦点的跨账号发送验收；自动回复未启动。无需先更换版本。',
                    currentVersion=version,interfaceExposed=True,sendCapabilityExposed=True,
                    navigationVerified=False,endToEndVerified=False,capabilities=capabilities)
            return blocked('wechat_accessibility','当前微信 '+version+' 尚未提供可验证的后台发送控件。检查不会自动换版、切换窗口或操纵桌面；请查看当前连接诊断。',
                currentVersion=version,interfaceExposed=exposed,sendCapabilityExposed=False,
                endToEndVerified=False,capabilities=capabilities)
        client=client_factory(version_reader=lambda:version)
        connection=client.inspect()
        return blocked('wechat_acceptance','本机后台接口已连接；当前账号绑定与真实收发还需测试，暂未开启自动回复。',
                       currentVersion=version,interfaceConnected=connection.get('connected') is True)
    except BackendError as error:return blocked(error.code,str(error))
    except Exception:return blocked('wechat_check','Windows 微信后台检查未完成，请查看连接诊断。')

if __name__=='__main__':
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    try:
        config=json.loads(sys.stdin.readline())
        from native_window_transport import inspect as current_inspect
        result=current_inspect(config)
    except (ValueError,TypeError):result=blocked('configuration','后台连接设置无法读取。')
    print(json.dumps(result,ensure_ascii=False))
