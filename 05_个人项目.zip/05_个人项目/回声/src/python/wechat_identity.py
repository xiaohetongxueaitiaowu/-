"""Read sender identity from each message shard, never a global numeric guess."""
import sqlite3
import threading

def attach_identity(conn, rows, own, chat):
    rows=[dict(row) for row in rows]
    numbers=sorted({int(row.get('real_sender_id') or 0) for row in rows if int(row.get('real_sender_id') or 0)>0})
    mapping={}
    try:
        for offset in range(0,len(numbers),500):
            part=numbers[offset:offset+500]
            query='SELECT rowid,user_name FROM Name2Id WHERE rowid IN ('+','.join('?' for _ in part)+')'
            mapping.update({int(num):user for num,user in conn.execute(query,part) if user})
    except sqlite3.Error:
        mapping={}
    for row in rows:
        user=mapping.get(int(row.get('real_sender_id') or 0),'')
        role='SELF' if user and user==own else 'OTHER' if user and (user==chat or chat.endswith('@chatroom')) else 'UNKNOWN'
        row.update(echo_sender_username=user,echo_sender_role=role,echo_identity_version='shard-v1')
    return rows

_CLASSES={}

def make_db(**kwargs):
    from personal_web_database import configured,WebDatabase
    if configured():return WebDatabase(**kwargs)
    from wechatauto import WeChatDB as Base
    if Base not in _CLASSES:
        class VerifiedDB(Base):
            echo_identity_supported=hasattr(Base,'_shard_rows') and hasattr(Base,'_msg_row_to_dict')
            def _open(self,rel):
                from database_cache_lock import open_locked
                return open_locked(self,super()._open,rel)
            def get_self_info(self):
                # The SDK version shipped with this app leaks this connection.
                # Close explicitly so a metadata query cannot hold the mutex.
                conn=self._contact_conn()
                if conn is None:return {'username':self.wxid,'nick_name':'','remark':''}
                try:
                    row=conn.execute('SELECT username,nick_name,remark FROM contact WHERE username=? LIMIT 1',(self.wxid,)).fetchone()
                    return {'username':row[0],'nick_name':row[1],'remark':row[2]} if row else {'username':self.wxid,'nick_name':'','remark':''}
                finally:conn.close()
            def _run_msg_query(self,user,build):
                if not hasattr(self,'_echo_context'):self._echo_context=threading.local()
                previous=getattr(self._echo_context,'chat','')
                self._echo_context.chat=user
                try:return super()._run_msg_query(user,build)
                finally:self._echo_context.chat=previous
            def _shard_rows(self,tables,sql_ext,params=(),order_ext='',per_shard_limit=None):
                result=[]
                chat=getattr(self._echo_context,'chat','')
                for conn,table in tables:
                    rows=super()._shard_rows([(conn,table)],sql_ext,params,order_ext,per_shard_limit)
                    result.extend(attach_identity(conn,rows,self.wxid,chat))
                return result
            def _msg_row_to_dict(self,row):
                result=super()._msg_row_to_dict(row)
                for name in ('echo_sender_username','echo_sender_role','echo_identity_version'):
                    result[name]=row[name] if name in row.keys() else ''
                # Exact API receipt matching must not lose 64-bit message IDs.
                if 'server_id' in row.keys():result['server_id']=str(row['server_id'] or '')
                return result
            def verified_history(self,user):
                rows=self._run_msg_query(user,lambda tables:self._shard_rows(tables,'',order_ext=self._MSG_ORDER_ASC)) or []
                output=[]
                for row in rows:
                    record=self._msg_row_to_dict(row);record['type_code']=row['local_type'];output.append(record)
                return output
        _CLASSES[Base]=VerifiedDB
    return _CLASSES[Base](**kwargs)
