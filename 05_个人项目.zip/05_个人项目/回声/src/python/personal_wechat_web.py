"""Personal Web WeChat protocol candidate; no UI or independent Bot fallback.

Protocol reference: littlecodersh/ItChat components login/contact/messages.
Server eligibility is required; this does not bypass account restrictions.
Not yet selected by the installed app. Login/real sending need acceptance.
"""
from dataclasses import dataclass, field
import hashlib
import html
import http.cookiejar
import io
import json
import re
import secrets
import time
import urllib.error
import urllib.parse
import urllib.request

from wechat_direct_probe import ProbeError, NoRedirect, network_error
from wechat_transport_validation import server_message_id
from model_client import strict_json

HOSTS={'wx.qq.com':'webpush.wx.qq.com', 'wx2.qq.com':'webpush.wx2.qq.com',
       'wx8.qq.com':'webpush.wx8.qq.com', 'web.wechat.com':'webpush.web.wechat.com',
       'web2.wechat.com':'webpush.web2.wechat.com'}
METHODS={'webwxinit':'POST','webwxgetcontact':'GET','webwxbatchgetcontact':'POST',
         'webwxsync':'POST','webwxsendmsg':'POST','webwxlogout':'GET','synccheck':'GET'}
SERVICE_USERS={'filehelper','weixin','newsapp','weibo','qqmail','fmessage','tmessage','qmessage','qqsync',
    'floatbottle','lbsapp','shakeapp','medianote','qqfriend','readerapp','blogapp','facebookapp','masssendapp',
    'meishiapp','feedsapp','voip','blogappweixin','brandsessionholder','weixinreminder','wxid_novlwrv3lqwv11',
    'gh_22b87fa7cb3c','officialaccounts','notification_messages'}


def username(value):
    return isinstance(value,str) and re.fullmatch(r'@{1,2}[A-Za-z0-9_-]{1,256}',value) is not None


def contact_kind(row,owner=None):
    if not isinstance(row,dict) or not username(row.get('UserName')):return 'unknown'
    user=row['UserName']
    if user==owner:return 'self'
    if user.startswith('@@'):return 'group'
    blocked=row.get('ContactFlag',0)
    if type(blocked) is not int:return 'unknown'
    if blocked&8:return 'blocked'
    flag=row.get('VerifyFlag',0)
    if type(flag) is not int:return 'unknown'
    return 'public' if flag&8 else 'private'


def sync_key(value):
    if not isinstance(value,dict) or type(value.get('Count')) is not int or not isinstance(value.get('List'),list):
        raise ProbeError('response','微信同步游标格式无效。')
    rows=value['List']
    if not 0<len(rows)<=100 or value['Count']!=len(rows):raise ProbeError('response','微信同步游标数量无效。')
    clean=[];seen=set()
    for row in rows:
        if not isinstance(row,dict) or any(type(row.get(k)) is not int or not 0<=row[k]<=2**63-1 for k in ('Key','Val')):
            raise ProbeError('response','微信同步游标字段无效。')
        if row['Key'] in seen:raise ProbeError('response','微信同步游标重复。')
        seen.add(row['Key']);clean.append({'Key':row['Key'],'Val':row['Val']})
    return {'Count':len(clean),'List':clean}


@dataclass(frozen=True)
class WebMessage:
    account: str = field(repr=False)
    conversation: str = field(repr=False)
    sender: str = field(repr=False)
    message_id: str
    role: str
    kind: str
    text: str = field(repr=False)
    created_ms: int
    bot_echo: bool = False
    message_type: int = 1


class PersonalWeb:
    def __init__(self,redirect,tickets,*,opener=None,cookie_jar=None,clock=time.time,timeout=30):
        try:parts=urllib.parse.urlsplit(redirect);port=parts.port
        except (TypeError,ValueError):raise ProbeError('address','微信登录节点无效。') from None
        if (parts.scheme!='https' or parts.hostname not in HOSTS or port not in (None,443) or
                parts.username is not None or parts.password is not None or parts.fragment or
                parts.path!='/cgi-bin/mmwebwx-bin/webwxnewloginpage'):
            raise ProbeError('address','微信登录节点不在已核验范围内。')
        if (not isinstance(tickets,dict) or not isinstance(tickets.get('wxuin'),str) or
                not re.fullmatch(r'[1-9][0-9]{0,19}',tickets['wxuin']) or int(tickets['wxuin'])>2**64-1):
            raise ProbeError('credentials','微信登录缺少本人账号凭据。')
        if any(not isinstance(tickets.get(k),str) or not 0<len(tickets[k])<=4096 or '\x00' in tickets[k]
               for k in ('wxsid','skey','pass_ticket')):
            raise ProbeError('credentials','微信登录凭据不完整。')
        if type(timeout) not in (int,float) or not 0<timeout<=35:raise ProbeError('configuration','微信连接时限无效。')
        self.host=parts.hostname;self.clock=clock;self.timeout=timeout
        self.tickets={k:tickets[k] for k in ('wxuin','wxsid','skey','pass_ticket')}
        self.cookies=cookie_jar if cookie_jar is not None else http.cookiejar.CookieJar()
        self.opener=opener or urllib.request.build_opener(NoRedirect(),urllib.request.ProxyHandler({}),
                                                         urllib.request.HTTPCookieProcessor(self.cookies))
        self.device='e'+''.join(str(secrets.randbelow(10)) for _ in range(15))
        self.account=hashlib.sha256(('personal-web\0'+str(tickets['wxuin'])).encode()).hexdigest()
        self.owner=None;self.owner_name='';self.key=None;self.check_key=None;self.contacts={};self.active=True;self.next_id=0
        self.events={};self.latest={};self.event_time={}
        self.sent_ids={};self.contact_revision=0

    def request(self,method,*,body=None,query=None):
        if not self.active:raise ProbeError('session','微信连接已停止，请重新扫码。')
        if method not in METHODS:raise ProbeError('configuration','未识别的微信协议操作。')
        host=HOSTS[self.host] if method=='synccheck' else self.host
        url='https://'+host+'/cgi-bin/mmwebwx-bin/'+method
        if query:url+='?'+urllib.parse.urlencode(query)
        data=None if body is None else json.dumps(body,ensure_ascii=False,allow_nan=False).encode('utf-8')
        headers={'User-Agent':'Mozilla/5.0','Content-Type':'application/json; charset=utf-8'}
        request=urllib.request.Request(url,data=data,headers=headers,method=METHODS[method])
        try:
            with self.opener.open(request,timeout=self.timeout) as response:blob=response.read(8*1024*1024+1)
        except urllib.error.HTTPError as error:
            status=error.code;error.close()
            raise ProbeError('http','微信服务器返回HTTP '+str(status)+'；未重复发送。') from None
        except (OSError,urllib.error.URLError) as error:raise network_error(error) from None
        if not isinstance(blob,bytes) or len(blob)>8*1024*1024:raise ProbeError('response','微信返回内容过大或格式错误。')
        if method in ('synccheck','webwxlogout'):return blob
        try:result=strict_json(blob.decode('utf-8-sig'))
        except (ValueError,UnicodeError):raise ProbeError('response','微信响应不是有效UTF-8 JSON。') from None
        base=result.get('BaseResponse') if isinstance(result,dict) else None
        if not isinstance(base,dict) or type(base.get('Ret')) is not int:raise ProbeError('response','微信响应缺少明确状态。')
        if base['Ret']!=0:
            if base['Ret'] in (1100,1101,1102,1203):self.active=False;raise ProbeError('session','微信登录已失效或账号受限，请重新扫码核验。')
            raise ProbeError('rejected','微信未接受操作，状态码 '+str(base['Ret'])+'。')
        return result

    def base_request(self):
        return {'Uin':int(self.tickets['wxuin']),'Sid':self.tickets['wxsid'],
                'Skey':self.tickets['skey'],'DeviceID':self.device}

    def require_ready(self):
        if not self.active or not self.owner or not self.key:raise ProbeError('session','微信连接尚未完成本人身份与消息同步核验。')

    def initialize(self):
        result=self.request('webwxinit',body={'BaseRequest':self.base_request()},
                            query={'r':~int(self.clock()),'pass_ticket':self.tickets['pass_ticket']})
        user=result.get('User')
        if not isinstance(user,dict) or not username(user.get('UserName')) or user['UserName'].startswith('@@'):
            raise ProbeError('identity','微信初始化未确认本人身份。')
        key=sync_key(result.get('SyncKey'))
        # Commit only after all fields validate; never guess the owner sender.
        check=sync_key(result.get('SyncCheckKey',key))
        name=user.get('NickName','')
        if not isinstance(name,str) or len(name)>256 or any(ord(c)<32 for c in name):
            raise ProbeError('identity','微信本人昵称格式无效，未保存身份。')
        self.owner=user['UserName'];self.owner_name=name;self.key=key;self.check_key=check
        return {'status':'initialized','accountVerified':True,'background':True,'desktopActions':0}

    def load_contacts(self):
        self.require_ready();seq=0;seen=set();contacts={}
        for _ in range(100):
            if seq in seen:raise ProbeError('response','微信联系人分页重复，未发布不完整名单。')
            seen.add(seq)
            result=self.request('webwxgetcontact',query={'skey':self.tickets['skey'],'pass_ticket':self.tickets['pass_ticket'],
                                                       'seq':seq,'r':int(self.clock()*1000)})
            rows=result.get('MemberList');count=result.get('MemberCount');next_seq=result.get('Seq')
            if not isinstance(rows,list) or type(count) is not int or count!=len(rows) or type(next_seq) is not int or next_seq<0:
                raise ProbeError('response','微信联系人列表或分页标识无效。')
            for raw in rows:
                if isinstance(raw,dict) and raw.get('UserName') in SERVICE_USERS:continue
                if not isinstance(raw,dict) or not username(raw.get('UserName')):raise ProbeError('response','微信联系人唯一身份无效。')
                identity=raw['UserName']
                if identity in contacts and contacts[identity]!=raw:raise ProbeError('identity','微信联系人身份出现矛盾。')
                contacts[identity]=dict(raw)
                if len(contacts)>30000:raise ProbeError('response','微信联系人数量超过当前处理范围。')
            if next_seq==0:
                self.contacts=contacts;self.contact_revision+=1
                return {'contacts':list(contacts.values()),'complete':True}
            seq=next_seq
        raise ProbeError('response','微信联系人分页尚未完成，未发布部分名单。')

    def check_updates(self):
        self.require_ready()
        query={'r':int(self.clock()*1000),'skey':self.tickets['skey'],'sid':self.tickets['wxsid'],
               'uin':self.tickets['wxuin'],'deviceid':self.device,
               'synckey':'|'.join(str(row['Key'])+'_'+str(row['Val']) for row in self.check_key['List']),
               '_':int(self.clock()*1000)}
        raw=self.request('synccheck',query=query)
        try:text=raw.decode('utf-8')
        except UnicodeError:raise ProbeError('response','微信消息检测响应编码错误。') from None
        match=re.fullmatch(r'\s*window\.synccheck\s*=\s*\{retcode:"(\d+)",selector:"(\d+)"\};?\s*',text)
        if not match:raise ProbeError('response','微信消息检测响应无效。')
        if match[1]!='0':self.active=False;raise ProbeError('session','微信消息连接已退出，需重新扫码。')
        return match[2]!='0'

    def normalize(self,raw):
        if not isinstance(raw,dict) or type(raw.get('MsgType')) is not int:return None
        message_type=raw['MsgType']
        if not 1<=message_type<=10000:return None
        source,target=raw.get('FromUserName'),raw.get('ToUserName')
        if not username(source) or not username(target):return None
        self_sent=source==self.owner
        if not self_sent and target!=self.owner:return None
        conversation=target if self_sent else source
        body=raw.get('Content');stamp=raw.get('CreateTime')
        if not isinstance(body,str) or len(body)>50000 or (message_type==1 and not body.strip()) or type(stamp) is not int or not 0<stamp<2**63//1000:return None
        try:mid=server_message_id(raw.get('NewMsgId',raw.get('MsgId')))
        except ValueError:return None
        sender=source;kind='group' if conversation.startswith('@@') else 'private'
        if kind=='group' and not self_sent:
            match=re.match(r'^(@[A-Za-z0-9_-]{1,256}):<br\s*/?>(.*)$',body,re.S)
            if not match:return None
            sender,body=match.groups()
            if sender==self.owner:return None  # Contradictory OTHER envelope.
        if kind=='private' and not self_sent and source not in self.contacts:return None
        text=html.unescape(re.sub(r'<br\s*/?>','\n',body))
        if message_type!=1:
            labels={3:'图片',34:'语音',43:'视频',47:'表情',49:'文件或链接',62:'短视频'}
            text='['+labels.get(message_type,'非文字消息')+'；内容未解析]'
        role='SELF' if self_sent else 'OTHER'
        if kind=='group' and not self_sent:
            members=self.contacts.get(conversation,{}).get('MemberList',[])
            if not isinstance(members,list) or not any(isinstance(m,dict) and m.get('UserName')==sender for m in members):role='UNKNOWN'
        bot_echo=self_sent and (conversation,mid) in self.sent_ids
        return WebMessage(self.account,conversation,sender,mid,role,kind,text,stamp*1000,bot_echo,message_type)

    def contact_changes(self,result):
        additions=result.get('ModContactList',[]);deletions=result.get('DelContactList',[])
        for field,rows in (('ModContact',additions),('DelContact',deletions)):
            if not isinstance(rows,list) or len(rows)>30000:raise ProbeError('response','微信联系人更新格式无效。')
            count=result.get(field+'Count',len(rows))
            if type(count) is not int or count!=len(rows):raise ProbeError('response','微信联系人变更数量不一致。')
            if any(not isinstance(row,dict) or not (username(row.get('UserName')) or row.get('UserName') in SERVICE_USERS) for row in rows):raise ProbeError('identity','联系人更新缺少唯一身份。')
        current=dict(self.contacts)
        for row in deletions:current.pop(row['UserName'],None)
        for row in additions:
            if row['UserName'] in SERVICE_USERS:continue
            current[row['UserName']]={**current.get(row['UserName'],{}),**row}
        if len(current)>30000:raise ProbeError('capacity','微信联系人更新超过当前处理范围。')
        if current!=self.contacts:self.contacts=current;self.contact_revision+=1

    def load_group_members(self,groups):
        """Normal official batch contact request, never a group send permission."""
        wanted=sorted(set(groups))
        if any(not username(u) or not u.startswith('@@') for u in wanted):raise ProbeError('identity','群成员查询缺少明确群身份。')
        gathered={}
        for start in range(0,len(wanted),50):
            batch=wanted[start:start+50]
            result=self.request('webwxbatchgetcontact',query={'type':'ex','r':int(self.clock()*1000)},body={
                'BaseRequest':self.base_request(),'Count':len(batch),'List':[{'UserName':u,'EncryChatRoomId':''} for u in batch]})
            rows=result.get('ContactList')
            if not isinstance(rows,list) or len(rows)!=len(batch):raise ProbeError('response','群成员详情尚未完整返回。')
            for row in rows:
                if not isinstance(row,dict) or row.get('UserName') not in batch or row['UserName'] in gathered:raise ProbeError('identity','群成员详情与所查群身份矛盾。')
                members=row.get('MemberList');count=row.get('MemberCount')
                if not isinstance(members,list) or type(count) is not int or count!=len(members) or not 0<count<=30000:raise ProbeError('response','群成员数量尚未完整核验。')
                ids=[m.get('UserName') if isinstance(m,dict) else None for m in members]
                if any(not username(u) or u.startswith('@@') for u in ids) or len(set(ids))!=len(ids):raise ProbeError('identity','群成员详情含无效或重复身份。')
                gathered[row['UserName']]={**self.contacts.get(row['UserName'],{}),**row}
        self.contacts.update(gathered)
        if gathered:self.contact_revision+=1

    def get_updates(self):
        self.require_ready()
        result=self.request('webwxsync',body={'BaseRequest':self.base_request(),'SyncKey':self.key,'rr':~int(self.clock())},
                            query={'sid':self.tickets['wxsid'],'skey':self.tickets['skey'],'pass_ticket':self.tickets['pass_ticket']})
        rows=result.get('AddMsgList');count=result.get('AddMsgCount')
        new_key=sync_key(result.get('SyncKey'));check=sync_key(result.get('SyncCheckKey',new_key))
        if not isinstance(rows,list) or type(count) is not int or count!=len(rows):raise ProbeError('response','微信新增消息列表不完整。')
        self.contact_changes(result)
        groups={raw.get('FromUserName') for raw in rows if isinstance(raw,dict) and username(raw.get('FromUserName')) and raw['FromUserName'].startswith('@@')}
        missing=[u for u in groups if not self.contacts.get(u,{}).get('MemberList')]
        if missing:
            try:self.load_group_members(missing)
            except ProbeError as error:
                if not self.active:raise
                # Other verified conversations remain usable; this group will
                # stay UNKNOWN and is excluded from factual model extraction.
                self.group_membership_error=error.code
        now=self.clock()
        self.sent_ids={key:stamp for key,stamp in self.sent_ids.items() if 0<=now-stamp<300}
        messages=[item for raw in rows if (item:=self.normalize(raw)) is not None]
        keep={key:item for key,item in self.events.items() if 0<=now-self.event_time.get(key,-1e9)<300}
        latest={};times={key:self.event_time[key] for key in keep}
        def update_latest(item):
            if item.bot_echo:return
            old=latest.get(item.conversation)
            if (old is None or item.created_ms>old.created_ms or
                item.created_ms==old.created_ms and (item.role=='SELF' or old.role!='SELF')):
                latest[item.conversation]=item
        for item in keep.values():update_latest(item)
        for item in messages:
            key=(item.conversation,item.message_id)
            previous=keep.get(key)
            if previous is not None and previous!=item:
                raise ProbeError('identity','同一微信消息编号的正文或发送身份矛盾，未更新游标。')
            if previous is not None:continue  # Replayed input cannot refresh its authorization lifetime.
            keep[key]=item;times[key]=now
            # IDs are identities, not a documented time ordering. An owner
            # message wins an ambiguous same-second batch over another input.
            update_latest(item)
        if len(keep)>2000:raise ProbeError('capacity','待处理消息过多，未更新消息游标。')
        self.events=keep;self.latest=latest;self.event_time=times
        self.key=new_key;self.check_key=check
        return {'messages':messages,'skipped':len(rows)-len(messages)}

    def queue_text(self,target,text,*,authorize,ledger,event_id):
        self.require_ready()
        if target not in self.contacts or not username(target) or target==self.owner:raise ProbeError('recipient','目标不是本账号已核验的联系人。')
        # Groups need structured @ and membership verification before enabling.
        if target.startswith('@@'):raise ProbeError('group_unverified','群自动回复仍待结构化艾特与成员核验。')
        if contact_kind(self.contacts[target],self.owner)!='private':raise ProbeError('recipient','目标不是已核验的普通私聊好友。')
        if not isinstance(text,str) or not text.strip() or len(text)>4000 or '\x00' in text:raise ProbeError('text','微信回复正文无效。')
        if not isinstance(event_id,str) or not event_id or len(event_id)>128:raise ProbeError('authorization','缺少入站消息唯一身份。')
        event=self.events.get((target,event_id))
        if event is None or event.role!='OTHER' or event.message_type!=1 or event.account!=self.account or self.latest.get(target)!=event:
            raise ProbeError('authorization','此回复不对应当前账号的最新对方消息，可能已发生人工接管。')
        if not 0<=self.clock()-self.event_time.get((target,event_id),-1e9)<300:
            raise ProbeError('authorization','此次消息回复授权已过期，请等待新消息。')
        if not -30<=self.clock()-event.created_ms/1000<300:
            raise ProbeError('authorization','此消息不是近期新消息，未补发历史回复。')
        if not callable(authorize) or authorize() is not True:raise ProbeError('authorization','当前设置或人工接管不允许发送。')
        if ledger is None or not ledger.claim(self.account,target,event_id):raise ProbeError('already_attempted','缺少持久化单次授权或该消息已尝试发送，未重发。')
        self.next_id=max(self.next_id+1,int(self.clock()*1000000)+secrets.randbelow(1000))
        local_id=str(self.next_id)
        result=self.request('webwxsendmsg',body={'BaseRequest':self.base_request(),'Scene':0,'Msg':{
            'Type':1,'Content':text,'FromUserName':self.owner,'ToUserName':target,'LocalID':local_id,'ClientMsgId':local_id}})
        try:mid=server_message_id(result.get('MsgID'))
        except ValueError:raise ProbeError('receipt','微信未返回有效发送编号；结果尚未确认，不重发。') from None
        self.sent_ids[(target,mid)]=self.clock()
        return {'queued':True,'sentConfirmed':False,'serverMessageId':mid,'clientId':local_id,'desktopActions':0,'retryAllowed':False}

    def logout(self):
        try:
            if self.active:self.request('webwxlogout',query={'redirect':'1','type':'1','skey':self.tickets['skey']})
        finally:self.active=False;self.cookies.clear();self.tickets.clear()
