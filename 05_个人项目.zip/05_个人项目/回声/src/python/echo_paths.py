"""One layout contract, compatible with older flat developer checkouts."""
from pathlib import Path

CODE = Path(__file__).resolve().parent
ORGANIZED = CODE.name == '程序'
ROOT = CODE.parent if ORGANIZED else CODE
STORAGE = ROOT / '资料' if ORGANIZED else ROOT
DATA = STORAGE / 'data'
REPORTS = STORAGE / '报告'
PEOPLE = STORAGE / '用户'
GROUPS = STORAGE / '群'
DOCS = ROOT / '说明' if ORGANIZED else ROOT
RUNTIME = ROOT / 'runtime'
