"""Measured A4 pages; explicit overflow and a full local appendix, never silent drops."""
import html
import pathlib
import re
from functools import lru_cache
from PIL import ImageFont

WIDTH=698
HEIGHT=944  # Printable body; title/footer/page number have reserved space.
@lru_cache(maxsize=8)
def font(size,bold=False):
    path=pathlib.Path('C:/Windows/Fonts')/('msyhbd.ttc' if bold else 'msyh.ttc')
    return ImageFont.truetype(str(path),size) if path.exists() else ImageFont.load_default(size=size)

def wrapped(line):
    marker=re.match(r'^(#{1,3}) (.*)',line)
    level=len(marker[1]) if marker else 0
    text=marker[2] if marker else line
    size={1:24,2:20,3:18}.get(level,16);height={1:36,2:32,3:28}.get(level,24)
    if not text:return [('',0,12)]
    face=font(size,level>0);lines=[];part=''
    for ch in text:
        if part and face.getlength(part+ch)>WIDTH:lines.append((part,level,height));part=''
        part+=ch
    if part:lines.append((part,level,height))
    return lines

def layout(document,max_pages):
    parts=re.split(r'(?=^### )',document,flags=re.M)
    def fit(parts):
        pages=[[]];used=0
        for part in parts:
            block=[entry for line in part.strip().splitlines() for entry in wrapped(line)]
            size=sum(x[2] for x in block)+12
            if size>HEIGHT:return None
            if used+size>HEIGHT:
                if len(pages)==max_pages:return None
                pages.append([]);used=0
            pages[-1].extend(block+[('',0,12)]);used+=size
        return pages
    pages=fit(parts);compacted=[]
    if pages is None:
        for summary_limit in (240,160,100,60):
            short=[parts[0]];compacted=[]
            for part in parts[1:]:
                lines=[x.strip() for x in part.strip().splitlines() if x.strip()]
                title=lines[0]
                summary=next((x for x in lines[1:] if not x.startswith(('#','- ','来源：','时间：'))),'详见完整事件')
                # Keep every event title. Evidence is retained once in the full appendix.
                if len(summary)>summary_limit:
                    summary=summary[:summary_limit]+'…（完整摘要见附录）'
                source=next((x for x in lines if x.startswith('来源：')),'')
                short.append('\n'.join([title,summary]+([source[:70]] if source and summary_limit>=100 else [])))
                compacted.append(title.lstrip('# '))
            pages=fit(short)
            if pages is not None:break
        if pages is None:raise ValueError('事件数量超过版面容量，完整事件已保留；请缩小时间范围后分页，不能静默删除重要事件')
    omitted=[]
    notice='所有事件标题和摘要均已展示；详细证据保留在“查看完整事件”附录。'+(f'有 {len(compacted)} 条事件采用短摘要。' if compacted else '')
    markdown=[];html_pages=[]
    for number,page in enumerate(pages,1):
        markdown+=['## 第 %d / %d 页'%(number,len(pages)),'']
        lines=[]
        for text,level,height in page:
            markdown.append(('#'*level+' ' if level else '')+text)
            lines.append('<div style="height:%dpx;line-height:%dpx;font-size:%dpx;font-weight:%s;white-space:pre">%s</div>'%(height,height,{1:24,2:20,3:18}.get(level,16),'bold' if level else 'normal',html.escape(text)))
        html_pages.append('<div class="page"><div class="pagebody">'+''.join(lines)+'</div><div class="footer">'+html.escape(notice)+'<br>第 %d / %d 页</div></div>'%(number,len(pages)))
    markdown+=['','## 版面说明',notice]
    html_document='<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><style>body{margin:0;background:#e9edf2;font-family:"Microsoft YaHei",sans-serif;color:#1f2937}.page{background:white;width:698px;height:1027px;padding:48px;margin:20px auto;page-break-after:always;position:relative}div.pagebody{height:944px}div.footer{position:absolute;bottom:36px;left:48px;width:698px;font-size:12px;line-height:20px;color:#526175}@media print{body{background:white}.page{margin:0} @page{size:A4;margin:0}}</style></head><body>'+''.join(html_pages)+'</body></html>'
    return {'text':'\n'.join(markdown),'html':html_document,'pages':len(pages),'omitted':omitted,'compacted':compacted,'full':document}
