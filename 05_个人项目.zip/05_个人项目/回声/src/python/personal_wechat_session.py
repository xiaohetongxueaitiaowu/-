"""Encrypted QR session restoration with generation checks; no network calls."""
import http.cookiejar
import math
import re
from personal_wechat_web import PersonalWeb,HOSTS,username,sync_key
from wechat_direct_probe import ProbeError,challenge_lock
from wechat_scan_connect import cookie_records
from wechat_transport_validation import server_message_id

COOKIE_HOSTS=set(HOSTS)|set(HOSTS.values())|{'qq.com','wechat.com','weixin.qq.com','login.wx.qq.com','login.weixin.qq.com'}
COOKIE_FIELDS=('version','name','value','port','port_specified','domain','domain_specified',
               'domain_initial_dot','path','path_specified','secure','expires','discard',
               'comment','comment_url','rfc2109','rest')

def cookies_from_records(rows):
    if not isinstance(rows,list) or len(rows)>200:raise ProbeError('credentials','微信Cookie数量无效。')
    jar=http.cookiejar.CookieJar()
    for row in rows:
        if not isinstance(row,dict) or set(row)!=set(COOKIE_FIELDS):raise ProbeError('credentials','微信Cookie结构无效。')
        if (type(row['version']) is not int or row['version'] not in (0,1) or
            any(type(row[key]) is not bool for key in ('port_specified','domain_specified','domain_initial_dot','path_specified','secure','discard','rfc2109'))):
            raise ProbeError('credentials','微信Cookie标志无效。')
        for key,limit in (('name',256),('value',8192),('domain',256),('path',2048)):
            value=row[key]
            if not isinstance(value,str) or len(value)>limit or any(ord(c)<32 or ord(c)==127 for c in value):raise ProbeError('credentials','微信Cookie字段无效。')
        if not row['name'] or not row['path'].startswith('/') or row['domain'].lstrip('.') not in COOKIE_HOSTS:
            raise ProbeError('credentials','微信Cookie节点不在已核验范围内。')
        if row['expires'] is not None and (type(row['expires']) is not int or not 0<=row['expires']<=2**63-1):raise ProbeError('credentials','微信Cookie有效期无效。')
        for key in ('port','comment','comment_url'):
            if row[key] is not None and (not isinstance(row[key],str) or len(row[key])>4096):raise ProbeError('credentials','微信Cookie说明无效。')
        if not isinstance(row['rest'],dict) or len(row['rest'])>16:raise ProbeError('credentials','微信Cookie附加字段无效。')
        for key,value in row['rest'].items():
            if not isinstance(key,str) or len(key)>128 or value is not None and (not isinstance(value,str) or len(value)>4096):raise ProbeError('credentials','微信Cookie附加值无效。')
        jar.set_cookie(http.cookiejar.Cookie(**row))
    return jar


class PersonalSessionStore:
    def __init__(self,connection):self.connection=connection;self._binding=None;self._stamp=None
    def _remember(self,identity,account):
        stat=self.connection.session_path.stat();self._binding=(identity,account);self._stamp=(stat.st_mtime_ns,stat.st_size)
    def _saved(self,identity):
        controller=self.connection;state=controller._any(identity)
        if state.get('state')!='connected_unverified':raise ProbeError('cancelled','扫码连接尚未就绪或已经停止。')
        saved=controller.session_read()
        if (not isinstance(saved,dict) or saved.get('active') is not True or
            saved.get('challenge')!=identity or saved.get('phase')!='connected_unverified'):
            raise ProbeError('credentials','此凭据不属于当前扫码连接。')
        return saved
    def restore(self,identity,*,opener=None):
        with challenge_lock(self.connection.folder):saved=self._saved(identity)
        jar=cookies_from_records(saved.get('cookies'))
        client=PersonalWeb(saved.get('redirect'),saved.get('tickets'),cookie_jar=jar,
                           opener=opener,clock=self.connection.clock)
        owner=saved.get('owner');device=saved.get('device')
        if (not username(owner) or owner.startswith('@@') or saved.get('account')!=client.account or
            not isinstance(device,str) or not re.fullmatch(r'e\d{15}',device)):
            raise ProbeError('identity','保存的本人身份、账号或设备标识矛盾，未恢复连接。')
        key=sync_key(saved.get('key'));check=sync_key(saved.get('checkKey'))
        contacts=saved.get('contacts')
        if not isinstance(contacts,dict) or len(contacts)>30000:raise ProbeError('credentials','保存的微信联系人范围无效。')
        for identifier,row in contacts.items():
            if not username(identifier) or not isinstance(row,dict) or row.get('UserName')!=identifier:
                raise ProbeError('identity','保存的联系人与唯一身份不一致。')
        client.owner=owner;client.device=device;client.key=key;client.check_key=check;client.contacts=contacts
        name=saved.get('ownerName','')
        if not isinstance(name,str) or len(name)>256 or any(ord(c)<32 for c in name):raise ProbeError('identity','保存的本人昵称格式无效。')
        client.owner_name=name
        echoes=saved.get('sentIds',[])
        if not isinstance(echoes,list) or len(echoes)>2000:raise ProbeError('credentials','发送回执索引无效。')
        for item in echoes:
            if (not isinstance(item,dict) or not username(item.get('conversation')) or
                type(item.get('time')) not in (int,float) or not math.isfinite(item['time'])):
                raise ProbeError('credentials','发送回执字段无效。')
            try:mid=server_message_id(item.get('messageId'))
            except ValueError:raise ProbeError('credentials','发送回执编号无效。') from None
            if 0<=self.connection.clock()-item['time']<300:client.sent_ids[(item['conversation'],mid)]=item['time']
        # Stop may have completed while decrypting/validating. Do not revive it.
        with challenge_lock(self.connection.folder):
            self._saved(identity);self._remember(identity,client.account)
        return client
    def active(self,identity,account):
        try:
            with challenge_lock(self.connection.folder):
                state=self.connection._any(identity)
                if state.get('state')!='connected_unverified':return False
                stat=self.connection.session_path.stat();stamp=(stat.st_mtime_ns,stat.st_size)
                if self._binding==(identity,account) and self._stamp==stamp:return True
                saved=self._saved(identity)
                if saved.get('account')!=account:return False
                self._remember(identity,account);return True
        except (ProbeError,OSError,ValueError):return False
    def persist(self,identity,client):
        with challenge_lock(self.connection.folder):
            saved=self._saved(identity)
            if not client.active or saved.get('account')!=client.account or saved.get('owner')!=client.owner:
                raise ProbeError('identity','当前连接账号已改变，未保存消息游标。')
            saved.update(device=client.device,key=sync_key(client.key),checkKey=sync_key(client.check_key),
                         contacts=client.contacts,cookies=cookie_records(client.cookies),
                         sentIds=[{'conversation':peer,'messageId':mid,'time':stamp}
                                  for (peer,mid),stamp in client.sent_ids.items()
                                  if 0<=self.connection.clock()-stamp<300])
            self.connection._session_write(saved)
            self._remember(identity,client.account)

