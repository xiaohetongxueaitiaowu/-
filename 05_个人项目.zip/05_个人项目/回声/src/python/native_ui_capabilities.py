"""Bounded, read-only native capability inspection; no names or drafts exported."""
import time
from collections import deque


def inspect(*,seconds=5,max_nodes=800):
    import psutil,uiautomation as auto,win32gui,win32process
    pids={p.pid for p in psutil.process_iter(['name'])
          if (p.info['name'] or '').lower()=='weixin.exe'}
    handles=[]
    def collect(h,_):
        if (win32process.GetWindowThreadProcessId(h)[1] in pids and
            win32gui.IsWindowVisible(h) and not win32gui.IsIconic(h) and
            not win32gui.GetWindow(h,4) and win32gui.GetClassName(h).endswith('QWindowIcon')):
            handles.append(h)
    win32gui.EnumWindows(collect,None)
    result={'windows':len(handles),'nativeNodes':0,'inputValuePatterns':0,
            'sendInvokePatterns':0,'sessionSelectionPatterns':0,'complete':False}
    if len(handles)!=1:return result
    pid=win32process.GetWindowThreadProcessId(handles[0])[1]
    queue=deque([(auto.ControlFromHandle(handles[0]),0)])
    deadline=time.monotonic()+seconds;count=0
    while queue and count<max_nodes and time.monotonic()<deadline:
        c,depth=queue.popleft();count+=1
        if c.ProcessId!=pid:return result
        cls=c.ClassName or ''
        result['nativeNodes']+=int(cls.startswith('mmui::'))
        if cls=='mmui::ChatInputField':
            value=c.GetPattern(auto.PatternId.ValuePattern)
            result['inputValuePatterns']+=int(value is not None and not value.IsReadOnly)
        elif cls=='mmui::ChatSessionCell':
            result['sessionSelectionPatterns']+=int(c.GetPattern(auto.PatternId.SelectionItemPattern) is not None)
        elif cls.startswith('mmui::') and c.Name in ('发送','Send'):
            result['sendInvokePatterns']+=int(c.GetPattern(auto.PatternId.InvokePattern) is not None)
        children=c.GetChildren()
        if depth>=40 and children:return result
        queue.extend((child,depth+1) for child in children)
    result['complete']=not queue
    return result
