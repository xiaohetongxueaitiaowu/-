"""Windows per-user encrypted WeChat secrets; kept out of settings/exports."""
import json,os,pathlib,uuid
from echo_paths import DATA

def get_token(provider):
 from local_hook_client import BackendError
 path=DATA/'wechat-secrets.bin'
 if not path.exists():raise BackendError('credentials','尚未填写微信服务 Token；模型 API Key 不能连接微信。')
 try:
  import win32crypt
  value=json.loads(win32crypt.CryptUnprotectData(path.read_bytes(),None,None,None,0)[1].decode('utf-8'))
  token=value.get(provider,'')
 except Exception:raise BackendError('credentials','此电脑无法解密微信接口凭据，请在设置中重新填写。') from None
 if not isinstance(token,str) or not token.strip():raise BackendError('credentials','尚未填写所选微信接口的 Token。')
 return token

def store_token(provider,token):
 if provider!='gewe' or not isinstance(token,str) or '\n' in token or '\r' in token:raise ValueError('微信凭据格式不正确')
 import win32crypt
 DATA.mkdir(parents=True,exist_ok=True);path=DATA/'wechat-secrets.bin';values={}
 if path.exists():
  values=json.loads(win32crypt.CryptUnprotectData(path.read_bytes(),None,None,None,0)[1].decode('utf-8'))
 values[provider]=token.strip()
 blob=win32crypt.CryptProtectData(json.dumps(values,ensure_ascii=False).encode('utf-8'),None,None,None,None,0)
 temporary=path.with_name(path.name+'.'+uuid.uuid4().hex+'.tmp')
 temporary.write_bytes(blob);os.replace(temporary,path)
