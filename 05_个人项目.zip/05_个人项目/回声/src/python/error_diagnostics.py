"""Bounded, credential-free diagnostics. Never display raw provider responses."""
import json
import socket
import ssl
import urllib.error

def http_detail(error):
    if not hasattr(error, '_echo_detail'):
        try: error._echo_detail = error.read(4096).decode('utf-8', 'replace')
        except Exception: error._echo_detail = ''
    return error._echo_detail

def diagnose(error, origin='local'):
    cached = getattr(error, 'echo_diagnostic', None)
    if cached: return dict(cached)
    code = getattr(error, 'code', None) if isinstance(error, urllib.error.HTTPError) else None
    detail = http_detail(error) if code else ''
    raw = (detail + ' ' + str(error)).lower()
    reason = getattr(error, 'reason', error)
    def result(key, category, title, action):
        return dict(errorCode=key, errorCategory=category, errorTitle=title,
                    errorAction=action, httpStatus=code or 0)
    if type(error).__name__=='ProbeError':
        qr=getattr(error,'code','unknown')
        titles={'login_html':'微信返回网页，扫码认证未完成','response':'微信认证响应格式异常','account_restricted':'微信限制此账号使用后台接口',
                'login':'尚未扫码连接微信','session':'微信登录已失效','cancelled':'扫码连接尚未就绪或已停止',
                'credentials':'本机扫码凭据无法读取','identity':'微信账号身份核验失败','qr_expired':'二维码已过期',
                'challenge':'二维码已结束或连接状态已改变','address':'微信登录服务器或参数未通过核验','storage':'扫码凭据保存失败',
                'network':'微信服务器连接失败','dns':'微信服务器域名无法解析','timeout':'微信连接查询超时',
                'tls':'微信加密连接失败','certificate':'微信服务器证书校验失败','receipt':'微信发送结果未确认'}
        title=titles.get(qr,'微信后台操作未完成')
        return result('wechat_'+qr,'微信扫码连接',title,str(error)+'。未切换到桌面操作，也未重复发送。')
    if type(error).__name__=='BackendError':
        backend=getattr(error,'code','')
        mappings={
            'version':('微信版本不兼容','到设置 → 微信连接查看接口支持的版本；当前连接未启动。'),
            'wechat_missing':('未找到微信安装','在设置 → 微信连接选择微信程序位置。'),
            'wechat_ambiguous':('发现多个微信安装','明确选择要接入的微信程序和账号。'),
            'version_unknown':('无法确认微信版本','检查安装位置和读取权限；不会猜测版本。'),
            'login':('微信接口账号未登录或离线','检查所选微信服务的扫码登录；本机接口则检查电脑微信。'),
            'credentials':('微信接口凭据未填写或无法解密','到设置 → 微信连接填写该服务的 Token；模型 API Key 不能代替。'),
            'identity':('微信接口连接了不同账号','确保微信接口节点和本机读取的是同一个微信账号，未发送消息。'),
            'connection':('微信后台接口连接失败或超时','检查此微信接口服务和网络；未自动改成桌面操作或重发。'),
            'data_route':('尚未确认微信消息接入方式','到设置 → 微信连接确认是否允许消息经过所选独立服务。'),
            'adapter_missing':('所选微信接口尚未接入','选择已实现的连接方式；未切换为鼠标键盘操作。'),
            'wechat_auth':('微信接口 Token 认证失败','检查微信服务 Token 和权限；这不是模型 API Key 错误。'),
            'wechat_rate':('微信接口限流','稍后检查微信服务的调用限制；不自动重复发送。'),
            'receipt':('微信发送回执无法核实','发送结果未确认；检查目标、消息ID和服务记录，不自动重发。'),
            'address':('微信接口地址不符合连接要求','远程服务使用 HTTPS；本机 Hook 使用回环地址，不在地址内填写密钥。'),
            'response':('微信接口返回格式异常','响应缺失、重复字段或编码不合法；未作为有效登录或发送回执，不自动重发。'),
            'timeout_setting':('微信连接超时设置无效','连接等待时间必须为范围内的有效秒数；重新检查此接口设置。'),
            'recipient':('微信发送目标未核实','使用已核验名单中的唯一账号或群ID；昵称和显示称呼不能替代。'),
            'connection_settings':('微信连接设置格式无效','重新选择微信接入方式并保存；损坏的连接不会自动改为桌面操作。'),
        }
        title,action=mappings.get(backend,('微信接口操作未完成','到设置 → 微信连接查看接口配置和状态；未自动重发。'))
        return result('wechat_'+backend,'微信接口',title,action)
    if code in (301,302,303,307,308): return result('redirect', '接口配置', '模型接口要求跳转，已停止请求', '在设置 → 功能与 API 填写服务商确认的最终接口地址；不会跟随跳转转发密钥或聊天。')
    if code == 401: return result('auth', '接口认证', 'API 密钥无效或已失效', '到设置 → 功能与 API，检查此功能所选接口的密钥。')
    if code == 403: return result('access', '接口权限', '此账户没有调用权限', '检查所选模型权限、账户状态或地区限制。')
    quota = any(x in raw for x in ('insufficient_quota', 'insufficient balance', 'insufficient_balance', 'credit balance', 'billing_hard_limit', '余额不足'))
    if code == 402 or code == 429 and quota: return result('balance', '账户额度', '接口账户余额或配额不足', '到此 API 服务商的账户页面检查余额、套餐或配额。')
    if code == 429: return result('rate_limit', '接口限流', '请求过于频繁或并发超限', '稍后再试，或减少同时开启的分析任务；这不代表余额不足。')
    if any(x in raw for x in ('context_length', 'maximum context', 'context window', 'too many tokens', '上下文过长')): return result('context', '输入长度', '本次输入超过模型上下文长度', '缩短原稿或历史范围，或选择上下文更长的模型。')
    if any(x in raw for x in ('输出上限', '输出被截断', '输出截断')): return result('output_limit', '输出长度', '回复达到本次输出长度上限', '缩短内容或减少方案数量；原有结果保留，这不代表账户没钱。')
    if code in (404, 405): return result('endpoint', '接口配置', '接口地址或模型名称不正确', '检查 API 地址、接口协议和模型名称。')
    if code in (400, 422): return result('parameters', '接口参数', '模型不接受当前请求格式或参数', '检查模型与协议；结构化格式不兼容时选仅提示词 JSON。')
    if code and code >= 500: return result('service', '服务商故障', '模型服务暂时不可用', '稍后重试或切换此功能的 API；原有结果保留。')
    if isinstance(reason, ssl.SSLError): return result('tls', '网络连接', '接口安全连接或证书校验失败', '检查系统时间、代理和网络证书，不要关闭证书验证。')
    if isinstance(reason, socket.gaierror): return result('dns', '网络连接', '无法解析接口域名', '检查网络、DNS、代理和 API 地址。')
    if isinstance(reason, (TimeoutError, socket.timeout)) or 'timed out' in raw or 'timeout' in raw: return result('timeout', '请求超时', '操作等待超时，结果未确认', '检查网络或服务状态后手动重试；不自动重复发送。')
    if isinstance(error, urllib.error.URLError) or isinstance(reason, ConnectionError): return result('network', '网络连接', '无法连接模型接口', '检查网络、代理、接口地址及本地模型服务是否启动。')
    if type(error).__name__ == 'BudgetExceeded': return result('local_limit', '本机限制', '达到本机设置的请求次数或预算上限', '到设置 → 高级选项调整本机限制；不等于服务商余额不足。')
    # Filesystem exception paths may contain "API"; the type takes precedence.
    if isinstance(error, PermissionError): return result('permission', '本机权限', '无法访问所需文件或组件', '检查目录权限以及安全软件是否阻止访问。')
    if isinstance(error, FileNotFoundError):
        if str(getattr(error, 'filename', '')).lower().endswith(('.py', '.exe', '.dll')):
            return result('runtime', '运行组件', '所需运行组件缺失', '使用完整的回声安装目录，检查安全软件是否隔离文件。')
        return result('storage', '本机读写', '所需文件或目录不存在', '检查资料目录和保存位置，重新导入或创建所需资料。')
    if isinstance(error, ImportError): return result('runtime', '运行组件', '所需运行组件缺失', '使用完整的回声安装目录，检查安全软件是否隔离文件。')
    if any(x in raw for x in ('api', '密钥', '接口地址', '模型名称', '模型地址', 'https')): return result('configuration', '接口配置', '此功能的 API 配置不完整或无法读取', '到设置 → 功能与 API 确认对应接口，并检查地址、模型和密钥。')
    if isinstance(error, PermissionError): return result('permission', '本机权限', '无法访问所需文件或组件', '检查目录权限以及安全软件是否阻止访问。')
    if isinstance(error, (FileNotFoundError, ImportError)): return result('runtime', '运行组件', '所需文件或运行组件缺失', '使用完整的回声安装目录，检查安全软件是否隔离文件。')
    if 'database is locked' in raw or 'database is busy' in raw:
        return result('database_busy','本机数据库','本机数据库暂时繁忙','本机读写冲突；等待当前操作结束后重新运行。这不是网络或 API 余额不足。')
    if origin == 'wechat' or any(x in raw for x in ('微信', 'wechat', 'wcf', 'owner identity', 'sender identity')):
        if any(x in raw for x in ('未登录', 'not logged', '没有登录', 'login')): return result('wechat_login', '微信连接', '微信未登录或登录状态失效', '先在电脑登录微信，再点击开始运行。')
        return result('wechat_connection', '微信连接', '微信读取或连接失败', '确认电脑微信已登录且窗口正常；重新连接，仍失败时检查微信版本与读取组件。')
    if isinstance(error, json.JSONDecodeError) or any(x in raw for x in ('json', '模型格式', '模型响应', '模型返回', 'choices', '审校', '核验')): return result('format', '模型结果', '模型返回空内容、无效格式或未通过核验', '原有结果保留；可切换模型或检查结构化输出设置后重试。')
    if isinstance(error, OSError): return result('storage', '本机读写', '本机文件读取或保存失败', '检查磁盘空间、目录权限及文件是否被占用。')
    if isinstance(error, ValueError) and origin == 'local':
        # Only our application validation messages are eligible for display.
        safe = str(error)
        if safe in ('请先选择要分析的联系人', '请先选择联系人', '请先填写原稿', '请先填写问题', '消息修改建议已关闭', '人物问答已关闭', '当前分析范围不允许上传此联系人的聊天'):
            return result('validation', '操作条件', safe, '检查当前选择、功能开关及输入内容。')
    return result('unknown', '未确认原因', '操作未完成，尚不能确认具体原因', '查看本功能的运行记录；不能仅凭此错误判断网络或余额不足。')

def message(error, origin='local'):
    info = diagnose(error, origin)
    return info['errorTitle'] + '。' + info['errorAction']

def payload(error, origin='local'):
    info = diagnose(error, origin)
    return {'error': message(error, origin), 'errorInfo': info}
