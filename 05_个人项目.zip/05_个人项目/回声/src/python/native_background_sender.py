"""Experimental Value/Invoke sender for an already open, exact WeChat chat.

Not selected by the installed app. Windows UIA providers must pass a real
receipt and focus test before this can be enabled. No mouse, keys, clipboard,
window activation, fuzzy search, chat switching, or retry is implemented here.
"""
from dataclasses import dataclass
import time


class Blocked(Exception):
    def __init__(self, code):
        self.code = code
        super().__init__(code)


def chat_name(value):
    """Strip ONLY the known input placeholder; never substring/fuzzy matching."""
    if not isinstance(value, str):
        return ''
    name = value.strip()
    suffix = '输入文字，或按住Ctrl+Win使用语音输入'
    if name.endswith(suffix):
        name = name[:-len(suffix)].rstrip()
    return name


def session_name(value):
    """Known session-row schema: first nonempty line, exact name only."""
    if not isinstance(value, str):return ''
    return next((line.strip() for line in value.splitlines() if line.strip()), '')


def get_pattern(control, name):
    # Qt exposes Send as a CustomControl on some WeChat layouts. Generic UIA
    # controls have GetPattern, but not the specialized GetInvokePattern method.
    if hasattr(control, 'GetPattern'):
        import uiautomation as auto
        return control.GetPattern(getattr(auto.PatternId, name + 'Pattern'))
    # Pure injected test controls and older typed wrappers.
    return getattr(control, 'Get' + name + 'Pattern')()


@dataclass(frozen=True)
class Outcome:
    status: str
    code: str
    invoked: bool = False
    receipt: tuple | None = None
    invariants_unchanged: bool = True
    draft_remaining: bool = False
    detail: str = ''


def send_current_chat(*, recipient, text, locate, snapshot, foreground_is_wechat,
                      validate, claim, find_receipt, clock=time.monotonic,
                      wait=time.sleep, timeout=8):
    """One guarded invocation; claim revalidates through its single-use guard.

    locate returns the input and send button from the same confirmed window.
    validate and claim are required; callers bind exact native account/chat,
    latest message, pause, quiet hours, configuration, and owner identity.
    find_receipt must return a scoped new SELF message identity or None.
    A provider exception during Invoke is uncertain, never automatically retried.
    """
    if not isinstance(recipient, str) or not recipient.strip():
        return Outcome('blocked', 'identity')
    if not isinstance(text, str) or not text.strip() or len(text) > 20000:
        return Outcome('blocked', 'text')
    if type(timeout) not in (int, float) or not 0 < timeout <= 30:
        return Outcome('blocked', 'timeout')
    box = value = button = invoke = before = None
    wrote = invoked = False

    def desktop_unchanged():
        try:
            return before is not None and snapshot() == before
        except Exception:
            return False

    def owned_draft_remaining():
        try:
            return bool(wrote and chat_name(box.Name) == recipient and value.Value == text)
        except Exception:
            return wrote

    def check_input(expected):
        validate()
        if chat_name(box.Name) != recipient:
            raise Blocked('chat_changed')
        if snapshot() != before:
            raise Blocked('desktop_changed')
        if foreground_is_wechat():
            raise Blocked('owner_active')
        if box.IsOffscreen or button.IsOffscreen:
            raise Blocked('controls_not_visible')
        actual = value.Value
        if not isinstance(actual, str) or actual != expected:
            raise Blocked('input_changed')
        if value.IsReadOnly or not box.IsEnabled or (expected != '' and not button.IsEnabled):
            raise Blocked('controls_unavailable')

    try:
        validate()
        before = snapshot()
        if foreground_is_wechat():
            raise Blocked('owner_active')
        box, button = locate(recipient)
        if chat_name(box.Name) != recipient:
            raise Blocked('chat_changed')
        value = get_pattern(box, 'Value')
        invoke = get_pattern(button, 'Invoke')
        if value is None or invoke is None or value.IsReadOnly or not box.IsEnabled:
            raise Blocked('controls_unavailable')
        check_input('')
        # A partially failed SetValue can leave text; mark ownership before call.
        wrote = True
        value.SetValue(text)
        check_input(text)
        # Claim calls this verifier before atomically consuming the active grant.
        claim(lambda: check_input(text))
        # One more read protects a change between grant consumption and Invoke.
        check_input(text)
        invoked = True
        try:
            invoke.Invoke()
        except Exception:
            # A COM failure can occur after the provider actually sent the text.
            pass
        deadline = clock() + timeout
        receipt_error = False
        while clock() < deadline:
            try:
                receipt = find_receipt()
                if receipt is not None:
                    if (not isinstance(receipt, tuple) or len(receipt) != 2 or
                            any(type(n) is not int or n <= 0 for n in receipt)):
                        receipt_error = True
                    else:
                        unchanged = desktop_unchanged()
                        return Outcome('confirmed' if unchanged else 'confirmed_desktop_changed',
                                       'ok' if unchanged else 'desktop_changed', True,
                                       receipt, unchanged, owned_draft_remaining())
            except Exception:
                receipt_error = True
            wait(.1)
        unchanged = desktop_unchanged()
        return Outcome('uncertain', 'receipt_unavailable' if receipt_error else 'receipt_missing',
                       True, invariants_unchanged=unchanged,
                       draft_remaining=owned_draft_remaining())
    except Exception as error:
        code = error.code if isinstance(error, Blocked) else 'verification_failed'
        if invoked:
            return Outcome('uncertain', code, True, invariants_unchanged=False,
                           draft_remaining=owned_draft_remaining())
        # Cleanup only text demonstrably owned by this attempt in the SAME chat,
        # with all original desktop invariants intact. Never erase an owner draft.
        remaining = wrote
        try:
            if (wrote and chat_name(box.Name) == recipient and snapshot() == before and
                    not foreground_is_wechat() and value.Value == text):
                value.SetValue('')
                remaining = value.Value != ''
        except Exception:
            remaining = True
        return Outcome('blocked', code, draft_remaining=remaining,
                       invariants_unchanged=not wrote if before is None else desktop_unchanged())


def locate_current_chat(recipient, *, max_nodes=800, max_depth=40, allowed_handles=None,include_minimized=False):
    """Bounded Weixin-owned native controls only; no SDK ensure_window side effects."""
    from native_background_navigation import find_chat_controls
    import psutil
    import uiautomation as auto
    import win32gui
    import win32process
    pids = {p.pid for p in psutil.process_iter(['name'])
            if (p.info['name'] or '').lower() == 'weixin.exe'}
    handles = []

    def collect(handle, _):
        if (win32process.GetWindowThreadProcessId(handle)[1] in pids and
                win32gui.IsWindowVisible(handle) and (include_minimized is True or not win32gui.IsIconic(handle))):
            handles.append(handle)

    win32gui.EnumWindows(collect, None)
    if allowed_handles is not None:
        allowed = set(allowed_handles)
        if not allowed or any(type(h) is not int or h <= 0 for h in allowed):
            raise Blocked('account_binding')
        handles = [handle for handle in handles if handle in allowed]
    pairs = []
    deadline = time.monotonic() + 8
    for handle in handles:
        remaining=deadline-time.monotonic()
        if remaining<=0:raise Blocked('scan_incomplete')
        try:
            pid=win32process.GetWindowThreadProcessId(handle)[1]
            pairs.append(find_chat_controls(auto.ControlFromHandle(handle),pid,recipient,
                max_nodes=max_nodes,max_depth=max_depth,seconds=remaining))
        except Blocked as error:
            if error.code!='chat_not_open':raise
    if len(pairs) != 1:
        raise Blocked('chat_not_open')
    return pairs[0]
