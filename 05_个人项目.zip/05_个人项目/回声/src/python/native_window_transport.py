"""Account-bound Windows transport. No host input, clipboard or activation API.

Only the exact reviewed client can use this route. Local SELF receipts confirm
submission; they are not evidence of delivery to the remote phone.
"""
import contextlib,ctypes,io,json,logging,os,subprocess,sys,time,uuid
from pathlib import Path
from native_background_sender import Blocked,Outcome,get_pattern,chat_name,session_name
from native_background_account import make_cached_database,bind_database_window,WindowsMetadata
from native_background_navigation import owned_tree,find_chat_controls
from native_activation_trial import WindowsStyle,NOACTIVATE

VERSION='4.1.15.13'
REASONS={
 'owner_active':'你正在使用微信，已暂缓后台发送；不会抢焦点。',
 'owner_draft':'微信输入框已有你的草稿，已保留并停止本次发送。',
 'owner_mouse_down':'你正在按住鼠标，已暂缓本次发送。',
 'owner_modifier_active':'你正在按住修饰键，已暂缓本次发送。',
 'chat_not_open':'目标会话未打开，且不在当前可见的最近会话列表中；未进行模糊搜索。',
 'navigation_ambiguous':'会话名称不唯一，未切换或发送；请设置唯一备注。',
 'chat_changed':'微信会话发生变化，已取消本次发送。',
 'input_changed':'微信输入内容发生变化，已保留输入并取消发送。',
 'account_binding':'当前微信账号与本地记录不一致，未发送。',
 'binding_changed':'微信账号或窗口已经变化，已取消本次发送。',
 'receipt_missing':'发送动作已提交，但未查到新的本人发送记录；已暂停该会话，避免重复发送。',
 'verification_failed':'发送动作已提交，但读取发送结果时发生异常；不会重复发送。',
 'consent':'请在设置 → 微信连接允许当前 Windows 后台处理。',
 'version':'当前微信版本尚未通过此后台路线验收；未操作微信。',
 'accessibility':'微信后台控件尚未就绪；未操作鼠标或键盘。',
 'lease':'无法建立窗口状态恢复保护，未操作微信。',
}

def consent(config):
    value=config.get('wechatConnection') or {}
    if value.get('allowNativeAccessibility') is not True or value.get('allowNativeWindowEvents') is not True:
        raise Blocked('consent')

def foreground_is_wechat(binding):
    import win32gui,win32process
    handle=win32gui.GetForegroundWindow()
    return bool(handle and win32process.GetWindowThreadProcessId(handle)[1]==binding.pid)

def owner_guard(binding):
    import win32api
    if not binding.confirmed():raise Blocked('binding_changed')
    if foreground_is_wechat(binding):raise Blocked('owner_active')
    if win32api.GetAsyncKeyState(1)&0x8000:raise Blocked('owner_mouse_down')
    if any(win32api.GetAsyncKeyState(k)&0x8000 for k in (0x10,0x11,0x12)):raise Blocked('owner_modifier_active')

def ensure_accessibility(binding,config):
    consent(config)
    from wechat_connection_check import file_version
    from wechatauto.uia_driver import WeChatUIA
    module=WeChatUIA._weixin_dll_module(binding.pid)
    if not module or file_version(module[2])!=VERSION:raise Blocked('version')
    import uiautomation as auto
    # Read before activation; never repeat memory writes when already exposed.
    root=auto.ControlFromHandle(binding.handle)
    if root.ClassName=='mmui::MainWindow':return root
    if not binding.confirmed():raise Blocked('binding_changed')
    class ExactDriver(WeChatUIA):
        @staticmethod
        def _qaccessible_candidate_rvas(path):return [0x0B135C38]
    with contextlib.redirect_stdout(io.StringIO()):
        activated=ExactDriver(timeout=3)._hot_activate_accessibility(binding.handle,verify=True,max_candidates=1)
    if not activated or not binding.confirmed():raise Blocked('accessibility')
    root=auto.ControlFromHandle(binding.handle)
    if root.ClassName!='mmui::MainWindow':raise Blocked('accessibility')
    return root

def inspect(config,db=None):
    try:
        consent(config)
        if db is None:
            with contextlib.redirect_stdout(io.StringIO()):db=make_cached_database()
        binding=bind_database_window(db,WindowsMetadata(include_minimized=True))
        root=ensure_accessibility(binding,config)
        return {'ready':True,'status':'connected','provider':'native_windows',
            'currentVersion':VERSION,'background':True,'requiresDesktop':False,
            'desktopActions':0,'modelRequests':0,'wechatSends':0,
            'message':'Windows 后台连接已就绪。开始运行后监听新消息；不会移动鼠标或占用其他应用。'}
    except Exception as error:
        code=error.code if isinstance(error,Blocked) else 'account_binding'
        return {'ready':False,'status':'blocked','provider':'native_windows','errorCode':'wechat_'+code,
                'message':REASONS.get(code,'后台连接未完成，请检查微信是否已登录以及账号记录。'),
                'requiresDesktop':False,'desktopActions':0,'modelRequests':0,'wechatSends':0}

def button_position(handle,control):
    import win32gui
    if not control.IsEnabled:raise Blocked('controls_unavailable')
    rect=control.BoundingRectangle
    if win32gui.IsIconic(handle):
        # Windows moves minimized HWNDs to -32000 and reports an icon-sized
        # client. Qt retains its actual client tree/layout; use that exact owned
        # provider coordinate space, without restoring or showing the window.
        import uiautomation as auto,win32process
        root=auto.ControlFromHandle(handle)
        if root.ClassName!='mmui::MainWindow' or root.ProcessId!=win32process.GetWindowThreadProcessId(handle)[1]:
            raise Blocked('controls_unavailable')
        region=root.BoundingRectangle
        right,bottom=region.right-region.left,region.bottom-region.top
        if not 300<=right<32768 or not 300<=bottom<32768:raise Blocked('controls_unavailable')
        x,y=int((rect.left+rect.right)/2-region.left),int((rect.top+rect.bottom)/2-region.top)
    else:
        if control.IsOffscreen:raise Blocked('controls_unavailable')
        x,y=win32gui.ScreenToClient(handle,(int((rect.left+rect.right)/2),int((rect.top+rect.bottom)/2)))
        left,top,right,bottom=win32gui.GetClientRect(handle)
    if not 0<=x<min(right,32768) or not 0<=y<min(bottom,32768):raise Blocked('controls_unavailable')
    if control.BoundingRectangle!=rect:raise Blocked('controls_changed')
    return (y<<16)|x

def post_click(binding,control,validate):
    import win32gui
    position=button_position(binding.handle,control)
    validate();owner_guard(binding)
    # Exactly one button pair, scoped to the bound HWND. Never SendInput/click.
    win32gui.PostMessage(binding.handle,0x0201,1,position)
    win32gui.PostMessage(binding.handle,0x0202,0,position)

def locate_exact_chat(binding,root,recipient,validate,_tab_attempted=False):
    try:return find_chat_controls(root,binding.pid,recipient)
    except Blocked as e:
        if e.code!='chat_not_open':raise
    rows=[];inputs=[];tabs=[];edits=[]
    for control,parents in owned_tree(root,binding.pid):
        if control.ClassName=='mmui::ChatInputField':inputs.append(control)
        if control.ControlTypeName=='EditControl':edits.append(control)
        if (control.ClassName=='mmui::XTabBarItem' and control.Name=='微信' and
            any(p.ClassName=='mmui::MainTabBar' for p in parents)):tabs.append(control)
        if (control.ClassName=='mmui::ChatSessionCell' and
            any(p.ClassName=='mmui::ChatSessionList' for p in parents) and
            session_name(control.Name)==recipient and not control.IsOffscreen):rows.append(control)
    if not rows and not _tab_attempted and len(tabs)==1:
        # WeChat may be left on Moments/Contacts. Switch only its exact native
        # Chats tab, without a desktop click, while preserving any editor draft.
        def tab_preflight():
            validate()
            for box in edits:
                value=get_pattern(box,'Value')
                if value is None or (not value.IsReadOnly and value.Value!=''):raise Blocked('owner_draft')
        post_click(binding,tabs[0],tab_preflight)
        deadline=time.monotonic()+1.2
        while time.monotonic()<deadline:
            validate();owner_guard(binding)
            try:return locate_exact_chat(binding,root,recipient,validate,True)
            except Blocked as error:
                if error.code!='chat_not_open':raise
            time.sleep(.05)
        raise Blocked('chat_not_open')
    if len(rows)!=1:raise Blocked('chat_not_open' if not rows else 'navigation_ambiguous')
    for box in inputs:
        value=get_pattern(box,'Value')
        if value is None or value.Value!='':raise Blocked('owner_draft')
    def preflight():
        validate()
        for box in inputs:
            if get_pattern(box,'Value').Value!='':raise Blocked('owner_draft')
    post_click(binding,rows[0],preflight)
    deadline=time.monotonic()+1.2
    while time.monotonic()<deadline:
        validate();owner_guard(binding)
        try:return find_chat_controls(root,binding.pid,recipient)
        except Blocked as error:
            if error.code!='chat_not_open':raise
        time.sleep(.05)
    raise Blocked('chat_changed')

def process_alive(pid,created):
    try:
        import psutil
        return psutil.Process(pid).create_time()==created
    except Exception:return False

def lease_folder():
    from echo_paths import DATA
    folder=DATA/'native-window-leases';folder.mkdir(parents=True,exist_ok=True)
    return folder

def restore_record(record):
    from native_background_account import Binding
    env=WindowsMetadata(include_minimized=True)
    binding=Binding(record['handle'],record['pid'],record['class'],record['created'],
                    Path(record['account']),Path(record['base']),env)
    if not binding.confirmed():return False
    if not record['added']:return True
    style=WindowsStyle();style.write(binding.handle,style.read(binding.handle)&~NOACTIVATE)
    return not bool(style.read(binding.handle)&NOACTIVATE)

def watchdog(path):
    import win32event,win32api
    path=Path(path).resolve()
    if path.parent!=lease_folder().resolve() or path.suffix!='.json':return 2
    record=json.loads(path.read_text('utf-8'));ready=path.with_suffix('.ready');done=path.with_suffix('.done')
    mutex=win32event.CreateMutex(None,False,'Local\\EchoNativeWindow_'+str(record['pid'])+'_'+str(record['handle']))
    acquired=win32event.WaitForSingleObject(mutex,0) in (0,0x80)
    if not acquired:
        win32api.CloseHandle(mutex)
        return 3
    ready.touch()
    try:
        while not done.exists() and process_alive(record['owner'],record['ownerCreated']) and time.time()<record['expires']:
            time.sleep(.1)
        if not done.exists():
            if time.time()>=record['expires'] and process_alive(record['owner'],record['ownerCreated']):
                # A stalled provider must not resume writing after its focus
                # protection expires. Kill only this lease's same-lifetime
                # Python sender, never the bound WeChat process.
                import psutil
                owner=psutil.Process(record['owner'])
                if (owner.create_time()==record['ownerCreated'] and
                    Path(owner.exe()).resolve()==Path(sys.executable).resolve()):
                    owner.kill()
                    try:owner.wait(timeout=2)
                    except psutil.TimeoutExpired:pass
            # Restore even if the sender is killed by manual takeover or Stop.
            # Wait a moment to let already queued messages finish before cleanup.
            time.sleep(.15)
            restore_record(record)
    finally:
        for p in (path,ready,done):p.unlink(missing_ok=True)
        win32event.ReleaseMutex(mutex);win32api.CloseHandle(mutex)
    return 0

@contextlib.contextmanager
def activation_lease(binding,*,seconds=25):
    import psutil
    if type(seconds) not in (int,float) or not 0<seconds<=25:raise Blocked('lease')
    owner=psutil.Process();styles=WindowsStyle();original=styles.read(binding.handle)
    path=lease_folder()/(uuid.uuid4().hex+'.json')
    record={'owner':owner.pid,'ownerCreated':owner.create_time(),'expires':time.time()+seconds,
        'handle':binding.handle,'pid':binding.pid,'class':binding.native_class,'created':binding.created,
        'account':str(binding.account),'base':str(binding.base),'added':not bool(original&NOACTIVATE)}
    path.write_text(json.dumps(record),'utf-8')
    helper=None;restored=False;changed=False
    try:
        helper=subprocess.Popen([sys.executable,'-X','utf8',str(Path(__file__).resolve()),'--watchdog',str(path)],
            stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        deadline=time.monotonic()+4
        while not path.with_suffix('.ready').exists():
            if helper.poll() is not None or time.monotonic()>deadline:raise Blocked('lease')
            time.sleep(.02)
        if not binding.confirmed():raise Blocked('binding_changed')
        if record['added']:
            changed=True
            styles.write(binding.handle,original|NOACTIVATE)
        if styles.read(binding.handle)&NOACTIVATE==0:raise Blocked('lease')
        yield
    finally:
        restored=restore_record(record) if changed else True
        if restored:path.with_suffix('.done').touch()
        if helper is not None:
            try:helper.wait(timeout=1)
            except subprocess.TimeoutExpired:pass
        if helper is None or helper.poll() is not None:
            for p in (path,path.with_suffix('.ready'),path.with_suffix('.done')):p.unlink(missing_ok=True)
        if not restored:raise Blocked('lease_restore')

def send_window_chat(*,binding,root,recipient,text,locate,snapshot,foreground_is_wechat,
                     validate,claim,find_receipt,timeout=8,clock=time.monotonic,wait=time.sleep):
    from sender_progress import stage
    box=value=None;wrote=posted=False
    phase='发送前检查';receipt_error=''
    def remaining_draft():
        try:return bool(wrote and chat_name(box.Name)==recipient and value.Value==text)
        except Exception:return False
    try:
        if not isinstance(text,str) or not text.strip() or len(text)>20000:raise Blocked('text')
        validate();owner_guard(binding)
        with activation_lease(binding):
            stage('精确定位收信会话')
            box,button=locate_exact_chat(binding,root,recipient,validate)
            value=get_pattern(box,'Value')
            def check(expected):
                validate();owner_guard(binding)
                if chat_name(box.Name)!=recipient:raise Blocked('chat_changed')
                if value.Value!=expected:raise Blocked('owner_draft' if expected=='' else 'input_changed')
                if value.IsReadOnly or not box.IsEnabled:raise Blocked('controls_unavailable')
            stage('发前检查并写入回复');check('');wrote=True
            value.SetValue(text,waitTime=.02)
            check(text)
            if button.ClassName!='mmui::XOutlineButton':raise Blocked('controls_unavailable')
            position=button_position(binding.handle,button)
            claim(lambda:check(text));check(text)
            if button_position(binding.handle,button)!=position:raise Blocked('controls_changed')
            import win32gui
            phase='发送记录核验';stage('提交微信发送并核验记录')
            posted=True
            win32gui.PostMessage(binding.handle,0x0201,1,position)
            win32gui.PostMessage(binding.handle,0x0202,0,position)
            deadline=clock()+timeout
            while clock()<deadline:
                try:receipt=find_receipt()
                except (OSError,__import__('sqlite3').Error) as error:
                    receipt_error=type(error).__name__;wait(.1);continue
                if receipt is not None:
                    if (not isinstance(receipt,tuple) or len(receipt)!=2 or any(type(x) is not int or x<=0 for x in receipt)):
                        raise Blocked('receipt_invalid')
                    # Receipt is authoritative. Reading an expired UIA value
                    # after Qt clears the editor must never turn it into failure.
                    try:unchanged=not foreground_is_wechat()
                    except Exception:unchanged=False
                    return Outcome('confirmed','ok',True,receipt,unchanged,remaining_draft())
                # Receiving new SELF content is also a takeover; parent revokes
                # the active grant and kills us. The watchdog restores the flag.
                if not binding.confirmed():raise Blocked('binding_changed')
                wait(.05)
            return Outcome('uncertain','receipt_missing',True,draft_remaining=remaining_draft(),detail=('发送记录读取异常：'+receipt_error) if receipt_error else '')
    except Exception as error:
        code=error.code if isinstance(error,Blocked) else 'verification_failed'
        if not posted and wrote:
            # Only erase our own exact draft while the account/chat and owner
            # state remain unchanged, protected against provider focus changes.
            try:
                owner_guard(binding)
                if chat_name(box.Name)==recipient and value.Value==text:
                    with activation_lease(binding):value.SetValue('',waitTime=.02)
            except Exception:pass
        remaining=False
        try:remaining=bool(wrote and chat_name(box.Name)==recipient and value.Value==text)
        except Exception:remaining=wrote
        return Outcome('uncertain' if posted else 'blocked',code,posted,draft_remaining=remaining,
                       detail=phase+'：'+type(error).__name__ if not isinstance(error,Blocked) else '')

def send_authorized(payload,db):
    from sender_progress import stage
    import send_guard
    from native_background_bridge import send_authorized as grant_send
    config=send_guard.read_settings();consent(config)
    stage('确认微信账号与窗口')
    binding=bind_database_window(db,WindowsMetadata(include_minimized=True))
    stage('读取微信后台控件')
    root=ensure_accessibility(binding,config)
    def implementation(**kwargs):
        stage('核验目标会话并准备发送')
        return send_window_chat(binding=binding,root=root,**kwargs)
    return grant_send(payload,db,assert_binding=binding.confirmed,bound_handle=binding.handle,
        snapshot=lambda:foreground_is_wechat(binding),foreground_is_wechat=lambda:foreground_is_wechat(binding),
        send_impl=implementation)

if __name__=='__main__':
    if len(sys.argv)==3 and sys.argv[1]=='--watchdog':raise SystemExit(watchdog(sys.argv[2]))
    raise SystemExit(2)
