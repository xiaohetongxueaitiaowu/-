"""Fail-closed binding of a live Weixin window to native DB file metadata.

Only paths/handles/process lifetime are inspected. No process memory, clipboard,
database contents, network, accessibility activation, or window focus actions.
"""
from dataclasses import dataclass
from pathlib import Path
from native_background_sender import Blocked


def make_cached_database(**kwargs):
    """Standalone probes: use cached keys; prohibit SDK live-memory key scans.

    The reviewed SDK routes key extraction through _find_weixin_pids. Empty it
    for initialization, restoring it even on failure. This process-local patch
    must not be used in a multithreaded in-process desktop service.
    """
    from unittest.mock import patch
    from wechatauto import WeChatDB as Base
    from wechat_identity import make_db
    with patch.object(Base, '_find_weixin_pids', return_value=[]):
        return make_db(**kwargs)


class WindowsMetadata:
    def __init__(self,*,include_minimized=False):
        self.include_minimized=include_minimized is True
    def windows(self):
        import psutil,win32gui,win32process
        processes={p.pid:p for p in psutil.process_iter(['name'])
                   if (p.info['name'] or '').lower()=='weixin.exe'}
        output=[]
        def collect(handle,_):
            pid=win32process.GetWindowThreadProcessId(handle)[1]
            if pid in processes and win32gui.IsWindowVisible(handle) and (self.include_minimized or not win32gui.IsIconic(handle)):
                # Browser/image popups are not treated as the main chat window.
                if win32gui.GetWindow(handle,4):return  # GW_OWNER
                output.append((handle,pid,win32gui.GetClassName(handle)))
        win32gui.EnumWindows(collect,None)
        return output
    def files(self,pid):
        import psutil
        return [f.path for f in psutil.Process(pid).open_files()]
    def lifetime(self,pid):
        import psutil
        p=psutil.Process(pid)
        if p.name().lower()!='weixin.exe':raise Blocked('account_binding')
        return p.create_time()


def account_paths(files,base):
    accounts=set()
    for value in files:
        try:
            path=Path(value).resolve();rel=path.relative_to(base)
        except (ValueError,OSError,TypeError):continue
        # Accept only the SDK's direct account/db_storage structure.
        if (len(rel.parts)>=3 and rel.parts[1].casefold()=='db_storage' and
                path.name.casefold().endswith(('.db','.db-wal','.db-shm','.db-journal'))):
            accounts.add((base/rel.parts[0]).resolve())
    return accounts


@dataclass(frozen=True,repr=False)
class Binding:
    handle:int
    pid:int
    native_class:str
    created:float
    account:Path
    base:Path
    environment:object
    def confirmed(self):
        try:
            return (self.environment.lifetime(self.pid)==self.created and
                    (self.handle,self.pid,self.native_class) in self.environment.windows() and
                    account_paths(self.environment.files(self.pid),self.base)=={self.account})
        except Exception:return False


def bind_database_window(db,environment=None):
    environment=environment or WindowsMetadata()
    try:
        base=Path(db.db_dir).resolve();account=Path(db.account_dir).resolve()
        if account.parent!=base:raise Blocked('account_binding')
        candidates=[];per_pid={}
        for handle,pid,cls in environment.windows():
            if not (type(handle) is int and handle>0 and type(pid) is int and pid>0 and
                    isinstance(cls,str) and cls.startswith('Qt') and cls.endswith('QWindowIcon')):
                continue
            if pid not in per_pid:per_pid[pid]=account_paths(environment.files(pid),base)
            if per_pid[pid]=={account}:
                candidates.append(Binding(handle,pid,cls,environment.lifetime(pid),account,base,environment))
        if len(candidates)!=1 or not candidates[0].confirmed():raise Blocked('account_binding')
        return candidates[0]
    except Exception as error:
        if isinstance(error,Blocked):raise
        raise Blocked('account_binding') from None
