"""One active sender's local phases; no message body or model credentials."""
import hashlib,json,os,time
from echo_paths import DATA
ACTIVE={}
START=0
PATH=DATA/'send-progress.json'
def operation(token):return hashlib.sha256(str(token).encode()).hexdigest()[:16]
def begin(payload):
    global START
    START=time.monotonic();ACTIVE.clear()
    ACTIVE.update(operation=operation(payload['authorization']),chatId=payload.get('user'),seq=payload.get('sourceSeq'),localId=payload.get('sourceId'),pid=os.getpid())
def stage(phase):
    if not ACTIVE:return
    value={**ACTIVE,'phase':phase,'elapsed':round(time.monotonic()-START,2),'updatedAt':time.time()}
    try:
        PATH.parent.mkdir(parents=True,exist_ok=True)
        temp=PATH.with_name('send-progress.'+str(os.getpid())+'.tmp');temp.write_text(json.dumps(value,ensure_ascii=False),'utf-8');os.replace(temp,PATH)
    except OSError:pass
def read(token):
    try:
        value=json.loads(PATH.read_text('utf-8-sig'))
        return value if value.get('operation')==operation(token) else {}
    except (OSError,ValueError,AttributeError):return {}
