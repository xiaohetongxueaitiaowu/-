"""Explicit per-feature routing. Credentials never belong in exported settings."""
import json
from pathlib import Path
import assistant_features as features

FEATURES=('reply','daily','weekly','reminders','memory','adviser','contact')

def resolve(config,feature=None):
    if not isinstance(config,dict):raise ValueError('API 设置必须是对象')
    result=dict(config)
    feature=feature or config.get('modelFeature') or 'reply'
    if feature not in FEATURES:raise ValueError('未知模型功能')
    result['modelFeature']=feature
    mappings=config.get('featureModels') or {}
    profiles=config.get('modelProfiles') or {}
    keys=config.get('profileKeys') or {}
    if not all(isinstance(value,dict) for value in (mappings,profiles,keys)):
        raise ValueError('功能 API 分配或密钥设置格式无效，请在设置重新保存')
    identity=mappings.get(feature,'default')
    if identity is not None and not isinstance(identity,str):raise ValueError('功能 API 名称格式无效')
    if identity in ('','default',None):return result
    profile=profiles.get(identity)
    if not isinstance(profile,dict):raise ValueError('所选功能的 API 配置已不存在，请在设置重新选择')
    if not str(profile.get('model') or '').strip() or not str(profile.get('apiBaseUrl') or '').strip():
        raise ValueError('所选 API 的地址或模型未填写，未回退默认服务')
    for key in ('apiBaseUrl','apiProtocol','model','jsonMode','maxOutputTokens'):
        if key in profile:result[key]=profile[key]
    if not str(result.get('model') or '').strip() or not str(result.get('apiBaseUrl') or '').strip():
        raise ValueError('所选功能的 API 地址或模型未填写')
    result['apiKey']=''
    secret=features.DATA/'api-profiles.bin'
    if identity not in keys and secret.exists():
        try:
            import win32crypt
            keys=json.loads(win32crypt.CryptUnprotectData(secret.read_bytes(),None,None,None,0)[1].decode('utf-8'))
            if not isinstance(keys,dict):raise ValueError()
        except Exception:raise ValueError('此电脑无法读取所选 API 的密钥，请在设置重新填写')
    result['apiKey']=str(keys.get(identity) or '')
    result['selectedModelProfile']=identity
    return result

def token_limit(value,allow_zero=False):
    if isinstance(value,str) and value.isascii() and value.isdecimal():value=int(value)
    if type(value) is not int or value<(0 if allow_zero else 1):
        raise ValueError('API 输出上限必须是有效整数，0 表示不设置配置上限')
    return value

def payload_for(config,payload):
    value=dict(payload);value['model']=config.get('model',value.get('model'))
    maximum=token_limit(config.get('maxOutputTokens',0),allow_zero=True)
    if 'max_tokens' in value:
        requested=token_limit(value['max_tokens'])
        value['max_tokens']=min(requested,maximum) if maximum else requested
    return value
