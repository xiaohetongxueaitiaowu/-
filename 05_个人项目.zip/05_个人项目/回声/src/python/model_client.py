"""Shared stdlib model client and a transactional daily request/cost guard."""
import datetime as dt
import json
import math
import urllib.request
import urllib.error
import time
from urllib.parse import urlsplit
import assistant_features as features

class BudgetExceeded(ValueError): pass

class NoModelRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None

def open_model(request,timeout):
    # Model prompts and API headers stay at the explicitly configured endpoint.
    # A redirect is a configuration error, never implicit upload authorization.
    return urllib.request.build_opener(NoModelRedirect()).open(request,timeout=timeout)

MAX_RESPONSE_BYTES=8*1024*1024

def strict_json(text):
    def pairs(items):
        result={}
        for key,value in items:
            if key in result:raise ValueError('模型响应包含重复字段')
            result[key]=value
        return result
    def constant(value):raise ValueError('模型响应包含无效数字')
    def number(value):
        parsed=float(value)
        if not math.isfinite(parsed):raise ValueError('模型响应包含无效数字')
        return parsed
    try:parsed=json.loads(text,object_pairs_hook=pairs,parse_constant=constant,parse_float=number)
    except RecursionError:raise ValueError('模型响应嵌套过深') from None
    stack=[(parsed,0)]
    while stack:
        value,depth=stack.pop()
        if depth>64:raise ValueError('模型响应嵌套过深')
        if isinstance(value,dict):stack.extend((x,depth+1) for x in value.values())
        elif isinstance(value,list):stack.extend((x,depth+1) for x in value)
    return parsed

def read_response(handle):
    raw=handle.read(MAX_RESPONSE_BYTES+1)
    if not isinstance(raw,(bytes,str)):raise ValueError('模型响应读取格式无效')
    size=len(raw) if isinstance(raw,bytes) else len(raw.encode('utf-8'))
    if size>MAX_RESPONSE_BYTES:raise ValueError('模型响应过大，已停止读取')
    try:return strict_json(raw.decode('utf-8-sig') if isinstance(raw,bytes) else raw)
    except (UnicodeError,json.JSONDecodeError,RecursionError):
        raise ValueError('模型响应不是有效UTF-8 JSON') from None

def nonnegative(value):
    number=float(value or 0)
    if not math.isfinite(number) or number<0: raise ValueError('费用或用量数值无效')
    return number

def endpoint(config):
    base=str(config.get('apiBaseUrl') or 'https://api.deepseek.com').rstrip('/')
    url=urlsplit(base)
    if url.username or url.password or url.query or url.fragment or (url.scheme!='https' and not
            (url.scheme=='http' and url.hostname in ('localhost','127.0.0.1','::1'))):
        raise ValueError('模型地址须为 HTTPS 或本机 HTTP，且不能包含密码或查询参数')
    if not url.hostname: raise ValueError('模型地址无效')
    suffix='/messages' if config.get('apiProtocol')=='anthropic' else '/chat/completions'
    if suffix=='/messages' and not base.endswith(('/v1','/messages')):base+='/v1'
    return base if base.endswith(suffix) else base+suffix

def reserve(config,payload):
    day=dt.date.today().isoformat()
    # Conservative byte upper bound avoids downloading a tokenizer.
    pool=config.get('requestPurpose','reply')
    cap=nonnegative(config.get('analysisCostLimit',0) if config.get('splitBudgets') and pool=='analysis' else config.get('assistCostLimit',0) if config.get('splitBudgets') and pool=='assist' else config.get('dailyCostLimit',0))
    inp=nonnegative(config.get('inputPrice',0));out=nonnegative(config.get('outputPrice',0))
    enabled=config.get('budgetEnabled',True)
    if int(payload.get('max_tokens',500))<1: raise ValueError('输出上限无效')
    if enabled and cap>0 and (inp<=0 or out<=0):
        raise BudgetExceeded('费用上限需要填写输入、输出单价；已暂停请求')
    worst=(len(json.dumps(payload['messages'],ensure_ascii=False).encode('utf-8'))*inp+
           int(payload.get('max_tokens',500))*out)/1000000
    with features.database() as conn:
        conn.execute('BEGIN IMMEDIATE')
        conn.execute('INSERT OR IGNORE INTO usage VALUES(?,0,0,0,0)',(day,))
        conn.execute('CREATE TABLE IF NOT EXISTS usage_pools(day TEXT,pool TEXT,calls INTEGER,cost REAL,reserved REAL,PRIMARY KEY(day,pool))')
        pool=config.get('requestPurpose','reply')
        if pool not in ('reply','analysis','assist'):raise ValueError('模型预算用途无效')
        conn.execute('INSERT OR IGNORE INTO usage_pools VALUES(?,?,0,0,0)',(day,pool))
        split=config.get('splitBudgets',False)
        poolrow=conn.execute('SELECT * FROM usage_pools WHERE day=? AND pool=?',(day,pool)).fetchone()
        limit=int(config.get('dailyAnalysisRequestLimit',30) if pool=='analysis' else config.get('dailyAssistRequestLimit',20) if pool=='assist' else config.get('dailyRequestLimit',80))
        if split:
            cap=nonnegative(config.get('analysisCostLimit',0) if pool=='analysis' else config.get('assistCostLimit',0) if pool=='assist' else config.get('dailyCostLimit',0))
        row=conn.execute('SELECT * FROM usage WHERE day=?',(day,)).fetchone()
        if enabled and (poolrow['calls']>=limit if split else row['calls']>=int(config.get('dailyRequestLimit',80))):
            raise BudgetExceeded('已达到今天的模型请求次数上限')
        if enabled and cap>0 and ((poolrow['cost']+poolrow['reserved']) if split else (row['cost']+row['reserved']))+worst>cap:
            raise BudgetExceeded('本次请求可能超过今天费用上限，已暂停')
        if enabled and cap>0 and (inp<=0 or out<=0):raise BudgetExceeded('费用上限需要输入、输出单价')
        conn.execute('UPDATE usage SET calls=calls+1,reserved=reserved+? WHERE day=?',(worst,day))
        conn.execute('UPDATE usage_pools SET calls=calls+1,reserved=reserved+? WHERE day=? AND pool=?',(worst,day,pool))
        conn.execute('DELETE FROM usage_pools WHERE day<?',((dt.date.today()-dt.timedelta(days=60)).isoformat(),))
        conn.execute('DELETE FROM usage WHERE day<?',((dt.date.today()-dt.timedelta(days=60)).isoformat(),))
    return day,worst

def complete(config,day,worst,response,success):
    usage=response.get('usage') or {}
    if not isinstance(usage,dict):usage={}
    try:
        inp=nonnegative(config.get('inputPrice',0));out=nonnegative(config.get('outputPrice',0))
        hit=nonnegative(usage.get('prompt_cache_hit_tokens',0))
        prompt=nonnegative(usage.get('prompt_tokens',0))
        miss=nonnegative(usage.get('prompt_cache_miss_tokens',max(0,prompt-hit)))
        cache_price=nonnegative(config.get('cacheInputPrice',inp))
        cost=(miss*inp+hit*cache_price+nonnegative(usage.get('completion_tokens',0))*out)/1000000 if usage else worst
    except (ValueError, TypeError):
        cost=worst
    # An uncertain timeout may already be charged; keep its worst reservation.
    with features.database() as conn:
        if success:
            conn.execute('UPDATE usage SET cost=cost+?,reserved=max(0,reserved-?) WHERE day=?',(cost,worst,day))
            conn.execute('UPDATE usage_pools SET cost=cost+?,reserved=max(0,reserved-?) WHERE day=? AND pool=?',(cost,worst,day,config.get('requestPurpose','reply')))
    features.event('模型请求完成' if success else '模型请求失败',
                   '已按配置估算费用' if success else '未自动重试；不确定请求保留预算')

def _request(config,payload,timeout=45,opener=None):
    url=endpoint(config)
    payload=dict(payload)
    if urlsplit(url).hostname!='api.deepseek.com': payload.pop('thinking',None)
    key=str(config.get('apiKey') or '')
    if not key and urlsplit(url).hostname not in ('localhost','127.0.0.1','::1'):
        raise ValueError('未填写模型 API Key')
    day,worst=reserve(config,payload)
    response={};success=False
    try:
        headers={'Content-Type':'application/json'}
        if config.get('apiProtocol')=='anthropic':
            headers['x-api-key']=key;headers['anthropic-version']='2023-06-01'
            payload={'model':payload['model'],'max_tokens':payload.get('max_tokens',500),
                     'system':'\n'.join(m['content'] for m in payload['messages'] if m['role']=='system'),
                     'messages':[m for m in payload['messages'] if m['role']!='system']}
        elif key: headers['Authorization']='Bearer '+key
        elif urlsplit(url).hostname not in ('localhost','127.0.0.1','::1'):
            raise ValueError('未填写模型 API Key')
        req=urllib.request.Request(url,data=json.dumps(payload,ensure_ascii=False).encode('utf-8'),headers=headers,method='POST')
        with (opener or open_model)(req,timeout=timeout) as handle:
            response=read_response(handle)
        if not isinstance(response,dict):
            response={};raise ValueError('模型响应不是对象')
        if config.get('apiProtocol')=='anthropic':
            blocks=response.get('content')
            if not isinstance(blocks,list) or any(not isinstance(x,dict) for x in blocks):raise ValueError('模型响应内容块格式无效')
            texts=[x.get('text') for x in blocks if x.get('type')=='text']
            if any(not isinstance(x,str) for x in texts):raise ValueError('模型响应文本格式无效')
            content=''.join(texts)
            use=response.get('usage') or {}
            if not isinstance(use,dict):raise ValueError('模型响应用量格式无效')
            response={'choices':[{'message':{'content':content},'finish_reason':'length' if response.get('stop_reason')=='max_tokens' else 'stop'}],
                      'usage':{'prompt_tokens':use.get('input_tokens',0),'completion_tokens':use.get('output_tokens',0)}}
        if not isinstance(response.get('choices'),list) or not response['choices']:
            raise ValueError('模型返回缺少 choices')
        choice=response['choices'][0]
        if not isinstance(choice,dict) or not isinstance(choice.get('message'),dict):raise ValueError('模型响应候选格式无效')
        if choice.get('finish_reason')=='length': raise ValueError('模型回复达到输出上限，已跳过截断内容')
        if not isinstance(choice.get('message',{}).get('content'),str) or not choice['message']['content'].strip():
            raise ValueError('模型返回空内容')
        success=True
        return response
    finally:
        complete(config,day,worst,response,success)

def _format_capability(config,value=None):
    identity=json.dumps([endpoint(config),config.get('model','')])
    with features.database() as conn:
        conn.execute('CREATE TABLE IF NOT EXISTS model_capabilities(identity TEXT PRIMARY KEY,json_format INTEGER,updated REAL)')
        if value is not None:
            conn.execute('INSERT OR REPLACE INTO model_capabilities VALUES(?,?,?)',(identity,int(value),time.time()))
        row=conn.execute('SELECT json_format FROM model_capabilities WHERE identity=? AND updated>?',(identity,time.time()-7*86400)).fetchone()
    return None if row is None else bool(row[0])

def request(config,payload,timeout=45,opener=None):
    import runtime_health as health
    import model_routes
    import error_diagnostics as diagnostics
    try:
        config=model_routes.resolve(config)
        payload=model_routes.payload_for(config,payload)
    except Exception as error:
        health.failure('model',error,'model')
        feature=config.get('modelFeature','reply')
        if feature in ('reply','daily','weekly','reminders','memory','adviser','contact'):health.failure('model-'+feature,error,'model')
        raise
    formatted='response_format' in payload and config.get('apiProtocol')!='anthropic'
    if config.get('jsonMode')=='prompt' or formatted and _format_capability(config) is False:
        payload.pop('response_format',None);formatted=False
    feature=config.get('modelFeature','reply')
    def signal(status,**details):
        details.update(feature=feature,model=config.get('model',''),phase=config.get('requestPurpose','reply'))
        health.update('model',status,**details)
        if feature in ('reply','daily','weekly','reminders','memory','adviser','contact'):health.update('model-'+feature,status,**details)
    signal('requesting')
    try:
        try:response=_request(config,payload,timeout,opener)
        except urllib.error.HTTPError as error:
            # Only an explicit unsupported structured-output parameter permits retry.
            if not formatted or error.code not in (400,422):raise
            detail=diagnostics.http_detail(error).lower()
            if not any(x in detail for x in ('response_format','json_object','json_schema')) or not any(x in detail for x in ('unsupported','not support','invalid','not allowed','unknown','不支持')):raise
            error.close();_format_capability(config,False);payload.pop('response_format',None)
            response=_request(config,payload,timeout,opener);formatted=False
        if formatted:_format_capability(config,True)
        signal('ok',lastSuccessAt=time.time(),error='',jsonMode='结构化JSON' if formatted else '提示词JSON / 普通文本')
        return response
    except Exception as error:
        error.echo_diagnostic=diagnostics.diagnose(error,'model')
        signal('error',lastFailureAt=time.time(),error=diagnostics.message(error,'model'),**error.echo_diagnostic)
        if isinstance(error,urllib.error.HTTPError):error.close()
        raise

def bounded_history(history,max_chars=4000,max_messages=6):
    result=[];length=0
    for item in reversed(history[-max_messages:]):
        text=str(item.get('content',''))
        if length+len(text)>max_chars: break
        result.append({'role':item['role'],'content':text});length+=len(text)
    result.reverse()
    if result and result[0]['role']=='assistant': result=result[1:]
    return result

if __name__=='__main__':
    import sys
    value=json.load(sys.stdin)
    try:print(json.dumps(request(value['config'],value['payload']),ensure_ascii=False))
    except Exception as error:
        import error_diagnostics
        print(json.dumps(error_diagnostics.payload(error,'model'),ensure_ascii=False),file=sys.stderr);sys.exit(2)
