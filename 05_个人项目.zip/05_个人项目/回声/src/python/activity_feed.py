"""Local run feed, keyed by conversation and message identity rather than text."""
import datetime as dt
import json
import sqlite3
import hashlib
from contextlib import closing
import assistant_features as features

LABELS={'RECEIVED':'已收到','QUEUED':'正在生成回复','READY_TO_SEND':'正在准备微信发送','AUTO_SENT':'已回复',
        'WAITING_OWNER':'你正在操作，等待后台发送（不重复调用 AI）',
        'SERVER_ACCEPTED':'微信已接受，等待回显核验','DRAFT_PENDING':'草稿待确认','MEDIA_UNSUPPORTED':'媒体内容尚未解析，未自动回复',
        'SEND_FAILED':'发送失败','NEED_OWNER':'需要你处理','QUIET':'免打扰，未回复','RECORDED':'只记录',
        'PAUSED':'本次本人发信后暂停','BLOCKED':'需处理暂停（查看原因）','SKIPPED':'已跳过','GROUP_MENTION_UNVERIFIED':'未确认@你','CANCELLED':'已取消'}
def tables(conn):
    conn.execute('CREATE TABLE IF NOT EXISTS incoming_activity(chat_id TEXT,seq INTEGER,local_id INTEGER,at REAL,source TEXT,speaker TEXT,preview TEXT,status TEXT,PRIMARY KEY(chat_id,seq,local_id))')
    if 'status_detail' not in {r[1] for r in conn.execute('PRAGMA table_info(incoming_activity)')}:
        conn.execute("ALTER TABLE incoming_activity ADD COLUMN status_detail TEXT NOT NULL DEFAULT ''")
def received(chat_id,seq,local_id,source,speaker,text,at=None):
    with features.database() as conn:
        tables(conn)
        conn.execute('INSERT OR IGNORE INTO incoming_activity(chat_id,seq,local_id,at,source,speaker,preview,status) VALUES(?,?,?,?,?,?,?,?)',(chat_id,int(seq),int(local_id),at or dt.datetime.now().timestamp(),source,speaker,str(text)[:300],'RECEIVED'))
        conn.execute('DELETE FROM incoming_activity WHERE at<?',(dt.datetime.now().timestamp()-60*86400,))
def status(chat_id,seq,local_id,decision,detail=''):
    with features.database() as conn:
        tables(conn)
        conn.execute('UPDATE incoming_activity SET status=?,status_detail=? WHERE chat_id=? AND seq=? AND local_id=?',(decision,str(detail)[:250],chat_id,int(seq),int(local_id)))
def read(start=0,limit=50):
    limit=max(1,min(100,int(limit)))
    with features.database() as conn:
        tables(conn);items=[dict(x) for x in conn.execute('SELECT * FROM incoming_activity WHERE at>=? ORDER BY at DESC,seq DESC LIMIT ?',(float(start),limit))]
    from personal_web_database import configured,archive_path
    from wechat_direct_probe import ProbeError
    try:path=archive_path() if configured() else features.DATA/'近两个月聊天.sqlite'
    except (OSError,ValueError,ProbeError):path=None
    known={hashlib.sha256(('%s|%s|%s|%s'%(x['chat_id'],x['seq'],x['local_id'],int(x['at']))).encode()).hexdigest()[:24] for x in items}
    if path is not None and path.exists():
        try:
            with closing(sqlite3.connect('file:'+path.as_posix()+'?mode=ro',uri=True,timeout=2)) as conn:
                conn.row_factory=sqlite3.Row
                feed_conversations={x['chat_id'] for x in items}
                for row in conn.execute("SELECT id,ts,chat_id,chat_name,sender_name,content FROM messages WHERE ts>=? AND sender_role='other' AND identity_state='verified' ORDER BY ts DESC LIMIT ?",(float(start),limit)):
                    if configured() and row['chat_id'] in feed_conversations:continue
                    if row['id'] in known:continue
                    items.append({'chat_id':row['chat_id'],'at':row['ts'],'source':row['chat_name'],'speaker':row['sender_name'],'preview':row['content'][:300],'status':'RECORDED'})
        except sqlite3.Error:pass
    for item in items:
        item['time']=dt.datetime.fromtimestamp(item['at']).strftime('%H:%M:%S');item['statusText']=LABELS.get(item['status'],'已收到，未自动回复')
        if item.get('status_detail'):item['statusText']+=' · '+item['status_detail']
    return {'items':sorted(items,key=lambda x:x['at'],reverse=True)[:limit],'scopeNote':'只显示当前已监测并核验身份的会话；未开启全量记录时不代表全部微信。'}

if __name__=='__main__':
    import sys
    value=json.load(sys.stdin);print(json.dumps(read(value.get('start',0),value.get('limit',50)),ensure_ascii=False))
