"""Evidence-backed task state changes; no cross-person or cross-chat guessing."""
import datetime as dt
import re
import information_core as core

OBJECTS=re.compile(r'合同|报告|作业|发票|资料|申请表|报名表|照片|证件|简历|会议|活动|报名|电子版|纸质版|面试|考试|快递|论文|表格|准考证|门票|火车票|车票|机票|海报|攻略')
CANCEL=core.CANCELLED_ACTION
DONE=re.compile(r'(?:已经|已)[^，,。；;？?\n]{0,16}?(?:提交|上交|交好|发出|发给|发送|完成|办好|处理好|打印好|扫描好|收到)|(?:提交|发出|发送|完成|办好|处理好|打印好|扫描好)(?:了|啦)|(?:报告|作业|发票|合同|资料)[^，,。；;？?\n]{0,12}?(?:交了|发了|收到了)')
MOVE=re.compile(r'改(?:到|为|成|期)|推迟(?:到)?|延期(?:到)?|提前到|延后(?:到)?')
CONTEXT=re.compile(r'(?:完成|提交).{0,4}(?:一半|一部分|部分)|假设|举例|例如|比如|示例|教学例句|如果.{0,20}(?:取消|完成|改期)|(?:没|未|尚未|没有).{0,8}(?:完成|提交|收到|取消)')

def _stamp(item):
    stamp=item.get('sourceTs')
    if type(stamp) in (int,float) and 0<stamp<10**11:return stamp
    try:return dt.datetime.fromisoformat(item['when']).timestamp()
    except (KeyError,ValueError,TypeError):return 0

def _matches(item,quote):
    task=item.get('task','');first=set(OBJECTS.findall(task));second=set(OBJECTS.findall(quote))
    # Explicitly another object is not this task, even if it shares its noun.
    if re.search(r'另一个|另一份|另(?:一项|外一份)|别的|其他|其它',quote):return False
    if core.task_object_disagreement(task,quote):return False
    if first and second and not first&second:return False
    if first&second:
        if core.task_object_disagreement(task,quote):return False
        required,actual=core._action_keys(task),core._action_keys(quote)
        if required and actual and not required&actual:return False
        # Object/action qualifiers distinguish paper vs electronic versions.
        for pair in [('纸质版','电子版'),('打印','发送'),('报告','发票')]:
            if pair[0] in task and pair[1] in quote and pair[0] not in quote:return False
            if pair[1] in task and pair[0] in quote and pair[1] not in quote:return False
        return True
    # Equal actions do not establish object identity (two things can be printed).
    # With no named common object, only an explicit back-reference is eligible;
    # the caller still refuses multiple matching tasks.
    return bool(re.search(r'这(?:个|项|件)|那(?:个|项|件)|刚才|之前|上面|不用了|算了',quote))

def update(items,rows,diagnostics=None):
    result=[dict(x) for x in items]
    for row in sorted(rows,key=lambda r:(r['ts'],r['id'])):
        if row.get('identity_state')!='verified' or row.get('sender_role') not in ('self','other'):continue
        for quote in core.request_parts(row.get('content','')):
            if CONTEXT.search(quote):continue
            operation='cancelled' if CANCEL.search(quote) else 'rescheduled' if MOVE.search(quote) else 'done' if DONE.search(quote) else ''
            if not operation:continue
            marker={'cancelled':CANCEL,'rescheduled':MOVE,'done':DONE}[operation].search(quote)
            before=quote[max(0,marker.start()-12):marker.start()]
            after=re.split(r'[，,。；;\n]',quote[marker.end():],maxsplit=1)[0]
            if re.search(r'不是|并非|可能|也许|应该|似乎|好像',before+marker.group()) or re.search(r'吗|么|是否|是不是|了没|[？?]',after):
                if diagnostics is not None:diagnostics.append({'field':'task-state','messageId':row['id'],'reason':'后续状态处于提问、否定或推测语境，未改成完成/取消','outcome':'pending-review'})
                continue
            eligible=[x for x in result if x.get('sourceId')==row['chat_id'] and _stamp(x)<row['ts'] and
                      (row['sender_role']=='self' or x.get('senderId')==row.get('sender_id')) and
                      not any(h.get('messageId')==row['id'] and h.get('quote')==quote for h in x.get('lifecycleHistory',[])) and _matches(x,quote)]
            if len(eligible)>1:
                # Specific action disambiguates e.g. print vs submit in one request.
                keys=core._action_keys(quote)
                exact=[x for x in eligible if keys and keys&core._action_keys(x.get('task',''))]
                if len(exact)==1:eligible=exact
            all_named=bool(re.search(r'全部|都(?:取消|不用|完成)|两(?:项|个).{0,8}(?:取消|完成)',quote))
            whole_task=bool(re.search(r'(?:这个|那个|这项|那项|整个|整项)任务\s*(?:已经|已)?(?:取消|作废|撤销|完成)',quote))
            if len(eligible)!=1 and not all_named:
                if eligible and diagnostics is not None:diagnostics.append({'field':'task-state','messageId':row['id'],'reason':'后续消息涉及多个任务，保留原待办待核对','outcome':'pending-review'})
                continue
            for item in eligible:
                required,actual=core._action_keys(item.get('task','')),core._action_keys(quote)
                if operation in ('done','cancelled') and len(required)>1 and actual and not required<=actual and not all_named and not whole_task:
                    if diagnostics is not None:diagnostics.append({'field':'task-state','messageId':row['id'],'reason':'后续仅涉及组合任务的一部分，完整任务保留待核对','outcome':'pending-review'})
                    continue
                state=item.get('lifecycleStatus','pending')
                if state in ('cancelled','done') and operation=='rescheduled':continue
                history=list(item.get('lifecycleHistory',[]));entry={'messageId':row['id'],'when':dt.datetime.fromtimestamp(row['ts']).isoformat(timespec='minutes'),'speaker':row['sender_role'],'senderId':row['sender_id'],'quote':quote,'operation':operation}
                if operation=='rescheduled':
                    due,evidence,precision=core.request_time(quote,row['ts'])
                    if precision=='待核对' and due.startswith('多个'):
                        if diagnostics is not None:diagnostics.append({'field':'task-state','messageId':row['id'],'reason':'改期仍有多个新时间，旧截止保留待核对','outcome':'pending-review'})
                        continue
                    if not evidence:
                        if diagnostics is not None:diagnostics.append({'field':'task-state','messageId':row['id'],'reason':'提及改期但没有可核对的新时间，旧截止保留','outcome':'pending-review'})
                        continue
                    # Explicit "改到" determines deadline relationship without adding a time.
                    if precision=='待核对' and MOVE.search(quote):due=evidence;precision='后续改期原话可核对'
                    entry.update(previousDue=item.get('due',''),newDue=due)
                    item.update(due=due,dueEvidence=evidence,duePrecision=precision,dueSourceMessageId=row['id'],lifecycleStatus=operation)
                    item.update(core.deadline_calendar(evidence,row['ts'],due,precision))
                else:item['lifecycleStatus']=operation
                history.append(entry);item['lifecycleHistory']=history;item['updatedWhen']=entry['when']
    return result

def pending(items,actions=None):
    actions=actions or {}
    return [x for x in items if x.get('lifecycleStatus','pending') not in ('cancelled','done') and actions.get(x['id'],{}).get('status') not in ('done','ignored')]
