"""Explicit QR login feasibility probe, never a message or contact transport.

Original implementation of the public normal Web WeChat login flow. No patch
headers, desktop session extraction or third-party service. Only transient
login-status GET failures are retried, at most three times per challenge.
Challenge data is encrypted per Windows user; account tickets remain in memory.
"""
import datetime,hashlib,hmac,http.cookiejar,io,json,os,re,socket,ssl,sys,time,urllib.error,urllib.parse,urllib.request,uuid
from contextlib import contextmanager
import xml.etree.ElementTree as ET
from html.parser import HTMLParser
from echo_paths import DATA

HOSTS={'login.wx.qq.com','login.weixin.qq.com','wx.qq.com','wx2.qq.com','wx8.qq.com','web.wechat.com','web2.wechat.com'}
EXPIRY=180
MAX_POLL_RETRIES=3
class ProbeError(Exception):
    def __init__(self,code,message):super().__init__(message);self.code=code
class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None

def network_error(error):
    reason=error.reason if isinstance(error,urllib.error.URLError) else error
    if isinstance(reason,ssl.SSLCertVerificationError):return ProbeError('certificate','微信登录服务器证书校验失败；请检查电脑时间、代理或证书，未关闭证书检查。')
    if isinstance(reason,ssl.SSLError):return ProbeError('tls','微信登录 TLS 连接失败；请检查代理或网络，未降低加密校验。')
    if isinstance(reason,(TimeoutError,socket.timeout)):return ProbeError('timeout','微信登录状态查询超时。')
    if isinstance(reason,socket.gaierror):return ProbeError('dns','无法解析微信登录服务器地址；请检查网络或 DNS。')
    return ProbeError('network','无法连接微信登录服务器；请检查网络或代理。')

@contextmanager
def challenge_lock(folder):
    """Short cross-process lock, shared with the native Stop action.

    No network runs under this lock. Byte-range locking matches FileStream.Lock
    in the Windows UI; replacement, cancellation and poll updates are serialized.
    """
    folder.mkdir(parents=True,exist_ok=True)
    with (folder/'challenge.lock').open('a+b') as stream:
        stream.seek(0,2)
        if not stream.tell():stream.write(b'\0');stream.flush()
        deadline=time.monotonic()+2
        while True:
            try:
                stream.seek(0)
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(stream.fileno(),msvcrt.LK_NBLCK,1)
                else:
                    import fcntl
                    fcntl.lockf(stream,fcntl.LOCK_EX|fcntl.LOCK_NB,1)
                break
            except OSError:
                if time.monotonic()>=deadline:raise ProbeError('busy','扫码状态正在更新，请稍后再试。') from None
                time.sleep(.02)
        try:yield
        finally:
            stream.seek(0)
            if os.name=='nt':msvcrt.locking(stream.fileno(),msvcrt.LK_UNLCK,1)
            else:fcntl.lockf(stream,fcntl.LOCK_UN,1)

def url_allowed(url):
    try:p=urllib.parse.urlsplit(url);port=p.port
    except (TypeError,ValueError):return False
    if not isinstance(url,str) or any(ord(c)<33 or ord(c)>126 for c in url):return False
    if p.scheme!='https' or p.hostname not in HOSTS or port not in (None,443) or p.username is not None or p.password is not None or p.fragment:return False
    if p.hostname=='login.wx.qq.com':return p.path in ('/jslogin','/cgi-bin/mmwebwx-bin/login')
    if p.hostname=='login.weixin.qq.com':return bool(re.fullmatch(r'/qrcode/[A-Za-z0-9_-]{8,64}={0,2}',p.path))
    return p.path in ('/cgi-bin/mmwebwx-bin/webwxnewloginpage','/cgi-bin/mmwebwx-bin/webwxlogout')

class Http:
    def __init__(self):self.opener=urllib.request.build_opener(NoRedirect(),urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
    def __call__(self,url):
        if not url_allowed(url):raise ProbeError('address','微信登录响应包含未核对的服务器或路径，已停止。')
        host=urllib.parse.urlsplit(url).hostname
        request=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36',
            'Accept':'application/json, text/plain, */*','Referer':'https://'+host+'/'})
        try:
            with self.opener.open(request,timeout=30) as response:
                body=response.read(524289)
                if len(body)>524288:raise ProbeError('response','微信登录响应过大，已停止。')
                self.last_response={'status':getattr(response,'status',None),'contentType':getattr(response,'headers',{}).get('Content-Type',''),'bytes':len(body)}
                return body
        except urllib.error.HTTPError as error:
            code=error.code;error.close()
            raise ProbeError('http','微信登录服务器返回 HTTP '+str(code)+'；未自动重试。') from None
        except (OSError,urllib.error.URLError) as error:raise network_error(error) from None

def parse_uuid(body):
    try:text=body.decode('utf-8')
    except UnicodeError:raise ProbeError('response','微信登录响应编码无效。') from None
    codes=re.findall(r'window\.QRLogin\.code\s*=\s*(\d+)\s*;',text)
    ids=re.findall(r'window\.QRLogin\.uuid\s*=\s*"([A-Za-z0-9_-]{8,64}={0,2})"\s*;',text)
    if codes!=['200'] or len(ids)!=1:raise ProbeError('response','微信没有返回唯一、有效的二维码标识。')
    return ids[0]

def parse_status(body):
    try:text=body.decode('utf-8')
    except UnicodeError:raise ProbeError('response','微信扫码响应编码无效。') from None
    codes=re.findall(r'window\.code\s*=\s*(\d+)\s*;',text)
    if len(codes)!=1 or codes[0] not in ('200','201','202','400','408','500','0'):raise ProbeError('response','微信返回未知或矛盾的扫码状态，未认定登录成功。')
    if codes[0]!='200':return codes[0],None
    urls=re.findall(r'window\.redirect_uri\s*=\s*"([^"\r\n]+)"\s*;',text)
    if len(urls)!=1 or not url_allowed(urls[0]) or urllib.parse.urlsplit(urls[0]).path!='/cgi-bin/mmwebwx-bin/webwxnewloginpage':raise ProbeError('address','微信登录确认地址未通过核验。')
    return '200',urls[0]

def credential_url(redirect):
    """Normal current Tencent web login query, verified from its public JS.

    Preserve opaque ticket bytes; never decode/re-encode the ticket query or
    accept a foreign origin. This selects XML credentials, not a browser page.
    """
    if not url_allowed(redirect) or urllib.parse.urlsplit(redirect).path!='/cgi-bin/mmwebwx-bin/webwxnewloginpage':
        raise ProbeError('address','扫码认证地址未通过微信服务器核验。')
    values=urllib.parse.parse_qs(urllib.parse.urlsplit(redirect).query,keep_blank_values=True)
    extra=[]
    for key,expected in (('fun','new'),('version','v2')):
        if key in values:
            if values[key]!=[expected]:raise ProbeError('address','扫码认证参数重复或不符合正常登录协议。')
        else:extra.append(key+'='+expected)
    return redirect+('' if not extra else ('&' if urllib.parse.urlsplit(redirect).query else '?')+'&'.join(extra))

WEB_LOGIN_MESSAGE='微信服务器提示：暂不支持使用网页版微信。扫码已确认，但当前网页通道无法代管此账号；未启动后台回复。重复扫码不能解除这个限制，需要其他可用的后台接入通道。'

class _LoginVisibleText(HTMLParser):
    def __init__(self):super().__init__(convert_charrefs=True);self.hidden=0;self.parts=[]
    def handle_starttag(self,tag,attrs):
        if tag in ('script','style'):self.hidden+=1
    def handle_endtag(self,tag):
        if tag in ('script','style'):self.hidden=max(0,self.hidden-1)
    def handle_data(self,text):
        if not self.hidden:self.parts.append(text)

def decode_login_page(body,content_type=''):
    """Preserve bytes separately; use only bounded, supported page encodings."""
    if not isinstance(body,bytes) or len(body)>524288:raise ProbeError('response','登录网页响应大小或类型无效。')
    match=re.search(r'charset\s*=\s*[\"\']?([a-zA-Z0-9_-]+)',str(content_type)[:200],re.I)
    charset=match.group(1).lower().replace('_','-') if match else ''
    aliases={'utf8':'utf-8','utf-8':'utf-8','gbk':'gb18030','gb2312':'gb18030','gb18030':'gb18030'}
    encodings=list(dict.fromkeys(([aliases[charset]] if charset in aliases else [])+['utf-8','gb18030']))
    for encoding in encodings:
        try:return body.decode(encoding),encoding
        except UnicodeError:pass
    return body.decode('utf-8',errors='replace'),'utf-8-replacement'

def login_page_restriction(text,*,legacy_utf8_replacement=False):
    if not isinstance(text,str) or len(text)>524288:return False
    parser=_LoginVisibleText();parser.feed(text)
    visible=re.sub(r'\s+','',''.join(parser.parts))
    if '暂不支持使用网页版微信' in visible:return True
    if legacy_utf8_replacement:
        # Version 35 discarded raw GBK bytes. Only match the entire fixed
        # clause plus a safety preamble; generic garbled HTML is not evidence.
        clause='，暂不支持使用网页版微信。'.encode('gbk').decode('utf-8',errors='replace')
        preambles=('为了保护你的账号安全','为了保障你的账号安全','为了保障你的帐号安全')
        return clause in visible and any(x.encode('gbk').decode('utf-8',errors='replace') in visible for x in preambles)
    return False

def parse_login(body,content_type=''):
    if not isinstance(body,bytes):raise ProbeError('response','登录凭据响应类型无效。')
    header=body[:4096].lstrip(b'\xef\xbb\xbf \r\n\t').lower()
    if header.startswith(b'<!doctype html') or header.startswith(b'<html'):
        text,_=decode_login_page(body,content_type)
        if login_page_restriction(text):raise ProbeError('web_login_unavailable',WEB_LOGIN_MESSAGE)
        raise ProbeError('login_html','微信返回了登录网页，尚未返回账号凭据；扫码认证没有完成，未开启代管。')
    if len(body)>65536 or b'<!DOCTYPE' in body.upper() or b'<!ENTITY' in body.upper():raise ProbeError('response','登录凭据响应格式无效。')
    try:root=ET.fromstring(body)
    except (ET.ParseError,ValueError):raise ProbeError('response','登录凭据不是有效XML。') from None
    if root.tag!='error':raise ProbeError('response','登录凭据缺少明确状态。')
    values={}
    for item in root:
        if item.tag in values or len(item):raise ProbeError('response','登录凭据含重复或嵌套字段。')
        values[item.tag]=item.text or ''
    if not re.fullmatch(r'-?\d{1,8}',values.get('ret','')):raise ProbeError('response','登录凭据状态码无效。')
    if values['ret']!='0':return values['ret'],None
    if not re.fullmatch(r'[1-9]\d{0,19}',values.get('wxuin','')) or any(not values.get(k) for k in ('wxsid','skey','pass_ticket')):raise ProbeError('response','登录响应缺少完整身份凭据，未认定登录成功。')
    return '0',values

def seal(data):
    import win32crypt
    return win32crypt.CryptProtectData(json.dumps(data).encode(),None,None,None,None,0)
def unseal(data):
    import win32crypt
    return json.loads(win32crypt.CryptUnprotectData(data,None,None,None,0)[1].decode())

class Probe:
    def __init__(self,folder=None,transport=None,clock=time.time,encrypt=seal,decrypt=unseal):
        self.folder=folder or DATA/'直接协议验证';self.http=transport or Http();self.clock=clock;self.encrypt=encrypt;self.decrypt=decrypt
        self.path=self.folder/'challenge.bin';self.qr=self.folder/'二维码.jpg'
    def write(self,value):
        with challenge_lock(self.folder):self._write(value)
    def _write(self,value):
        self.folder.mkdir(parents=True,exist_ok=True)
        temp=self.path.with_name(self.path.name+'.'+uuid.uuid4().hex+'.tmp')
        try:temp.write_bytes(self.encrypt(value));os.replace(temp,self.path)
        finally:
            if temp.exists():temp.unlink()
    def read(self,identity):
        with challenge_lock(self.folder):return self._read(identity)
    def _read(self,identity):
        if not isinstance(identity,str) or not re.fullmatch(r'[0-9a-f]{32}',identity):raise ProbeError('challenge','请选择当前二维码，不能沿用旧二维码。')
        try:
            if self.path.stat().st_size>8192:raise ValueError()
            value=self.decrypt(self.path.read_bytes())
            if not isinstance(value,dict) or not isinstance(value.get('id'),str) or not hmac.compare_digest(value['id'],identity):raise ValueError()
            if value.get('state')!='waiting' or type(value.get('created')) not in (int,float) or not -5<=self.clock()-value['created']<EXPIRY:raise ValueError()
            if not re.fullmatch(r'[A-Za-z0-9_-]{8,64}={0,2}',value.get('uuid','')):raise ValueError()
            return value
        except Exception:raise ProbeError('challenge','二维码已结束、过期或无法由当前Windows用户解密，请重新获取。') from None
    def create(self):
        query=urllib.parse.urlencode({'appid':'wx782c26e4c19acffb','redirect_uri':'https://wx.qq.com/cgi-bin/mmwebwx-bin/webwxnewloginpage','fun':'new','lang':'zh_CN','_':str(int(self.clock()*1000))})
        identity=parse_uuid(self.http('https://login.wx.qq.com/jslogin?'+query))
        image=self.http('https://login.weixin.qq.com/qrcode/'+identity)
        if not image.startswith(b'\xff\xd8\xff') or not image.endswith(b'\xff\xd9'):raise ProbeError('response','微信二维码没有通过JPEG格式核对。')
        from PIL import Image
        try:
            with Image.open(io.BytesIO(image)) as decoded:
                if not 100<=decoded.width<=2048 or not 100<=decoded.height<=2048:raise ValueError()
                decoded.verify()
        except Exception:raise ProbeError('response','微信二维码无法安全解码。') from None
        value={'id':uuid.uuid4().hex,'uuid':identity,'created':self.clock(),'state':'waiting'}
        with challenge_lock(self.folder):
            self.qr.write_bytes(image);self._write(value)
        return {'status':'waiting','challengeId':value['id'],'imagePath':str(self.qr),'expiresSeconds':EXPIRY,'message':'请用测试号扫码并在手机确认。这是登录资格验证，未启动代管。'}
    def cancel(self,identity):
        self.update(identity,state='cancelled')
        return {'status':'cancelled','message':'本次扫码验证已停止，未读取聊天或发送消息。'}
    def update(self,identity,**changes):
        with challenge_lock(self.folder):
            value=self._read(identity);value.update(changes);self._write(value)
            return value
    def retry(self,identity,error):
        with challenge_lock(self.folder):
            value=self._read(identity)
            previous=value.get('pollFailures',0)
            if type(previous) is not int or not 0<=previous<=MAX_POLL_RETRIES:raise ProbeError('challenge','扫码重试状态无效，请重新获取二维码。')
            count=previous+1;value['pollFailures']=count
            if count>MAX_POLL_RETRIES:
                value['state']='failed';self._write(value)
                raise ProbeError(error.code,str(error)+' 已连续失败，停止自动重试；请检查网络后重新获取二维码。') from None
            self._write(value)
            remaining=max(0,int(EXPIRY-(self.clock()-value['created'])))
            return {'status':'retrying','errorCode':error.code,'retryCount':count,'retryAfterSeconds':min(2**count,8),'expiresSeconds':remaining,'message':str(error)+' 二维码仍保留；将进行第 '+str(count)+'/'+str(MAX_POLL_RETRIES)+' 次重试，剩余约 '+str(remaining)+' 秒。'}
    def logout(self,redirect,tickets):
        logout='https://'+urllib.parse.urlsplit(redirect).hostname+'/cgi-bin/mmwebwx-bin/webwxlogout?'+urllib.parse.urlencode({'redirect':'1','type':'1','skey':tickets['skey']})
        try:self.http(logout);return '已请求结束测试会话，请在手机核对。'
        except Exception:return '测试会话退出未确认，请在手机结束此次网页登录。'
    def poll(self,identity):
        value=self.read(identity)
        query=urllib.parse.urlencode({'uuid':value['uuid'],'tip':'0','loginicon':'false','_':str(int(self.clock()))})
        try:body=self.http('https://login.wx.qq.com/cgi-bin/mmwebwx-bin/login?'+query)
        except ProbeError as error:
            if error.code in ('timeout','dns','network'):return self.retry(identity,error)
            raise
        code,redirect=parse_status(body)
        # Recheck after the long poll: no old result may consume a new challenge.
        self.update(identity,pollFailures=0)
        if code=='408':return {'status':'waiting','message':'等待扫码；二维码可达尚不表示账号可登录。'}
        if code=='201':return {'status':'scanned','message':'已扫码，请在手机确认登录。'}
        if code=='202':self.update(identity,state='cancelled');return {'status':'phone_cancelled','message':'手机已取消这次登录，请重新获取二维码。'}
        if code in ('0','500'):self.update(identity,state='finished');return {'status':'login_server_error','errorCode':'login_server','message':'微信登录服务未完成这次请求，请重新获取二维码；未认定账号已连接。'}
        if code=='400':self.update(identity,state='expired');return {'status':'expired','message':'二维码已过期，请重新获取。'}
        ret,tickets=parse_login(self.http(credential_url(redirect)))
        try:self.update(identity,state='finished')
        except Exception:
            # Confirmation may have allocated a server session while Stop or
            # expiry won the local race. Still request logout using only the
            # in-memory tickets; never revive the challenge or initialize chat.
            if tickets is not None:self.logout(redirect,tickets)
            raise
        if tickets is None:return {'status':'account_rejected','loginCode':ret,'message':'微信不允许此账号使用直接协议登录（状态 '+ret+'）。此路线尚不可用于该账号。'}
        # Do not init the account, fetch contacts, sync chats or save its tickets.
        cleanup=self.logout(redirect,tickets)
        return {'status':'account_authorized','accountLoginConfirmed':True,'message':'微信已允许此测试号获取登录凭据；未读取联系人或聊天，未发送消息。'+cleanup+'后台收发仍需下一步验收。','probeLogoutConfirmed':False}

def dispatch(value,probe=None):
    if not isinstance(value,dict):raise ProbeError('configuration','扫码验证参数无效。')
    probe=probe or Probe();action=value.get('action')
    if action=='create':return probe.create()
    if action=='poll':return probe.poll(value.get('challengeId'))
    if action=='cancel':return probe.cancel(value.get('challengeId'))
    raise ProbeError('configuration','扫码验证操作未识别。')

def publish_audit(probe,result,identity):
    """Publish only a matching current challenge, without tickets or QR paths."""
    if not isinstance(identity,str) or not re.fullmatch(r'[0-9a-f]{32}',identity):return False
    states={'waiting':{'waiting','scanned','retrying','error'},'cancelled':{'cancelled'},
            'expired':{'expired'},'finished':{'account_authorized','account_rejected'},'failed':{'error'}}
    # Compare and replace under the same cross-process lock; no network here.
    with challenge_lock(probe.folder):
        try:
            if probe.path.stat().st_size>8192:return False
            current=probe.decrypt(probe.path.read_bytes())
            if not isinstance(current,dict) or current.get('id')!=identity or result.get('status') not in states.get(current.get('state'),set()):return False
        except Exception:return False
        audit={k:v for k,v in result.items() if k not in ('imagePath','challengeId')}
        audit.update(challengeDigest=hashlib.sha256(identity.encode()).hexdigest(),checkedAt=datetime.datetime.now().astimezone().isoformat())
        target=probe.folder/'结果.json';temp=target.with_name('result.'+uuid.uuid4().hex+'.tmp')
        try:
            temp.write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temp,target)
        finally:
            if temp.exists():temp.unlink()
    return True

def main():
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    value={};probe=Probe()
    try:
        value=json.loads(sys.stdin.readline(16385));result=dispatch(value,probe)
    except ProbeError as error:result={'status':'error','errorCode':error.code,'message':str(error)}
    except Exception:result={'status':'error','errorCode':'local','message':'本机扫码验证组件发生异常，登录状态未确认；未读取聊天或发送消息。'}
    result.update(messageReads=0,messageSends=0,contactReads=0,modelRequests=0,desktopActions=0)
    try:
        identity=result.get('challengeId') or (value.get('challengeId') if isinstance(value,dict) else None)
        publish_audit(probe,result,identity)
    except (OSError,ProbeError):pass
    print(json.dumps(result,ensure_ascii=False))
if __name__=='__main__':main()
