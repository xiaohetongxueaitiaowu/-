"""Hold one Windows cache mutex until every reader connection is closed.

The SDK atomically replaces decoded snapshots. A lock around just rebuilding
does not protect another process's open SQLite handle from that replacement.
The mutex is recursive on the owning thread and abandoned safely on exit.
"""
import hashlib,os,threading
from pathlib import Path

class CacheBusy(OSError):
    pass

class CacheLease:
    def __init__(self,workdir,timeout=15):
        import win32event,win32api
        self.event=win32event;self.api=win32api;self.owner=threading.get_ident()
        key=hashlib.sha256(os.path.normcase(str(Path(workdir).resolve())).encode()).hexdigest()
        self.handle=win32event.CreateMutex(None,False,'Local\\EchoWechatCache_'+key)
        result=win32event.WaitForSingleObject(self.handle,int(timeout*1000))
        if result not in (0,0x80):
            win32api.CloseHandle(self.handle);self.handle=None
            raise CacheBusy('微信记录缓存正在被另一项任务使用，请稍后重试')
    def close(self):
        if self.handle is not None:
            handle=self.handle;self.handle=None
            try:self.event.ReleaseMutex(handle)
            finally:self.api.CloseHandle(handle)

class LeasedConnection:
    def __init__(self,connection,lease):self.connection=connection;self.lease=lease
    def __getattr__(self,name):return getattr(self.connection,name)
    def close(self):
        if self.connection is not None:
            connection=self.connection;self.connection=None
            try:connection.close()
            finally:self.lease.close()
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
    def __del__(self):
        try:self.close()
        except Exception:pass

def open_locked(db,opener,rel):
    if os.name!='nt':return opener(rel)
    lease=CacheLease(db.workdir)
    try:return LeasedConnection(opener(rel),lease)
    except BaseException:
        lease.close();raise
